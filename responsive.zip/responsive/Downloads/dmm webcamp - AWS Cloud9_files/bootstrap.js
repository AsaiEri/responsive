!function(){
var MODULE_LOAD_URL="/static/build/modules",IN_WORKER="function"==typeof importScripts,requireSourceUrl="undefined"!=typeof document&&document.currentScript&&document.currentScript.src
;/mini_require\.js$/.test(requireSourceUrl)||(requireSourceUrl="")
var host=location.protocol+"//"+location.hostname+(location.port?":"+location.port:""),global=function(){
return this}()
global||"undefined"==typeof window||(global=window),global||"undefined"==typeof self||(global=self)
var commentRegExp=/(\/\*([\s\S]*?)\*\/|([^:]|^)\/\/(.*)$)/gm,cjsRequireRegExp=/\brequire\s*\(\s*["']([^'"\s]+)["']\s*\)/g
function getInlineDeps(fn){var deps=[]
return fn.length&&(fn.toString().replace(commentRegExp,"").replace(cjsRequireRegExp,(function(match,dep,index,str){
for(var i=index;str.charCodeAt(i-=1)<=32;);"."!==str.charAt(i)&&deps.push(dep)})),
deps=["require","exports","module"].concat(deps)),deps}function define(name,deps,callback){
if("string"!=typeof name&&(callback=deps,
deps=name,name=null),deps&&!Array.isArray(deps)&&(callback=deps,
deps=null),nextModule&&(name&&name!=nextModule.name||(name=nextModule.name,
deps=deps||nextModule.deps,nextModule=null)),!name)return defQueue.push([deps,callback])
define.loaded[name]||(deps||"function"!=typeof callback||(deps=getInlineDeps(callback)),
define.loaded[name]={id:name,deps:resolveNames(name,deps||[]),factory:callback,exports:{}},
define.loading[name]&&delete define.loading[name],
define.lastModule?define.pending.push(name):define.lastModule=name)}
var nextModule,defQueue=[],addToLoadQueue=function(missing,deps,callback,errback){
var toLoad=missing.length,map={}
define.queue.push({deps:deps,map:map,toLoad:toLoad,callback:callback,errback:errback})
for(var i=0;i<missing.length;++i){var p=missing[i]
map[p]=1,define.loading[p]||(define.loading[p]=1,require.load(p))}
},processLoadQueue=function(err,id){var changed=!1
if(err){for(var i in id||(id=err.id),define.errors[id]=err,err.from=[],define.loaded){
-1!=define.loaded[i].deps.indexOf(id)&&err.from.push(define.loaded[i].id)}
console.error("Error loading "+id+" required from "+err.from.slice(0,2)),
define.queue.forEach((function(r){r.map[id]&&(r.toLoad=-1,r.errback&&r.errback(err))})),
define.lastModule==id&&(define.lastModule=null),define.pending=define.pending.filter((function(p){
return p!=id})),changed=!0
}else!id||defQueue.length||define.loaded[id]||(defQueue=[config.shim&&config.shim[id]||[[],null]])
defQueue.length&&(defQueue.length>1&&(console.error("possible error, more than one module in defqueue",defQueue),
defQueue=defQueue.slice(-1)),define(id,defQueue[0][0],defQueue[0][1]),defQueue.length=0)
var pending=define.pending
define.queue.forEach((function(request){pending.forEach((function(id){
request.map[id]&&request.toLoad--})),request.map[define.lastModule]&&request.toLoad--,
request.toLoad<=0&&(request.toLoad=NaN,
changed=!0,_require("",request.deps,request.callback,request.errback))})),define.lastModule=null,
pending.length&&(define.pending=[]),changed&&(define.queue=define.queue.filter((function(r){
return r.toLoad>0})))}
define.amd={},define.queue=[],define.loaded={},define.errors={},define.loading={},define.pending=[],
define.modules={require:1,exports:1,module:1},define.fetchedUrls={}
var activateModule=function(name){var module=define.loaded[name]
module.getModuleDefinition&&(module=module.getModuleDefinition(module))
var exports=module.exports
if("function"!=typeof module.factory)exports=module.factory
else{var req=function(path,callback){return _require(name,path,callback)}
req.config=config
var missing=checkMissing(module.deps)
if(missing.length)return missing
module.define=define
var specialModules={require:req,exports:exports,module:module}
0!=name.lastIndexOf("architect!",0)||module.pluginFactory||(module.pluginFactory=module.factory,
module.factory=activateArchitectModule),define.modules[name]=exports
var args=module.deps.slice(0,module.factory.length),returnValue=args.length?module.factory.apply(module,args.map((function(name){
return specialModules[name]||lookup(name)}))):module.factory(req,exports,module)
exports=null==returnValue?module.exports:returnValue}
config.$keepLoaders||delete define.loaded[name],define.modules[name]=exports
},checkMissing=function(deps,seen,missing){missing=missing||{},seen=seen||{}
for(var i=0;i<deps.length;++i){var depName=deps[i]
if(!define.modules[depName]){var dep=define.loaded[depName]
dep?missing[depName]||seen[depName]||(seen[depName]=1,checkMissing(dep.deps,seen,missing)):missing[depName]=1
}}return Object.keys(missing)},lookup=function(moduleName){var mod=define.modules[moduleName]
return void 0===mod&&define.loaded[moduleName]&&(activateModule(moduleName),mod=define.modules[moduleName]),
mod}
function asyncRequire(parentId,moduleName,callback,errback){
var result,deps=resolveNames(parentId,moduleName),missing=checkMissing(deps)
if(callback||errback||"function"!=typeof Promise||(result=new Promise((function(resolve,reject){
callback=function(){resolve([].slice.call(arguments))},errback=reject
}))),missing.length)addToLoadQueue(missing,deps,callback,errback)
else{var args=deps.map(lookup)
result&&(result.resolved=args),callback&&callback.apply(null,args)}return result}
var _require=function(parentId,moduleName,callback,errback){if("string"==typeof moduleName){
var depName=resolveName(parentId,moduleName),module=lookup(depName)
if(void 0!==module)return"function"==typeof callback&&callback(module),module
if(IN_WORKER||syncLoaders.test(moduleName))return addToLoadQueue([depName],[depName]),
lookup(depName)
}else if(Array.isArray(moduleName))return asyncRequire(parentId,moduleName,callback,errback)}
function resolveName(parentId,moduleName,isPluginPath){
/!/.test(parentId)&&(parentId=parentId.split("!").pop())
var i=moduleName.indexOf("!")
if(-1!==i)return resolveName(parentId,moduleName.slice(0,i),!0)+"!"+resolveName(parentId,moduleName.slice(i+1))
if("."==moduleName.charAt(0)){
var parentChunks=parentId.split("/"),parentModule=parentChunks.shift(),path=parentChunks.slice(0,-1).join("/")
for(moduleName=parentModule+(path?"/"+path:"")+"/"+moduleName;-1!==moduleName.indexOf(".")&&previous!=moduleName;){
var previous=moduleName
moduleName=moduleName.replace(/\/\.\//,"/").replace(/[^\/]+\/\.\.\//,"")}}
return!isPluginPath&&config.alias[moduleName]&&(moduleName=config.alias[moduleName]),moduleName}
function resolveNames(parentId,moduleNames){return moduleNames.map((function(name){
return resolveName(parentId,name)}))}var require=function(module,callback,errback){
return _require("",module,callback,errback)},config=require.config=function(options){
if(options.baseUrl&&(config.baseUrl=options.baseUrl.replace(/\/*$/,"/")),
options.host&&(host=options.host),options.alias&&Object.keys(options.alias).forEach((function(p){
config.alias[p]=options.alias[p]})),options.paths&&Object.keys(options.paths).forEach((function(p){
config.paths[p]=options.paths[p]
})),"useDevBundle"in options&&(config.useDevBundle=options.useDevBundle),
options.transform&&(config.transform=options.transform),
/\bes5\b/.test(options.transform)&&!global.shimIncluded){
console.assert||(console.assert=function(){})
var oldFlags=RegExp.prototype.flags
RegExp.prototype.flags=!0,require(["js-polyfills/es6"]),RegExp.prototype.flags=oldFlags,
global.shimIncluded=!0}options.MODULE_LOAD_URL&&(require.MODULE_LOAD_URL=options.MODULE_LOAD_URL),
options.assetUrl&&(config.assetUrl=options.assetUrl),
null!=options.$keepLoaders&&(config.$keepLoaders=options.$keepLoaders)}
function undefOne(module,path){delete define.errors[module],delete define.loaded[module],
delete define.modules[module],delete define.loading[module],delete define.fetchedUrls[path]}
function undefAll(module,hash){Object.keys(hash).forEach((function(key){var i=key.indexOf("!")+1
if(0==key.lastIndexOf(module,0)&&undefOne(key,require.toUrl(key,".js")),i){
var plugin=key.slice(0,i-1),resource=key.slice(i)
0!=resource.lastIndexOf(module,0)&&0!=plugin.lastIndexOf(module,0)||(undefOne(key,require.toUrl(key,"")),
undefOne(resource,require.toUrl(resource,"")))}}))}function addTransform(url,moduleName){
var transform=require.config.transform
return Array.isArray(transform)||(transform=[transform]),("~/"+transform.map((function(part){
return"string"==typeof part?part:"object"==typeof part&&part.except&&-1===moduleName.lastIndexOf(part.except,0)?part.transform:-1!=moduleName.lastIndexOf(part[0],0)?part[1]:void 0
})).filter(Boolean).join(",")+"/"+url).replace("//","/")}require.resetConfig=function(cfg){
config.alias=Object.create(null),config.paths=Object.create(null),config.baseUrl="",
config.transform="",cfg&&require.config(cfg)},require.getConfig=function(){return{host:host,
paths:config.paths,baseUrl:config.baseUrl,alias:config.alias,transform:config.transform,
useDevBundle:config.useDevBundle,MODULE_LOAD_URL:require.MODULE_LOAD_URL,
requireSourceUrl:!config.packed&&requireSourceUrl,assetUrl:config.assetUrl}},require.resetConfig(),
define.undef=require.undef=function(module,recursive){if(module=resolveName("",module),recursive){
var root=(module+"/").replace(/\/+$/,"/")
undefAll(root,define.errors),undefAll(root,define.loaded),undefAll(root,define.modules),
undefAll(root,define.loading)}else undefOne(module,require.toUrl(module,".js"))},
require.MODULE_LOAD_URL=MODULE_LOAD_URL,require.toUrl=function(moduleName,ext,skipExt,isStatic){
var absRe=/^([\w\+\.\-]+:|\/)/;-1===moduleName.indexOf("!")&&ext&&!/^\//.test(moduleName)||(ext="")
for(var paths=config.paths,testPath=moduleName,tail="";testPath;){if(paths[testPath]){
moduleName=paths[testPath]+tail
break}var i=testPath.lastIndexOf("/")
if(-1===i)break
tail=testPath.substr(i)+tail,testPath=testPath.slice(0,i)}if(skipExt)return testPath
var url=".js"==ext&&moduleName.slice(-3)==ext?moduleName:moduleName+ext
if(ext&&".ts"==moduleName.slice(-3)&&(url=moduleName.slice(0,-3)+ext),!absRe.test(url)){
".js"==ext&&require.config.transform&&(url=addTransform(url,moduleName))
var baseUrl=config.baseUrl
baseUrl||(baseUrl=isStatic?config.assetUrl||require.MODULE_LOAD_URL+"/../":require.MODULE_LOAD_URL),
"/"!=baseUrl.slice(-1)&&(baseUrl+="/"),url=baseUrl+url}return"/"==url[0]&&(url=host+url),url}
var loadScriptWithTag=function(path,id,callback){if(IN_WORKER)return nextModule={name:id,deps:null},
"/"==path[0]&&(path=host+path),importScripts(path),callback(null,id)
var head=document.head||document.documentElement,s=document.createElement("script")
s.setAttribute("crossorigin","anonymous"),s.src=path,s.charset="utf-8",s.async=!0,
s.onload=s.onreadystatechange=function(_,isAbort){
!isAbort&&s.readyState&&"loaded"!=s.readyState&&"complete"!=s.readyState||(s.remove&&s.remove(),
s=s.onload=s.onreadystatechange=null,isAbort||callback(null,id))},s.onerror=function(e){
processLoadQueue({message:"Error loading script "+id+":"+path,id:id,path:path})},head.appendChild(s)
}
function loadText(path,sync,callback){callback||(callback=sync,sync=!1)
var xhr=new global.XMLHttpRequest
xhr.open("GET",path,!sync),xhr.setRequestHeader("Content-Type","application/x-www-form-urlencoded; charset=UTF-8"),
xhr.onload=function(e){if(xhr.status>399&&xhr.status<600)return callback({message:xhr.statusText,
path:path})
callback(null,xhr.responseText,xhr)},xhr.onabort=xhr.onerror=function(e){callback(e)},xhr.send("")}
var loadScript=function(path,id,callback){var useDevBundle=config.useDevBundle
return"string"==typeof useDevBundle&&(useDevBundle=id.match(useDevBundle)),useDevBundle&&!(path===id)?loadDevBundle(path,id,callback):loadScriptWithTag(path,id,callback)
}
function loadDevBundle(path,id,callback){
loadText(path+="?devBundle=1",IN_WORKER,(function(err,text,xhr){if(err)return callback(err)
parseDevBundle(text)
var continuationToken=xhr.getResponseHeader("x-metadata-length")
if(!continuationToken)return callback(err,id)
loadText(path+"&continue="+continuationToken,IN_WORKER,(function(err,text){
if(err)return callback(err)
parseDevBundle(text,!0),callback(err,id)}))}))}var DEV_BUNDLE_SEPARATOR="\0\0"
function parseDevBundle(text,isDiff){
for(var parts=text.split(DEV_BUNDLE_SEPARATOR),i=1;i<parts.length;i+=2)define.bundlePart(parts[i],parts[i+1],isDiff)
return parts[0]}function prepareBundlePart(part){var id=part.id
define.loaded[id]=null
var source=part._source
nextModule={name:id,deps:[]}
var path=require.MODULE_LOAD_URL+"~/amd/"+id.replace(/^[^/!]+!/,"")+".js"
return"/"==path[0]&&(path=host+path),global.eval(source+"\n//# sourceURL="+path),nextModule=null,
define.loaded[id]}define.bundlePart=function(id,source,reload){reload&&require.undef(id)
var factory=/text!/.test(id)?source:void 0
define.loaded[id]={id:id,deps:[],factory:factory,exports:{},
getModuleDefinition:factory?void 0:prepareBundlePart,_source:source
},define.loading[id]&&delete define.loading[id],define.pending.push(id)},require.load=function(id){
var i=id.indexOf("!")+1
if(i){var plugin=id.substring(0,i),resourceId=id.substr(i)
"function"==typeof require[plugin]?require[plugin](resourceId,processLoadQueue,id):console.error("require plugin "+plugin+"missing")
}else{var url=require.toUrl(id,".js")
define.fetchedUrls[url]|=1,loadScript(url,id,processLoadQueue)}}
var syncLoaders=/^(language!|webworker!|vfs!|asset-url!)/
function activateArchitectModule(_1,_2,_3){var module=this,wrapper=function(){
return module.pluginFactory(_1,_2,_3),
"function"==typeof module.exports&&(module.exports.provides||module.exports.consumes)?module.exports.apply(this,arguments):module.exports
}
return wrapper.packagePath=module.id,wrapper}require["language!"]=function(module,callback,id){
define(id,[],module),callback()},require["webworker!"]=function(module,callback,id){
define(id,[],require.toUrl(module.split("!").pop(),".js")),callback()
},require["asset-url!"]=function(module,callback,id){
define(id,[],require.toUrl(module.split("!").pop(),"","",!0)),callback()
},require["vfs!"]=function(module,callback,id){var url=require.MODULE_LOAD_URL+"/~node/"+module
if(4&define.fetchedUrls[url])return!1
define.fetchedUrls[url]|=4,define(id,[],{srcUrl:url,path:module}),callback()
},require["text!"]=function(module,callback,id){var url=require.toUrl(module)
if(2&define.fetchedUrls[url])return!1
define.fetchedUrls[url]|=2,loadText(url,(function(err,val){if(err)return callback(err,id)
define(id,[],val),callback()}))},require["json!"]=function(module,callback,id){
var textId="text!"+module
require["text!"](module,(function(err){if(err)return callback(err,id)
var val=JSON.parse(require(textId))
define(id,[],val),callback()}),textId)},require["architect-config!"]=function(module,callback,id){
var url=require.toUrl(module,".js").replace("~/","~/config,")
if(1&define.fetchedUrls[url])return!1
define.fetchedUrls[url]|=1,loadScript(url,id,processLoadQueue)
},require["ace/requirejs/text!"]=require["text!"],
require["architect!"]=function(module,callback,id){var url=require.toUrl(module,".js")
if(1&define.fetchedUrls[url])return!1
define.fetchedUrls[url]|=1,loadScript(url,id,processLoadQueue)
},require["vs/css!"]=function(module,callback,id){define(id,[],{}),callback()
},global.define&&global.define.packaged||(define.original=global.define,global.define=define,
global.define.packaged=!0),global.require&&global.require.packaged||(global.require=require,
global.require.packaged=!0),global.requirejs||(global.requirejs=require),global.miniRequire=require
}()


define("@amzn/cloud9-ide-client/bootstrap/configure-requirejs",[],(function(require,exports,module){
!function(){const currentScript=document.currentScript
if(!currentScript)return
const globalRequire=window.requirejs,staticPrefix=currentScript.src.replace("/bootstrap.js","")
globalRequire.MODULE_LOAD_URL=staticPrefix+"/modules",globalRequire.resetConfig({packed:!0,
assetUrl:staticPrefix})}()}))


define("tangerinebox-weblib-bundle/dist/index",[],(function(require,exports,module){
var $build_deps$={require:require,exports:exports,module:module}
function define(name,deps,m){"function"==typeof name&&(m=name,deps=["require","exports","module"],
name=$build_deps$.module.id),"string"!=typeof name&&(m=deps,deps=name,name=$build_deps$.module.id),
m||(m=deps,deps=[])
var ret="function"==typeof m?m.apply($build_deps$.module,deps.map((function(n){
return $build_deps$[n]||require(n)}))):m
null!=ret&&($build_deps$.module.exports=ret),name!=$build_deps$.module.id&&$build_deps$.module.define&&$build_deps$.module.define(name,[],(function(){
return $build_deps$.module.exports}))}exports=void 0,module=void 0,define.amd=!0,function(e,t){
if("object"==typeof exports&&"object"==typeof module)module.exports=t()
else if("function"==typeof define&&define.amd)define([],t)
else{var r=t()
for(var n in r)("object"==typeof exports?exports:e)[n]=r[n]}}(this,()=>(()=>{var e={
8424:function(e,t,r){"use strict"
var n=this&&this.__createBinding||(Object.create?function(e,t,r,n){void 0===n&&(n=r)
var i=Object.getOwnPropertyDescriptor(t,r)
i&&!("get"in i?!t.__esModule:i.writable||i.configurable)||(i={enumerable:!0,get:function(){
return t[r]}}),Object.defineProperty(e,n,i)}:function(e,t,r,n){void 0===n&&(n=r),e[n]=t[r]
}),i=this&&this.__exportStar||function(e,t){
for(var r in e)"default"===r||Object.prototype.hasOwnProperty.call(t,r)||n(t,e,r)}
Object.defineProperty(t,"__esModule",{value:!0}),t.PanoramaWrapper=t.PanoramaAttribute=void 0,
i(r(989),t)
var o=r(6255)
Object.defineProperty(t,"PanoramaAttribute",{enumerable:!0,get:function(){return o.PanoramaAttribute
}}),Object.defineProperty(t,"PanoramaWrapper",{enumerable:!0,get:function(){return o.PanoramaWrapper
}})},1285:(e,t,r)=>{"use strict"
Object.defineProperty(t,"__esModule",{value:!0}),t.CookieObserver=void 0
var n=r(9332),i=function(){function e(e,t){void 0===t&&(t=5e3),this.cookieName=e,this.listeners=[],
this.lastSeenCookieValue=(0,n.parseCookie)(e),setInterval(this.poll.bind(this),t)}
return e.prototype.addChangeListener=function(e){this.listeners.push(e)
},e.prototype.poll=function(){var e=(0,n.parseCookie)(this.cookieName)
this.lastSeenCookieValue!==e&&this.listeners.forEach((function(e){return e()})),
this.lastSeenCookieValue=e},e}()
t.CookieObserver=i},4082:function(e,t){"use strict"
var r=this&&this.__assign||function(){return(r=Object.assign||function(e){
for(var t,r=1,n=arguments.length;r<n;r++)for(var i in t=arguments[r])Object.prototype.hasOwnProperty.call(t,i)&&(e[i]=t[i])
return e}).apply(this,arguments)}
Object.defineProperty(t,"__esModule",{value:!0}),t.HttpClient=t.MAX_RETRIES=void 0,t.MAX_RETRIES=4
var n=function(){function e(e){this.jsonReplacer=e}return e.prototype.call=function(e,r,n){
var i=this,o=new Date,a=function(r){var i
return n({code:r.code,message:r.message,startTimestamp:o,retries:r.retries,
latencyMillseconds:(new Date).getTime()-o.getTime(),
maxRetriesExceeded:r.retries>=(null!==(i=e.maxRetries)&&void 0!==i?i:t.MAX_RETRIES)})
},s=function(t){var r
setTimeout((function(){return i.callOnce(e,t,u,c)
}),(r=t,Math.random()*Math.min(10,Math.pow(2,r))*100))},u=function(n){var i,u
if(function(e){return e.status>=500||429===e.status
}(n))return n.retries<(null!==(i=e.maxRetries)&&void 0!==i?i:t.MAX_RETRIES)?s(n.retries+1):a({
retries:n.retries,status:n.status,code:"MaxRetriesExceeded",message:"Too many retries"})
r({data:(u=n).data,startTimestamp:o,retries:u.retries,finalHttpStatusCode:u.status,
latencyMillseconds:(new Date).getTime()-o.getTime(),maxRetriesExceeded:!1})},c=function(r){var n
return r.retries<(null!==(n=e.maxRetries)&&void 0!==n?n:t.MAX_RETRIES)?s(r.retries+1):a(r)}
this.callOnce(e,0,u,c)},e.prototype.callOnce=function(e,t,r,n){
!0===e.keepalive&&"function"==typeof fetch?this.callWithFetch(e,t,r,n):this.callWithXHR(e,t,r,n)},
e.prototype.callWithFetch=function(e,t,n,i){var o={method:e.method,headers:r({
"X-Retries":"".concat(t)},e.headers),keepalive:!0}
if(void 0!==e.timeout&&e.timeout>0){var a=new AbortController
setTimeout((function(){return a.abort()}),e.timeout+t*(e.timeoutIncreasePerRetry||0)),
o.signal=a.signal}
"GET"!==e.method.toUpperCase()&&(o.body=this.createBody(e)),fetch(e.url,o).then((function(e){
var r,i=null===(r=null==e?void 0:e.headers)||void 0===r?void 0:r.get("Content-Type")
i&&/application\/json/.test(i)?e.json().then((function(r){return n({data:r,retries:t,status:e.status
})})):e.text().then((function(r){return n({data:r,retries:t,status:e.status})}))
})).catch((function(e){"AbortError"===e.name?i({status:500,retries:t,code:"RequestTimeout",
message:"Request timeout"}):i({status:500,retries:t,code:"RequestFailed",
message:"Request encountered an error"})}))},e.prototype.callWithXHR=function(e,t,r,n){
var i=new XMLHttpRequest
try{i.open(e.method,e.url,!0)}catch(e){return n({status:i.status,retries:t,code:"InvalidRequest",
message:"Failed to open the XMLHttpRequest"})}
if(e.timeout&&(i.timeout=e.timeout+t*(e.timeoutIncreasePerRetry||0)),
e.headers)for(var o in e.headers)i.setRequestHeader(o,e.headers[o])
i.setRequestHeader("X-Retries","".concat(t)),i.onload=function(){
var e,n=i.getResponseHeader("Content-Type")
return e=n&&/application\/json/.test(n)?JSON.parse(i.responseText):i.response,r({data:e,retries:t,
status:i.status})},i.onerror=function(){return n({status:i.status,retries:t,code:"RequestFailed",
message:"Request encountered an error"})},i.onabort=function(){return n({status:i.status,retries:t,
code:"RequestAborted",message:"Request was aborted"})},i.ontimeout=function(){n({status:i.status,
retries:t,code:"RequestTimeout",message:"Request timeout"})}
var a=this.createBody(e)
try{i.send(a)}catch(e){return n({status:i.status,retries:t,code:"NetworkError",
message:"Failed to make XMLHttpRequest"})}},e.prototype.createBody=function(e){var t=e.data
return t?"string"==typeof t?t:"object"==typeof t?JSON.stringify(t,this.jsonReplacer):String(t):null
},e}()
t.HttpClient=n},6255:(e,t,r)=>{"use strict"
Object.defineProperty(t,"__esModule",{value:!0}),t.PanoramaWrapper=t.PanoramaAttribute=void 0
var n,i=r(8774);(n=t.PanoramaAttribute||(t.PanoramaAttribute={})).SERVICE="service",
n.SERVICE_SUB_SECTION="serviceSubSection",n.SERVICE_CONSOLE_PAGE="serviceConsolePage",
n.VARIANT="variant"
var o=function(){function e(){this.isPanoramaAvailable=function(){var e
return void 0!==typeof window&&"function"==typeof(null===window||void 0===window?void 0:window.panorama)&&(null===(e=null===window||void 0===window?void 0:window.panorama)||void 0===e?void 0:e.enabled)
}}return e.prototype.updateCommonAttribute=function(e,t){
if(!this.isPanoramaAvailable())throw new i.PanoramaNotAvailableError("Could not update attribute")
null===window||void 0===window||window.panorama("updateCommonAttribute",e,t)
},e.prototype.readCommonAttribute=function(e){var t,r,n,o
if(!this.isPanoramaAvailable())throw new i.PanoramaNotAvailableError("Could not read attribute")
var a=null===(o=null===(n=null===(r=null===(t=null===window||void 0===window?void 0:window.panorama)||void 0===t?void 0:t.q)||void 0===r?void 0:r.trackerDictionary)||void 0===n?void 0:n.cf)||void 0===o?void 0:o.readCommonAttribute
return a&&"function"==typeof a?a()[e]:void 0},e}()
t.PanoramaWrapper=o},989:function(e,t,r){"use strict"
var n=this&&this.__awaiter||function(e,t,r,n){return new(r||(r=Promise))((function(i,o){
function a(e){try{u(n.next(e))}catch(e){o(e)}}function s(e){try{u(n.throw(e))}catch(e){o(e)}}
function u(e){var t
e.done?i(e.value):(t=e.value,t instanceof r?t:new r((function(e){e(t)}))).then(a,s)}
u((n=n.apply(e,t||[])).next())}))},i=this&&this.__generator||function(e,t){var r,n,i,o,a={label:0,
sent:function(){if(1&i[0])throw i[1]
return i[1]},trys:[],ops:[]}
return o={next:s(0),throw:s(1),return:s(2)
},"function"==typeof Symbol&&(o[Symbol.iterator]=function(){return this}),o
function s(o){return function(s){return function(o){
if(r)throw new TypeError("Generator is already executing.")
for(;a;)try{if(r=1,n&&(i=2&o[0]?n.return:o[0]?n.throw||((i=n.return)&&i.call(n),
0):n.next)&&!(i=i.call(n,o[1])).done)return i
switch(n=0,i&&(o=[2&o[0],i.value]),o[0]){case 0:case 1:i=o
break
case 4:return a.label++,{value:o[1],done:!1}
case 5:a.label++,n=o[1],o=[0]
continue
case 7:o=a.ops.pop(),a.trys.pop()
continue
default:if(!((i=(i=a.trys).length>0&&i[i.length-1])||6!==o[0]&&2!==o[0])){a=0
continue}if(3===o[0]&&(!i||o[1]>i[0]&&o[1]<i[3])){a.label=o[1]
break}if(6===o[0]&&a.label<i[1]){a.label=i[1],i=o
break}if(i&&a.label<i[2]){a.label=i[2],a.ops.push(o)
break}i[2]&&a.ops.pop(),a.trys.pop()
continue}o=t.call(e,a)}catch(e){o=[6,e],n=0}finally{r=i=0}if(5&o[0])throw o[1]
return{value:o[0]?o[1]:void 0,done:!0}}([o,s])}}}
Object.defineProperty(t,"__esModule",{value:!0}),t.TangerineBox=void 0
var o,a,s,u,c,p,l,f=r(8705),d=r(8773),h=r(9207),m=r(8411),v=r(1033),y=r(6146),g=r(6255),b=r(9332),S=r(8774),E=function(){
function e(e){e&&(u=e)}return e.prototype.getCredentials=function(){
return o||(o=new m.TangerineBoxCredentials(this.getMetaTagContent().browserCredsFullPath,this.getMetaTagContent().csrfToken,this.getInternalEventTracker(),this.getLogoutDetectionCookieName())),
o},e.prototype.getLogoutDetectionCookieName=function(){var e=this.getSessionData()
if(this.isPrismModeEnabled()){
if(!e.sessionDifferentiator)throw new S.MetaTagParsingError("sessionDifferentiator is not found in prism mode")
return(0,b.sessionIdCookie)(e.sessionDifferentiator)}return b.USER_INFO_COOKIE},
e.prototype.isPrismModeEnabled=function(){var e=this.getMetaTagContent().prismModeEnabled
return"boolean"==typeof e?e:!!this.getSessionData().prismModeEnabled
},e.prototype.getCdnUrl=function(e){
return/^(http|https|ws|wss):\/\//.test(e)?e:"".concat(this.getMetaTagContent().cdn).concat(e)},
e.prototype.getCustomContext=function(e){return this.getMetaTagContent().custom[e]},
e.prototype.getEventTracker=function(){return this.getInternalEventTracker()
},e.prototype.getPanoramaWrapper=function(){return p||(p=new g.PanoramaWrapper),p},
e.prototype.getInternalEventTracker=function(){if(!s){var e=this.getMetaTagContent().telemetry
if(!e||!e.endpoint)return console.error("[TangerineBox] Telemetry configuration is missing"),
new f.NoOpTracker
var t=this.getEventPublisher()
s=new f.ScheduledEventTracker(t,new d.PerformanceEventEmitter)}return s
},e.prototype.getEventPublisher=function(){if(!a){
var e=new v.NoOpEventPublisher,t=this.getMetaTagContent().telemetry
if(!t||!t.endpoint)return console.error("[TangerineBox] Telemetry configuration is missing"),e
var r=this.getSessionData().identityToken
if(!r)return console.error("[TangerineBox] Identity token is missing"),e
var n=this.getTelemetryMetaTagContent().telemetryToken
if(!n)return console.error("[TangerineBox] Console telemetry token is missing"),e
var i=(0,y.createAuthHeaderV2)(r),o=t.endpoint
a=new v.EventPublisher({endpoint:o,authorizationHeader:i,consoleTelemetryToken:n
},this.getPanoramaWrapper())}return a},e.prototype.getMetaTagContent=function(){return u||(u=(0,
h.parseTangerineBoxMetaTag)()),u},e.prototype.getTelemetryMetaTagContent=function(){return c||(c=(0,
h.parseTangerineBoxTelemetryMetaTag)()),c},e.prototype.getSessionData=function(){return l||(l=(0,
h.parseSessionDataMetaTag)()),l},e.prototype.getSessionDataAttribute=function(e){
return n(this,void 0,void 0,(function(){return i(this,(function(t){
return[2,this.getSessionData()[e]]}))}))},e.prototype.getSessionARN=function(){
return n(this,void 0,void 0,(function(){return i(this,(function(e){
return[2,this.getSessionDataAttribute("sessionARN")]}))}))},e.prototype.getAccountId=function(){
return n(this,void 0,void 0,(function(){return i(this,(function(e){
return[2,this.getSessionDataAttribute("accountId")]}))}))},e.prototype.getIdentityToken=function(){
return n(this,void 0,void 0,(function(){return i(this,(function(e){
return[2,this.getSessionDataAttribute("identityToken")]}))}))},e.prototype.getSessionId=function(){
return n(this,void 0,void 0,(function(){return i(this,(function(e){
return[2,this.getSessionDataAttribute("sessionId")]}))}))
},e.prototype.getInfrastructureRegion=function(){return n(this,void 0,void 0,(function(){
return i(this,(function(e){return[2,this.getSessionDataAttribute("infrastructureRegion")]}))}))},
e.prototype.getVpc=function(){return n(this,void 0,void 0,(function(){return i(this,(function(e){
return[2,this.getSessionDataAttribute("vpc")]}))}))},e.prototype.getAccountAlias=function(){
return n(this,void 0,void 0,(function(){return i(this,(function(e){
return[2,this.getSessionDataAttribute("accountAlias")]}))}))},e.prototype.getDisplayName=function(){
return n(this,void 0,void 0,(function(){return i(this,(function(e){
return[2,this.getSessionDataAttribute("displayName")]}))}))
},e.prototype.getSessionDifferentiator=function(){return n(this,void 0,void 0,(function(){
return i(this,(function(e){return[2,this.getSessionDataAttribute("sessionDifferentiator")]}))}))},e
}()
t.TangerineBox=E},8411:function(e,t,r){"use strict"
var n,i=this&&this.__extends||(n=function(e,t){return(n=Object.setPrototypeOf||{__proto__:[]
}instanceof Array&&function(e,t){e.__proto__=t}||function(e,t){
for(var r in t)Object.prototype.hasOwnProperty.call(t,r)&&(e[r]=t[r])})(e,t)},function(e,t){
if("function"!=typeof t&&null!==t)throw new TypeError("Class extends value "+String(t)+" is not a constructor or null")
function r(){this.constructor=e}
n(e,t),e.prototype=null===t?Object.create(t):(r.prototype=t.prototype,new r)
}),o=this&&this.__assign||function(){return(o=Object.assign||function(e){
for(var t,r=1,n=arguments.length;r<n;r++)for(var i in t=arguments[r])Object.prototype.hasOwnProperty.call(t,i)&&(e[i]=t[i])
return e}).apply(this,arguments)}
Object.defineProperty(t,"__esModule",{value:!0}),t.TangerineBoxCredentials=void 0
var a=r(1285),s=r(4082),u=r(8705),c=r(9207),p=r(9132),l=r(9019),f=function(e){
return l.error(new Error,{code:"TangerineBoxCredentialsProviderFailure",message:e})},d=function(e){
function t(t,r,n,i,o,u){void 0===o&&(o=new s.HttpClient)
var c=e.call(this,"","","")||this
return c.browserCredsFullPath=t,c.csrfToken=r,c.eventTracker=n,c.cookieNameToObserve=i,
c.httpClient=o,
c.isLoggedOut=!1,c.cookieObserver=null!=u?u:new a.CookieObserver(c.cookieNameToObserve),
c.cookieObserver.addChangeListener((function(){c.markAsLoggedOut()})),c}return i(t,e),
t.prototype.markAsLoggedOut=function(){this.isLoggedOut=!0,this.update({expiration:new Date(0),
accessKeyId:"",secretAccessKey:"",sessionToken:""})},t.prototype.refresh=function(e){
this.isLoggedOut?e(f("User logged out")):this.coalesceRefresh(e||l.fn.callback)},
t.prototype.load=function(e){this.isLoggedOut?e(f("User logged out")):this.fetchCredentials(e)},
t.prototype.fetchCredentials=function(e){var t=this,r={url:this.browserCredsFullPath,method:"POST",
headers:{"x-csrf-token":this.csrfToken},timeout:5e3,timeoutIncreasePerRetry:5e3,maxRetries:4}
this.httpClient.call(r,(function(r){
if(t.emitClientResponseEvent(r),r.finalHttpStatusCode>=200&&r.finalHttpStatusCode<300)t.validateAndUpdate(r.data,e)
else{401===r.finalHttpStatusCode&&(t.markAsLoggedOut(),t.triggerLoggedOutDialog())
var n=void 0
try{n=JSON.parse(r.data.toString()).error}catch(e){
n="HTTP status code ".concat(r.finalHttpStatusCode)}e(f(n))}}),(function(r){
t.emitClientErrorEvent(r),e(f(r.message))}))},t.prototype.validateAndUpdate=function(e,t){
if(this.isLoggedOut)t(f("User logged out"))
else{for(var r=0,n=["accessKeyId","secretAccessKey","sessionToken"];r<n.length;r++){var i=n[r]
if(!e[i])return t(f('Invalid credentials, missing property: "'.concat(i,'"')))}this.update(e),
t(void 0)}},t.prototype.update=function(e){var t=new Date,r=new Date(e.expiration)
this.expireTime=r,this.expired=r<t,this.accessKeyId=e.accessKeyId,this.secretAccessKey=e.secretAccessKey,
this.sessionToken=e.sessionToken},t.prototype.emitClientResponseEvent=function(e){var t={
attemptCount:e.retries,finalHttpStatusCode:e.finalHttpStatusCode,
latencyMillseconds:e.latencyMillseconds,maxRetriesExceeded:e.maxRetriesExceeded,
startTimestamp:e.startTimestamp,operation:"RefreshCredentials",service:"TangerineBox",region:"",
sdkVersion:u.AWS_SDK_VERSION}
e.finalHttpStatusCode>=400&&(t=o({finalSdkException:"RequestFailed",
finalSdkExceptionMessage:"Request failed with status code ".concat(e.finalHttpStatusCode),
finalHttpStatusCode:e.finalHttpStatusCode},t)),this.eventTracker.addAwsSdkEvent(t)},
t.prototype.triggerLoggedOutDialog=function(){
var e=void 0!==(0,c.parseMetaTag)("awsc-widget-nav")||void 0!==(0,
c.parseMetaTag)("awsc-widget-next")
"undefined"!=typeof window&&(e?window.dispatchEvent(this.createCustomEvent("auth-change-detected")):window.AWSC&&"function"==typeof window.AWSC.jQuery&&window.AWSC.jQuery(window.AWSC).trigger("auth-change-detected"))
},t.prototype.createCustomEvent=function(e){
if("undefined"!=typeof window&&"function"==typeof window.CustomEvent)return new CustomEvent(e)
var t=!1,r=!1,n=null,i=document.createEvent("CustomEvent")
return i.initCustomEvent(e,t,r,n),i},t.prototype.emitClientErrorEvent=function(e){var t={
attemptCount:e.retries,latencyMillseconds:e.latencyMillseconds,
maxRetriesExceeded:e.maxRetriesExceeded,startTimestamp:e.startTimestamp,finalSdkException:e.code,
finalSdkExceptionMessage:e.message,operation:"RefreshCredentials",service:"TangerineBox",region:"",
sdkVersion:u.AWS_SDK_VERSION}
this.eventTracker.addAwsSdkEvent(t)},t}(p.Credentials)
t.TangerineBoxCredentials=d},8774:function(e,t){"use strict"
var r,n=this&&this.__extends||(r=function(e,t){return(r=Object.setPrototypeOf||{__proto__:[]
}instanceof Array&&function(e,t){e.__proto__=t}||function(e,t){
for(var r in t)Object.prototype.hasOwnProperty.call(t,r)&&(e[r]=t[r])})(e,t)},function(e,t){
if("function"!=typeof t&&null!==t)throw new TypeError("Class extends value "+String(t)+" is not a constructor or null")
function n(){this.constructor=e}
r(e,t),e.prototype=null===t?Object.create(t):(n.prototype=t.prototype,new n)})
Object.defineProperty(t,"__esModule",{value:!0
}),t.PanoramaNotAvailableError=t.MetaTagParsingError=void 0
var i=function(e){function t(t,r){var n=e.call(this,t)||this
return n.message=t,n.originalError=r,n.name=n.constructor.name,r&&(n.stack+="\nCaused by: "+r.stack),
n}return n(t,e),t}(Error),o=function(e){function t(){return null!==e&&e.apply(this,arguments)||this}
return n(t,e),t}(i)
t.MetaTagParsingError=o
var a=function(e){function t(){return null!==e&&e.apply(this,arguments)||this}return n(t,e),t}(i)
t.PanoramaNotAvailableError=a},8833:(e,t)=>{"use strict"
Object.defineProperty(t,"__esModule",{value:!0
}),t.PACKAGE_VERSION=void 0,t.PACKAGE_VERSION="1.0.62902.0#794039b5"},9332:(e,t)=>{"use strict"
Object.defineProperty(t,"__esModule",{value:!0
}),t.parseCookie=t.sessionIdCookie=t.REQUEST_CATEGORY_COOKIE=t.USER_INFO_COOKIE=void 0,
t.USER_INFO_COOKIE="aws-userInfo",
t.REQUEST_CATEGORY_COOKIE="metrics-req-cat",t.sessionIdCookie=function(e){
return"".concat("__Secure-aws-session-id","-").concat(e)},t.parseCookie=function(e,t){
void 0===t&&(t=document.cookie)
var r=t.match("".concat(e,"=([^;]*)"))
if(r&&r[1])return r[1]}},9207:(e,t,r)=>{"use strict"
Object.defineProperty(t,"__esModule",{value:!0
}),t.parseSessionDataMetaTag=t.parseTangerineBoxTelemetryMetaTag=t.parseTangerineBoxMetaTag=t.parseMetaTag=void 0
var n=r(8774)
function i(e,t){void 0===t&&(t=!1)
for(var r=window;;){var n=r.document.querySelector("meta[name='".concat(e,"']"))
if(n)return n.content
if(!t||r===r.parent)return
r=r.parent}}t.parseMetaTag=i,t.parseTangerineBoxMetaTag=function(){var e=i("tb-data",!0)
if(!e)throw new n.MetaTagParsingError("TangerineBox meta tag not found")
try{return JSON.parse(e)}catch(e){
throw new n.MetaTagParsingError("Unable to parse TangerineBox meta tag contents",e instanceof Error?e:new Error(String(e)))
}},t.parseTangerineBoxTelemetryMetaTag=function(){var e=i("tbt-data",!0)
if(!e)throw new n.MetaTagParsingError("TangerineBox Telemetry meta tag not found")
try{return JSON.parse(e)}catch(e){
throw new n.MetaTagParsingError("Unable to parse TangerineBox Telemetry meta tag contents",e instanceof Error?e:new Error(String(e)))
}},t.parseSessionDataMetaTag=function(){var e=i("awsc-session-data",!0)
if(!e)throw new n.MetaTagParsingError("Session data meta tag not found")
try{return JSON.parse(e)}catch(e){
throw new n.MetaTagParsingError("Unable to parse session data meta tag content",e instanceof Error?e:new Error(String(e)))
}}},5650:(e,t)=>{"use strict"
Object.defineProperty(t,"__esModule",{value:!0
}),t.DOMAINS=void 0,t.DOMAINS=["csp.hci.ic.gov","amazonaws.com.cn","c2s.ic.gov","amazonaws.com","sc2s.sgov.gov","cloud.adc-e.uk","amazonaws.com","amazonaws.eu"]
},1033:function(e,t,r){"use strict"
var n=this&&this.__assign||function(){return(n=Object.assign||function(e){
for(var t,r=1,n=arguments.length;r<n;r++)for(var i in t=arguments[r])Object.prototype.hasOwnProperty.call(t,i)&&(e[i]=t[i])
return e}).apply(this,arguments)}
Object.defineProperty(t,"__esModule",{value:!0
}),t.NoOpEventPublisher=t.EventPublisher=t.compareBasedOnTypeAndTimestamp=void 0
var i=r(3401),o=r(4718),a=r(4082),s=r(6255)
function u(e,t){return e.timestamp===t.timestamp?0:e.timestamp<t.timestamp?-1:1}function c(e,t){
return e.type===i.TrackerEventType.ERROR&&t.type===i.TrackerEventType.ERROR?u(e,t):e.type===i.TrackerEventType.ERROR?-1:t.type===i.TrackerEventType.ERROR?1:u(e,t)
}t.compareBasedOnTypeAndTimestamp=c
var p=function(){function e(t,r){var n,i,s,u,p
this.endpoint=t.endpoint,this.authorizationHeader=t.authorizationHeader,this.consoleTelemetryToken=t.consoleTelemetryToken,
this.httpClient=null!==(n=null==t?void 0:t.httpClient)&&void 0!==n?n:new a.HttpClient(e.errorReplacer),
this.maxEventsInChunk=null!==(i=null==t?void 0:t.maxEventsInChunk)&&void 0!==i?i:100,
this.maxPayloadSizePerChunk=null!==(s=null==t?void 0:t.maxPayloadSizePerChunk)&&void 0!==s?s:524288,
this.queue=null!==(u=null==t?void 0:t.queue)&&void 0!==u?u:new o.Queue({comparator:c,
maxSize:null!==(p=null==t?void 0:t.maxQueueSize)&&void 0!==p?p:1e4}),this.panoramaWrapper=r}
return Object.defineProperty(e.prototype,"queueSize",{get:function(){return this.queue.size},
enumerable:!1,configurable:!0}),e.prototype.hasEvents=function(){return!this.queue.isEmpty},
e.prototype.addEvent=function(e){try{this.queue.add(this.addPageInformation(e))}catch(t){
this.queue.add(e)}},e.prototype.publish=function(e,t,r,n){void 0===r&&(r=!1),void 0===n&&(n=!1)
var i=this.queue.remove(this.maxEventsInChunk,r?65536:this.maxPayloadSizePerChunk)
if(0===i.length)e()
else{var o={events:i,tokens:[this.consoleTelemetryToken]}
this.sendChunk(o,e,t,r,n)}},e.prototype.flush=function(){var e=this
this.hasEvents()&&this.publish((function(){return e.flush()}),(function(){return e.flush()}),!0,!0)
},e.prototype.sendChunk=function(e,t,r,n,i){void 0===n&&(n=!1),void 0===i&&(i=!1)
var o={timeout:3e4,keepalive:n,method:"POST",headers:{Authorization:this.authorizationHeader,
"Content-Type":"application/json","X-Remaining-Events":this.queueSize.toString(),
"X-Publish-Type":i?"flushed":"scheduled"},url:this.endpoint,data:e}
this.httpClient.call(o,t,r)},e.errorReplacer=function(e,t){if(t instanceof Error){var r={}
return Object.getOwnPropertyNames(t).forEach((function(e){r[e]=t[e]})),t.stack&&(r.stack=t.stack),r}
if(t instanceof ErrorEvent){var n={}
return t.message&&(n.message=t.message),t.filename&&(n.filename=t.filename),t.lineno&&(n.lineNumber=t.lineno),
t.colno&&(n.columnNumber=t.colno),t.error&&t.error.stack&&(n.stack=t.error.stack),n}return t},
e.prototype.addPageInformation=function(e){
var t=this.panoramaWrapper.readCommonAttribute(s.PanoramaAttribute.SERVICE_SUB_SECTION),r=this.panoramaWrapper.readCommonAttribute(s.PanoramaAttribute.SERVICE_CONSOLE_PAGE)
return n(n({},e),{subSection:t||void 0,page:r||void 0})},e}()
t.EventPublisher=p
var l=function(){function e(){}
return e.prototype.addEvent=function(e){},e.prototype.hasEvents=function(){return!1},
e.prototype.flush=function(){},e.prototype.publish=function(){},e}()
t.NoOpEventPublisher=l},8705:(e,t,r)=>{"use strict"
Object.defineProperty(t,"__esModule",{value:!0
}),t.NoOpTracker=t.ScheduledEventTracker=t.AWS_SDK_VERSION=void 0
var n=r(4835),i=r(3401),o=r(5650),a=r(9132)
t.AWS_SDK_VERSION=(null==a?void 0:a.VERSION)||"unknown"
var s=function(){function e(e,r){var i=this
this.eventPublisher=e,this.performanceEventEmitter=r,this.setupRequestListeners=function(e){
var r,n,o,a=0,s=!1,u=!0,c=e
function p(){
return"undefined"!=typeof performance&&"function"==typeof performance.now?performance.now():Date.now()
}e.on("validate",(function(){r=p(),o=Date.now()}),u),e.on("sign",(function(){n=e.httpRequest.region,
a++}),u),e.on("complete",(function(e){var u,l,f,d,h
if(!(a<=0)){if(e.error){var m=e.error
e.httpResponse.statusCode>299?m.code&&(d=m.code):(m.code||m.name)&&(h=m.code||m.name)}
var v=Math.max(0,Math.round(p()-r))
e.error&&e.error.retryable&&"number"==typeof e.retryCount&&"number"==typeof e.maxRetries&&e.retryCount>=e.maxRetries&&(s=!0)
var y={attemptCount:a,
finalHttpStatusCode:null===(u=null==e?void 0:e.httpResponse)||void 0===u?void 0:u.statusCode,
latencyMillseconds:v,maxRetriesExceeded:s,
operation:null!==(f=null===(l=c.service.api.operations[c.operation])||void 0===l?void 0:l.name)&&void 0!==f?f:c.operation,
service:c.service.api.serviceId||c.service.api.endpointPrefix,region:n,startTimestamp:new Date(o),
finalSdkException:h,finalAwsException:d,finalRequestId:null==e?void 0:e.requestId,
sdkVersion:t.AWS_SDK_VERSION}
i.addAwsSdkEvent(y)}}))},this.requestScheduler=new n.RequestScheduler(this.eventPublisher),
r.emitPageMetrics((function(e){return i.processPageEvent(e)
})),r.emitPerformanceMetrics(["resource","navigation","measure"],(function(e){
return i.processPerformanceMetrics(e)
})),"undefined"!=typeof window&&window.addEventListener("beforeunload",(function(){
return i.flushEvents()}))}return e.prototype.addEvent=function(e){
var t=new i.TrackerEvent(i.TrackerEventType.LOG,e)
this.eventPublisher.addEvent(t)},e.prototype.addError=function(e){
var t=new i.TrackerEvent(i.TrackerEventType.ERROR,e)
this.eventPublisher.addEvent(t),this.requestScheduler.scheduleError()
},e.prototype.addAwsSdkEvent=function(e){var t=new i.AwsSdkMetricEvent(e,{})
this.eventPublisher.addEvent(t)},e.prototype.emitAwsSdkMetrics=function(e){
var t=this,r=e.setupRequestListeners
e.setupRequestListeners=function(n){r.call(e,n),t.setupRequestListeners(n)}
},e.prototype.processCustomMeasureMetrics=function(e){
if(e.name.length>0&&e.name.match("^[A-Za-z]")){var t={name:e.name,timeToCustomMark:e.duration}
this.eventPublisher.addEvent(new i.CustomMeasureMetricEvent(t,{}))}
},e.prototype.processNavigationMetrics=function(e){var t={startTime:e.startTime,duration:e.duration,
initiatorType:e.initiatorType,domComplete:e.domComplete,
domContentLoadedEventEnd:e.domContentLoadedEventEnd,
domContentLoadedEventStart:e.domContentLoadedEventStart,domInteractive:e.domInteractive,
loadEventEnd:e.loadEventEnd,loadEventStart:e.loadEventStart,redirectCount:e.redirectCount,
redirectStart:e.redirectStart,requestStart:e.requestStart,responseStart:e.responseStart,type:e.type,
unloadEventEnd:e.unloadEventEnd,unloadEventStart:e.unloadEventStart}
this.eventPublisher.addEvent(new i.NavigationMetricEvent(t,{}))
},e.prototype.processPageEvent=function(e){var t={timeToLoadLargestContentfulPaint:e.value}
this.eventPublisher.addEvent(new i.PageMetricEvent(t,{}))
},e.prototype.processResourceMetrics=function(e){
if(!(e.name.includes("/p/log/")||e.name.includes("panoramaroute")||e.name.includes("telemetry")||e.name.startsWith("data:")||e.name.startsWith("blob:")||e.name.match(new RegExp("^https://polly\\.[a-z0-9-]+\\.".concat(o.DOMAINS.map((function(e){
return e.replace(/\./g,"\\.")})).join("|"),"/v1/speech\\?}"))))){var t={url:e.name,
startTime:e.startTime,duration:e.duration,initiatorType:e.initiatorType,
nextHopProtocol:e.nextHopProtocol,fetchStart:e.fetchStart,domainLookupStart:e.domainLookupStart,
domainLookupEnd:e.domainLookupEnd,connectStart:e.connectStart,connectEnd:e.connectEnd,
requestStart:e.requestStart,responseStart:e.responseStart,responseEnd:e.responseEnd,
transferSize:e.transferSize,encodedBodySize:e.encodedBodySize,decodedBodySize:e.decodedBodySize}
this.eventPublisher.addEvent(new i.ResourceMetricEvent(t,{}))}
},e.prototype.isMeasureEntry=function(e){return"measure"===e.entryType
},e.prototype.isNavigationEntry=function(e){return"navigation"===e.entryType
},e.prototype.isResourceEntry=function(e){return"resource"===e.entryType
},e.prototype.processPerformanceMetrics=function(e){for(var t=0,r=e.getEntries();t<r.length;t++){
var n=r[t]
this.isMeasureEntry(n)?this.processCustomMeasureMetrics(n):this.isNavigationEntry(n)?this.processNavigationMetrics(n):this.isResourceEntry(n)&&this.processResourceMetrics(n)
}},e.prototype.flushEvents=function(){this.eventPublisher.flush()},e}()
t.ScheduledEventTracker=s
var u=function(){function e(){}
return e.prototype.addEvent=function(e){},e.prototype.addError=function(e){},
e.prototype.addAwsSdkEvent=function(e){},e.prototype.emitAwsSdkMetrics=function(e){},e}()
t.NoOpTracker=u},8773:(e,t,r)=>{"use strict"
Object.defineProperty(t,"__esModule",{value:!0}),t.PerformanceEventEmitter=void 0
var n=r(364),i=function(){function e(){}return e.prototype.emitPageMetrics=function(e){(0,
n.getLCP)(e)},e.prototype.emitPerformanceMetrics=function(e,t){
if(window&&"PerformanceObserver"in window){var r=new PerformanceObserver(t)
try{e.forEach((function(e){return r.observe({type:e,buffered:!0})}))}catch(t){r.observe({
entryTypes:e})}}},e}()
t.PerformanceEventEmitter=i},4718:(e,t)=>{"use strict"
Object.defineProperty(t,"__esModule",{value:!0}),t.Queue=void 0
var r=function(){function e(e){this.queue=[],this.comparator=null==e?void 0:e.comparator,
this.maxSize=null==e?void 0:e.maxSize}return Object.defineProperty(e.prototype,"size",{
get:function(){return this.queue.length},enumerable:!1,configurable:!0
}),Object.defineProperty(e.prototype,"isEmpty",{get:function(){return 0===this.queue.length},
enumerable:!1,configurable:!0}),e.prototype.add=function(){
for(var e,t=[],r=0;r<arguments.length;r++)t[r]=arguments[r]
this.isAbleToFit(t.length)||(this.prioritize(),this.queue.splice(-t.length,this.queue.length-t.length)),
(e=this.queue).push.apply(e,t)},e.prototype.isAbleToFit=function(e){
return void 0===this.maxSize||this.maxSize>=this.size+e},e.prototype.remove=function(e,t){
this.prioritize()
var r=Math.min(this.queue.length,e)
if(!t)return this.queue.splice(0,r)
for(;r>0;r--){var n=this.queue.slice(0,r)
if(1===r||JSON.stringify({items:n}).length<=t)return this.queue.splice(0,r),n}return[]},
e.prototype.prioritize=function(){this.comparator&&this.queue.sort(this.comparator)},e}()
t.Queue=r},4835:(e,t)=>{"use strict"
Object.defineProperty(t,"__esModule",{value:!0
}),t.RequestScheduler=t.SUBSEQUENT_REPORT_FREQUENCY_MS=t.ERROR_REPORT_FREQUENCY_MS=t.REPORT_FREQUENCY_MS=void 0,
t.REPORT_FREQUENCY_MS=5e3,t.ERROR_REPORT_FREQUENCY_MS=1e3,t.SUBSEQUENT_REPORT_FREQUENCY_MS=500
var r=function(){function e(e){this.eventPublisher=e,this.scheduledInvocation=null,
this.scheduledInvocationTime=0,this.isPublishing=!1,this.scheduleWithNextTick()}
return e.prototype.schedule=function(e){var r=this
if(void 0===e&&(e=t.REPORT_FREQUENCY_MS),!this.isPublishing){if(this.scheduledInvocation){
if(this.scheduledInvocationTime<this.now()+e)return
clearTimeout(this.scheduledInvocation),this.scheduledInvocation=null}
this.scheduledInvocation=setTimeout((function(){r.isPublishing=!0,r.scheduledInvocation=null,
r.eventPublisher.publish((function(){
r.isPublishing=!1,r.eventPublisher.hasEvents()?r.scheduleSubsequent():r.scheduleWithNextTick()
}),(function(){r.isPublishing=!1,r.scheduleWithNextTick()}))
}),e),this.scheduledInvocationTime=this.now()+e}},e.prototype.scheduleWithNextTick=function(){
this.schedule(t.REPORT_FREQUENCY_MS)},e.prototype.scheduleSubsequent=function(){
this.schedule(t.SUBSEQUENT_REPORT_FREQUENCY_MS)},e.prototype.scheduleError=function(){
this.schedule(t.ERROR_REPORT_FREQUENCY_MS)},e.prototype.now=function(){
return"undefined"!=typeof performance&&"function"==typeof performance.now?performance.now():Date.now()
},e}()
t.RequestScheduler=r},3401:function(e,t,r){"use strict"
var n,i=this&&this.__extends||(n=function(e,t){return(n=Object.setPrototypeOf||{__proto__:[]
}instanceof Array&&function(e,t){e.__proto__=t}||function(e,t){
for(var r in t)Object.prototype.hasOwnProperty.call(t,r)&&(e[r]=t[r])})(e,t)},function(e,t){
if("function"!=typeof t&&null!==t)throw new TypeError("Class extends value "+String(t)+" is not a constructor or null")
function r(){this.constructor=e}
n(e,t),e.prototype=null===t?Object.create(t):(r.prototype=t.prototype,new r)})
Object.defineProperty(t,"__esModule",{value:!0
}),t.ResourceMetricEvent=t.PageMetricEvent=t.NavigationMetricEvent=t.CustomMeasureMetricEvent=t.AwsSdkMetricEvent=t.TrackerEvent=t.TrackerEventType=void 0
var o,a=r(8833),s=r(9207),u=r(9332)
!function(e){e.LOG="log",e.ERROR="error",e.ASSET_LOAD_METRIC="asset-load-metric",
e.AWS_SDK_METRIC="aws-sdk-metric",e.CUSTOM_MEASURE_METRIC="custom-measure-metric",
e.NAVIGATION_METRIC="navigation-metric",
e.PAGE_METRIC="page-metric",e.RESOURCE_METRIC="resource-metric",e.INTERNAL="internal"
}(o=t.TrackerEventType||(t.TrackerEventType={}))
var c=function(e,t){this.type=e,this.content=t,this.tokenRefs=[0],this.retries=0,
this.timestamp=new Date,
this.version=a.PACKAGE_VERSION,this.callerCategory=(0,u.parseCookie)(u.REQUEST_CATEGORY_COOKIE)||"customer",
"undefined"!=typeof window?(this.location=window.location.href,this.requestId=(0,
s.parseMetaTag)("awsc-proxy-request-id",!0)||"unknown"):(this.location="nodejs",
this.requestId="unknown")}
t.TrackerEvent=c
var p=function(e){function t(t,r){var n=e.call(this,o.AWS_SDK_METRIC,r)||this
return n.awsSdkMetric=t,n.type=o.AWS_SDK_METRIC,n}return i(t,e),t}(c)
t.AwsSdkMetricEvent=p
var l=function(e){function t(t,r){var n=e.call(this,o.CUSTOM_MEASURE_METRIC,r)||this
return n.customMeasureMetric=t,n.type=o.CUSTOM_MEASURE_METRIC,n}return i(t,e),t}(c)
t.CustomMeasureMetricEvent=l
var f=function(e){function t(t,r){var n=e.call(this,o.NAVIGATION_METRIC,r)||this
return n.navigationMetric=t,n.type=o.NAVIGATION_METRIC,n}return i(t,e),t}(c)
t.NavigationMetricEvent=f
var d=function(e){function t(t,r){var n=e.call(this,o.PAGE_METRIC,r)||this
return n.pageMetric=t,n.type=o.PAGE_METRIC,n}return i(t,e),t}(c)
t.PageMetricEvent=d
var h=function(e){function t(t,r){var n=e.call(this,o.RESOURCE_METRIC,r)||this
return n.resourceMetric=t,n.type=o.RESOURCE_METRIC,n}return i(t,e),t}(c)
t.ResourceMetricEvent=h},6146:(e,t)=>{"use strict"
Object.defineProperty(t,"__esModule",{value:!0
}),t.createAuthHeaderV2=void 0,t.createAuthHeaderV2=function(e){return"Bearer ".concat(e)}},
9701:e=>{function t(e,r){
if(!t.services.hasOwnProperty(e))throw new Error("InvalidService: Failed to load api for "+e)
return t.services[e][r]}t.services={},e.exports=t},4089:(e,t,r)=>{var n,i=r(9132)
r(1833),r(4279),i.Config=i.util.inherit({constructor:function(e){void 0===e&&(e={}),
e=this.extractCredentials(e),i.util.each.call(this,this.keys,(function(t,r){this.set(t,e[t],r)}))},
getCredentials:function(e){var t,r=this
function n(t){e(t,t?null:r.credentials)}function o(e,t){return new i.util.error(t||new Error,{
code:"CredentialsError",message:e,name:"CredentialsError"})}
r.credentials?"function"==typeof r.credentials.get?r.credentials.get((function(e){
e&&(e=o("Could not load credentials from "+r.credentials.constructor.name,e)),n(e)})):(t=null,
r.credentials.accessKeyId&&r.credentials.secretAccessKey||(t=o("Missing credentials")),
n(t)):r.credentialProvider?r.credentialProvider.resolve((function(e,t){
e&&(e=o("Could not load credentials from any providers",e)),r.credentials=t,n(e)
})):n(o("No credentials to load"))},getToken:function(e){var t,r=this
function n(t){e(t,t?null:r.token)}function o(e,t){return new i.util.error(t||new Error,{
code:"TokenError",message:e,name:"TokenError"})}
r.token?"function"==typeof r.token.get?r.token.get((function(e){
e&&(e=o("Could not load token from "+r.token.constructor.name,e)),n(e)})):(t=null,
r.token.token||(t=o("Missing token")),n(t)):r.tokenProvider?r.tokenProvider.resolve((function(e,t){
e&&(e=o("Could not load token from any providers",e)),r.token=t,n(e)})):n(o("No token to load"))},
update:function(e,t){t=t||!1,e=this.extractCredentials(e),i.util.each.call(this,e,(function(e,r){
(t||Object.prototype.hasOwnProperty.call(this.keys,e)||i.Service.hasService(e))&&this.set(e,r)}))},
loadFromPath:function(e){this.clear()
var t=JSON.parse(i.util.readFileSync(e)),r=new i.FileSystemCredentials(e),n=new i.CredentialProviderChain
return n.providers.unshift(r),n.resolve((function(e,r){if(e)throw e
t.credentials=r})),this.constructor(t),this},clear:function(){
i.util.each.call(this,this.keys,(function(e){delete this[e]})),this.set("credentials",void 0),
this.set("credentialProvider",void 0)},set:function(e,t,r){void 0===t?(void 0===r&&(r=this.keys[e]),
this[e]="function"==typeof r?r.call(this):r):"httpOptions"===e&&this[e]?this[e]=i.util.merge(this[e],t):this[e]=t
},keys:{credentials:null,credentialProvider:null,region:null,logger:null,apiVersions:{},
apiVersion:null,endpoint:void 0,httpOptions:{timeout:12e4},maxRetries:void 0,maxRedirects:10,
paramValidation:!0,sslEnabled:!0,s3ForcePathStyle:!1,s3BucketEndpoint:!1,s3DisableBodySigning:!0,
s3UsEast1RegionalEndpoint:"legacy",s3UseArnRegion:void 0,computeChecksums:!0,
convertResponseTypes:!0,correctClockSkew:!1,customUserAgent:null,dynamoDbCrc32:!0,
systemClockOffset:0,signatureVersion:null,signatureCache:!0,retryDelayOptions:{},
useAccelerateEndpoint:!1,clientSideMonitoring:!1,endpointDiscoveryEnabled:void 0,
endpointCacheSize:1e3,hostPrefixEnabled:!0,stsRegionalEndpoints:"legacy",useFipsEndpoint:!1,
useDualstackEndpoint:!1,token:null},extractCredentials:function(e){
return e.accessKeyId&&e.secretAccessKey&&((e=i.util.copy(e)).credentials=new i.Credentials(e)),e},
setPromisesDependency:function(e){n=e,null===e&&"function"==typeof Promise&&(n=Promise)
var t=[i.Request,i.Credentials,i.CredentialProviderChain]
i.S3&&(t.push(i.S3),i.S3.ManagedUpload&&t.push(i.S3.ManagedUpload)),i.util.addPromises(t,n)},
getPromisesDependency:function(){return n}}),i.config=new i.Config},9132:(e,t,r)=>{var n={
util:r(9019)};({}).toString(),e.exports=n,n.util.update(n,{VERSION:"2.1606.0",Signers:{},Protocol:{
Json:r(3652),Query:r(324),Rest:r(9648),RestJson:r(5897),RestXml:r(5830)},XML:{Builder:r(1838),
Parser:null},JSON:{Builder:r(3681),Parser:r(5919)},Model:{Api:r(9341),Operation:r(6176),
Shape:r(1304),Paginator:r(8910),ResourceWaiter:r(3110)},apiLoader:r(9701),EndpointCache:r(5593).k}),
r(5138),r(5400),r(4089),r(5615),r(5585),r(4002),r(4396),r(4344),r(7383),r(1215),r(2520),
n.events=new n.SequentialExecutor,n.util.memoizedProperty(n,"endpointCache",(function(){
return new n.EndpointCache(n.config.endpointCacheSize)}),!0)},1833:(e,t,r)=>{var n=r(9132)
n.Credentials=n.util.inherit({constructor:function(){
if(n.util.hideProperties(this,["secretAccessKey"]),this.expired=!1,this.expireTime=null,
this.refreshCallbacks=[],1===arguments.length&&"object"==typeof arguments[0]){
var e=arguments[0].credentials||arguments[0]
this.accessKeyId=e.accessKeyId,this.secretAccessKey=e.secretAccessKey,this.sessionToken=e.sessionToken
}else this.accessKeyId=arguments[0],this.secretAccessKey=arguments[1],this.sessionToken=arguments[2]
},expiryWindow:15,needsRefresh:function(){
var e=n.util.date.getDate().getTime(),t=new Date(e+1e3*this.expiryWindow)
return!!(this.expireTime&&t>this.expireTime)||this.expired||!this.accessKeyId||!this.secretAccessKey
},get:function(e){var t=this
this.needsRefresh()?this.refresh((function(r){r||(t.expired=!1),e&&e(r)})):e&&e()},
refresh:function(e){this.expired=!1,e()},coalesceRefresh:function(e,t){var r=this
1===r.refreshCallbacks.push(e)&&r.load((function(e){
n.util.arrayEach(r.refreshCallbacks,(function(r){t?r(e):n.util.defer((function(){r(e)}))})),
r.refreshCallbacks.length=0}))},load:function(e){e()}
}),n.Credentials.addPromisesToClass=function(e){
this.prototype.getPromise=n.util.promisifyMethod("get",e),
this.prototype.refreshPromise=n.util.promisifyMethod("refresh",e)
},n.Credentials.deletePromisesFromClass=function(){delete this.prototype.getPromise,
delete this.prototype.refreshPromise},n.util.addPromises(n.Credentials)},4279:(e,t,r)=>{
var n=r(9132)
n.CredentialProviderChain=n.util.inherit(n.Credentials,{constructor:function(e){
this.providers=e||n.CredentialProviderChain.defaultProviders.slice(0),this.resolveCallbacks=[]},
resolve:function(e){var t=this
if(0===t.providers.length)return e(new Error("No providers")),t
if(1===t.resolveCallbacks.push(e)){var r=0,i=t.providers.slice(0)
!function e(o,a){if(!o&&a||r===i.length)return n.util.arrayEach(t.resolveCallbacks,(function(e){
e(o,a)})),void(t.resolveCallbacks.length=0)
var s=i[r++];(a="function"==typeof s?s.call():s).get?a.get((function(t){e(t,t?null:a)})):e(null,a)
}()}return t}
}),n.CredentialProviderChain.defaultProviders=[],n.CredentialProviderChain.addPromisesToClass=function(e){
this.prototype.resolvePromise=n.util.promisifyMethod("resolve",e)
},n.CredentialProviderChain.deletePromisesFromClass=function(){delete this.prototype.resolvePromise
},n.util.addPromises(n.CredentialProviderChain)},1130:(e,t,r)=>{
var n=r(9132),i=r(9019),o=["AWS_ENABLE_ENDPOINT_DISCOVERY","AWS_ENDPOINT_DISCOVERY_ENABLED"]
function a(e){var t=e.service,r=t.api||{},n=(r.operations,{})
return t.config.region&&(n.region=t.config.region),r.serviceId&&(n.serviceId=r.serviceId),
t.config.credentials.accessKeyId&&(n.accessKeyId=t.config.credentials.accessKeyId),n}
function s(e,t,r){
r&&null!=t&&"structure"===r.type&&r.required&&r.required.length>0&&i.arrayEach(r.required,(function(n){
var i=r.members[n]
if(!0===i.endpointDiscoveryId){var o=i.isLocationName?i.name:n
e[o]=String(t[n])}else s(e,t[n],i)}))}function u(e,t){var r={}
return s(r,e.params,t),r}function c(e){
var t=e.service,r=t.api,o=r.operations?r.operations[e.operation]:void 0,s=u(e,o?o.input:void 0),c=a(e)
Object.keys(s).length>0&&(c=i.update(c,s),o&&(c.operation=o.name))
var p=n.endpointCache.get(c)
if(!p||1!==p.length||""!==p[0].Address)if(p&&p.length>0)e.httpRequest.updateEndpoint(p[0].Address)
else{var l=t.makeRequest(r.endpointOperation,{Operation:o.name,Identifiers:s})
f(l),l.removeListener("validate",n.EventListeners.Core.VALIDATE_PARAMETERS),l.removeListener("retry",n.EventListeners.Core.RETRY_CHECK),
n.endpointCache.put(c,[{Address:"",CachePeriodInMinutes:1}]),l.send((function(e,t){
t&&t.Endpoints?n.endpointCache.put(c,t.Endpoints):e&&n.endpointCache.put(c,[{Address:"",
CachePeriodInMinutes:1}])}))}}var p={}
function l(e,t){
var r=e.service,o=r.api,s=o.operations?o.operations[e.operation]:void 0,c=s?s.input:void 0,l=u(e,c),d=a(e)
Object.keys(l).length>0&&(d=i.update(d,l),s&&(d.operation=s.name))
var h=n.EndpointCache.getKeyString(d),m=n.endpointCache.get(h)
if(m&&1===m.length&&""===m[0].Address)return p[h]||(p[h]=[]),void p[h].push({request:e,callback:t})
if(m&&m.length>0)e.httpRequest.updateEndpoint(m[0].Address),t()
else{var v=r.makeRequest(o.endpointOperation,{Operation:s.name,Identifiers:l})
v.removeListener("validate",n.EventListeners.Core.VALIDATE_PARAMETERS),f(v),n.endpointCache.put(h,[{
Address:"",CachePeriodInMinutes:60}]),v.send((function(r,o){if(r){if(e.response.error=i.error(r,{
retryable:!1}),n.endpointCache.remove(d),p[h]){var a=p[h]
i.arrayEach(a,(function(e){e.request.response.error=i.error(r,{retryable:!1}),e.callback()})),
delete p[h]}
}else o&&(n.endpointCache.put(h,o.Endpoints),e.httpRequest.updateEndpoint(o.Endpoints[0].Address),
p[h])&&(a=p[h],i.arrayEach(a,(function(e){
e.request.httpRequest.updateEndpoint(o.Endpoints[0].Address),e.callback()})),delete p[h])
t()}))}}function f(e){var t=e.service.api.apiVersion
t&&!e.httpRequest.headers["x-amz-api-version"]&&(e.httpRequest.headers["x-amz-api-version"]=t)}
function d(e){var t=e.error,r=e.httpResponse
if(t&&("InvalidEndpointException"===t.code||421===r.statusCode)){
var o=e.request,s=o.service.api.operations||{},c=u(o,s[o.operation]?s[o.operation].input:void 0),p=a(o)
Object.keys(c).length>0&&(p=i.update(p,c),s[o.operation]&&(p.operation=s[o.operation].name)),
n.endpointCache.remove(p)}}function h(e){return["false","0"].indexOf(e)>=0}e.exports={
discoverEndpoint:function(e,t){var r=e.service||{}
if(function(e){
if(e._originalConfig&&e._originalConfig.endpoint&&!0===e._originalConfig.endpointDiscoveryEnabled)throw i.error(new Error,{
code:"ConfigurationException",
message:"Custom endpoint is supplied; endpointDiscoveryEnabled must not be true."})
var t=n.config[e.serviceIdentifier]||{}
return Boolean(n.config.endpoint||t.endpoint||e._originalConfig&&e._originalConfig.endpoint)
}(r)||e.isPresigned())return t()
var a=(r.api.operations||{})[e.operation],s=a?a.endpointDiscoveryRequired:"NULL",u=function(e){
var t=e.service||{}
if(void 0!==t.config.endpointDiscoveryEnabled)return t.config.endpointDiscoveryEnabled
if(!i.isBrowser()){for(var r=0;r<o.length;r++){var a=o[r]
if(Object.prototype.hasOwnProperty.call(process.env,a)){
if(""===process.env[a]||void 0===process.env[a])throw i.error(new Error,{
code:"ConfigurationException",message:"environmental variable "+a+" cannot be set to nothing"})
return!h(process.env[a])}}var s={}
try{s=n.util.iniLoader?n.util.iniLoader.loadFrom({isConfig:!0,
filename:process.env[n.util.sharedConfigFileEnv]}):{}}catch(e){}
var u=s[process.env.AWS_PROFILE||n.util.defaultProfile]||{}
if(Object.prototype.hasOwnProperty.call(u,"endpoint_discovery_enabled")){
if(void 0===u.endpoint_discovery_enabled)throw i.error(new Error,{code:"ConfigurationException",
message:"config file entry 'endpoint_discovery_enabled' cannot be set to nothing"})
return!h(u.endpoint_discovery_enabled)}}}(e),p=r.api.hasRequiredEndpointDiscovery
switch((u||p)&&e.httpRequest.appendToUserAgent("endpoint-discovery"),s){case"OPTIONAL":
(u||p)&&(c(e),e.addNamedListener("INVALIDATE_CACHED_ENDPOINTS","extractError",d)),t()
break
case"REQUIRED":if(!1===u){e.response.error=i.error(new Error,{code:"ConfigurationException",
message:"Endpoint Discovery is disabled but "+r.api.className+"."+e.operation+"() requires it. Please check your configurations."
}),t()
break}e.addNamedListener("INVALIDATE_CACHED_ENDPOINTS","extractError",d),l(e,t)
break
default:t()}},requiredDiscoverEndpoint:l,optionalDiscoverEndpoint:c,marshallCustomIdentifiers:u,
getCacheKey:a,invalidateCachedEndpoint:d}},5585:(e,t,r)=>{
var n=r(9132),i=r(5138),o=r(1130).discoverEndpoint
function a(e){if(!e.service.api.operations)return""
var t=e.service.api.operations[e.operation]
return t?t.authtype:""}function s(e){var t=e.service
return t.config.signatureVersion?t.config.signatureVersion:t.api.signatureVersion?t.api.signatureVersion:a(e)
}n.EventListeners={Core:{}},n.EventListeners={Core:(new i).addNamedListeners((function(e,t){
t("VALIDATE_CREDENTIALS","validate",(function(e,t){
if(!e.service.api.signatureVersion&&!e.service.config.signatureVersion)return t()
"bearer"!==s(e)?e.service.config.getCredentials((function(r){r&&(e.response.error=n.util.error(r,{
code:"CredentialsError",
message:"Missing credentials in config, if using AWS_CONFIG_FILE, set AWS_SDK_LOAD_CONFIG=1"})),t()
})):e.service.config.getToken((function(r){r&&(e.response.error=n.util.error(r,{code:"TokenError"
})),t()}))})),e("VALIDATE_REGION","validate",(function(e){if(!e.service.isGlobalEndpoint){
var t=new RegExp(/^([a-zA-Z0-9]|[a-zA-Z0-9][a-zA-Z0-9-]{0,61}[a-zA-Z0-9])$/)
e.service.config.region?t.test(e.service.config.region)||(e.response.error=n.util.error(new Error,{
code:"ConfigError",message:"Invalid region in config"})):e.response.error=n.util.error(new Error,{
code:"ConfigError",message:"Missing region in config"})}
})),e("BUILD_IDEMPOTENCY_TOKENS","validate",(function(e){if(e.service.api.operations){
var t=e.service.api.operations[e.operation]
if(t){var r=t.idempotentMembers
if(r.length){
for(var i=n.util.copy(e.params),o=0,a=r.length;o<a;o++)i[r[o]]||(i[r[o]]=n.util.uuid.v4())
e.params=i}}}})),e("VALIDATE_PARAMETERS","validate",(function(e){if(e.service.api.operations){
var t=e.service.api.operations[e.operation].input,r=e.service.config.paramValidation
new n.ParamValidator(r).validate(t,e.params)}})),e("COMPUTE_CHECKSUM","afterBuild",(function(e){
if(e.service.api.operations){var t=e.service.api.operations[e.operation]
if(t){
var r=e.httpRequest.body,i=r&&(n.util.Buffer.isBuffer(r)||"string"==typeof r),o=e.httpRequest.headers
if(t.httpChecksumRequired&&e.service.config.computeChecksums&&i&&!o["Content-MD5"]){
var a=n.util.crypto.md5(r,"base64")
o["Content-MD5"]=a}}}})),t("COMPUTE_SHA256","afterBuild",(function(e,t){if(e.haltHandlersOnError(),
e.service.api.operations){var r=e.service.api.operations[e.operation],i=r?r.authtype:""
if(!e.service.api.signatureVersion&&!i&&!e.service.config.signatureVersion)return t()
if(e.service.getSignerClass(e)===n.Signers.V4){var o=e.httpRequest.body||""
if(i.indexOf("unsigned-body")>=0)return e.httpRequest.headers["X-Amz-Content-Sha256"]="UNSIGNED-PAYLOAD",
t()
n.util.computeSha256(o,(function(r,n){r?t(r):(e.httpRequest.headers["X-Amz-Content-Sha256"]=n,t())
}))}else t()}})),e("SET_CONTENT_LENGTH","afterBuild",(function(e){
var t=a(e),r=n.util.getRequestPayloadShape(e)
if(void 0===e.httpRequest.headers["Content-Length"])try{
var i=n.util.string.byteLength(e.httpRequest.body)
e.httpRequest.headers["Content-Length"]=i}catch(n){if(r&&r.isStreaming){if(r.requiresLength)throw n
if(t.indexOf("unsigned-body")>=0)return void(e.httpRequest.headers["Transfer-Encoding"]="chunked")
throw n}throw n}})),e("SET_HTTP_HOST","afterBuild",(function(e){
e.httpRequest.headers.Host=e.httpRequest.endpoint.host
})),e("SET_TRACE_ID","afterBuild",(function(e){var t="X-Amzn-Trace-Id"
if(n.util.isNode()&&!Object.hasOwnProperty.call(e.httpRequest.headers,t)){
var r=process.env.AWS_LAMBDA_FUNCTION_NAME,i=process.env._X_AMZN_TRACE_ID
"string"==typeof r&&r.length>0&&"string"==typeof i&&i.length>0&&(e.httpRequest.headers[t]=i)}})),
e("RESTART","restart",(function(){var e=this.response.error
e&&e.retryable&&(this.httpRequest=new n.HttpRequest(this.service.endpoint,this.service.region),
this.response.retryCount<this.service.config.maxRetries?this.response.retryCount++:this.response.error=null)
})),t("DISCOVER_ENDPOINT","sign",o,!0),t("SIGN","sign",(function(e,t){var r=e.service,n=s(e)
if(!n||0===n.length)return t()
"bearer"===n?r.config.getToken((function(n,i){if(n)return e.response.error=n,t()
try{new(r.getSignerClass(e))(e.httpRequest).addAuthorization(i)}catch(t){e.response.error=t}t()
})):r.config.getCredentials((function(n,i){if(n)return e.response.error=n,t()
try{
var o=r.getSkewCorrectedDate(),a=r.getSignerClass(e),s=(e.service.api.operations||{})[e.operation],u=new a(e.httpRequest,r.getSigningName(e),{
signatureCache:r.config.signatureCache,operation:s,signatureVersion:r.api.signatureVersion})
u.setServiceClientId(r._clientId),delete e.httpRequest.headers.Authorization,delete e.httpRequest.headers.Date,
delete e.httpRequest.headers["X-Amz-Date"],u.addAuthorization(i,o),e.signedAt=o}catch(t){
e.response.error=t}t()}))})),e("VALIDATE_RESPONSE","validateResponse",(function(e){
this.service.successfulResponse(e,this)?(e.data={},
e.error=null):(e.data=null,e.error=n.util.error(new Error,{code:"UnknownError",
message:"An unknown error occurred."}))})),e("ERROR","error",(function(e,t){
if(t.request.service.api.awsQueryCompatible){
var r=t.httpResponse.headers,n=r?r["x-amzn-query-error"]:void 0
n&&n.includes(";")&&(t.error.code=n.split(";")[0])}}),!0),t("SEND","send",(function(e,t){
function r(r){e.httpResponse.stream=r
var i=e.request.httpRequest.stream,o=e.request.service,a=o.api,s=e.request.operation,u=a.operations[s]||{}
r.on("headers",(function(i,a,s){
if(e.request.emit("httpHeaders",[i,a,e,s]),!e.httpResponse.streaming)if(2===n.HttpClient.streamsApiVersion){
if(u.hasEventOutput&&o.successfulResponse(e))return e.request.emit("httpDone"),void t()
r.on("readable",(function(){var t=r.read()
null!==t&&e.request.emit("httpData",[t,e])}))}else r.on("data",(function(t){
e.request.emit("httpData",[t,e])}))})),r.on("end",(function(){if(!i||!i.didCallback){
if(2===n.HttpClient.streamsApiVersion&&u.hasEventOutput&&o.successfulResponse(e))return
e.request.emit("httpDone"),t()}}))}function i(r){if("RequestAbortedError"!==r.code){
var i="TimeoutError"===r.code?r.code:"NetworkingError"
r=n.util.error(r,{code:i,region:e.request.httpRequest.region,
hostname:e.request.httpRequest.endpoint.hostname,retryable:!0})}
e.error=r,e.request.emit("httpError",[e.error,e],(function(){t()}))}function o(){
var t,o=n.HttpClient.getInstance(),a=e.request.service.config.httpOptions||{}
try{(t=o.handleRequest(e.request.httpRequest,a,r,i)).on("sendProgress",(function(t){
e.request.emit("httpUploadProgress",[t,e])})),t.on("receiveProgress",(function(t){
e.request.emit("httpDownloadProgress",[t,e])}))}catch(e){i(e)}}e.httpResponse._abortCallback=t,
e.error=null,
e.data=null,(e.request.service.getSkewCorrectedDate()-this.signedAt)/1e3>=600?this.emit("sign",[this],(function(e){
e?t(e):o()})):o()})),e("HTTP_HEADERS","httpHeaders",(function(e,t,r,i){r.httpResponse.statusCode=e,
r.httpResponse.statusMessage=i,
r.httpResponse.headers=t,r.httpResponse.body=n.util.buffer.toBuffer(""),r.httpResponse.buffers=[],
r.httpResponse.numBytes=0
var o=t.date||t.Date,a=r.request.service
if(o){var s=Date.parse(o)
a.config.correctClockSkew&&a.isClockSkewed(s)&&a.applyClockOffset(s)}
})),e("HTTP_DATA","httpData",(function(e,t){if(e){if(n.util.isNode()){
t.httpResponse.numBytes+=e.length
var r=t.httpResponse.headers["content-length"],i={loaded:t.httpResponse.numBytes,total:r}
t.request.emit("httpDownloadProgress",[i,t])}t.httpResponse.buffers.push(n.util.buffer.toBuffer(e))}
})),e("HTTP_DONE","httpDone",(function(e){
if(e.httpResponse.buffers&&e.httpResponse.buffers.length>0){
var t=n.util.buffer.concat(e.httpResponse.buffers)
e.httpResponse.body=t}delete e.httpResponse.numBytes,delete e.httpResponse.buffers})),
e("FINALIZE_ERROR","retry",(function(e){
e.httpResponse.statusCode&&(e.error.statusCode=e.httpResponse.statusCode,
void 0===e.error.retryable&&(e.error.retryable=this.service.retryableError(e.error,this)))})),
e("INVALIDATE_CREDENTIALS","retry",(function(e){if(e.error)switch(e.error.code){
case"RequestExpired":case"ExpiredTokenException":case"ExpiredToken":e.error.retryable=!0,
e.request.service.config.credentials.expired=!0}})),e("EXPIRED_SIGNATURE","retry",(function(e){
var t=e.error
t&&"string"==typeof t.code&&"string"==typeof t.message&&t.code.match(/Signature/)&&t.message.match(/expired/)&&(e.error.retryable=!0)
})),e("CLOCK_SKEWED","retry",(function(e){
e.error&&this.service.clockSkewError(e.error)&&this.service.config.correctClockSkew&&(e.error.retryable=!0)
})),e("REDIRECT","retry",(function(e){
e.error&&e.error.statusCode>=300&&e.error.statusCode<400&&e.httpResponse.headers.location&&(this.httpRequest.endpoint=new n.Endpoint(e.httpResponse.headers.location),
this.httpRequest.headers.Host=this.httpRequest.endpoint.host,
this.httpRequest.path=this.httpRequest.endpoint.path,e.error.redirect=!0,e.error.retryable=!0)})),
e("RETRY_CHECK","retry",(function(e){
e.error&&(e.error.redirect&&e.redirectCount<e.maxRedirects?e.error.retryDelay=0:e.retryCount<e.maxRetries&&(e.error.retryDelay=this.service.retryDelays(e.retryCount,e.error)||0))
})),t("RESET_RETRY_STATE","afterRetry",(function(e,t){var r,n=!1
e.error&&(r=e.error.retryDelay||0,e.error.retryable&&e.retryCount<e.maxRetries?(e.retryCount++,
n=!0):e.error.redirect&&e.redirectCount<e.maxRedirects&&(e.redirectCount++,n=!0)),
n&&r>=0?(e.error=null,setTimeout(t,r)):t()}))})),CorePost:(new i).addNamedListeners((function(e){
e("EXTRACT_REQUEST_ID","extractData",n.util.extractRequestId),
e("EXTRACT_REQUEST_ID","extractError",n.util.extractRequestId),
e("ENOTFOUND_ERROR","httpError",(function(e){if("NetworkingError"===e.code&&function(e){
return"ENOTFOUND"===e.errno||"number"==typeof e.errno&&"function"==typeof n.util.getSystemErrorName&&["EAI_NONAME","EAI_NODATA"].indexOf(n.util.getSystemErrorName(e.errno)>=0)
}(e)){
var t="Inaccessible host: `"+e.hostname+"' at port `"+e.port+"'. This service may not be available in the `"+e.region+"' region."
this.response.error=n.util.error(new Error(t),{code:"UnknownEndpoint",region:e.region,
hostname:e.hostname,retryable:!0,originalError:e})}}))})),
Logger:(new i).addNamedListeners((function(e){e("LOG_REQUEST","complete",(function(e){
var t=e.request,i=t.service.config.logger
if(i){var o=function(){
var o=(e.request.service.getSkewCorrectedDate().getTime()-t.startTime.getTime())/1e3,s=!!i.isTTY,u=e.httpResponse.statusCode,c=t.params
t.service.api.operations&&t.service.api.operations[t.operation]&&t.service.api.operations[t.operation].input&&(c=a(t.service.api.operations[t.operation].input,t.params))
var p=r(537).inspect(c,!0,null),l=""
return s&&(l+="[33m"),l+="[AWS "+t.service.serviceIdentifier+" "+u,l+=" "+o.toString()+"s "+e.retryCount+" retries]",
s&&(l+="[0;1m"),l+=" "+n.util.string.lowerFirst(t.operation),l+="("+p+")",s&&(l+="[0m"),l}()
"function"==typeof i.log?i.log(o):"function"==typeof i.write&&i.write(o+"\n")}function a(e,t){
if(!t)return t
if(e.isSensitive)return"***SensitiveInformation***"
switch(e.type){case"structure":var r={}
return n.util.each(t,(function(t,n){
Object.prototype.hasOwnProperty.call(e.members,t)?r[t]=a(e.members[t],n):r[t]=n})),r
case"list":var i=[]
return n.util.arrayEach(t,(function(t,r){i.push(a(e.member,t))})),i
case"map":var o={}
return n.util.each(t,(function(t,r){o[t]=a(e.value,r)})),o
default:return t}}}))})),Json:(new i).addNamedListeners((function(e){var t=r(3652)
e("BUILD","build",t.buildRequest),e("EXTRACT_DATA","extractData",t.extractData),
e("EXTRACT_ERROR","extractError",t.extractError)})),Rest:(new i).addNamedListeners((function(e){
var t=r(9648)
e("BUILD","build",t.buildRequest),e("EXTRACT_DATA","extractData",t.extractData),
e("EXTRACT_ERROR","extractError",t.extractError)})),RestJson:(new i).addNamedListeners((function(e){
var t=r(5897)
e("BUILD","build",t.buildRequest),e("EXTRACT_DATA","extractData",t.extractData),
e("EXTRACT_ERROR","extractError",t.extractError),
e("UNSET_CONTENT_LENGTH","afterBuild",t.unsetContentLength)})),
RestXml:(new i).addNamedListeners((function(e){var t=r(5830)
e("BUILD","build",t.buildRequest),e("EXTRACT_DATA","extractData",t.extractData),
e("EXTRACT_ERROR","extractError",t.extractError)})),Query:(new i).addNamedListeners((function(e){
var t=r(324)
e("BUILD","build",t.buildRequest),e("EXTRACT_DATA","extractData",t.extractData),
e("EXTRACT_ERROR","extractError",t.extractError)}))}},5615:(e,t,r)=>{var n=r(9132),i=n.util.inherit
n.Endpoint=i({constructor:function(e,t){
if(n.util.hideProperties(this,["slashes","auth","hash","search","query"]),
null==e)throw new Error("Invalid endpoint: "+e)
if("string"!=typeof e)return n.util.copy(e)
e.match(/^http/)||(e=((t&&void 0!==t.sslEnabled?t.sslEnabled:n.config.sslEnabled)?"https":"http")+"://"+e),
n.util.update(this,n.util.urlParse(e)),
this.port?this.port=parseInt(this.port,10):this.port="https:"===this.protocol?443:80}}),
n.HttpRequest=i({constructor:function(e,t){e=new n.Endpoint(e),this.method="POST",
this.path=e.path||"/",this.headers={},this.body="",this.endpoint=e,this.region=t,this._userAgent="",
this.setUserAgent()},setUserAgent:function(){
this._userAgent=this.headers[this.getUserAgentHeaderName()]=n.util.userAgent()},
getUserAgentHeaderName:function(){return(n.util.isBrowser()?"X-Amz-":"")+"User-Agent"},
appendToUserAgent:function(e){
"string"==typeof e&&e&&(this._userAgent+=" "+e),this.headers[this.getUserAgentHeaderName()]=this._userAgent
},getUserAgent:function(){return this._userAgent},pathname:function(){
return this.path.split("?",1)[0]},search:function(){var e=this.path.split("?",2)[1]
return e?(e=n.util.queryStringParse(e),n.util.queryParamsToString(e)):""},
updateEndpoint:function(e){var t=new n.Endpoint(e)
this.endpoint=t,this.path=t.path||"/",this.headers.Host&&(this.headers.Host=t.host)}}),
n.HttpResponse=i({constructor:function(){this.statusCode=void 0,this.headers={},this.body=void 0,
this.streaming=!1,this.stream=null},createUnbufferedStream:function(){return this.streaming=!0,
this.stream}}),n.HttpClient=i({}),n.HttpClient.getInstance=function(){
return void 0===this.singleton&&(this.singleton=new this),this.singleton}},3681:(e,t,r)=>{
var n=r(9019)
function i(){}function o(e,t){if(t&&null!=e)switch(t.type){case"structure":return function(e,t){
if(t.isDocument)return e
var r={}
return n.each(e,(function(e,n){var i=t.members[e]
if(i){if("body"!==i.location)return
var a=i.isLocationName?i.name:e,s=o(n,i)
void 0!==s&&(r[a]=s)}})),r}(e,t)
case"map":return function(e,t){var r={}
return n.each(e,(function(e,n){var i=o(n,t.value)
void 0!==i&&(r[e]=i)})),r}(e,t)
case"list":return function(e,t){var r=[]
return n.arrayEach(e,(function(e){var n=o(e,t.member)
void 0!==n&&r.push(n)})),r}(e,t)
default:return function(e,t){return t.toWireFormat(e)}(e,t)}}i.prototype.build=function(e,t){
return JSON.stringify(o(e,t))},e.exports=i},5919:(e,t,r)=>{var n=r(9019)
function i(){}function o(e,t){if(t&&void 0!==e)switch(t.type){case"structure":return function(e,t){
if(null!=e){if(t.isDocument)return e
var r={},i=t.members,a=t.api&&t.api.awsQueryCompatible
return n.each(i,(function(t,n){var i=n.isLocationName?n.name:t
if(Object.prototype.hasOwnProperty.call(e,i)){var s=o(e[i],n)
void 0!==s&&(r[t]=s)
}else a&&n.defaultValue&&"list"===n.type&&(r[t]="function"==typeof n.defaultValue?n.defaultValue():n.defaultValue)
})),r}}(e,t)
case"map":return function(e,t){if(null!=e){var r={}
return n.each(e,(function(e,n){var i=o(n,t.value)
r[e]=void 0===i?null:i})),r}}(e,t)
case"list":return function(e,t){if(null!=e){var r=[]
return n.arrayEach(e,(function(e){var n=o(e,t.member)
void 0===n?r.push(null):r.push(n)})),r}}(e,t)
default:return function(e,t){return t.toType(e)}(e,t)}}i.prototype.parse=function(e,t){
return o(JSON.parse(e),t)},e.exports=i},2520:e=>{
var t=["The AWS SDK for JavaScript (v2) will enter maintenance mode","on September 8, 2024 and reach end-of-support on September 8, 2025.\n","Please migrate your code to use AWS SDK for JavaScript (v3).","For more information, check blog post at https://a.co/cUPnyil"].join("\n")
e.exports={suppress:!1},setTimeout((function(){
e.exports.suppress||"undefined"!=typeof process&&("object"==typeof process.env&&void 0!==process.env.AWS_EXECUTION_ENV&&0===process.env.AWS_EXECUTION_ENV.indexOf("AWS_Lambda_")||"object"==typeof process.env&&void 0!==process.env.AWS_SDK_JS_SUPPRESS_MAINTENANCE_MODE_MESSAGE||"function"==typeof process.emitWarning&&process.emitWarning(t,{
type:"NOTE"}))}),0)},9341:(e,t,r)=>{
var n=r(6737),i=r(6176),o=r(1304),a=r(8910),s=r(3110),u=r(5087),c=r(9019),p=c.property,l=c.memoizedProperty
e.exports=function(e,t){var r=this
e=e||{},(t=t||{}).api=this,e.metadata=e.metadata||{}
var f=t.serviceIdentifier
delete t.serviceIdentifier,p(this,"isApi",!0,!1),p(this,"apiVersion",e.metadata.apiVersion),
p(this,"endpointPrefix",e.metadata.endpointPrefix),p(this,"signingName",e.metadata.signingName),
p(this,"globalEndpoint",e.metadata.globalEndpoint),
p(this,"signatureVersion",e.metadata.signatureVersion),p(this,"jsonVersion",e.metadata.jsonVersion),
p(this,"targetPrefix",e.metadata.targetPrefix),p(this,"protocol",e.metadata.protocol),
p(this,"timestampFormat",e.metadata.timestampFormat),
p(this,"xmlNamespaceUri",e.metadata.xmlNamespace),
p(this,"abbreviation",e.metadata.serviceAbbreviation),p(this,"fullName",e.metadata.serviceFullName),
p(this,"serviceId",e.metadata.serviceId),
f&&u[f]&&p(this,"xmlNoDefaultLists",u[f].xmlNoDefaultLists,!1),l(this,"className",(function(){
var t=e.metadata.serviceAbbreviation||e.metadata.serviceFullName
return t?("ElasticLoadBalancing"===(t=t.replace(/^Amazon|AWS\s*|\(.*|\s+|\W+/g,""))&&(t="ELB"),
t):null})),p(this,"operations",new n(e.operations,t,(function(e,r){return new i(e,r,t)
}),c.string.lowerFirst,(function(e,t){
!0===t.endpointoperation&&p(r,"endpointOperation",c.string.lowerFirst(e)),
t.endpointdiscovery&&!r.hasRequiredEndpointDiscovery&&p(r,"hasRequiredEndpointDiscovery",!0===t.endpointdiscovery.required)
}))),p(this,"shapes",new n(e.shapes,t,(function(e,r){return o.create(r,t)
}))),p(this,"paginators",new n(e.paginators,t,(function(e,r){return new a(e,r,t)}))),
p(this,"waiters",new n(e.waiters,t,(function(e,r){return new s(e,r,t)}),c.string.lowerFirst)),
t.documentation&&(p(this,"documentation",e.documentation),
p(this,"documentationUrl",e.documentationUrl)),
p(this,"awsQueryCompatible",e.metadata.awsQueryCompatible)}},6737:(e,t,r)=>{
var n=r(9019).memoizedProperty
function i(e,t,r,i){n(this,i(e),(function(){return r(e,t)}))}e.exports=function(e,t,r,n,o){
for(var a in n=n||String,e)Object.prototype.hasOwnProperty.call(e,a)&&(i.call(this,a,e[a],r,n),
o&&o(a,e[a]))}},6176:(e,t,r)=>{var n=r(1304),i=r(9019),o=i.property,a=i.memoizedProperty
e.exports=function(e,t,r){var i=this
r=r||{},o(this,"name",t.name||e),o(this,"api",r.api,!1),t.http=t.http||{},o(this,"endpoint",t.endpoint),
o(this,"httpMethod",t.http.method||"POST"),o(this,"httpPath",t.http.requestUri||"/"),
o(this,"authtype",t.authtype||""),
o(this,"endpointDiscoveryRequired",t.endpointdiscovery?t.endpointdiscovery.required?"REQUIRED":"OPTIONAL":"NULL")
var s=t.httpChecksumRequired||t.httpChecksum&&t.httpChecksum.requestChecksumRequired
o(this,"httpChecksumRequired",s,!1),a(this,"input",(function(){
return t.input?n.create(t.input,r):new n.create({type:"structure"},r)
})),a(this,"output",(function(){return t.output?n.create(t.output,r):new n.create({type:"structure"
},r)})),a(this,"errors",(function(){var e=[]
if(!t.errors)return null
for(var i=0;i<t.errors.length;i++)e.push(n.create(t.errors[i],r))
return e})),a(this,"paginator",(function(){return r.api.paginators[e]
})),r.documentation&&(o(this,"documentation",t.documentation),
o(this,"documentationUrl",t.documentationUrl)),a(this,"idempotentMembers",(function(){
var e=[],t=i.input,r=t.members
if(!t.members)return e
for(var n in r)r.hasOwnProperty(n)&&!0===r[n].isIdempotent&&e.push(n)
return e})),a(this,"hasEventOutput",(function(){return function(e){var t=e.members,r=e.payload
if(!e.members)return!1
if(r)return t[r].isEventStream
for(var n in t)if(!t.hasOwnProperty(n)&&!0===t[n].isEventStream)return!0
return!1}(i.output)}))}},8910:(e,t,r)=>{var n=r(9019).property
e.exports=function(e,t){n(this,"inputToken",t.input_token),n(this,"limitKey",t.limit_key),
n(this,"moreResults",t.more_results),
n(this,"outputToken",t.output_token),n(this,"resultKey",t.result_key)}},3110:(e,t,r)=>{
var n=r(9019),i=n.property
e.exports=function(e,t,r){
r=r||{},i(this,"name",e),i(this,"api",r.api,!1),t.operation&&i(this,"operation",n.string.lowerFirst(t.operation))
var o=this;["type","description","delay","maxAttempts","acceptors"].forEach((function(e){var r=t[e]
r&&i(o,e,r)}))}},1304:(e,t,r)=>{var n=r(6737),i=r(9019)
function o(e,t,r){null!=r&&i.property.apply(this,arguments)}function a(e,t){
e.constructor.prototype[t]||i.memoizedProperty.apply(this,arguments)}function s(e,t,r){t=t||{},
o(this,"shape",e.shape),o(this,"api",t.api,!1),o(this,"type",e.type),o(this,"enum",e.enum),
o(this,"min",e.min),
o(this,"max",e.max),o(this,"pattern",e.pattern),o(this,"location",e.location||this.location||"body"),
o(this,"name",this.name||e.xmlName||e.queryName||e.locationName||r),
o(this,"isStreaming",e.streaming||this.isStreaming||!1),
o(this,"requiresLength",e.requiresLength,!1),o(this,"isComposite",e.isComposite||!1),
o(this,"isShape",!0,!1),
o(this,"isQueryName",Boolean(e.queryName),!1),o(this,"isLocationName",Boolean(e.locationName),!1),
o(this,"isIdempotent",!0===e.idempotencyToken),o(this,"isJsonValue",!0===e.jsonvalue),
o(this,"isSensitive",!0===e.sensitive||e.prototype&&!0===e.prototype.sensitive),
o(this,"isEventStream",Boolean(e.eventstream),!1),o(this,"isEvent",Boolean(e.event),!1),
o(this,"isEventPayload",Boolean(e.eventpayload),!1),
o(this,"isEventHeader",Boolean(e.eventheader),!1),
o(this,"isTimestampFormatSet",Boolean(e.timestampFormat)||e.prototype&&!0===e.prototype.isTimestampFormatSet,!1),
o(this,"endpointDiscoveryId",Boolean(e.endpointdiscoveryid),!1),
o(this,"hostLabel",Boolean(e.hostLabel),!1),
t.documentation&&(o(this,"documentation",e.documentation),
o(this,"documentationUrl",e.documentationUrl)),
e.xmlAttribute&&o(this,"isXmlAttribute",e.xmlAttribute||!1),o(this,"defaultValue",null),
this.toWireFormat=function(e){return null==e?"":e},this.toType=function(e){return e}}function u(e){
s.apply(this,arguments),o(this,"isComposite",!0),e.flattened&&o(this,"flattened",e.flattened||!1)}
function c(e,t){var r=this,i=null,c=!this.isShape
u.apply(this,arguments),c&&(o(this,"defaultValue",(function(){return{}})),o(this,"members",{}),
o(this,"memberNames",[]),o(this,"required",[]),o(this,"isRequired",(function(){return!1})),
o(this,"isDocument",Boolean(e.document))),
e.members&&(o(this,"members",new n(e.members,t,(function(e,r){return s.create(r,t,e)}))),
a(this,"memberNames",(function(){return e.xmlOrder||Object.keys(e.members)
})),e.event&&(a(this,"eventPayloadMemberName",(function(){
for(var e=r.members,t=r.memberNames,n=0,i=t.length;n<i;n++)if(e[t[n]].isEventPayload)return t[n]})),
a(this,"eventHeaderMemberNames",(function(){
for(var e=r.members,t=r.memberNames,n=[],i=0,o=t.length;i<o;i++)e[t[i]].isEventHeader&&n.push(t[i])
return n})))),e.required&&(o(this,"required",e.required),o(this,"isRequired",(function(t){if(!i){
i={}
for(var r=0;r<e.required.length;r++)i[e.required[r]]=!0}return i[t]
}),!1,!0)),o(this,"resultWrapper",e.resultWrapper||null),e.payload&&o(this,"payload",e.payload),
"string"==typeof e.xmlNamespace?o(this,"xmlNamespaceUri",e.xmlNamespace):"object"==typeof e.xmlNamespace&&(o(this,"xmlNamespacePrefix",e.xmlNamespace.prefix),
o(this,"xmlNamespaceUri",e.xmlNamespace.uri))}function p(e,t){var r=this,n=!this.isShape
if(u.apply(this,arguments),n&&o(this,"defaultValue",(function(){return[]
})),e.member&&a(this,"member",(function(){return s.create(e.member,t)})),this.flattened){
var i=this.name
a(this,"name",(function(){return r.member.name||i}))}}function l(e,t){var r=!this.isShape
u.apply(this,arguments),r&&(o(this,"defaultValue",(function(){return{}})),o(this,"key",s.create({
type:"string"},t)),o(this,"value",s.create({type:"string"},t))),e.key&&a(this,"key",(function(){
return s.create(e.key,t)})),e.value&&a(this,"value",(function(){return s.create(e.value,t)}))}
function f(){s.apply(this,arguments)
var e=["rest-xml","query","ec2"]
this.toType=function(t){return t=this.api&&e.indexOf(this.api.protocol)>-1?t||"":t,
this.isJsonValue?JSON.parse(t):t&&"function"==typeof t.toString?t.toString():t},
this.toWireFormat=function(e){return this.isJsonValue?JSON.stringify(e):e}}function d(){
s.apply(this,arguments),this.toType=function(e){var t=i.base64.decode(e)
if(this.isSensitive&&i.isNode()&&"function"==typeof i.Buffer.alloc){var r=i.Buffer.alloc(t.length,t)
t.fill(0),t=r}return t},this.toWireFormat=i.base64.encode}function h(){d.apply(this,arguments)}
function m(){s.apply(this,arguments),this.toType=function(e){
return"boolean"==typeof e?e:null==e?null:"true"===e}}s.normalizedTypes={character:"string",
double:"float",long:"integer",short:"integer",biginteger:"integer",bigdecimal:"float",blob:"binary"
},s.types={structure:c,list:p,map:l,boolean:m,timestamp:function(e){var t=this
if(s.apply(this,arguments),e.timestampFormat)o(this,"timestampFormat",e.timestampFormat)
else if(t.isTimestampFormatSet&&this.timestampFormat)o(this,"timestampFormat",this.timestampFormat)
else if("header"===this.location)o(this,"timestampFormat","rfc822")
else if("querystring"===this.location)o(this,"timestampFormat","iso8601")
else if(this.api)switch(this.api.protocol){case"json":case"rest-json":
o(this,"timestampFormat","unixTimestamp")
break
case"rest-xml":case"query":case"ec2":o(this,"timestampFormat","iso8601")}this.toType=function(e){
return null==e?null:"function"==typeof e.toUTCString?e:"string"==typeof e||"number"==typeof e?i.date.parseTimestamp(e):null
},this.toWireFormat=function(e){return i.date.format(e,t.timestampFormat)}},float:function(){
s.apply(this,arguments),this.toType=function(e){return null==e?null:parseFloat(e)},
this.toWireFormat=this.toType},integer:function(){s.apply(this,arguments),this.toType=function(e){
return null==e?null:parseInt(e,10)},this.toWireFormat=this.toType},string:f,base64:h,binary:d},
s.resolve=function(e,t){if(e.shape){var r=t.api.shapes[e.shape]
if(!r)throw new Error("Cannot find shape reference: "+e.shape)
return r}return null},s.create=function(e,t,r){if(e.isShape)return e
var n=s.resolve(e,t)
if(n){var i=Object.keys(e)
t.documentation||(i=i.filter((function(e){return!e.match(/documentation/)})))
var o=function(){n.constructor.call(this,e,t,r)}
return o.prototype=n,new o}
e.type||(e.members?e.type="structure":e.member?e.type="list":e.key?e.type="map":e.type="string")
var a=e.type
if(s.normalizedTypes[e.type]&&(e.type=s.normalizedTypes[e.type]),s.types[e.type])return new s.types[e.type](e,t,r)
throw new Error("Unrecognized shape type: "+a)},s.shapes={StructureShape:c,ListShape:p,MapShape:l,
StringShape:f,BooleanShape:m,Base64Shape:h},e.exports=s},1215:(e,t,r)=>{var n=r(9132)
n.ParamValidator=n.util.inherit({constructor:function(e){!0!==e&&void 0!==e||(e={min:!0}),
this.validation=e},validate:function(e,t,r){
if(this.errors=[],this.validateMember(e,t||{},r||"params"),this.errors.length>1){
var i=this.errors.join("\n* ")
throw i="There were "+this.errors.length+" validation errors:\n* "+i,n.util.error(new Error(i),{
code:"MultipleValidationErrors",errors:this.errors})}if(1===this.errors.length)throw this.errors[0]
return!0},fail:function(e,t){this.errors.push(n.util.error(new Error(t),{code:e}))},
validateStructure:function(e,t,r){if(e.isDocument)return!0
var n
this.validateType(t,r,["object"],"structure")
for(var i=0;e.required&&i<e.required.length;i++)null==t[n=e.required[i]]&&this.fail("MissingRequiredParameter","Missing required key '"+n+"' in "+r)
for(n in t)if(Object.prototype.hasOwnProperty.call(t,n)){var o=t[n],a=e.members[n]
if(void 0!==a){var s=[r,n].join(".")
this.validateMember(a,o,s)
}else null!=o&&this.fail("UnexpectedParameter","Unexpected key '"+n+"' found in "+r)}return!0},
validateMember:function(e,t,r){switch(e.type){case"structure":return this.validateStructure(e,t,r)
case"list":return this.validateList(e,t,r)
case"map":return this.validateMap(e,t,r)
default:return this.validateScalar(e,t,r)}},validateList:function(e,t,r){
if(this.validateType(t,r,[Array])){this.validateRange(e,t.length,r,"list member count")
for(var n=0;n<t.length;n++)this.validateMember(e.member,t[n],r+"["+n+"]")}},
validateMap:function(e,t,r){if(this.validateType(t,r,["object"],"map")){var n=0
for(var i in t)Object.prototype.hasOwnProperty.call(t,i)&&(this.validateMember(e.key,i,r+"[key='"+i+"']"),
this.validateMember(e.value,t[i],r+"['"+i+"']"),n++)
this.validateRange(e,n,r,"map member count")}},validateScalar:function(e,t,r){switch(e.type){
case null:case void 0:case"string":return this.validateString(e,t,r)
case"base64":case"binary":return this.validatePayload(t,r)
case"integer":case"float":return this.validateNumber(e,t,r)
case"boolean":return this.validateType(t,r,["boolean"])
case"timestamp":
return this.validateType(t,r,[Date,/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(\.\d+)?Z$/,"number"],"Date object, ISO-8601 string, or a UNIX timestamp")
default:return this.fail("UnkownType","Unhandled type "+e.type+" for "+r)}},
validateString:function(e,t,r){var n=["string"]
e.isJsonValue&&(n=n.concat(["number","object","boolean"])),null!==t&&this.validateType(t,r,n)&&(this.validateEnum(e,t,r),
this.validateRange(e,t.length,r,"string length"),
this.validatePattern(e,t,r),this.validateUri(e,t,r))},validateUri:function(e,t,r){
"uri"===e.location&&0===t.length&&this.fail("UriParameterError",'Expected uri parameter to have length >= 1, but found "'+t+'" for '+r)
},validatePattern:function(e,t,r){
this.validation.pattern&&void 0!==e.pattern&&(new RegExp(e.pattern).test(t)||this.fail("PatternMatchError",'Provided value "'+t+'" does not match regex pattern /'+e.pattern+"/ for "+r))
},validateRange:function(e,t,r,n){
this.validation.min&&void 0!==e.min&&t<e.min&&this.fail("MinRangeError","Expected "+n+" >= "+e.min+", but found "+t+" for "+r),
this.validation.max&&void 0!==e.max&&t>e.max&&this.fail("MaxRangeError","Expected "+n+" <= "+e.max+", but found "+t+" for "+r)
},validateEnum:function(e,t,r){
this.validation.enum&&void 0!==e.enum&&-1===e.enum.indexOf(t)&&this.fail("EnumError","Found string value of "+t+", but expected "+e.enum.join("|")+" for "+r)
},validateType:function(e,t,r,i){if(null==e)return!1
for(var o=!1,a=0;a<r.length;a++){if("string"==typeof r[a]){if(typeof e===r[a])return!0
}else if(r[a]instanceof RegExp){if((e||"").toString().match(r[a]))return!0}else{
if(e instanceof r[a])return!0
if(n.util.isType(e,r[a]))return!0
i||o||(r=r.slice()),r[a]=n.util.typeName(r[a])}o=!0}var s=i
s||(s=r.join(", ").replace(/,([^,]+)$/,", or$1"))
var u=s.match(/^[aeiou]/i)?"n":""
return this.fail("InvalidParameterType","Expected "+t+" to be a"+u+" "+s),!1},
validateNumber:function(e,t,r){if(null!=t){if("string"==typeof t){var n=parseFloat(t)
n.toString()===t&&(t=n)}this.validateType(t,r,["number"])&&this.validateRange(e,t,r,"numeric value")
}},validatePayload:function(e,t){
if(null!=e&&"string"!=typeof e&&(!e||"number"!=typeof e.byteLength)){if(n.util.isNode()){
var r=n.util.stream.Stream
if(n.util.Buffer.isBuffer(e)||e instanceof r)return
}else if(void 0!==typeof Blob&&e instanceof Blob)return
var i=["Buffer","Stream","File","Blob","ArrayBuffer","DataView"]
if(e)for(var o=0;o<i.length;o++){if(n.util.isType(e,i[o]))return
if(n.util.typeName(e.constructor)===i[o])return}
this.fail("InvalidParameterType","Expected "+t+" to be a string, Buffer, Stream, Blob, or typed array object")
}}})},8201:(e,t,r)=>{var n=r(9019),i=r(9132)
e.exports={populateHostPrefix:function(e){if(!e.service.config.hostPrefixEnabled)return e
var t,r,o,a,s,u,c,p=e.service.api.operations[e.operation]
if(function(e){
var t=e.service.api,r=t.operations[e.operation],i=t.endpointOperation&&t.endpointOperation===n.string.lowerFirst(r.name)
return"NULL"!==r.endpointDiscoveryRequired||!0===i}(e))return e
p.endpoint&&p.endpoint.hostPrefix&&(a=(s=p.endpoint.hostPrefix,u=e.params,c=p.input,
n.each(c.members,(function(e,t){if(!0===t.hostLabel){
if("string"!=typeof u[e]||""===u[e])throw n.error(new Error,{
message:"Parameter "+e+" should be a non-empty string.",code:"InvalidParameter"})
var r=new RegExp("\\{"+e+"\\}","g")
s=s.replace(r,u[e])}
})),s),(o=e.httpRequest.endpoint).host&&(o.host=a+o.host),o.hostname&&(o.hostname=a+o.hostname),
t=e.httpRequest.endpoint.hostname.split("."),
r=/^[a-zA-Z0-9]{1}$|^[a-zA-Z0-9][a-zA-Z0-9\-]*[a-zA-Z0-9]$/,n.arrayEach(t,(function(e){
if(!e.length||e.length<1||e.length>63)throw n.error(new Error,{code:"ValidationError",
message:"Hostname label length should be between 1 to 63 characters, inclusive."})
if(!r.test(e))throw i.util.error(new Error,{code:"ValidationError",
message:e+" is not hostname compatible."})})))
return e}}},3652:(e,t,r)=>{var n=r(9019),i=r(3681),o=r(5919),a=r(8201).populateHostPrefix
e.exports={buildRequest:function(e){
var t=e.httpRequest,r=e.service.api,n=r.targetPrefix+"."+r.operations[e.operation].name,o=r.jsonVersion||"1.0",s=r.operations[e.operation].input,u=new i
1===o&&(o="1.0"),r.awsQueryCompatible&&(t.params||(t.params={}),Object.assign(t.params,e.params)),
t.body=u.build(e.params||{},s),t.headers["Content-Type"]="application/x-amz-json-"+o,
t.headers["X-Amz-Target"]=n,a(e)},extractError:function(e){var t={},r=e.httpResponse
if(t.code=r.headers["x-amzn-errortype"]||"UnknownError","string"==typeof t.code&&(t.code=t.code.split(":")[0]),
r.body.length>0)try{var i=JSON.parse(r.body.toString()),o=i.__type||i.code||i.Code
for(var a in o&&(t.code=o.split("#").pop()),"RequestEntityTooLarge"===t.code?t.message="Request body must be less than 1 MB":t.message=i.message||i.Message||null,
i||{})"code"!==a&&"message"!==a&&(t["["+a+"]"]="See error."+a+" for details.",
Object.defineProperty(t,a,{value:i[a],enumerable:!1,writable:!0}))}catch(i){
t.statusCode=r.statusCode,t.message=r.statusMessage}else t.statusCode=r.statusCode,
t.message=r.statusCode.toString()
e.error=n.error(new Error,t)},extractData:function(e){var t=e.httpResponse.body.toString()||"{}"
if(!1===e.request.service.config.convertResponseTypes)e.data=JSON.parse(t)
else{var r=e.request.service.api.operations[e.request.operation].output||{},n=new o
e.data=n.parse(t,r)}}}},324:(e,t,r)=>{
var n=r(9132),i=r(9019),o=r(329),a=r(1304),s=r(8201).populateHostPrefix
e.exports={buildRequest:function(e){var t=e.service.api.operations[e.operation],r=e.httpRequest
r.headers["Content-Type"]="application/x-www-form-urlencoded; charset=utf-8",r.params={
Version:e.service.api.apiVersion,Action:t.name},(new o).serialize(e.params,t.input,(function(e,t){
r.params[e]=t})),r.body=i.queryParamsToString(r.params),s(e)},extractError:function(e){
var t,r=e.httpResponse.body.toString()
if(r.match("<UnknownOperationException"))t={Code:"UnknownOperation",
Message:"Unknown operation "+e.request.operation}
else try{t=(new n.XML.Parser).parse(r)}catch(r){t={Code:e.httpResponse.statusCode,
Message:e.httpResponse.statusMessage}}t.requestId&&!e.requestId&&(e.requestId=t.requestId),
t.Errors&&(t=t.Errors),t.Error&&(t=t.Error),t.Code?e.error=i.error(new Error,{code:t.Code,
message:t.Message}):e.error=i.error(new Error,{code:e.httpResponse.statusCode,message:null})},
extractData:function(e){var t=e.request,r=t.service.api.operations[t.operation].output||{},o=r
if(o.resultWrapper){var s=a.create({type:"structure"})
s.members[o.resultWrapper]=r,s.memberNames=[o.resultWrapper],i.property(r,"name",r.resultWrapper),
r=s}var u=new n.XML.Parser
if(r&&r.members&&!r.members._XAMZRequestId){var c=a.create({type:"string"},{api:{protocol:"query"}
},"requestId")
r.members._XAMZRequestId=c}var p=u.parse(e.httpResponse.body.toString(),r)
e.requestId=p._XAMZRequestId||p.requestId,p._XAMZRequestId&&delete p._XAMZRequestId,
o.resultWrapper&&p[o.resultWrapper]&&(i.update(p,p[o.resultWrapper]),delete p[o.resultWrapper]),
e.data=p}}},9648:(e,t,r)=>{var n=r(9019),i=r(8201).populateHostPrefix
function o(e,t,r,i){var o=[e,t].join("/")
o=o.replace(/\/+/g,"/")
var a={},s=!1
if(n.each(r.members,(function(e,t){var r=i[e]
if(null!=r)if("uri"===t.location){var u=new RegExp("\\{"+t.name+"(\\+)?\\}")
o=o.replace(u,(function(e,t){return(t?n.uriEscapePath:n.uriEscape)(String(r))}))
}else"querystring"===t.location&&(s=!0,"list"===t.type?a[t.name]=r.map((function(e){
return n.uriEscape(t.member.toWireFormat(e).toString())})):"map"===t.type?n.each(r,(function(e,t){
Array.isArray(t)?a[e]=t.map((function(e){return n.uriEscape(String(e))
})):a[e]=n.uriEscape(String(t))})):a[t.name]=n.uriEscape(t.toWireFormat(r).toString()))})),s){
o+=o.indexOf("?")>=0?"&":"?"
var u=[]
n.arrayEach(Object.keys(a).sort(),(function(e){Array.isArray(a[e])||(a[e]=[a[e]])
for(var t=0;t<a[e].length;t++)u.push(n.uriEscape(String(e))+"="+a[e][t])})),o+=u.join("&")}return o}
e.exports={buildRequest:function(e){!function(e){
e.httpRequest.method=e.service.api.operations[e.operation].httpMethod}(e),function(e){
var t=e.service.api.operations[e.operation],r=t.input,n=o(e.httpRequest.endpoint.path,t.httpPath,r,e.params)
e.httpRequest.path=n}(e),function(e){var t=e.service.api.operations[e.operation]
n.each(t.input.members,(function(t,r){var i=e.params[t]
null!=i&&("headers"===r.location&&"map"===r.type?n.each(i,(function(t,n){
e.httpRequest.headers[r.name+t]=n})):"header"===r.location&&(i=r.toWireFormat(i).toString(),
r.isJsonValue&&(i=n.base64.encode(i)),e.httpRequest.headers[r.name]=i))}))}(e),i(e)},
extractError:function(){},extractData:function(e){
var t=e.request,r={},i=e.httpResponse,o=t.service.api.operations[t.operation].output,a={}
n.each(i.headers,(function(e,t){a[e.toLowerCase()]=t})),n.each(o.members,(function(e,t){
var o=(t.name||e).toLowerCase()
if("headers"===t.location&&"map"===t.type){r[e]={}
var s=t.isLocationName?t.name:"",u=new RegExp("^"+s+"(.+)","i")
n.each(i.headers,(function(t,n){var i=t.match(u)
null!==i&&(r[e][i[1]]=n)}))}else if("header"===t.location){if(void 0!==a[o]){
var c=t.isJsonValue?n.base64.decode(a[o]):a[o]
r[e]=t.toType(c)}}else"statusCode"===t.location&&(r[e]=parseInt(i.statusCode,10))})),e.data=r},
generateURI:o}},5897:(e,t,r)=>{
var n=r(9019),i=r(9648),o=r(3652),a=r(3681),s=r(5919),u=["GET","HEAD","DELETE"]
function c(e,t){if(!e.httpRequest.headers["Content-Type"]){
var r=t?"binary/octet-stream":"application/json"
e.httpRequest.headers["Content-Type"]=r}}e.exports={buildRequest:function(e){i.buildRequest(e),
u.indexOf(e.httpRequest.method)<0&&function(e){
var t=new a,r=e.service.api.operations[e.operation].input
if(r.payload){var n,i=r.members[r.payload]
n=e.params[r.payload],"structure"===i.type?(e.httpRequest.body=t.build(n||{},i),
c(e)):void 0!==n&&(e.httpRequest.body=n,("binary"===i.type||i.isStreaming)&&c(e,!0))
}else e.httpRequest.body=t.build(e.params,r),c(e)}(e)},extractError:function(e){o.extractError(e)},
extractData:function(e){i.extractData(e)
var t=e.request,r=t.service.api.operations[t.operation],a=t.service.api.operations[t.operation].output||{}
if(r.hasEventOutput,a.payload){var u=a.members[a.payload],c=e.httpResponse.body
if(u.isEventStream)p=new s,e.data[payload]=n.createEventStream(2===AWS.HttpClient.streamsApiVersion?e.httpResponse.stream:c,p,u)
else if("structure"===u.type||"list"===u.type){var p=new s
e.data[a.payload]=p.parse(c,u)
}else"binary"===u.type||u.isStreaming?e.data[a.payload]=c:e.data[a.payload]=u.toType(c)}else{
var l=e.data
o.extractData(e),e.data=n.merge(l,e.data)}},unsetContentLength:function(e){
void 0===n.getRequestPayloadShape(e)&&u.indexOf(e.httpRequest.method)>=0&&delete e.httpRequest.headers["Content-Length"]
}}},5830:(e,t,r)=>{var n=r(9132),i=r(9019),o=r(9648)
e.exports={buildRequest:function(e){
o.buildRequest(e),["GET","HEAD"].indexOf(e.httpRequest.method)<0&&function(e){
var t=e.service.api.operations[e.operation].input,r=new n.XML.Builder,o=e.params,a=t.payload
if(a){var s=t.members[a]
if(void 0===(o=o[a]))return
if("structure"===s.type){var u=s.name
e.httpRequest.body=r.toXML(o,s,u,!0)}else e.httpRequest.body=o
}else e.httpRequest.body=r.toXML(o,t,t.name||t.shape||i.string.upperFirst(e.operation)+"Request")
}(e)},extractError:function(e){var t
o.extractError(e)
try{t=(new n.XML.Parser).parse(e.httpResponse.body.toString())}catch(r){t={
Code:e.httpResponse.statusCode,Message:e.httpResponse.statusMessage}}t.Errors&&(t=t.Errors),
t.Error&&(t=t.Error),t.Code?e.error=i.error(new Error,{code:t.Code,message:t.Message
}):e.error=i.error(new Error,{code:e.httpResponse.statusCode,message:null})},
extractData:function(e){var t
o.extractData(e)
var r=e.request,a=e.httpResponse.body,s=r.service.api.operations[r.operation],u=s.output,c=(s.hasEventOutput,
u.payload)
if(c){var p=u.members[c]
p.isEventStream?(t=new n.XML.Parser,e.data[c]=i.createEventStream(2===n.HttpClient.streamsApiVersion?e.httpResponse.stream:e.httpResponse.body,t,p)):"structure"===p.type?(t=new n.XML.Parser,
e.data[c]=t.parse(a.toString(),p)):"binary"===p.type||p.isStreaming?e.data[c]=a:e.data[c]=p.toType(a)
}else if(a.length>0){var l=(t=new n.XML.Parser).parse(a.toString(),u)
i.update(e.data,l)}}}},329:(e,t,r)=>{var n=r(9019)
function i(){}function o(e){
return e.isQueryName||"ec2"!==e.api.protocol?e.name:e.name[0].toUpperCase()+e.name.substr(1)}
function a(e,t,r,i){n.each(r.members,(function(r,n){var a=t[r]
if(null!=a){var u=o(n)
s(u=e?e+"."+u:u,a,n,i)}}))}function s(e,t,r,i){
null!=t&&("structure"===r.type?a(e,t,r,i):"list"===r.type?function(e,t,r,i){var a=r.member||{}
0!==t.length?n.arrayEach(t,(function(t,n){var u="."+(n+1)
if("ec2"===r.api.protocol)u+=""
else if(r.flattened){if(a.name){var c=e.split(".")
c.pop(),c.push(o(a)),e=c.join(".")}}else u="."+(a.name?a.name:"member")+u
s(e+u,t,a,i)})):i.call(this,e,null)}(e,t,r,i):"map"===r.type?function(e,t,r,i){var o=1
n.each(t,(function(t,n){
var a=(r.flattened?".":".entry.")+o+++".",u=a+(r.key.name||"key"),c=a+(r.value.name||"value")
s(e+u,t,r.key,i),s(e+c,n,r.value,i)}))}(e,t,r,i):i(e,r.toWireFormat(t).toString()))}
i.prototype.serialize=function(e,t,r){a("",e,t,r)},e.exports=i},7357:e=>{e.exports={
isFipsRegion:function(e){return"string"==typeof e&&(e.startsWith("fips-")||e.endsWith("-fips"))},
isGlobalRegion:function(e){return"string"==typeof e&&["aws-global","aws-us-gov-global"].includes(e)
},getRealRegion:function(e){
return["fips-aws-global","aws-fips","aws-global"].includes(e)?"us-east-1":["fips-aws-us-gov-global","aws-us-gov-global"].includes(e)?"us-gov-west-1":e.replace(/fips-(dkr-|prod-)?|-fips/,"")
}}},9240:(e,t,r)=>{var n=r(9019),i=r(3548)
function o(e,t){n.each(t,(function(t,r){
"globalEndpoint"!==t&&(void 0!==e.config[t]&&null!==e.config[t]||(e.config[t]=r))}))}e.exports={
configureEndpoint:function(e){for(var t=function(e){var t=e.config.region,r=function(e){
if(!e)return null
var t=e.split("-")
return t.length<3?null:t.slice(0,t.length-2).join("-")+"-*"}(t),n=e.api.endpointPrefix
return[[t,n],[r,n],[t,"*"],[r,"*"],["*",n],[t,"internal-*"],["*","*"]].map((function(e){
return e[0]&&e[1]?e.join("/"):null}))
}(e),r=e.config.useFipsEndpoint,n=e.config.useDualstackEndpoint,a=0;a<t.length;a++){var s=t[a]
if(s){var u=r?n?i.dualstackFipsRules:i.fipsRules:n?i.dualstackRules:i.rules
if(Object.prototype.hasOwnProperty.call(u,s)){var c=u[s]
"string"==typeof c&&(c=i.patterns[c]),e.isGlobalEndpoint=!!c.globalEndpoint,c.signingRegion&&(e.signingRegion=c.signingRegion),
c.signatureVersion||(c.signatureVersion="v4")
var p="bearer"===(e.api&&e.api.signatureVersion)
return void o(e,Object.assign({},c,{signatureVersion:p?"bearer":c.signatureVersion}))}}}},
getEndpointSuffix:function(e){for(var t={"^(us|eu|ap|sa|ca|me)\\-\\w+\\-\\d+$":"amazonaws.com",
"^cn\\-\\w+\\-\\d+$":"amazonaws.com.cn","^us\\-gov\\-\\w+\\-\\d+$":"amazonaws.com",
"^us\\-iso\\-\\w+\\-\\d+$":"c2s.ic.gov","^us\\-isob\\-\\w+\\-\\d+$":"sc2s.sgov.gov"
},r=Object.keys(t),n=0;n<r.length;n++){var i=RegExp(r[n]),o=t[r[n]]
if(i.test(e))return o}return"amazonaws.com"}}},4002:(e,t,r)=>{
var n=r(9132),i=r(8900),o=n.util.inherit,a=n.util.domain,s=r(7533),u={success:1,error:1,complete:1
},c=new i
c.setupStates=function(){var e=function(e,t){var r=this
r._haltHandlersOnError=!1,r.emit(r._asm.currentState,(function(e){
if(e)if(n=r,Object.prototype.hasOwnProperty.call(u,n._asm.currentState)){
if(!(a&&r.domain instanceof a.Domain))throw e
e.domainEmitter=r,e.domain=r.domain,e.domainThrown=!1,r.domain.emit("error",e)
}else r.response.error=e,t(e)
else t(r.response.error)
var n}))}
this.addState("validate","build","error",e),this.addState("build","afterBuild","restart",e),
this.addState("afterBuild","sign","restart",e),this.addState("sign","send","retry",e),
this.addState("retry","afterRetry","afterRetry",e),this.addState("afterRetry","sign","error",e),
this.addState("send","validateResponse","retry",e),
this.addState("validateResponse","extractData","extractError",e),
this.addState("extractError","extractData","retry",e),
this.addState("extractData","success","retry",e),this.addState("restart","build","error",e),
this.addState("success","complete","complete",e),this.addState("error","complete","complete",e),
this.addState("complete",null,null,e)},c.setupStates(),n.Request=o({constructor:function(e,t,r){
var o=e.endpoint,s=e.config.region,u=e.config.customUserAgent
e.signingRegion?s=e.signingRegion:e.isGlobalEndpoint&&(s="us-east-1"),this.domain=a&&a.active,
this.service=e,this.operation=t,this.params=r||{},this.httpRequest=new n.HttpRequest(o,s),
this.httpRequest.appendToUserAgent(u),
this.startTime=e.getSkewCorrectedDate(),this.response=new n.Response(this),
this._asm=new i(c.states,"validate"),this._haltHandlersOnError=!1,n.SequentialExecutor.call(this),
this.emit=this.emitEvent},send:function(e){
return e&&(this.httpRequest.appendToUserAgent("callback"),this.on("complete",(function(t){
e.call(t,t.error,t.data)}))),this.runTo(),this.response},build:function(e){
return this.runTo("send",e)},runTo:function(e,t){return this._asm.runTo(e,t,this),this},
abort:function(){
return this.removeAllListeners("validateResponse"),this.removeAllListeners("extractError"),
this.on("validateResponse",(function(e){e.error=n.util.error(new Error("Request aborted by user"),{
code:"RequestAbortedError",retryable:!1})
})),this.httpRequest.stream&&!this.httpRequest.stream.didCallback&&(this.httpRequest.stream.abort(),
this.httpRequest._abortCallback?this.httpRequest._abortCallback():this.removeAllListeners("send")),
this},eachPage:function(e){e=n.util.fn.makeAsync(e,3),this.on("complete",(function t(r){
e.call(r,r.error,r.data,(function(i){
!1!==i&&(r.hasNextPage()?r.nextPage().on("complete",t).send():e.call(r,null,null,n.util.fn.noop))}))
})).send()},eachItem:function(e){var t=this
this.eachPage((function(r,i){if(r)return e(r,null)
if(null===i)return e(null,null)
var o=t.service.paginationConfig(t.operation).resultKey
Array.isArray(o)&&(o=o[0])
var a=s.search(i,o),u=!0
return n.util.arrayEach(a,(function(t){if(!1===(u=e(null,t)))return n.util.abort})),u}))},
isPageable:function(){return!!this.service.paginationConfig(this.operation)},
createReadStream:function(){var e=n.util.stream,t=this,r=null
return 2===n.HttpClient.streamsApiVersion?(r=new e.PassThrough,process.nextTick((function(){t.send()
}))):((r=new e.Stream).readable=!0,r.sent=!1,r.on("newListener",(function(e){
r.sent||"data"!==e||(r.sent=!0,process.nextTick((function(){t.send()})))
}))),this.on("error",(function(e){r.emit("error",e)})),this.on("httpHeaders",(function(i,o,a){
if(i<300){
t.removeListener("httpData",n.EventListeners.Core.HTTP_DATA),t.removeListener("httpError",n.EventListeners.Core.HTTP_ERROR),
t.on("httpError",(function(e){a.error=e,a.error.retryable=!1}))
var s,u=!1
if("HEAD"!==t.httpRequest.method&&(s=parseInt(o["content-length"],10)),void 0!==s&&!isNaN(s)&&s>=0){
u=!0
var c=0}var p=function(){
u&&c!==s?r.emit("error",n.util.error(new Error("Stream content length mismatch. Received "+c+" of "+s+" bytes."),{
code:"StreamContentLengthMismatch"})):2===n.HttpClient.streamsApiVersion?r.end():r.emit("end")
},l=a.httpResponse.createUnbufferedStream()
if(2===n.HttpClient.streamsApiVersion)if(u){var f=new e.PassThrough
f._write=function(t){
return t&&t.length&&(c+=t.length),e.PassThrough.prototype._write.apply(this,arguments)},
f.on("end",p),r.on("error",(function(e){u=!1,l.unpipe(f),f.emit("end"),f.end()})),l.pipe(f).pipe(r,{
end:!1})}else l.pipe(r)
else u&&l.on("data",(function(e){e&&e.length&&(c+=e.length)})),l.on("data",(function(e){
r.emit("data",e)})),l.on("end",p)
l.on("error",(function(e){u=!1,r.emit("error",e)}))}})),r},emitEvent:function(e,t,r){
"function"==typeof t&&(r=t,t=null),r||(r=function(){}),t||(t=this.eventParameters(e,this.response)),
n.SequentialExecutor.prototype.emit.call(this,e,t,(function(e){e&&(this.response.error=e),
r.call(this,e)}))},eventParameters:function(e){switch(e){case"restart":case"validate":case"sign":
case"build":case"afterValidate":case"afterBuild":return[this]
case"error":return[this.response.error,this.response]
default:return[this.response]}},presign:function(e,t){return t||"function"!=typeof e||(t=e,e=null),
(new n.Signers.Presign).sign(this.toGet(),e,t)},isPresigned:function(){
return Object.prototype.hasOwnProperty.call(this.httpRequest.headers,"presigned-expires")},
toUnauthenticated:function(){
return this._unAuthenticated=!0,this.removeListener("validate",n.EventListeners.Core.VALIDATE_CREDENTIALS),
this.removeListener("sign",n.EventListeners.Core.SIGN),this},toGet:function(){
return"query"!==this.service.api.protocol&&"ec2"!==this.service.api.protocol||(this.removeListener("build",this.buildAsGet),
this.addListener("build",this.buildAsGet)),this},buildAsGet:function(e){e.httpRequest.method="GET",
e.httpRequest.path=e.service.endpoint.path+"?"+e.httpRequest.body,e.httpRequest.body="",
delete e.httpRequest.headers["Content-Length"],delete e.httpRequest.headers["Content-Type"]},
haltHandlersOnError:function(){this._haltHandlersOnError=!0}
}),n.Request.addPromisesToClass=function(e){this.prototype.promise=function(){var t=this
return this.httpRequest.appendToUserAgent("promise"),new e((function(e,r){
t.on("complete",(function(t){t.error?r(t.error):e(Object.defineProperty(t.data||{},"$response",{
value:t}))})),t.runTo()}))}},n.Request.deletePromisesFromClass=function(){
delete this.prototype.promise
},n.util.addPromises(n.Request),n.util.mixin(n.Request,n.SequentialExecutor)},4344:(e,t,r)=>{
var n=r(9132),i=n.util.inherit,o=r(7533)
function a(e){var t=e.request._waiter,r=t.config.acceptors,n=!1,i="retry"
r.forEach((function(r){if(!n){var o=t.matchers[r.matcher]
o&&o(e,r.expected,r.argument)&&(n=!0,i=r.state)}
})),!n&&e.error&&(i="failure"),"success"===i?t.setSuccess(e):t.setError(e,"retry"===i)}
n.ResourceWaiter=i({constructor:function(e,t){
this.service=e,this.state=t,this.loadWaiterConfig(this.state)},service:null,state:null,config:null,
matchers:{path:function(e,t,r){try{var n=o.search(e.data,r)}catch(e){return!1}
return o.strictDeepEqual(n,t)},pathAll:function(e,t,r){try{var n=o.search(e.data,r)}catch(e){
return!1}Array.isArray(n)||(n=[n])
var i=n.length
if(!i)return!1
for(var a=0;a<i;a++)if(!o.strictDeepEqual(n[a],t))return!1
return!0},pathAny:function(e,t,r){try{var n=o.search(e.data,r)}catch(e){return!1}
Array.isArray(n)||(n=[n])
for(var i=n.length,a=0;a<i;a++)if(o.strictDeepEqual(n[a],t))return!0
return!1},status:function(e,t){var r=e.httpResponse.statusCode
return"number"==typeof r&&r===t},error:function(e,t){
return"string"==typeof t&&e.error?t===e.error.code:t===!!e.error}},
listeners:(new n.SequentialExecutor).addNamedListeners((function(e){
e("RETRY_CHECK","retry",(function(e){var t=e.request._waiter
e.error&&"ResourceNotReady"===e.error.code&&(e.error.retryDelay=1e3*(t.config.delay||0))})),
e("CHECK_OUTPUT","extractData",a),e("CHECK_ERROR","extractError",a)})),wait:function(e,t){
"function"==typeof e&&(t=e,
e=void 0),e&&e.$waiter&&("number"==typeof(e=n.util.copy(e)).$waiter.delay&&(this.config.delay=e.$waiter.delay),
"number"==typeof e.$waiter.maxAttempts&&(this.config.maxAttempts=e.$waiter.maxAttempts),
delete e.$waiter)
var r=this.service.makeRequest(this.config.operation,e)
return r._waiter=this,r.response.maxRetries=this.config.maxAttempts,r.addListeners(this.listeners),
t&&r.send(t),r},setSuccess:function(e){
e.error=null,e.data=e.data||{},e.request.removeAllListeners("extractData")},setError:function(e,t){
e.data=null,e.error=n.util.error(e.error||new Error,{code:"ResourceNotReady",
message:"Resource is not in the state "+this.state,retryable:t})},loadWaiterConfig:function(e){
if(!this.service.api.waiters[e])throw new n.util.error(new Error,{code:"StateNotFoundError",
message:"State "+e+" not found."})
this.config=n.util.copy(this.service.api.waiters[e])}})},4396:(e,t,r)=>{
var n=r(9132),i=n.util.inherit,o=r(7533)
n.Response=i({constructor:function(e){this.request=e,this.data=null,this.error=null,
this.retryCount=0,
this.redirectCount=0,this.httpResponse=new n.HttpResponse,e&&(this.maxRetries=e.service.numRetries(),
this.maxRedirects=e.service.config.maxRedirects)},nextPage:function(e){
var t,r=this.request.service,i=this.request.operation
try{t=r.paginationConfig(i,!0)}catch(e){this.error=e}if(!this.hasNextPage()){if(e)e(this.error,null)
else if(this.error)throw this.error
return null}var o=n.util.copy(this.request.params)
if(this.nextPageTokens){var a=t.inputToken
"string"==typeof a&&(a=[a])
for(var s=0;s<a.length;s++)o[a[s]]=this.nextPageTokens[s]
return r.makeRequest(this.request.operation,o,e)}return e?e(null,null):null},hasNextPage:function(){
return this.cacheNextPageTokens(),!!this.nextPageTokens||void 0===this.nextPageTokens&&void 0},
cacheNextPageTokens:function(){
if(Object.prototype.hasOwnProperty.call(this,"nextPageTokens"))return this.nextPageTokens
this.nextPageTokens=void 0
var e=this.request.service.paginationConfig(this.request.operation)
if(!e)return this.nextPageTokens
if(this.nextPageTokens=null,e.moreResults&&!o.search(this.data,e.moreResults))return this.nextPageTokens
var t=e.outputToken
return"string"==typeof t&&(t=[t]),n.util.arrayEach.call(this,t,(function(e){
var t=o.search(this.data,e)
t&&(this.nextPageTokens=this.nextPageTokens||[],this.nextPageTokens.push(t))})),this.nextPageTokens}
})},5138:(e,t,r)=>{var n=r(9132)
n.SequentialExecutor=n.util.inherit({constructor:function(){this._events={}},listeners:function(e){
return this._events[e]?this._events[e].slice(0):[]},on:function(e,t,r){
return this._events[e]?r?this._events[e].unshift(t):this._events[e].push(t):this._events[e]=[t],this
},onAsync:function(e,t,r){return t._isAsync=!0,this.on(e,t,r)},removeListener:function(e,t){
var r=this._events[e]
if(r){for(var n=r.length,i=-1,o=0;o<n;++o)r[o]===t&&(i=o)
i>-1&&r.splice(i,1)}return this},removeAllListeners:function(e){
return e?delete this._events[e]:this._events={},this},emit:function(e,t,r){r||(r=function(){})
var n=this.listeners(e),i=n.length
return this.callListeners(n,t,r),i>0},callListeners:function(e,t,r,i){var o=this,a=i||null
function s(i){if(i&&(a=n.util.error(a||new Error,i),o._haltHandlersOnError))return r.call(o,a)
o.callListeners(e,t,r,a)}for(;e.length>0;){var u=e.shift()
if(u._isAsync)return void u.apply(o,t.concat([s]))
try{u.apply(o,t)}catch(e){a=n.util.error(a||new Error,e)}
if(a&&o._haltHandlersOnError)return void r.call(o,a)}r.call(o,a)},addListeners:function(e){
var t=this
return e._events&&(e=e._events),n.util.each(e,(function(e,r){"function"==typeof r&&(r=[r]),
n.util.arrayEach(r,(function(r){t.on(e,r)}))})),t},addNamedListener:function(e,t,r,n){
return this[e]=r,this.addListener(t,r,n),this},addNamedAsyncListener:function(e,t,r,n){
return r._isAsync=!0,this.addNamedListener(e,t,r,n)},addNamedListeners:function(e){var t=this
return e((function(){t.addNamedListener.apply(t,arguments)}),(function(){
t.addNamedAsyncListener.apply(t,arguments)})),this}
}),n.SequentialExecutor.prototype.addListener=n.SequentialExecutor.prototype.on,
e.exports=n.SequentialExecutor},5400:(e,t,r)=>{
var n=r(9132),i=r(9341),o=r(9240),a=n.util.inherit,s=0,u=r(7357)
n.Service=a({constructor:function(e){
if(!this.loadServiceClass)throw n.util.error(new Error,"Service must be constructed with `new' operator")
if(e){if(e.region){var t=e.region
u.isFipsRegion(t)&&(e.region=u.getRealRegion(t),e.useFipsEndpoint=!0),u.isGlobalRegion(t)&&(e.region=u.getRealRegion(t))
}
"boolean"==typeof e.useDualstack&&"boolean"!=typeof e.useDualstackEndpoint&&(e.useDualstackEndpoint=e.useDualstack)
}var r=this.loadServiceClass(e||{})
if(r){var i=n.util.copy(e),o=new r(e)
return Object.defineProperty(o,"_originalConfig",{get:function(){return i},enumerable:!1,
configurable:!0}),o._clientId=++s,o}this.initialize(e)},initialize:function(e){
var t=n.config[this.serviceIdentifier]
if(this.config=new n.Config(n.config),t&&this.config.update(t,!0),e&&this.config.update(e,!0),
this.validateService(),
this.config.endpoint||o.configureEndpoint(this),this.config.endpoint=this.endpointFromTemplate(this.config.endpoint),
this.setEndpoint(this.config.endpoint),
n.SequentialExecutor.call(this),n.Service.addDefaultMonitoringListeners(this),
(this.config.clientSideMonitoring||n.Service._clientSideMonitoring)&&this.publisher){
var r=this.publisher
this.addNamedListener("PUBLISH_API_CALL","apiCall",(function(e){process.nextTick((function(){
r.eventHandler(e)}))})),this.addNamedListener("PUBLISH_API_ATTEMPT","apiCallAttempt",(function(e){
process.nextTick((function(){r.eventHandler(e)}))}))}},validateService:function(){},
loadServiceClass:function(e){var t=e
if(n.util.isEmpty(this.api)){
if(t.apiConfig)return n.Service.defineServiceApi(this.constructor,t.apiConfig)
if(this.constructor.services){(t=new n.Config(n.config)).update(e,!0)
var r=t.apiVersions[this.constructor.serviceIdentifier]
return r=r||t.apiVersion,this.getLatestServiceClass(r)}return null}return null},
getLatestServiceClass:function(e){
return e=this.getLatestServiceVersion(e),null===this.constructor.services[e]&&n.Service.defineServiceApi(this.constructor,e),
this.constructor.services[e]},getLatestServiceVersion:function(e){
if(!this.constructor.services||0===this.constructor.services.length)throw new Error("No services defined on "+this.constructor.serviceIdentifier)
if(e?n.util.isType(e,Date)&&(e=n.util.date.iso8601(e).split("T")[0]):e="latest",
Object.hasOwnProperty(this.constructor.services,e))return e
for(var t=Object.keys(this.constructor.services).sort(),r=null,i=t.length-1;i>=0;i--)if("*"!==t[i][t[i].length-1]&&(r=t[i]),
t[i].substr(0,10)<=e)return r
throw new Error("Could not find "+this.constructor.serviceIdentifier+" API to satisfy version constraint `"+e+"'")
},api:{},defaultRetryCount:3,customizeRequests:function(e){if(e){
if("function"!=typeof e)throw new Error("Invalid callback type '"+typeof e+"' provided in customizeRequests")
this.customRequestHandler=e}else this.customRequestHandler=null},makeRequest:function(e,t,r){
if("function"==typeof t&&(r=t,t=null),t=t||{},this.config.params){var i=this.api.operations[e]
i&&(t=n.util.copy(t),n.util.each(this.config.params,(function(e,r){
i.input.members[e]&&(void 0!==t[e]&&null!==t[e]||(t[e]=r))})))}var o=new n.Request(this,e,t)
return this.addAllRequestListeners(o),this.attachMonitoringEmitter(o),r&&o.send(r),o},
makeUnauthenticatedRequest:function(e,t,r){"function"==typeof t&&(r=t,t={})
var n=this.makeRequest(e,t).toUnauthenticated()
return r?n.send(r):n},waitFor:function(e,t,r){return new n.ResourceWaiter(this,e).wait(t,r)},
addAllRequestListeners:function(e){
for(var t=[n.events,n.EventListeners.Core,this.serviceInterface(),n.EventListeners.CorePost],r=0;r<t.length;r++)t[r]&&e.addListeners(t[r])
this.config.paramValidation||e.removeListener("validate",n.EventListeners.Core.VALIDATE_PARAMETERS),
this.config.logger&&e.addListeners(n.EventListeners.Logger),this.setupRequestListeners(e),
"function"==typeof this.constructor.prototype.customRequestHandler&&this.constructor.prototype.customRequestHandler(e),
Object.prototype.hasOwnProperty.call(this,"customRequestHandler")&&"function"==typeof this.customRequestHandler&&this.customRequestHandler(e)
},apiCallEvent:function(e){var t=e.service.api.operations[e.operation],r={Type:"ApiCall",
Api:t?t.name:e.operation,Version:1,Service:e.service.api.serviceId||e.service.api.endpointPrefix,
Region:e.httpRequest.region,MaxRetriesExceeded:0,UserAgent:e.httpRequest.getUserAgent()
},n=e.response
if(n.httpResponse.statusCode&&(r.FinalHttpStatusCode=n.httpResponse.statusCode),n.error){
var i=n.error
n.httpResponse.statusCode>299?(i.code&&(r.FinalAwsException=i.code),i.message&&(r.FinalAwsExceptionMessage=i.message)):((i.code||i.name)&&(r.FinalSdkException=i.code||i.name),
i.message&&(r.FinalSdkExceptionMessage=i.message))}return r},apiAttemptEvent:function(e){
var t=e.service.api.operations[e.operation],r={Type:"ApiCallAttempt",Api:t?t.name:e.operation,
Version:1,Service:e.service.api.serviceId||e.service.api.endpointPrefix,
Fqdn:e.httpRequest.endpoint.hostname,UserAgent:e.httpRequest.getUserAgent()},n=e.response
return n.httpResponse.statusCode&&(r.HttpStatusCode=n.httpResponse.statusCode),!e._unAuthenticated&&e.service.config.credentials&&e.service.config.credentials.accessKeyId&&(r.AccessKey=e.service.config.credentials.accessKeyId),
n.httpResponse.headers?(e.httpRequest.headers["x-amz-security-token"]&&(r.SessionToken=e.httpRequest.headers["x-amz-security-token"]),
n.httpResponse.headers["x-amzn-requestid"]&&(r.XAmznRequestId=n.httpResponse.headers["x-amzn-requestid"]),
n.httpResponse.headers["x-amz-request-id"]&&(r.XAmzRequestId=n.httpResponse.headers["x-amz-request-id"]),
n.httpResponse.headers["x-amz-id-2"]&&(r.XAmzId2=n.httpResponse.headers["x-amz-id-2"]),r):r},
attemptFailEvent:function(e){var t=this.apiAttemptEvent(e),r=e.response,n=r.error
return r.httpResponse.statusCode>299?(n.code&&(t.AwsException=n.code),n.message&&(t.AwsExceptionMessage=n.message)):((n.code||n.name)&&(t.SdkException=n.code||n.name),
n.message&&(t.SdkExceptionMessage=n.message)),t},attachMonitoringEmitter:function(e){
var t,r,i,o,a,s,u=0,c=this,p=!0
e.on("validate",(function(){o=n.util.realClock.now(),s=Date.now()}),p),e.on("sign",(function(){
r=n.util.realClock.now(),t=Date.now(),a=e.httpRequest.region,u++
}),p),e.on("validateResponse",(function(){i=Math.round(n.util.realClock.now()-r)})),
e.addNamedListener("API_CALL_ATTEMPT","success",(function(){var r=c.apiAttemptEvent(e)
r.Timestamp=t,r.AttemptLatency=i>=0?i:0,r.Region=a,c.emit("apiCallAttempt",[r])})),
e.addNamedListener("API_CALL_ATTEMPT_RETRY","retry",(function(){var o=c.attemptFailEvent(e)
o.Timestamp=t,i=i||Math.round(n.util.realClock.now()-r),o.AttemptLatency=i>=0?i:0,o.Region=a,
c.emit("apiCallAttempt",[o])})),e.addNamedListener("API_CALL","complete",(function(){
var t=c.apiCallEvent(e)
if(t.AttemptCount=u,!(t.AttemptCount<=0)){t.Timestamp=s
var r=Math.round(n.util.realClock.now()-o)
t.Latency=r>=0?r:0
var i=e.response
i.error&&i.error.retryable&&"number"==typeof i.retryCount&&"number"==typeof i.maxRetries&&i.retryCount>=i.maxRetries&&(t.MaxRetriesExceeded=1),
c.emit("apiCall",[t])}}))},setupRequestListeners:function(e){},getSigningName:function(){
return this.api.signingName||this.api.endpointPrefix},getSignerClass:function(e){var t,r=null,i=""
return e&&(i=(r=(e.service.api.operations||{})[e.operation]||null)?r.authtype:""),
t=this.config.signatureVersion?this.config.signatureVersion:"v4"===i||"v4-unsigned-body"===i?"v4":"bearer"===i?"bearer":this.api.signatureVersion,
n.Signers.RequestSigner.getVersion(t)},serviceInterface:function(){switch(this.api.protocol){
case"ec2":case"query":return n.EventListeners.Query
case"json":return n.EventListeners.Json
case"rest-json":return n.EventListeners.RestJson
case"rest-xml":return n.EventListeners.RestXml}
if(this.api.protocol)throw new Error("Invalid service `protocol' "+this.api.protocol+" in API config")
},successfulResponse:function(e){return e.httpResponse.statusCode<300},numRetries:function(){
return void 0!==this.config.maxRetries?this.config.maxRetries:this.defaultRetryCount},
retryDelays:function(e,t){return n.util.calculateRetryDelay(e,this.config.retryDelayOptions,t)},
retryableError:function(e){
return!!this.timeoutError(e)||!!this.networkingError(e)||!!this.expiredCredentialsError(e)||!!this.throttledError(e)||e.statusCode>=500
},networkingError:function(e){return"NetworkingError"===e.code},timeoutError:function(e){
return"TimeoutError"===e.code},expiredCredentialsError:function(e){
return"ExpiredTokenException"===e.code},clockSkewError:function(e){switch(e.code){
case"RequestTimeTooSkewed":case"RequestExpired":case"InvalidSignatureException":
case"SignatureDoesNotMatch":case"AuthFailure":case"RequestInTheFuture":return!0
default:return!1}},getSkewCorrectedDate:function(){
return new Date(Date.now()+this.config.systemClockOffset)},applyClockOffset:function(e){
e&&(this.config.systemClockOffset=e-Date.now())},isClockSkewed:function(e){
if(e)return Math.abs(this.getSkewCorrectedDate().getTime()-e)>=3e5},throttledError:function(e){
if(429===e.statusCode)return!0
switch(e.code){case"ProvisionedThroughputExceededException":case"Throttling":
case"ThrottlingException":case"RequestLimitExceeded":case"RequestThrottled":
case"RequestThrottledException":case"TooManyRequestsException":case"TransactionInProgressException":
case"EC2ThrottledException":return!0
default:return!1}},endpointFromTemplate:function(e){if("string"!=typeof e)return e
return e.replace(/\{service\}/g,this.api.endpointPrefix).replace(/\{region\}/g,this.config.region).replace(/\{scheme\}/g,this.config.sslEnabled?"https":"http")
},setEndpoint:function(e){this.endpoint=new n.Endpoint(e,this.config)},
paginationConfig:function(e,t){var r=this.api.operations[e].paginator
if(!r){if(t){var i=new Error
throw n.util.error(i,"No pagination configuration for "+e)}return null}return r}}),
n.util.update(n.Service,{defineMethods:function(e){
n.util.each(e.prototype.api.operations,(function(t){
e.prototype[t]||("none"===e.prototype.api.operations[t].authtype?e.prototype[t]=function(e,r){
return this.makeUnauthenticatedRequest(t,e,r)}:e.prototype[t]=function(e,r){
return this.makeRequest(t,e,r)})}))},defineService:function(e,t,r){n.Service._serviceMap[e]=!0,
Array.isArray(t)||(r=t,t=[])
var i=a(n.Service,r||{})
if("string"==typeof e){n.Service.addVersions(i,t)
var o=i.serviceIdentifier||e
i.serviceIdentifier=o}else i.prototype.api=e,n.Service.defineMethods(i)
if(n.SequentialExecutor.call(this.prototype),!this.prototype.publisher&&n.util.clientSideMonitoring){
var s=n.util.clientSideMonitoring.Publisher,u=(0,n.util.clientSideMonitoring.configProvider)()
this.prototype.publisher=new s(u),u.enabled&&(n.Service._clientSideMonitoring=!0)}
return n.SequentialExecutor.call(i.prototype),n.Service.addDefaultMonitoringListeners(i.prototype),i
},addVersions:function(e,t){Array.isArray(t)||(t=[t]),e.services=e.services||{}
for(var r=0;r<t.length;r++)void 0===e.services[t[r]]&&(e.services[t[r]]=null)
e.apiVersions=Object.keys(e.services).sort()},defineServiceApi:function(e,t,r){var o=a(e,{
serviceIdentifier:e.serviceIdentifier})
function s(t){t.isApi?o.prototype.api=t:o.prototype.api=new i(t,{
serviceIdentifier:e.serviceIdentifier})}if("string"==typeof t){if(r)s(r)
else try{s(n.apiLoader(e.serviceIdentifier,t))}catch(r){throw n.util.error(r,{
message:"Could not find API configuration "+e.serviceIdentifier+"-"+t})}
Object.prototype.hasOwnProperty.call(e.services,t)||(e.apiVersions=e.apiVersions.concat(t).sort()),
e.services[t]=o}else s(t)
return n.Service.defineMethods(o),o},hasService:function(e){
return Object.prototype.hasOwnProperty.call(n.Service._serviceMap,e)},
addDefaultMonitoringListeners:function(e){
e.addNamedListener("MONITOR_EVENTS_BUBBLE","apiCallAttempt",(function(t){
var r=Object.getPrototypeOf(e)
r._events&&r.emit("apiCallAttempt",[t])
})),e.addNamedListener("CALL_EVENTS_BUBBLE","apiCall",(function(t){var r=Object.getPrototypeOf(e)
r._events&&r.emit("apiCall",[t])}))},_serviceMap:{}}),n.util.mixin(n.Service,n.SequentialExecutor),
e.exports=n.Service},2486:(e,t,r)=>{var n=r(9132)
n.Signers.Bearer=n.util.inherit(n.Signers.RequestSigner,{constructor:function(e){
n.Signers.RequestSigner.call(this,e)},addAuthorization:function(e){
this.request.headers.Authorization="Bearer "+e.token}})},9899:(e,t,r)=>{
var n=r(9132),i=n.util.inherit,o="presigned-expires"
function a(e){var t=e.httpRequest.headers[o],r=e.service.getSignerClass(e)
if(delete e.httpRequest.headers["User-Agent"],delete e.httpRequest.headers["X-Amz-User-Agent"],
r===n.Signers.V4){if(t>604800)throw n.util.error(new Error,{code:"InvalidExpiryTime",
message:"Presigning does not support expiry time greater than a week with SigV4 signing.",
retryable:!1})
e.httpRequest.headers[o]=t}else{if(r!==n.Signers.S3)throw n.util.error(new Error,{
message:"Presigning only supports S3 or SigV4 signing.",code:"UnsupportedSigner",retryable:!1})
var i=e.service?e.service.getSkewCorrectedDate():n.util.date.getDate()
e.httpRequest.headers[o]=parseInt(n.util.date.unixTimestamp(i)+t,10).toString()}}function s(e){
var t=e.httpRequest.endpoint,r=n.util.urlParse(e.httpRequest.path),i={}
r.search&&(i=n.util.queryStringParse(r.search.substr(1)))
var a=e.httpRequest.headers.Authorization.split(" ")
if("AWS"===a[0])a=a[1].split(":"),i.Signature=a.pop(),i.AWSAccessKeyId=a.join(":"),
n.util.each(e.httpRequest.headers,(function(e,t){
e===o&&(e="Expires"),0===e.indexOf("x-amz-meta-")&&(delete i[e],e=e.toLowerCase()),i[e]=t})),
delete e.httpRequest.headers[o],delete i.Authorization,delete i.Host
else if("AWS4-HMAC-SHA256"===a[0]){a.shift()
var s=a.join(" ").match(/Signature=(.*?)(?:,|\s|\r?\n|$)/)[1]
i["X-Amz-Signature"]=s,delete i.Expires}t.pathname=r.pathname,t.search=n.util.queryParamsToString(i)
}n.Signers.Presign=i({sign:function(e,t,r){if(e.httpRequest.headers[o]=t||3600,e.on("build",a),
e.on("sign",s),e.removeListener("afterBuild",n.EventListeners.Core.SET_CONTENT_LENGTH),
e.removeListener("afterBuild",n.EventListeners.Core.COMPUTE_SHA256),e.emit("beforePresign",[e]),!r){
if(e.build(),e.response.error)throw e.response.error
return n.util.urlFormat(e.httpRequest.endpoint)}e.build((function(){
this.response.error?r(this.response.error):r(null,n.util.urlFormat(e.httpRequest.endpoint))}))}}),
e.exports=n.Signers.Presign},7383:(e,t,r)=>{var n=r(9132),i=n.util.inherit
n.Signers.RequestSigner=i({constructor:function(e){this.request=e},setServiceClientId:function(e){
this.serviceClientId=e},getServiceClientId:function(){return this.serviceClientId}}),
n.Signers.RequestSigner.getVersion=function(e){switch(e){case"v2":return n.Signers.V2
case"v3":return n.Signers.V3
case"s3v4":case"v4":return n.Signers.V4
case"s3":return n.Signers.S3
case"v3https":return n.Signers.V3Https
case"bearer":return n.Signers.Bearer}throw new Error("Unknown signing version "+e)},r(4243),r(2956),
r(9667),r(1417),r(7661),r(9899),r(2486)},7661:(e,t,r)=>{var n=r(9132),i=n.util.inherit
n.Signers.S3=i(n.Signers.RequestSigner,{subResources:{acl:1,accelerate:1,analytics:1,cors:1,
lifecycle:1,delete:1,inventory:1,location:1,logging:1,metrics:1,notification:1,partNumber:1,
policy:1,requestPayment:1,replication:1,restore:1,tagging:1,torrent:1,uploadId:1,uploads:1,
versionId:1,versioning:1,versions:1,website:1},responseHeaders:{"response-content-type":1,
"response-content-language":1,"response-expires":1,"response-cache-control":1,
"response-content-disposition":1,"response-content-encoding":1},addAuthorization:function(e,t){
this.request.headers["presigned-expires"]||(this.request.headers["X-Amz-Date"]=n.util.date.rfc822(t)),
e.sessionToken&&(this.request.headers["x-amz-security-token"]=e.sessionToken)
var r=this.sign(e.secretAccessKey,this.stringToSign()),i="AWS "+e.accessKeyId+":"+r
this.request.headers.Authorization=i},stringToSign:function(){var e=this.request,t=[]
t.push(e.method),t.push(e.headers["Content-MD5"]||""),t.push(e.headers["Content-Type"]||""),
t.push(e.headers["presigned-expires"]||"")
var r=this.canonicalizedAmzHeaders()
return r&&t.push(r),t.push(this.canonicalizedResource()),t.join("\n")},
canonicalizedAmzHeaders:function(){var e=[]
n.util.each(this.request.headers,(function(t){t.match(/^x-amz-/i)&&e.push(t)})),
e.sort((function(e,t){return e.toLowerCase()<t.toLowerCase()?-1:1}))
var t=[]
return n.util.arrayEach.call(this,e,(function(e){
t.push(e.toLowerCase()+":"+String(this.request.headers[e]))})),t.join("\n")},
canonicalizedResource:function(){var e=this.request,t=e.path.split("?"),r=t[0],i=t[1],o=""
if(e.virtualHostedBucket&&(o+="/"+e.virtualHostedBucket),o+=r,i){var a=[]
n.util.arrayEach.call(this,i.split("&"),(function(e){var t=e.split("=")[0],r=e.split("=")[1]
if(this.subResources[t]||this.responseHeaders[t]){var n={name:t}
void 0!==r&&(this.subResources[t]?n.value=r:n.value=decodeURIComponent(r)),a.push(n)}})),
a.sort((function(e,t){return e.name<t.name?-1:1})),a.length&&(i=[],n.util.arrayEach(a,(function(e){
void 0===e.value?i.push(e.name):i.push(e.name+"="+e.value)})),o+="?"+i.join("&"))}return o},
sign:function(e,t){return n.util.crypto.hmac(e,t,"base64","sha1")}}),e.exports=n.Signers.S3},
4243:(e,t,r)=>{var n=r(9132),i=n.util.inherit
n.Signers.V2=i(n.Signers.RequestSigner,{addAuthorization:function(e,t){t||(t=n.util.date.getDate())
var r=this.request
r.params.Timestamp=n.util.date.iso8601(t),r.params.SignatureVersion="2",r.params.SignatureMethod="HmacSHA256",
r.params.AWSAccessKeyId=e.accessKeyId,e.sessionToken&&(r.params.SecurityToken=e.sessionToken),
delete r.params.Signature,
r.params.Signature=this.signature(e),r.body=n.util.queryParamsToString(r.params),
r.headers["Content-Length"]=r.body.length},signature:function(e){
return n.util.crypto.hmac(e.secretAccessKey,this.stringToSign(),"base64")},stringToSign:function(){
var e=[]
return e.push(this.request.method),e.push(this.request.endpoint.host.toLowerCase()),
e.push(this.request.pathname()),e.push(n.util.queryParamsToString(this.request.params)),e.join("\n")
}}),e.exports=n.Signers.V2},2956:(e,t,r)=>{var n=r(9132),i=n.util.inherit
n.Signers.V3=i(n.Signers.RequestSigner,{addAuthorization:function(e,t){var r=n.util.date.rfc822(t)
this.request.headers["X-Amz-Date"]=r,e.sessionToken&&(this.request.headers["x-amz-security-token"]=e.sessionToken),
this.request.headers["X-Amzn-Authorization"]=this.authorization(e,r)},authorization:function(e){
return"AWS3 AWSAccessKeyId="+e.accessKeyId+",Algorithm=HmacSHA256,SignedHeaders="+this.signedHeaders()+",Signature="+this.signature(e)
},signedHeaders:function(){var e=[]
return n.util.arrayEach(this.headersToSign(),(function(t){e.push(t.toLowerCase())})),
e.sort().join(";")},canonicalHeaders:function(){var e=this.request.headers,t=[]
return n.util.arrayEach(this.headersToSign(),(function(r){
t.push(r.toLowerCase().trim()+":"+String(e[r]).trim())})),t.sort().join("\n")+"\n"},
headersToSign:function(){var e=[]
return n.util.each(this.request.headers,(function(t){
("Host"===t||"Content-Encoding"===t||t.match(/^X-Amz/i))&&e.push(t)})),e},signature:function(e){
return n.util.crypto.hmac(e.secretAccessKey,this.stringToSign(),"base64")},stringToSign:function(){
var e=[]
return e.push(this.request.method),e.push("/"),e.push(""),e.push(this.canonicalHeaders()),
e.push(this.request.body),n.util.crypto.sha256(e.join("\n"))}}),e.exports=n.Signers.V3},
9667:(e,t,r)=>{var n=r(9132),i=n.util.inherit
r(2956),n.Signers.V3Https=i(n.Signers.V3,{authorization:function(e){
return"AWS3-HTTPS AWSAccessKeyId="+e.accessKeyId+",Algorithm=HmacSHA256,Signature="+this.signature(e)
},stringToSign:function(){return this.request.headers["X-Amz-Date"]}}),e.exports=n.Signers.V3Https},
1417:(e,t,r)=>{var n=r(9132),i=r(9944),o=n.util.inherit,a="presigned-expires"
n.Signers.V4=o(n.Signers.RequestSigner,{constructor:function(e,t,r){
n.Signers.RequestSigner.call(this,e),
this.serviceName=t,r=r||{},this.signatureCache="boolean"!=typeof r.signatureCache||r.signatureCache,
this.operation=r.operation,this.signatureVersion=r.signatureVersion},algorithm:"AWS4-HMAC-SHA256",
addAuthorization:function(e,t){var r=n.util.date.iso8601(t).replace(/[:\-]|\.\d{3}/g,"")
this.isPresigned()?this.updateForPresigned(e,r):this.addHeaders(e,r),this.request.headers.Authorization=this.authorization(e,r)
},addHeaders:function(e,t){
this.request.headers["X-Amz-Date"]=t,e.sessionToken&&(this.request.headers["x-amz-security-token"]=e.sessionToken)
},updateForPresigned:function(e,t){var r=this.credentialString(t),i={"X-Amz-Date":t,
"X-Amz-Algorithm":this.algorithm,"X-Amz-Credential":e.accessKeyId+"/"+r,
"X-Amz-Expires":this.request.headers[a],"X-Amz-SignedHeaders":this.signedHeaders()}
e.sessionToken&&(i["X-Amz-Security-Token"]=e.sessionToken),this.request.headers["Content-Type"]&&(i["Content-Type"]=this.request.headers["Content-Type"]),
this.request.headers["Content-MD5"]&&(i["Content-MD5"]=this.request.headers["Content-MD5"]),
this.request.headers["Cache-Control"]&&(i["Cache-Control"]=this.request.headers["Cache-Control"]),
n.util.each.call(this,this.request.headers,(function(e,t){if(e!==a&&this.isSignableHeader(e)){
var r=e.toLowerCase()
0===r.indexOf("x-amz-meta-")?i[r]=t:0===r.indexOf("x-amz-")&&(i[e]=t)}}))
var o=this.request.path.indexOf("?")>=0?"&":"?"
this.request.path+=o+n.util.queryParamsToString(i)},authorization:function(e,t){
var r=[],n=this.credentialString(t)
return r.push(this.algorithm+" Credential="+e.accessKeyId+"/"+n),r.push("SignedHeaders="+this.signedHeaders()),
r.push("Signature="+this.signature(e,t)),r.join(", ")},signature:function(e,t){
var r=i.getSigningKey(e,t.substr(0,8),this.request.region,this.serviceName,this.signatureCache)
return n.util.crypto.hmac(r,this.stringToSign(t),"hex")},stringToSign:function(e){var t=[]
return t.push("AWS4-HMAC-SHA256"),t.push(e),t.push(this.credentialString(e)),t.push(this.hexEncodedHash(this.canonicalString())),
t.join("\n")},canonicalString:function(){var e=[],t=this.request.pathname()
return"s3"!==this.serviceName&&"s3v4"!==this.signatureVersion&&(t=n.util.uriEscapePath(t)),
e.push(this.request.method),
e.push(t),e.push(this.request.search()),e.push(this.canonicalHeaders()+"\n"),
e.push(this.signedHeaders()),e.push(this.hexEncodedBodyHash()),e.join("\n")},
canonicalHeaders:function(){var e=[]
n.util.each.call(this,this.request.headers,(function(t,r){e.push([t,r])})),e.sort((function(e,t){
return e[0].toLowerCase()<t[0].toLowerCase()?-1:1}))
var t=[]
return n.util.arrayEach.call(this,e,(function(e){var r=e[0].toLowerCase()
if(this.isSignableHeader(r)){var i=e[1]
if(null==i||"function"!=typeof i.toString)throw n.util.error(new Error("Header "+r+" contains invalid value"),{
code:"InvalidHeader"})
t.push(r+":"+this.canonicalHeaderValues(i.toString()))}})),t.join("\n")},
canonicalHeaderValues:function(e){return e.replace(/\s+/g," ").replace(/^\s+|\s+$/g,"")},
signedHeaders:function(){var e=[]
return n.util.each.call(this,this.request.headers,(function(t){t=t.toLowerCase(),
this.isSignableHeader(t)&&e.push(t)})),e.sort().join(";")},credentialString:function(e){
return i.createScope(e.substr(0,8),this.request.region,this.serviceName)},
hexEncodedHash:function(e){return n.util.crypto.sha256(e,"hex")},hexEncodedBodyHash:function(){
var e=this.request
return this.isPresigned()&&["s3","s3-object-lambda"].indexOf(this.serviceName)>-1&&!e.body?"UNSIGNED-PAYLOAD":e.headers["X-Amz-Content-Sha256"]?e.headers["X-Amz-Content-Sha256"]:this.hexEncodedHash(this.request.body||"")
},
unsignableHeaders:["authorization","content-type","content-length","user-agent",a,"expect","x-amzn-trace-id"],
isSignableHeader:function(e){
return 0===e.toLowerCase().indexOf("x-amz-")||this.unsignableHeaders.indexOf(e)<0},
isPresigned:function(){return!!this.request.headers[a]}}),e.exports=n.Signers.V4},9944:(e,t,r)=>{
var n=r(9132),i={},o=[],a="aws4_request"
e.exports={createScope:function(e,t,r){return[e.substr(0,8),t,r,a].join("/")},
getSigningKey:function(e,t,r,s,u){
var c=[n.util.crypto.hmac(e.secretAccessKey,e.accessKeyId,"base64"),t,r,s].join("_")
if((u=!1!==u)&&c in i)return i[c]
var p=n.util.crypto.hmac("AWS4"+e.secretAccessKey,t,"buffer"),l=n.util.crypto.hmac(p,r,"buffer"),f=n.util.crypto.hmac(l,s,"buffer"),d=n.util.crypto.hmac(f,a,"buffer")
return u&&(i[c]=d,o.push(c),o.length>50&&delete i[o.shift()]),d},emptyCache:function(){i={},o=[]}}},
8900:e=>{function t(e,t){this.currentState=t||null,this.states=e||{}}
t.prototype.runTo=function(e,t,r,n){"function"==typeof e&&(n=r,r=t,t=e,e=null)
var i=this,o=i.states[i.currentState]
o.fn.call(r||i,n,(function(n){if(n){if(!o.fail)return t?t.call(r,n):null
i.currentState=o.fail}else{if(!o.accept)return t?t.call(r):null
i.currentState=o.accept}if(i.currentState===e)return t?t.call(r,n):null
i.runTo(e,t,r,n)}))},t.prototype.addState=function(e,t,r,n){return"function"==typeof t?(n=t,t=null,
r=null):"function"==typeof r&&(n=r,r=null),this.currentState||(this.currentState=e),this.states[e]={
accept:t,fail:r,fn:n},this},e.exports=t},9019:(e,t,r)=>{var n,i={environment:"nodejs",
engine:function(){if(i.isBrowser()&&"undefined"!=typeof navigator)return navigator.userAgent
var e=process.platform+"/"+process.version
return process.env.AWS_EXECUTION_ENV&&(e+=" exec-env/"+process.env.AWS_EXECUTION_ENV),e},
userAgent:function(){var e=i.environment,t="aws-sdk-"+e+"/"+r(9132).VERSION
return"nodejs"===e&&(t+=" "+i.engine()),t},uriEscape:function(e){var t=encodeURIComponent(e)
return(t=t.replace(/[^A-Za-z0-9_.~\-%]+/g,escape)).replace(/[*]/g,(function(e){
return"%"+e.charCodeAt(0).toString(16).toUpperCase()}))},uriEscapePath:function(e){var t=[]
return i.arrayEach(e.split("/"),(function(e){t.push(i.uriEscape(e))})),t.join("/")},
urlParse:function(e){return i.url.parse(e)},urlFormat:function(e){return i.url.format(e)},
queryStringParse:function(e){return i.querystring.parse(e)},queryParamsToString:function(e){
var t=[],r=i.uriEscape,n=Object.keys(e).sort()
return i.arrayEach(n,(function(n){var o=e[n],a=r(n),s=a+"="
if(Array.isArray(o)){var u=[]
i.arrayEach(o,(function(e){u.push(r(e))})),s=a+"="+u.sort().join("&"+a+"=")
}else null!=o&&(s=a+"="+r(o))
t.push(s)})),t.join("&")},readFileSync:function(e){
return i.isBrowser()?null:r(1976).readFileSync(e,"utf-8")},base64:{encode:function(e){
if("number"==typeof e)throw i.error(new Error("Cannot base64 encode number "+e))
return null==e?e:i.buffer.toBuffer(e).toString("base64")},decode:function(e){
if("number"==typeof e)throw i.error(new Error("Cannot base64 decode number "+e))
return null==e?e:i.buffer.toBuffer(e,"base64")}},buffer:{toBuffer:function(e,t){
return"function"==typeof i.Buffer.from&&i.Buffer.from!==Uint8Array.from?i.Buffer.from(e,t):new i.Buffer(e,t)
},alloc:function(e,t,r){
if("number"!=typeof e)throw new Error("size passed to alloc must be a number.")
if("function"==typeof i.Buffer.alloc)return i.Buffer.alloc(e,t,r)
var n=new i.Buffer(e)
return void 0!==t&&"function"==typeof n.fill&&n.fill(t,void 0,void 0,r),n},toStream:function(e){
i.Buffer.isBuffer(e)||(e=i.buffer.toBuffer(e))
var t=new i.stream.Readable,r=0
return t._read=function(n){if(r>=e.length)return t.push(null)
var i=r+n
i>e.length&&(i=e.length),t.push(e.slice(r,i)),r=i},t},concat:function(e){var t,r,n=0,o=0
for(r=0;r<e.length;r++)n+=e[r].length
for(t=i.buffer.alloc(n),r=0;r<e.length;r++)e[r].copy(t,o),o+=e[r].length
return t}},string:{byteLength:function(e){if(null==e)return 0
if("string"==typeof e&&(e=i.buffer.toBuffer(e)),"number"==typeof e.byteLength)return e.byteLength
if("number"==typeof e.length)return e.length
if("number"==typeof e.size)return e.size
if("string"==typeof e.path)return r(1976).lstatSync(e.path).size
throw i.error(new Error("Cannot determine length of "+e),{object:e})},upperFirst:function(e){
return e[0].toUpperCase()+e.substr(1)},lowerFirst:function(e){return e[0].toLowerCase()+e.substr(1)}
},ini:{parse:function(e){var t,r={}
return i.arrayEach(e.split(/\r?\n/),(function(e){
if("["===(e=e.split(/(^|\s)[;#]/)[0].trim())[0]&&"]"===e[e.length-1]){
if("__proto__"===(t=e.substring(1,e.length-1))||"__proto__"===t.split(/\s/)[1])throw i.error(new Error("Cannot load profile name '"+t+"' from shared ini file."))
}else if(t){var n=e.indexOf("="),o=e.length-1
if(-1!==n&&0!==n&&n!==o){var a=e.substring(0,n).trim(),s=e.substring(n+1).trim()
r[t]=r[t]||{},r[t][a]=s}}})),r}},fn:{noop:function(){},callback:function(e){if(e)throw e},
makeAsync:function(e,t){return t&&t<=e.length?e:function(){
var t=Array.prototype.slice.call(arguments,0)
t.pop()(e.apply(null,t))}}},date:{getDate:function(){
return n||(n=r(9132)),n.config.systemClockOffset?new Date((new Date).getTime()+n.config.systemClockOffset):new Date
},iso8601:function(e){
return void 0===e&&(e=i.date.getDate()),e.toISOString().replace(/\.\d{3}Z$/,"Z")},
rfc822:function(e){return void 0===e&&(e=i.date.getDate()),e.toUTCString()},
unixTimestamp:function(e){return void 0===e&&(e=i.date.getDate()),e.getTime()/1e3},from:function(e){
return"number"==typeof e?new Date(1e3*e):new Date(e)},format:function(e,t){return t||(t="iso8601"),
i.date[t](i.date.from(e))},parseTimestamp:function(e){if("number"==typeof e)return new Date(1e3*e)
if(e.match(/^\d+$/))return new Date(1e3*e)
if(e.match(/^\d{4}/))return new Date(e)
if(e.match(/^\w{3},/))return new Date(e)
throw i.error(new Error("unhandled timestamp format: "+e),{code:"TimestampParserError"})}},crypto:{
crc32Table:[0,1996959894,3993919788,2567524794,124634137,1886057615,3915621685,2657392035,249268274,2044508324,3772115230,2547177864,162941995,2125561021,3887607047,2428444049,498536548,1789927666,4089016648,2227061214,450548861,1843258603,4107580753,2211677639,325883990,1684777152,4251122042,2321926636,335633487,1661365465,4195302755,2366115317,997073096,1281953886,3579855332,2724688242,1006888145,1258607687,3524101629,2768942443,901097722,1119000684,3686517206,2898065728,853044451,1172266101,3705015759,2882616665,651767980,1373503546,3369554304,3218104598,565507253,1454621731,3485111705,3099436303,671266974,1594198024,3322730930,2970347812,795835527,1483230225,3244367275,3060149565,1994146192,31158534,2563907772,4023717930,1907459465,112637215,2680153253,3904427059,2013776290,251722036,2517215374,3775830040,2137656763,141376813,2439277719,3865271297,1802195444,476864866,2238001368,4066508878,1812370925,453092731,2181625025,4111451223,1706088902,314042704,2344532202,4240017532,1658658271,366619977,2362670323,4224994405,1303535960,984961486,2747007092,3569037538,1256170817,1037604311,2765210733,3554079995,1131014506,879679996,2909243462,3663771856,1141124467,855842277,2852801631,3708648649,1342533948,654459306,3188396048,3373015174,1466479909,544179635,3110523913,3462522015,1591671054,702138776,2966460450,3352799412,1504918807,783551873,3082640443,3233442989,3988292384,2596254646,62317068,1957810842,3939845945,2647816111,81470997,1943803523,3814918930,2489596804,225274430,2053790376,3826175755,2466906013,167816743,2097651377,4027552580,2265490386,503444072,1762050814,4150417245,2154129355,426522225,1852507879,4275313526,2312317920,282753626,1742555852,4189708143,2394877945,397917763,1622183637,3604390888,2714866558,953729732,1340076626,3518719985,2797360999,1068828381,1219638859,3624741850,2936675148,906185462,1090812512,3747672003,2825379669,829329135,1181335161,3412177804,3160834842,628085408,1382605366,3423369109,3138078467,570562233,1426400815,3317316542,2998733608,733239954,1555261956,3268935591,3050360625,752459403,1541320221,2607071920,3965973030,1969922972,40735498,2617837225,3943577151,1913087877,83908371,2512341634,3803740692,2075208622,213261112,2463272603,3855990285,2094854071,198958881,2262029012,4057260610,1759359992,534414190,2176718541,4139329115,1873836001,414664567,2282248934,4279200368,1711684554,285281116,2405801727,4167216745,1634467795,376229701,2685067896,3608007406,1308918612,956543938,2808555105,3495958263,1231636301,1047427035,2932959818,3654703836,1088359270,936918e3,2847714899,3736837829,1202900863,817233897,3183342108,3401237130,1404277552,615818150,3134207493,3453421203,1423857449,601450431,3009837614,3294710456,1567103746,711928724,3020668471,3272380065,1510334235,755167117],
crc32:function(e){var t=i.crypto.crc32Table,r=-1
"string"==typeof e&&(e=i.buffer.toBuffer(e))
for(var n=0;n<e.length;n++)r=r>>>8^t[255&(r^e.readUInt8(n))]
return~r>>>0},hmac:function(e,t,r,n){return r||(r="binary"),"buffer"===r&&(r=void 0),
n||(n="sha256"),
"string"==typeof t&&(t=i.buffer.toBuffer(t)),i.crypto.lib.createHmac(n,e).update(t).digest(r)},
md5:function(e,t,r){return i.crypto.hash("md5",e,t,r)},sha256:function(e,t,r){
return i.crypto.hash("sha256",e,t,r)},hash:function(e,t,r,n){var o=i.crypto.createHash(e)
r||(r="binary"),"buffer"===r&&(r=void 0),"string"==typeof t&&(t=i.buffer.toBuffer(t))
var a=i.arraySliceFn(t),s=i.Buffer.isBuffer(t)
if(i.isBrowser()&&"undefined"!=typeof ArrayBuffer&&t&&t.buffer instanceof ArrayBuffer&&(s=!0),
n&&"object"==typeof t&&"function"==typeof t.on&&!s)t.on("data",(function(e){o.update(e)})),
t.on("error",(function(e){n(e)})),t.on("end",(function(){n(null,o.digest(r))}))
else{if(!n||!a||s||"undefined"==typeof FileReader){
i.isBrowser()&&"object"==typeof t&&!s&&(t=new i.Buffer(new Uint8Array(t)))
var u=o.update(t).digest(r)
return n&&n(null,u),u}var c=0,p=new FileReader
p.onerror=function(){n(new Error("Failed to read data."))},p.onload=function(){
var e=new i.Buffer(new Uint8Array(p.result))
o.update(e),c+=e.length,p._continueReading()},p._continueReading=function(){
if(c>=t.size)n(null,o.digest(r))
else{var e=c+524288
e>t.size&&(e=t.size),p.readAsArrayBuffer(a.call(t,c,e))}},p._continueReading()}},toHex:function(e){
for(var t=[],r=0;r<e.length;r++)t.push(("0"+e.charCodeAt(r).toString(16)).substr(-2,2))
return t.join("")},createHash:function(e){return i.crypto.lib.createHash(e)}},abort:{},
each:function(e,t){
for(var r in e)if(Object.prototype.hasOwnProperty.call(e,r)&&t.call(this,r,e[r])===i.abort)break},
arrayEach:function(e,t){
for(var r in e)if(Object.prototype.hasOwnProperty.call(e,r)&&t.call(this,e[r],parseInt(r,10))===i.abort)break
},update:function(e,t){return i.each(t,(function(t,r){e[t]=r})),e},merge:function(e,t){
return i.update(i.copy(e),t)},copy:function(e){if(null==e)return e
var t={}
for(var r in e)t[r]=e[r]
return t},isEmpty:function(e){for(var t in e)if(Object.prototype.hasOwnProperty.call(e,t))return!1
return!0},arraySliceFn:function(e){var t=e.slice||e.webkitSlice||e.mozSlice
return"function"==typeof t?t:null},isType:function(e,t){
return"function"==typeof t&&(t=i.typeName(t)),Object.prototype.toString.call(e)==="[object "+t+"]"},
typeName:function(e){if(Object.prototype.hasOwnProperty.call(e,"name"))return e.name
var t=e.toString(),r=t.match(/^\s*function (.+)\(/)
return r?r[1]:t},error:function(e,t){var r=null
for(var n in"string"==typeof e.message&&""!==e.message&&("string"==typeof t||t&&t.message)&&((r=i.copy(e)).message=e.message),
e.message=e.message||null,
"string"==typeof t?e.message=t:"object"==typeof t&&null!==t&&(i.update(e,t),
t.message&&(e.message=t.message),
(t.code||t.name)&&(e.code=t.code||t.name),t.stack&&(e.stack=t.stack)),
"function"==typeof Object.defineProperty&&(Object.defineProperty(e,"name",{writable:!0,enumerable:!1
}),Object.defineProperty(e,"message",{enumerable:!0
})),e.name=String(t&&t.name||e.name||e.code||"Error"),e.time=new Date,r&&(e.originalError=r),
t||{})if("["===n[0]&&"]"===n[n.length-1]){if("code"===(n=n.slice(1,-1))||"message"===n)continue
e["["+n+"]"]="See error."+n+" for details.",Object.defineProperty(e,n,{value:e[n]||t&&t[n]||r&&r[n],
enumerable:!1,writable:!0})}return e},inherit:function(e,t){var r=null
if(void 0===t)t=e,e=Object,r={}
else{var n=function(){}
n.prototype=e.prototype,r=new n}return t.constructor===Object&&(t.constructor=function(){
if(e!==Object)return e.apply(this,arguments)
}),t.constructor.prototype=r,i.update(t.constructor.prototype,t),t.constructor.__super__=e,
t.constructor},mixin:function(){
for(var e=arguments[0],t=1;t<arguments.length;t++)for(var r in arguments[t].prototype){
var n=arguments[t].prototype[r]
"constructor"!==r&&(e.prototype[r]=n)}return e},hideProperties:function(e,t){
"function"==typeof Object.defineProperty&&i.arrayEach(t,(function(t){Object.defineProperty(e,t,{
enumerable:!1,writable:!0,configurable:!0})}))},property:function(e,t,r,n,i){var o={configurable:!0,
enumerable:void 0===n||n}
"function"!=typeof r||i?(o.value=r,o.writable=!0):o.get=r,Object.defineProperty(e,t,o)},
memoizedProperty:function(e,t,r,n){var o=null
i.property(e,t,(function(){return null===o&&(o=r()),o}),n)},hoistPayloadMember:function(e){
var t=e.request,r=t.operation,n=t.service.api.operations[r],o=n.output
if(o.payload&&!n.hasEventOutput){var a=o.members[o.payload],s=e.data[o.payload]
"structure"===a.type&&i.each(s,(function(t,r){i.property(e.data,t,r,!1)}))}},
computeSha256:function(e,t){if(i.isNode()){var n=i.stream.Stream,o=r(1976)
if("function"==typeof n&&e instanceof n){
if("string"!=typeof e.path)return t(new Error("Non-file stream objects are not supported with SigV4"))
var a={}
"number"==typeof e.start&&(a.start=e.start),"number"==typeof e.end&&(a.end=e.end),
e=o.createReadStream(e.path,a)}}i.crypto.sha256(e,"hex",(function(e,r){e?t(e):t(null,r)}))},
isClockSkewed:function(e){
if(e)return i.property(n.config,"isClockSkewed",Math.abs((new Date).getTime()-e)>=3e5,!1),
n.config.isClockSkewed},applyClockOffset:function(e){
e&&(n.config.systemClockOffset=e-(new Date).getTime())},extractRequestId:function(e){
var t=e.httpResponse.headers["x-amz-request-id"]||e.httpResponse.headers["x-amzn-requestid"]
!t&&e.data&&e.data.ResponseMetadata&&(t=e.data.ResponseMetadata.RequestId),t&&(e.requestId=t),
e.error&&(e.error.requestId=t)},addPromises:function(e,t){var r=!1
void 0===t&&n&&n.config&&(t=n.config.getPromisesDependency()),void 0===t&&"undefined"!=typeof Promise&&(t=Promise),
"function"!=typeof t&&(r=!0),Array.isArray(e)||(e=[e])
for(var i=0;i<e.length;i++){var o=e[i]
r?o.deletePromisesFromClass&&o.deletePromisesFromClass():o.addPromisesToClass&&o.addPromisesToClass(t)
}},promisifyMethod:function(e,t){return function(){
var r=this,n=Array.prototype.slice.call(arguments)
return new t((function(t,i){n.push((function(e,r){e?i(e):t(r)})),r[e].apply(r,n)}))}},
isDualstackAvailable:function(e){if(!e)return!1
var t=r(5087)
return"string"!=typeof e&&(e=e.serviceIdentifier),!("string"!=typeof e||!t.hasOwnProperty(e)||!t[e].dualstackAvailable)
},calculateRetryDelay:function(e,t,r){t||(t={})
var n=t.customBackoff||null
if("function"==typeof n)return n(e,r)
var i="number"==typeof t.base?t.base:100
return Math.random()*(Math.pow(2,e)*i)},handleRequestWithRetries:function(e,t,r){t||(t={})
var o=n.HttpClient.getInstance(),a=t.httpOptions||{},s=0,u=function(e){var n=t.maxRetries||0
if(e&&"TimeoutError"===e.code&&(e.retryable=!0),e&&e.retryable&&s<n){
var o=i.calculateRetryDelay(s,t.retryDelayOptions,e)
if(o>=0)return s++,void setTimeout(c,o+(e.retryAfter||0))}r(e)},c=function(){var t=""
o.handleRequest(e,a,(function(e){e.on("data",(function(e){t+=e.toString()})),e.on("end",(function(){
var n=e.statusCode
if(n<300)r(null,t)
else{var o=1e3*parseInt(e.headers["retry-after"],10)||0,a=i.error(new Error,{statusCode:n,
retryable:n>=500||429===n})
o&&a.retryable&&(a.retryAfter=o),u(a)}}))}),u)}
n.util.defer(c)},uuid:{v4:function(){return r(2107).v4()}},convertPayloadToString:function(e){
var t=e.request,r=t.operation,n=t.service.api.operations[r].output||{}
n.payload&&e.data[n.payload]&&(e.data[n.payload]=e.data[n.payload].toString())},defer:function(e){
"object"==typeof process&&"function"==typeof process.nextTick?process.nextTick(e):"function"==typeof setImmediate?setImmediate(e):setTimeout(e,0)
},getRequestPayloadShape:function(e){var t=e.service.api.operations
if(t){var r=(t||{})[e.operation]
if(r&&r.input&&r.input.payload)return r.input.members[r.input.payload]}},
getProfilesFromSharedConfig:function(e,t){var r={},n={}
process.env[i.configOptInEnv]&&(n=e.loadFrom({isConfig:!0,
filename:process.env[i.sharedConfigFileEnv]}))
var o={}
try{o=e.loadFrom({filename:t||process.env[i.configOptInEnv]&&process.env[i.sharedCredentialsFileEnv]
})}catch(e){if(!process.env[i.configOptInEnv])throw e}
for(var a=0,s=Object.keys(n);a<s.length;a++)r[s[a]]=u(r[s[a]]||{},n[s[a]])
for(a=0,s=Object.keys(o);a<s.length;a++)r[s[a]]=u(r[s[a]]||{},o[s[a]])
return r
function u(e,t){for(var r=0,n=Object.keys(t);r<n.length;r++)e[n[r]]=t[n[r]]
return e}},ARN:{validate:function(e){return e&&0===e.indexOf("arn:")&&e.split(":").length>=6},
parse:function(e){var t=e.split(":")
return{partition:t[1],service:t[2],region:t[3],accountId:t[4],resource:t.slice(5).join(":")}},
build:function(e){
if(void 0===e.service||void 0===e.region||void 0===e.accountId||void 0===e.resource)throw i.error(new Error("Input ARN object is invalid"))
return"arn:"+(e.partition||"aws")+":"+e.service+":"+e.region+":"+e.accountId+":"+e.resource}},
defaultProfile:"default",configOptInEnv:"AWS_SDK_LOAD_CONFIG",
sharedCredentialsFileEnv:"AWS_SHARED_CREDENTIALS_FILE",sharedConfigFileEnv:"AWS_CONFIG_FILE",
imdsDisabledEnv:"AWS_EC2_METADATA_DISABLED"}
e.exports=i},1838:(e,t,r)=>{var n=r(9019),i=r(4533).XmlNode,o=r(7710).XmlText
function a(){}function s(e,t,r){switch(r.type){case"structure":return function(e,t,r){
n.arrayEach(r.memberNames,(function(n){var o=r.members[n]
if("body"===o.location){var a=t[n],c=o.name
if(null!=a)if(o.isXmlAttribute)e.addAttribute(c,a)
else if(o.flattened)s(e,a,o)
else{var p=new i(c)
e.addChildNode(p),u(p,o),s(p,a,o)}}}))}(e,t,r)
case"map":return function(e,t,r){var o=r.key.name||"key",a=r.value.name||"value"
n.each(t,(function(t,n){var u=new i(r.flattened?r.name:"entry")
e.addChildNode(u)
var c=new i(o),p=new i(a)
u.addChildNode(c),u.addChildNode(p),s(c,t,r.key),s(p,n,r.value)}))}(e,t,r)
case"list":return function(e,t,r){r.flattened?n.arrayEach(t,(function(t){
var n=r.member.name||r.name,o=new i(n)
e.addChildNode(o),s(o,t,r.member)})):n.arrayEach(t,(function(t){
var n=r.member.name||"member",o=new i(n)
e.addChildNode(o),s(o,t,r.member)}))}(e,t,r)
default:return function(e,t,r){e.addChildNode(new o(r.toWireFormat(t)))}(e,t,r)}}function u(e,t,r){
var n,i="xmlns"
t.xmlNamespaceUri?(n=t.xmlNamespaceUri,t.xmlNamespacePrefix&&(i+=":"+t.xmlNamespacePrefix)):r&&t.api.xmlNamespaceUri&&(n=t.api.xmlNamespaceUri),
n&&e.addAttribute(i,n)}a.prototype.toXML=function(e,t,r,n){var o=new i(r)
return u(o,t,!0),s(o,e,t),o.children.length>0||n?o.toString():""},e.exports=a},4735:e=>{e.exports={
escapeAttribute:function(e){
return e.replace(/&/g,"&amp;").replace(/'/g,"&apos;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;")
}}},4215:e=>{e.exports={escapeElement:function(e){
return e.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/\r/g,"&#x0D;").replace(/\n/g,"&#x0A;").replace(/\u0085/g,"&#x85;").replace(/\u2028/,"&#x2028;")
}}},4533:(e,t,r)=>{var n=r(4735).escapeAttribute
function i(e,t){void 0===t&&(t=[]),this.name=e,this.children=t,this.attributes={}}
i.prototype.addAttribute=function(e,t){return this.attributes[e]=t,this
},i.prototype.addChildNode=function(e){return this.children.push(e),this
},i.prototype.removeAttribute=function(e){return delete this.attributes[e],this},
i.prototype.toString=function(){
for(var e=Boolean(this.children.length),t="<"+this.name,r=this.attributes,i=0,o=Object.keys(r);i<o.length;i++){
var a=o[i],s=r[a]
null!=s&&(t+=" "+a+'="'+n(""+s)+'"')}return t+(e?">"+this.children.map((function(e){
return e.toString()})).join("")+"</"+this.name+">":"/>")},e.exports={XmlNode:i}},7710:(e,t,r)=>{
var n=r(4215).escapeElement
function i(e){this.value=e}i.prototype.toString=function(){return n(""+this.value)},e.exports={
XmlText:i}},5593:(e,t,r)=>{"use strict"
var n=r(8278),i=function(){function e(e){
void 0===e&&(e=1e3),this.maxSize=e,this.cache=new n.LRUCache(e)}
return Object.defineProperty(e.prototype,"size",{get:function(){return this.cache.length},
enumerable:!0,configurable:!0}),e.prototype.put=function(t,r){
var n="string"!=typeof t?e.getKeyString(t):t,i=this.populateValue(r)
this.cache.put(n,i)},e.prototype.get=function(t){
var r="string"!=typeof t?e.getKeyString(t):t,n=Date.now(),i=this.cache.get(r)
if(i){for(var o=i.length-1;o>=0;o--)i[o].Expire<n&&i.splice(o,1)
if(0===i.length)return void this.cache.remove(r)}return i},e.getKeyString=function(e){
for(var t=[],r=Object.keys(e).sort(),n=0;n<r.length;n++){var i=r[n]
void 0!==e[i]&&t.push(e[i])}return t.join(" ")},e.prototype.populateValue=function(e){
var t=Date.now()
return e.map((function(e){return{Address:e.Address||"",Expire:t+60*(e.CachePeriodInMinutes||1)*1e3}
}))},e.prototype.empty=function(){this.cache.empty()},e.prototype.remove=function(t){
var r="string"!=typeof t?e.getKeyString(t):t
this.cache.remove(r)},e}()
t.k=i},8278:(e,t)=>{"use strict"
Object.defineProperty(t,"__esModule",{value:!0})
var r=function(e,t){this.key=e,this.value=t},n=function(){function e(e){if(this.nodeMap={},
this.size=0,"number"!=typeof e||e<1)throw new Error("Cache size can only be positive number")
this.sizeLimit=e}return Object.defineProperty(e.prototype,"length",{get:function(){return this.size
},enumerable:!0,configurable:!0}),e.prototype.prependToList=function(e){
this.headerNode?(this.headerNode.prev=e,e.next=this.headerNode):this.tailNode=e,this.headerNode=e,
this.size++},e.prototype.removeFromTail=function(){if(this.tailNode){var e=this.tailNode,t=e.prev
return t&&(t.next=void 0),e.prev=void 0,this.tailNode=t,this.size--,e}
},e.prototype.detachFromList=function(e){this.headerNode===e&&(this.headerNode=e.next),
this.tailNode===e&&(this.tailNode=e.prev),e.prev&&(e.prev.next=e.next),e.next&&(e.next.prev=e.prev),
e.next=void 0,e.prev=void 0,this.size--},e.prototype.get=function(e){if(this.nodeMap[e]){
var t=this.nodeMap[e]
return this.detachFromList(t),this.prependToList(t),t.value}},e.prototype.remove=function(e){
if(this.nodeMap[e]){var t=this.nodeMap[e]
this.detachFromList(t),delete this.nodeMap[e]}},e.prototype.put=function(e,t){
if(this.nodeMap[e])this.remove(e)
else if(this.size===this.sizeLimit){var n=this.removeFromTail().key
delete this.nodeMap[n]}var i=new r(e,t)
this.nodeMap[e]=i,this.prependToList(i)},e.prototype.empty=function(){
for(var e=Object.keys(this.nodeMap),t=0;t<e.length;t++){var r=e[t],n=this.nodeMap[r]
this.detachFromList(n),delete this.nodeMap[r]}},e}()
t.LRUCache=n},8075:(e,t,r)=>{"use strict"
var n=r(453),i=r(487),o=i(n("String.prototype.indexOf"))
e.exports=function(e,t){var r=n(e,!!t)
return"function"==typeof r&&o(e,".prototype.")>-1?i(r):r}},487:(e,t,r)=>{"use strict"
var n=r(6743),i=r(453),o=r(6897),a=r(9675),s=i("%Function.prototype.apply%"),u=i("%Function.prototype.call%"),c=i("%Reflect.apply%",!0)||n.call(u,s),p=r(655),l=i("%Math.max%")
e.exports=function(e){if("function"!=typeof e)throw new a("a function is required")
var t=c(n,u,arguments)
return o(t,1+l(0,e.length-(arguments.length-1)),!0)}
var f=function(){return c(n,s,arguments)}
p?p(e.exports,"apply",{value:f}):e.exports.apply=f},41:(e,t,r)=>{"use strict"
var n=r(655),i=r(8068),o=r(9675),a=r(5795)
e.exports=function(e,t,r){
if(!e||"object"!=typeof e&&"function"!=typeof e)throw new o("`obj` must be an object or a function`")
if("string"!=typeof t&&"symbol"!=typeof t)throw new o("`property` must be a string or a symbol`")
if(arguments.length>3&&"boolean"!=typeof arguments[3]&&null!==arguments[3])throw new o("`nonEnumerable`, if provided, must be a boolean or null")
if(arguments.length>4&&"boolean"!=typeof arguments[4]&&null!==arguments[4])throw new o("`nonWritable`, if provided, must be a boolean or null")
if(arguments.length>5&&"boolean"!=typeof arguments[5]&&null!==arguments[5])throw new o("`nonConfigurable`, if provided, must be a boolean or null")
if(arguments.length>6&&"boolean"!=typeof arguments[6])throw new o("`loose`, if provided, must be a boolean")
var s=arguments.length>3?arguments[3]:null,u=arguments.length>4?arguments[4]:null,c=arguments.length>5?arguments[5]:null,p=arguments.length>6&&arguments[6],l=!!a&&a(e,t)
if(n)n(e,t,{configurable:null===c&&l?l.configurable:!c,enumerable:null===s&&l?l.enumerable:!s,
value:r,writable:null===u&&l?l.writable:!u})
else{
if(!p&&(s||u||c))throw new i("This environment does not support defining a property as non-configurable, non-writable, or non-enumerable.")
e[t]=r}}},655:(e,t,r)=>{"use strict"
var n=r(453)("%Object.defineProperty%",!0)||!1
if(n)try{n({},"a",{value:1})}catch(e){n=!1}e.exports=n},1237:e=>{"use strict"
e.exports=EvalError},9383:e=>{"use strict"
e.exports=Error},9290:e=>{"use strict"
e.exports=RangeError},9538:e=>{"use strict"
e.exports=ReferenceError},8068:e=>{"use strict"
e.exports=SyntaxError},9675:e=>{"use strict"
e.exports=TypeError},5345:e=>{"use strict"
e.exports=URIError},2682:(e,t,r)=>{"use strict"
var n=r(9600),i=Object.prototype.toString,o=Object.prototype.hasOwnProperty
e.exports=function(e,t,r){if(!n(t))throw new TypeError("iterator must be a function")
var a
arguments.length>=3&&(a=r),"[object Array]"===i.call(e)?function(e,t,r){
for(var n=0,i=e.length;n<i;n++)o.call(e,n)&&(null==r?t(e[n],n,e):t.call(r,e[n],n,e))
}(e,t,a):"string"==typeof e?function(e,t,r){
for(var n=0,i=e.length;n<i;n++)null==r?t(e.charAt(n),n,e):t.call(r,e.charAt(n),n,e)
}(e,t,a):function(e,t,r){for(var n in e)o.call(e,n)&&(null==r?t(e[n],n,e):t.call(r,e[n],n,e))
}(e,t,a)}},9353:e=>{"use strict"
var t=Object.prototype.toString,r=Math.max,n=function(e,t){
for(var r=[],n=0;n<e.length;n+=1)r[n]=e[n]
for(var i=0;i<t.length;i+=1)r[i+e.length]=t[i]
return r}
e.exports=function(e){var i=this
if("function"!=typeof i||"[object Function]"!==t.apply(i))throw new TypeError("Function.prototype.bind called on incompatible "+i)
for(var o,a=function(e,t){for(var r=[],n=1,i=0;n<e.length;n+=1,i+=1)r[i]=e[n]
return r}(arguments),s=r(0,i.length-a.length),u=[],c=0;c<s;c++)u[c]="$"+c
if(o=Function("binder","return function ("+function(e,t){for(var r="",n=0;n<e.length;n+=1)r+=e[n],
n+1<e.length&&(r+=",")
return r}(u)+"){ return binder.apply(this,arguments); }")((function(){if(this instanceof o){
var t=i.apply(this,n(a,arguments))
return Object(t)===t?t:this}return i.apply(e,n(a,arguments))})),i.prototype){var p=function(){}
p.prototype=i.prototype,o.prototype=new p,p.prototype=null}return o}},6743:(e,t,r)=>{"use strict"
var n=r(9353)
e.exports=Function.prototype.bind||n},453:(e,t,r)=>{"use strict"
var n,i=r(9383),o=r(1237),a=r(9290),s=r(9538),u=r(8068),c=r(9675),p=r(5345),l=Function,f=function(e){
try{return l('"use strict"; return ('+e+").constructor;")()}catch(e){}
},d=Object.getOwnPropertyDescriptor
if(d)try{d({},"")}catch(e){d=null}var h=function(){throw new c},m=d?function(){try{return h
}catch(e){try{return d(arguments,"callee").get}catch(e){return h}}
}():h,v=r(4039)(),y=r(24)(),g=Object.getPrototypeOf||(y?function(e){return e.__proto__
}:null),b={},S="undefined"!=typeof Uint8Array&&g?g(Uint8Array):n,E={__proto__:null,
"%AggregateError%":"undefined"==typeof AggregateError?n:AggregateError,"%Array%":Array,
"%ArrayBuffer%":"undefined"==typeof ArrayBuffer?n:ArrayBuffer,
"%ArrayIteratorPrototype%":v&&g?g([][Symbol.iterator]()):n,"%AsyncFromSyncIteratorPrototype%":n,
"%AsyncFunction%":b,"%AsyncGenerator%":b,"%AsyncGeneratorFunction%":b,"%AsyncIteratorPrototype%":b,
"%Atomics%":"undefined"==typeof Atomics?n:Atomics,"%BigInt%":"undefined"==typeof BigInt?n:BigInt,
"%BigInt64Array%":"undefined"==typeof BigInt64Array?n:BigInt64Array,
"%BigUint64Array%":"undefined"==typeof BigUint64Array?n:BigUint64Array,"%Boolean%":Boolean,
"%DataView%":"undefined"==typeof DataView?n:DataView,"%Date%":Date,"%decodeURI%":decodeURI,
"%decodeURIComponent%":decodeURIComponent,"%encodeURI%":encodeURI,
"%encodeURIComponent%":encodeURIComponent,"%Error%":i,"%eval%":eval,"%EvalError%":o,
"%Float32Array%":"undefined"==typeof Float32Array?n:Float32Array,
"%Float64Array%":"undefined"==typeof Float64Array?n:Float64Array,
"%FinalizationRegistry%":"undefined"==typeof FinalizationRegistry?n:FinalizationRegistry,
"%Function%":l,"%GeneratorFunction%":b,"%Int8Array%":"undefined"==typeof Int8Array?n:Int8Array,
"%Int16Array%":"undefined"==typeof Int16Array?n:Int16Array,
"%Int32Array%":"undefined"==typeof Int32Array?n:Int32Array,"%isFinite%":isFinite,"%isNaN%":isNaN,
"%IteratorPrototype%":v&&g?g(g([][Symbol.iterator]())):n,"%JSON%":"object"==typeof JSON?JSON:n,
"%Map%":"undefined"==typeof Map?n:Map,
"%MapIteratorPrototype%":"undefined"!=typeof Map&&v&&g?g((new Map)[Symbol.iterator]()):n,
"%Math%":Math,"%Number%":Number,"%Object%":Object,"%parseFloat%":parseFloat,"%parseInt%":parseInt,
"%Promise%":"undefined"==typeof Promise?n:Promise,"%Proxy%":"undefined"==typeof Proxy?n:Proxy,
"%RangeError%":a,"%ReferenceError%":s,"%Reflect%":"undefined"==typeof Reflect?n:Reflect,
"%RegExp%":RegExp,"%Set%":"undefined"==typeof Set?n:Set,
"%SetIteratorPrototype%":"undefined"!=typeof Set&&v&&g?g((new Set)[Symbol.iterator]()):n,
"%SharedArrayBuffer%":"undefined"==typeof SharedArrayBuffer?n:SharedArrayBuffer,"%String%":String,
"%StringIteratorPrototype%":v&&g?g(""[Symbol.iterator]()):n,"%Symbol%":v?Symbol:n,"%SyntaxError%":u,
"%ThrowTypeError%":m,"%TypedArray%":S,"%TypeError%":c,
"%Uint8Array%":"undefined"==typeof Uint8Array?n:Uint8Array,
"%Uint8ClampedArray%":"undefined"==typeof Uint8ClampedArray?n:Uint8ClampedArray,
"%Uint16Array%":"undefined"==typeof Uint16Array?n:Uint16Array,
"%Uint32Array%":"undefined"==typeof Uint32Array?n:Uint32Array,"%URIError%":p,
"%WeakMap%":"undefined"==typeof WeakMap?n:WeakMap,"%WeakRef%":"undefined"==typeof WeakRef?n:WeakRef,
"%WeakSet%":"undefined"==typeof WeakSet?n:WeakSet}
if(g)try{null.error}catch(e){var w=g(g(e))
E["%Error.prototype%"]=w}var R=function e(t){var r
if("%AsyncFunction%"===t)r=f("async function () {}")
else if("%GeneratorFunction%"===t)r=f("function* () {}")
else if("%AsyncGeneratorFunction%"===t)r=f("async function* () {}")
else if("%AsyncGenerator%"===t){var n=e("%AsyncGeneratorFunction%")
n&&(r=n.prototype)}else if("%AsyncIteratorPrototype%"===t){var i=e("%AsyncGenerator%")
i&&g&&(r=g(i.prototype))}return E[t]=r,r},x={__proto__:null,
"%ArrayBufferPrototype%":["ArrayBuffer","prototype"],"%ArrayPrototype%":["Array","prototype"],
"%ArrayProto_entries%":["Array","prototype","entries"],
"%ArrayProto_forEach%":["Array","prototype","forEach"],
"%ArrayProto_keys%":["Array","prototype","keys"],
"%ArrayProto_values%":["Array","prototype","values"],
"%AsyncFunctionPrototype%":["AsyncFunction","prototype"],
"%AsyncGenerator%":["AsyncGeneratorFunction","prototype"],
"%AsyncGeneratorPrototype%":["AsyncGeneratorFunction","prototype","prototype"],
"%BooleanPrototype%":["Boolean","prototype"],"%DataViewPrototype%":["DataView","prototype"],
"%DatePrototype%":["Date","prototype"],"%ErrorPrototype%":["Error","prototype"],
"%EvalErrorPrototype%":["EvalError","prototype"],
"%Float32ArrayPrototype%":["Float32Array","prototype"],
"%Float64ArrayPrototype%":["Float64Array","prototype"],
"%FunctionPrototype%":["Function","prototype"],"%Generator%":["GeneratorFunction","prototype"],
"%GeneratorPrototype%":["GeneratorFunction","prototype","prototype"],
"%Int8ArrayPrototype%":["Int8Array","prototype"],"%Int16ArrayPrototype%":["Int16Array","prototype"],
"%Int32ArrayPrototype%":["Int32Array","prototype"],"%JSONParse%":["JSON","parse"],
"%JSONStringify%":["JSON","stringify"],"%MapPrototype%":["Map","prototype"],
"%NumberPrototype%":["Number","prototype"],"%ObjectPrototype%":["Object","prototype"],
"%ObjProto_toString%":["Object","prototype","toString"],
"%ObjProto_valueOf%":["Object","prototype","valueOf"],"%PromisePrototype%":["Promise","prototype"],
"%PromiseProto_then%":["Promise","prototype","then"],"%Promise_all%":["Promise","all"],
"%Promise_reject%":["Promise","reject"],"%Promise_resolve%":["Promise","resolve"],
"%RangeErrorPrototype%":["RangeError","prototype"],
"%ReferenceErrorPrototype%":["ReferenceError","prototype"],
"%RegExpPrototype%":["RegExp","prototype"],"%SetPrototype%":["Set","prototype"],
"%SharedArrayBufferPrototype%":["SharedArrayBuffer","prototype"],
"%StringPrototype%":["String","prototype"],"%SymbolPrototype%":["Symbol","prototype"],
"%SyntaxErrorPrototype%":["SyntaxError","prototype"],
"%TypedArrayPrototype%":["TypedArray","prototype"],"%TypeErrorPrototype%":["TypeError","prototype"],
"%Uint8ArrayPrototype%":["Uint8Array","prototype"],
"%Uint8ClampedArrayPrototype%":["Uint8ClampedArray","prototype"],
"%Uint16ArrayPrototype%":["Uint16Array","prototype"],
"%Uint32ArrayPrototype%":["Uint32Array","prototype"],"%URIErrorPrototype%":["URIError","prototype"],
"%WeakMapPrototype%":["WeakMap","prototype"],"%WeakSetPrototype%":["WeakSet","prototype"]
},_=r(6743),A=r(9957),C=_.call(Function.call,Array.prototype.concat),k=_.call(Function.apply,Array.prototype.splice),T=_.call(Function.call,String.prototype.replace),O=_.call(Function.call,String.prototype.slice),P=_.call(Function.call,RegExp.prototype.exec),M=/[^%.[\]]+|\[(?:(-?\d+(?:\.\d+)?)|(["'])((?:(?!\2)[^\\]|\\.)*?)\2)\]|(?=(?:\.|\[\])(?:\.|\[\]|%$))/g,I=/\\(\\)?/g,q=function(e,t){
var r,n=e
if(A(x,n)&&(n="%"+(r=x[n])[0]+"%"),A(E,n)){var i=E[n]
if(i===b&&(i=R(n)),void 0===i&&!t)throw new c("intrinsic "+e+" exists, but is not available. Please file an issue!")
return{alias:r,name:n,value:i}}throw new u("intrinsic "+e+" does not exist!")}
e.exports=function(e,t){
if("string"!=typeof e||0===e.length)throw new c("intrinsic name must be a non-empty string")
if(arguments.length>1&&"boolean"!=typeof t)throw new c('"allowMissing" argument must be a boolean')
if(null===P(/^%?[^%]*%?$/,e))throw new u("`%` may not be present anywhere but at the beginning and end of the intrinsic name")
var r=function(e){var t=O(e,0,1),r=O(e,-1)
if("%"===t&&"%"!==r)throw new u("invalid intrinsic syntax, expected closing `%`")
if("%"===r&&"%"!==t)throw new u("invalid intrinsic syntax, expected opening `%`")
var n=[]
return T(e,M,(function(e,t,r,i){n[n.length]=r?T(i,I,"$1"):t||e})),n
}(e),n=r.length>0?r[0]:"",i=q("%"+n+"%",t),o=i.name,a=i.value,s=!1,p=i.alias
p&&(n=p[0],k(r,C([0,1],p)))
for(var l=1,f=!0;l<r.length;l+=1){var h=r[l],m=O(h,0,1),v=O(h,-1)
if(('"'===m||"'"===m||"`"===m||'"'===v||"'"===v||"`"===v)&&m!==v)throw new u("property names with quotes must have matching quotes")
if("constructor"!==h&&f||(s=!0),A(E,o="%"+(n+="."+h)+"%"))a=E[o]
else if(null!=a){if(!(h in a)){
if(!t)throw new c("base intrinsic for "+e+" exists, but the property is not available.")
return}if(d&&l+1>=r.length){var y=d(a,h)
a=(f=!!y)&&"get"in y&&!("originalValue"in y.get)?y.get:a[h]}else f=A(a,h),a=a[h]
f&&!s&&(E[o]=a)}}return a}},5795:(e,t,r)=>{"use strict"
var n=r(453)("%Object.getOwnPropertyDescriptor%",!0)
if(n)try{n([],"length")}catch(e){n=null}e.exports=n},592:(e,t,r)=>{"use strict"
var n=r(655),i=function(){return!!n}
i.hasArrayLengthDefineBug=function(){if(!n)return null
try{return 1!==n([],"length",{value:1}).length}catch(e){return!0}},e.exports=i},24:e=>{"use strict"
var t={__proto__:null,foo:{}},r=Object
e.exports=function(){return{__proto__:t}.foo===t.foo&&!(t instanceof r)}},4039:(e,t,r)=>{
"use strict"
var n="undefined"!=typeof Symbol&&Symbol,i=r(1333)
e.exports=function(){
return"function"==typeof n&&"function"==typeof Symbol&&"symbol"==typeof n("foo")&&"symbol"==typeof Symbol("bar")&&i()
}},1333:e=>{"use strict"
e.exports=function(){
if("function"!=typeof Symbol||"function"!=typeof Object.getOwnPropertySymbols)return!1
if("symbol"==typeof Symbol.iterator)return!0
var e={},t=Symbol("test"),r=Object(t)
if("string"==typeof t)return!1
if("[object Symbol]"!==Object.prototype.toString.call(t))return!1
if("[object Symbol]"!==Object.prototype.toString.call(r))return!1
for(t in e[t]=42,e)return!1
if("function"==typeof Object.keys&&0!==Object.keys(e).length)return!1
if("function"==typeof Object.getOwnPropertyNames&&0!==Object.getOwnPropertyNames(e).length)return!1
var n=Object.getOwnPropertySymbols(e)
if(1!==n.length||n[0]!==t)return!1
if(!Object.prototype.propertyIsEnumerable.call(e,t))return!1
if("function"==typeof Object.getOwnPropertyDescriptor){var i=Object.getOwnPropertyDescriptor(e,t)
if(42!==i.value||!0!==i.enumerable)return!1}return!0}},9092:(e,t,r)=>{"use strict"
var n=r(1333)
e.exports=function(){return n()&&!!Symbol.toStringTag}},9957:(e,t,r)=>{"use strict"
var n=Function.prototype.call,i=Object.prototype.hasOwnProperty,o=r(6743)
e.exports=o.call(n,i)},6698:e=>{"function"==typeof Object.create?e.exports=function(e,t){
t&&(e.super_=t,e.prototype=Object.create(t.prototype,{constructor:{value:e,enumerable:!1,
writable:!0,configurable:!0}}))}:e.exports=function(e,t){if(t){e.super_=t
var r=function(){}
r.prototype=t.prototype,e.prototype=new r,e.prototype.constructor=e}}},7244:(e,t,r)=>{"use strict"
var n=r(9092)(),i=r(8075)("Object.prototype.toString"),o=function(e){
return!(n&&e&&"object"==typeof e&&Symbol.toStringTag in e)&&"[object Arguments]"===i(e)
},a=function(e){
return!!o(e)||null!==e&&"object"==typeof e&&"number"==typeof e.length&&e.length>=0&&"[object Array]"!==i(e)&&"[object Function]"===i(e.callee)
},s=function(){return o(arguments)}()
o.isLegacyArguments=a,e.exports=s?o:a},9600:e=>{"use strict"
var t,r,n=Function.prototype.toString,i="object"==typeof Reflect&&null!==Reflect&&Reflect.apply
if("function"==typeof i&&"function"==typeof Object.defineProperty)try{
t=Object.defineProperty({},"length",{get:function(){throw r}}),r={},i((function(){throw 42}),null,t)
}catch(e){e!==r&&(i=null)}else i=null
var o=/^\s*class\b/,a=function(e){try{var t=n.call(e)
return o.test(t)}catch(e){return!1}},s=function(e){try{return!a(e)&&(n.call(e),!0)}catch(e){return!1
}
},u=Object.prototype.toString,c="function"==typeof Symbol&&!!Symbol.toStringTag,p=!(0 in[,]),l=function(){
return!1}
if("object"==typeof document){var f=document.all
u.call(f)===u.call(document.all)&&(l=function(e){if((p||!e)&&(void 0===e||"object"==typeof e))try{
var t=u.call(e)
return("[object HTMLAllCollection]"===t||"[object HTML document.all class]"===t||"[object HTMLCollection]"===t||"[object Object]"===t)&&null==e("")
}catch(e){}return!1})}e.exports=i?function(e){if(l(e))return!0
if(!e)return!1
if("function"!=typeof e&&"object"!=typeof e)return!1
try{i(e,null,t)}catch(e){if(e!==r)return!1}return!a(e)&&s(e)}:function(e){if(l(e))return!0
if(!e)return!1
if("function"!=typeof e&&"object"!=typeof e)return!1
if(c)return s(e)
if(a(e))return!1
var t=u.call(e)
return!("[object Function]"!==t&&"[object GeneratorFunction]"!==t&&!/^\[object HTML/.test(t))&&s(e)}
},8184:(e,t,r)=>{"use strict"
var n,i=Object.prototype.toString,o=Function.prototype.toString,a=/^\s*(?:function)?\*/,s=r(9092)(),u=Object.getPrototypeOf
e.exports=function(e){if("function"!=typeof e)return!1
if(a.test(o.call(e)))return!0
if(!s)return"[object GeneratorFunction]"===i.call(e)
if(!u)return!1
if(void 0===n){var t=function(){if(!s)return!1
try{return Function("return function*() {}")()}catch(e){}}()
n=!!t&&u(t)}return u(e)===n}},5680:(e,t,r)=>{"use strict"
var n=r(5767)
e.exports=function(e){return!!n(e)}},7533:(e,t)=>{!function(e){"use strict"
function t(e){return null!==e&&"[object Array]"===Object.prototype.toString.call(e)}function r(e){
return null!==e&&"[object Object]"===Object.prototype.toString.call(e)}function n(e,i){
if(e===i)return!0
if(Object.prototype.toString.call(e)!==Object.prototype.toString.call(i))return!1
if(!0===t(e)){if(e.length!==i.length)return!1
for(var o=0;o<e.length;o++)if(!1===n(e[o],i[o]))return!1
return!0}if(!0===r(e)){var a={}
for(var s in e)if(hasOwnProperty.call(e,s)){if(!1===n(e[s],i[s]))return!1
a[s]=!0}for(var u in i)if(hasOwnProperty.call(i,u)&&!0!==a[u])return!1
return!0}return!1}function i(e){if(""===e||!1===e||null===e)return!0
if(t(e)&&0===e.length)return!0
if(r(e)){for(var n in e)if(e.hasOwnProperty(n))return!1
return!0}return!1}var o
o="function"==typeof String.prototype.trimLeft?function(e){return e.trimLeft()}:function(e){
return e.match(/^\s*(.*)/)[1]}
var a=0,s=2,u={0:"number",1:"any",2:"string",3:"array",4:"object",5:"boolean",6:"expression",
7:"null",8:"Array<number>",9:"Array<string>"
},c="EOF",p="UnquotedIdentifier",l="QuotedIdentifier",f="Rbracket",d="Rparen",h="Comma",m="Colon",v="Rbrace",y="Number",g="Current",b="Expref",S="Pipe",E="Or",w="And",R="EQ",x="GT",_="LT",A="GTE",C="LTE",k="NE",T="Flatten",O="Star",P="Filter",M="Dot",I="Not",q="Lbrace",D="Lbracket",N="Lparen",j="Literal",L={
".":M,"*":O,",":h,":":m,"{":q,"}":v,"]":f,"(":N,")":d,"@":g},F={"<":!0,">":!0,"=":!0,"!":!0},B={
" ":!0,"\t":!0,"\n":!0}
function z(e){return e>="0"&&e<="9"||"-"===e}function U(){}U.prototype={tokenize:function(e){
var t,r,n,i,o=[]
for(this._current=0;this._current<e.length;)if((i=e[this._current])>="a"&&i<="z"||i>="A"&&i<="Z"||"_"===i)t=this._current,
r=this._consumeUnquotedIdentifier(e),o.push({type:p,value:r,start:t})
else if(void 0!==L[e[this._current]])o.push({type:L[e[this._current]],value:e[this._current],
start:this._current}),this._current++
else if(z(e[this._current]))n=this._consumeNumber(e),o.push(n)
else if("["===e[this._current])n=this._consumeLBracket(e),o.push(n)
else if('"'===e[this._current])t=this._current,r=this._consumeQuotedIdentifier(e),o.push({type:l,
value:r,start:t})
else if("'"===e[this._current])t=this._current,r=this._consumeRawStringLiteral(e),o.push({type:j,
value:r,start:t})
else if("`"===e[this._current]){t=this._current
var a=this._consumeLiteral(e)
o.push({type:j,value:a,start:t})
}else if(void 0!==F[e[this._current]])o.push(this._consumeOperator(e))
else if(void 0!==B[e[this._current]])this._current++
else if("&"===e[this._current])t=this._current,this._current++,"&"===e[this._current]?(this._current++,
o.push({type:w,value:"&&",start:t})):o.push({type:b,value:"&",start:t})
else{if("|"!==e[this._current]){var s=new Error("Unknown character:"+e[this._current])
throw s.name="LexerError",s}t=this._current,this._current++,"|"===e[this._current]?(this._current++,
o.push({type:E,value:"||",start:t})):o.push({type:S,value:"|",start:t})}return o},
_consumeUnquotedIdentifier:function(e){var t,r=this._current
for(this._current++;this._current<e.length&&((t=e[this._current])>="a"&&t<="z"||t>="A"&&t<="Z"||t>="0"&&t<="9"||"_"===t);)this._current++
return e.slice(r,this._current)},_consumeQuotedIdentifier:function(e){var t=this._current
this._current++
for(var r=e.length;'"'!==e[this._current]&&this._current<r;){var n=this._current
"\\"!==e[n]||"\\"!==e[n+1]&&'"'!==e[n+1]?n++:n+=2,this._current=n}return this._current++,
JSON.parse(e.slice(t,this._current))},_consumeRawStringLiteral:function(e){var t=this._current
this._current++
for(var r=e.length;"'"!==e[this._current]&&this._current<r;){var n=this._current
"\\"!==e[n]||"\\"!==e[n+1]&&"'"!==e[n+1]?n++:n+=2,this._current=n}return this._current++,
e.slice(t+1,this._current-1).replace("\\'","'")},_consumeNumber:function(e){var t=this._current
this._current++
for(var r=e.length;z(e[this._current])&&this._current<r;)this._current++
var n=parseInt(e.slice(t,this._current))
return{type:y,value:n,start:t}},_consumeLBracket:function(e){var t=this._current
return this._current++,"?"===e[this._current]?(this._current++,{type:P,value:"[?",start:t
}):"]"===e[this._current]?(this._current++,{type:T,value:"[]",start:t}):{type:D,value:"[",start:t}},
_consumeOperator:function(e){var t=this._current,r=e[t]
return this._current++,"!"===r?"="===e[this._current]?(this._current++,{type:k,value:"!=",start:t
}):{type:I,value:"!",start:t}:"<"===r?"="===e[this._current]?(this._current++,{type:C,value:"<=",
start:t}):{type:_,value:"<",start:t}:">"===r?"="===e[this._current]?(this._current++,{type:A,
value:">=",start:t}):{type:x,value:">",start:t}:"="===r&&"="===e[this._current]?(this._current++,{
type:R,value:"==",start:t}):void 0},_consumeLiteral:function(e){this._current++
for(var t,r=this._current,n=e.length;"`"!==e[this._current]&&this._current<n;){var i=this._current
"\\"!==e[i]||"\\"!==e[i+1]&&"`"!==e[i+1]?i++:i+=2,this._current=i}var a=o(e.slice(r,this._current))
return a=a.replace("\\`","`"),t=this._looksLikeJSON(a)?JSON.parse(a):JSON.parse('"'+a+'"'),
this._current++,t},_looksLikeJSON:function(e){if(""===e)return!1
if('[{"'.indexOf(e[0])>=0)return!0
if(["true","false","null"].indexOf(e)>=0)return!0
if(!("-0123456789".indexOf(e[0])>=0))return!1
try{return JSON.parse(e),!0}catch(e){return!1}}}
var W={}
function H(){}function V(e){this.runtime=e}function K(e){this._interpreter=e,this.functionTable={
abs:{_func:this._functionAbs,_signature:[{types:[a]}]},avg:{_func:this._functionAvg,_signature:[{
types:[8]}]},ceil:{_func:this._functionCeil,_signature:[{types:[a]}]},contains:{
_func:this._functionContains,_signature:[{types:[s,3]},{types:[1]}]},ends_with:{
_func:this._functionEndsWith,_signature:[{types:[s]},{types:[s]}]},floor:{_func:this._functionFloor,
_signature:[{types:[a]}]},length:{_func:this._functionLength,_signature:[{types:[s,3,4]}]},map:{
_func:this._functionMap,_signature:[{types:[6]},{types:[3]}]},max:{_func:this._functionMax,
_signature:[{types:[8,9]}]},merge:{_func:this._functionMerge,_signature:[{types:[4],variadic:!0}]},
max_by:{_func:this._functionMaxBy,_signature:[{types:[3]},{types:[6]}]},sum:{
_func:this._functionSum,_signature:[{types:[8]}]},starts_with:{_func:this._functionStartsWith,
_signature:[{types:[s]},{types:[s]}]},min:{_func:this._functionMin,_signature:[{types:[8,9]}]},
min_by:{_func:this._functionMinBy,_signature:[{types:[3]},{types:[6]}]},type:{
_func:this._functionType,_signature:[{types:[1]}]},keys:{_func:this._functionKeys,_signature:[{
types:[4]}]},values:{_func:this._functionValues,_signature:[{types:[4]}]},sort:{
_func:this._functionSort,_signature:[{types:[9,8]}]},sort_by:{_func:this._functionSortBy,
_signature:[{types:[3]},{types:[6]}]},join:{_func:this._functionJoin,_signature:[{types:[s]},{
types:[9]}]},reverse:{_func:this._functionReverse,_signature:[{types:[s,3]}]},to_array:{
_func:this._functionToArray,_signature:[{types:[1]}]},to_string:{_func:this._functionToString,
_signature:[{types:[1]}]},to_number:{_func:this._functionToNumber,_signature:[{types:[1]}]},
not_null:{_func:this._functionNotNull,_signature:[{types:[1],variadic:!0}]}}}W[c]=0,W[p]=0,W[l]=0,
W[f]=0,W[d]=0,W[h]=0,W[v]=0,W[y]=0,W[g]=0,W[b]=0,W[S]=1,W[E]=2,W[w]=3,W[R]=5,W[x]=5,W[_]=5,W[A]=5,
W[C]=5,W[k]=5,W[T]=9,W[O]=20,W[P]=21,W[M]=40,W[I]=45,W[q]=50,W[D]=55,W[N]=60,H.prototype={
parse:function(e){this._loadTokens(e),this.index=0
var t=this.expression(0)
if(this._lookahead(0)!==c){
var r=this._lookaheadToken(0),n=new Error("Unexpected token type: "+r.type+", value: "+r.value)
throw n.name="ParserError",n}return t},_loadTokens:function(e){var t=(new U).tokenize(e)
t.push({type:c,value:"",start:e.length}),this.tokens=t},expression:function(e){
var t=this._lookaheadToken(0)
this._advance()
for(var r=this.nud(t),n=this._lookahead(0);e<W[n];)this._advance(),r=this.led(n,r),
n=this._lookahead(0)
return r},_lookahead:function(e){return this.tokens[this.index+e].type},_lookaheadToken:function(e){
return this.tokens[this.index+e]},_advance:function(){this.index++},nud:function(e){var t,r
switch(e.type){case j:return{type:"Literal",value:e.value}
case p:return{type:"Field",name:e.value}
case l:var n={type:"Field",name:e.value}
if(this._lookahead(0)===N)throw new Error("Quoted identifier not allowed for function names.")
return n
case I:return{type:"NotExpression",children:[t=this.expression(W.Not)]}
case O:return t=null,{type:"ValueProjection",children:[{type:"Identity"},t=this._lookahead(0)===f?{
type:"Identity"}:this._parseProjectionRHS(W.Star)]}
case P:return this.led(e.type,{type:"Identity"})
case q:return this._parseMultiselectHash()
case T:return{type:"Projection",children:[{type:T,children:[{type:"Identity"}]
},t=this._parseProjectionRHS(W.Flatten)]}
case D:return this._lookahead(0)===y||this._lookahead(0)===m?(t=this._parseIndexExpression(),
this._projectIfSlice({type:"Identity"
},t)):this._lookahead(0)===O&&this._lookahead(1)===f?(this._advance(),this._advance(),{
type:"Projection",children:[{type:"Identity"},t=this._parseProjectionRHS(W.Star)]
}):this._parseMultiselectList()
case g:return{type:g}
case b:return{type:"ExpressionReference",children:[r=this.expression(W.Expref)]}
case N:for(var i=[];this._lookahead(0)!==d;)this._lookahead(0)===g?(r={type:g
},this._advance()):r=this.expression(0),i.push(r)
return this._match(d),i[0]
default:this._errorToken(e)}},led:function(e,t){var r
switch(e){case M:var n=W.Dot
return this._lookahead(0)!==O?{type:"Subexpression",children:[t,r=this._parseDotRHS(n)]
}:(this._advance(),{type:"ValueProjection",children:[t,r=this._parseProjectionRHS(n)]})
case S:return r=this.expression(W.Pipe),{type:S,children:[t,r]}
case E:return{type:"OrExpression",children:[t,r=this.expression(W.Or)]}
case w:return{type:"AndExpression",children:[t,r=this.expression(W.And)]}
case N:for(var i,o=t.name,a=[];this._lookahead(0)!==d;)this._lookahead(0)===g?(i={type:g},
this._advance()):i=this.expression(0),this._lookahead(0)===h&&this._match(h),a.push(i)
return this._match(d),{type:"Function",name:o,children:a}
case P:var s=this.expression(0)
return this._match(f),{type:"FilterProjection",children:[t,r=this._lookahead(0)===T?{type:"Identity"
}:this._parseProjectionRHS(W.Filter),s]}
case T:return{type:"Projection",children:[{type:T,children:[t]},this._parseProjectionRHS(W.Flatten)]
}
case R:case k:case x:case A:case _:case C:return this._parseComparator(t,e)
case D:var u=this._lookaheadToken(0)
return u.type===y||u.type===m?(r=this._parseIndexExpression(),this._projectIfSlice(t,r)):(this._match(O),
this._match(f),{type:"Projection",children:[t,r=this._parseProjectionRHS(W.Star)]})
default:this._errorToken(this._lookaheadToken(0))}},_match:function(e){if(this._lookahead(0)!==e){
var t=this._lookaheadToken(0),r=new Error("Expected "+e+", got: "+t.type)
throw r.name="ParserError",r}this._advance()},_errorToken:function(e){
var t=new Error("Invalid token ("+e.type+'): "'+e.value+'"')
throw t.name="ParserError",t},_parseIndexExpression:function(){
if(this._lookahead(0)===m||this._lookahead(1)===m)return this._parseSliceExpression()
var e={type:"Index",value:this._lookaheadToken(0).value}
return this._advance(),this._match(f),e},_projectIfSlice:function(e,t){var r={
type:"IndexExpression",children:[e,t]}
return"Slice"===t.type?{type:"Projection",children:[r,this._parseProjectionRHS(W.Star)]}:r},
_parseSliceExpression:function(){for(var e=[null,null,null],t=0,r=this._lookahead(0);r!==f&&t<3;){
if(r===m)t++,this._advance()
else{if(r!==y){
var n=this._lookahead(0),i=new Error("Syntax error, unexpected token: "+n.value+"("+n.type+")")
throw i.name="Parsererror",i}e[t]=this._lookaheadToken(0).value,this._advance()}r=this._lookahead(0)
}return this._match(f),{type:"Slice",children:e}},_parseComparator:function(e,t){return{
type:"Comparator",name:t,children:[e,this.expression(W[t])]}},_parseDotRHS:function(e){
var t=this._lookahead(0)
return[p,l,O].indexOf(t)>=0?this.expression(e):t===D?(this._match(D),this._parseMultiselectList()):t===q?(this._match(q),
this._parseMultiselectHash()):void 0},_parseProjectionRHS:function(e){var t
if(W[this._lookahead(0)]<10)t={type:"Identity"}
else if(this._lookahead(0)===D)t=this.expression(e)
else if(this._lookahead(0)===P)t=this.expression(e)
else{if(this._lookahead(0)!==M){
var r=this._lookaheadToken(0),n=new Error("Sytanx error, unexpected token: "+r.value+"("+r.type+")")
throw n.name="ParserError",n}this._match(M),t=this._parseDotRHS(e)}return t},
_parseMultiselectList:function(){for(var e=[];this._lookahead(0)!==f;){var t=this.expression(0)
if(e.push(t),this._lookahead(0)===h&&(this._match(h),this._lookahead(0)===f))throw new Error("Unexpected token Rbracket")
}return this._match(f),{type:"MultiSelectList",children:e}},_parseMultiselectHash:function(){
for(var e,t,r,n=[],i=[p,l];;){
if(e=this._lookaheadToken(0),i.indexOf(e.type)<0)throw new Error("Expecting an identifier token, got: "+e.type)
if(t=e.value,this._advance(),this._match(m),r={type:"KeyValuePair",name:t,value:this.expression(0)},
n.push(r),this._lookahead(0)===h)this._match(h)
else if(this._lookahead(0)===v){this._match(v)
break}}return{type:"MultiSelectHash",children:n}}},V.prototype={search:function(e,t){
return this.visit(e,t)},visit:function(e,o){var a,s,u,c,p,l,f,d,h
switch(e.type){case"Field":return null!==o&&r(o)?void 0===(l=o[e.name])?null:l:null
case"Subexpression":
for(u=this.visit(e.children[0],o),h=1;h<e.children.length;h++)if(null===(u=this.visit(e.children[1],u)))return null
return u
case"IndexExpression":return f=this.visit(e.children[0],o),this.visit(e.children[1],f)
case"Index":if(!t(o))return null
var m=e.value
return m<0&&(m=o.length+m),void 0===(u=o[m])&&(u=null),u
case"Slice":if(!t(o))return null
var v=e.children.slice(0),y=this.computeSliceParams(o.length,v),E=y[0],w=y[1],O=y[2]
if(u=[],O>0)for(h=E;h<w;h+=O)u.push(o[h])
else for(h=E;h>w;h+=O)u.push(o[h])
return u
case"Projection":var P=this.visit(e.children[0],o)
if(!t(P))return null
for(d=[],h=0;h<P.length;h++)null!==(s=this.visit(e.children[1],P[h]))&&d.push(s)
return d
case"ValueProjection":if(!r(P=this.visit(e.children[0],o)))return null
d=[]
var M=function(e){for(var t=Object.keys(e),r=[],n=0;n<t.length;n++)r.push(e[t[n]])
return r}(P)
for(h=0;h<M.length;h++)null!==(s=this.visit(e.children[1],M[h]))&&d.push(s)
return d
case"FilterProjection":if(!t(P=this.visit(e.children[0],o)))return null
var I=[],q=[]
for(h=0;h<P.length;h++)i(a=this.visit(e.children[2],P[h]))||I.push(P[h])
for(var D=0;D<I.length;D++)null!==(s=this.visit(e.children[1],I[D]))&&q.push(s)
return q
case"Comparator":switch(c=this.visit(e.children[0],o),p=this.visit(e.children[1],o),e.name){case R:
u=n(c,p)
break
case k:u=!n(c,p)
break
case x:u=c>p
break
case A:u=c>=p
break
case _:u=c<p
break
case C:u=c<=p
break
default:throw new Error("Unknown comparator: "+e.name)}return u
case T:var N=this.visit(e.children[0],o)
if(!t(N))return null
var j=[]
for(h=0;h<N.length;h++)t(s=N[h])?j.push.apply(j,s):j.push(s)
return j
case"Identity":return o
case"MultiSelectList":if(null===o)return null
for(d=[],h=0;h<e.children.length;h++)d.push(this.visit(e.children[h],o))
return d
case"MultiSelectHash":if(null===o)return null
var L
for(d={},h=0;h<e.children.length;h++)d[(L=e.children[h]).name]=this.visit(L.value,o)
return d
case"OrExpression":return i(a=this.visit(e.children[0],o))&&(a=this.visit(e.children[1],o)),a
case"AndExpression":return!0===i(c=this.visit(e.children[0],o))?c:this.visit(e.children[1],o)
case"NotExpression":return i(c=this.visit(e.children[0],o))
case"Literal":return e.value
case S:return f=this.visit(e.children[0],o),this.visit(e.children[1],f)
case g:return o
case"Function":var F=[]
for(h=0;h<e.children.length;h++)F.push(this.visit(e.children[h],o))
return this.runtime.callFunction(e.name,F)
case"ExpressionReference":var B=e.children[0]
return B.jmespathType=b,B
default:throw new Error("Unknown node type: "+e.type)}},computeSliceParams:function(e,t){
var r=t[0],n=t[1],i=t[2],o=[null,null,null]
if(null===i)i=1
else if(0===i){var a=new Error("Invalid slice, step cannot be 0")
throw a.name="RuntimeError",a}var s=i<0
return r=null===r?s?e-1:0:this.capSliceRange(e,r,i),n=null===n?s?-1:e:this.capSliceRange(e,n,i),
o[0]=r,o[1]=n,o[2]=i,o},capSliceRange:function(e,t,r){
return t<0?(t+=e)<0&&(t=r<0?-1:0):t>=e&&(t=r<0?e-1:e),t}},K.prototype={callFunction:function(e,t){
var r=this.functionTable[e]
if(void 0===r)throw new Error("Unknown function: "+e+"()")
return this._validateArgs(e,t,r._signature),r._func.call(this,t)},_validateArgs:function(e,t,r){
var n,i,o,a
if(r[r.length-1].variadic){if(t.length<r.length)throw n=1===r.length?" argument":" arguments",
new Error("ArgumentError: "+e+"() takes at least"+r.length+n+" but received "+t.length)
}else if(t.length!==r.length)throw n=1===r.length?" argument":" arguments",
new Error("ArgumentError: "+e+"() takes "+r.length+n+" but received "+t.length)
for(var s=0;s<r.length;s++){a=!1,i=r[s].types,o=this._getTypeName(t[s])
for(var c=0;c<i.length;c++)if(this._typeMatches(o,i[c],t[s])){a=!0
break}if(!a){var p=i.map((function(e){return u[e]})).join(",")
throw new Error("TypeError: "+e+"() expected argument "+(s+1)+" to be type "+p+" but received type "+u[o]+" instead.")
}}},_typeMatches:function(e,t,r){if(1===t)return!0
if(9!==t&&8!==t&&3!==t)return e===t
if(3===t)return 3===e
if(3===e){var n
8===t?n=a:9===t&&(n=s)
for(var i=0;i<r.length;i++)if(!this._typeMatches(this._getTypeName(r[i]),n,r[i]))return!1
return!0}},_getTypeName:function(e){switch(Object.prototype.toString.call(e)){case"[object String]":
return s
case"[object Number]":return a
case"[object Array]":return 3
case"[object Boolean]":return 5
case"[object Null]":return 7
case"[object Object]":return e.jmespathType===b?6:4}},_functionStartsWith:function(e){
return 0===e[0].lastIndexOf(e[1])},_functionEndsWith:function(e){var t=e[0],r=e[1]
return-1!==t.indexOf(r,t.length-r.length)},_functionReverse:function(e){
if(this._getTypeName(e[0])===s){for(var t=e[0],r="",n=t.length-1;n>=0;n--)r+=t[n]
return r}var i=e[0].slice(0)
return i.reverse(),i},_functionAbs:function(e){return Math.abs(e[0])},_functionCeil:function(e){
return Math.ceil(e[0])},_functionAvg:function(e){for(var t=0,r=e[0],n=0;n<r.length;n++)t+=r[n]
return t/r.length},_functionContains:function(e){return e[0].indexOf(e[1])>=0},
_functionFloor:function(e){return Math.floor(e[0])},_functionLength:function(e){
return r(e[0])?Object.keys(e[0]).length:e[0].length},_functionMap:function(e){
for(var t=[],r=this._interpreter,n=e[0],i=e[1],o=0;o<i.length;o++)t.push(r.visit(n,i[o]))
return t},_functionMerge:function(e){for(var t={},r=0;r<e.length;r++){var n=e[r]
for(var i in n)t[i]=n[i]}return t},_functionMax:function(e){if(e[0].length>0){
if(this._getTypeName(e[0][0])===a)return Math.max.apply(Math,e[0])
for(var t=e[0],r=t[0],n=1;n<t.length;n++)r.localeCompare(t[n])<0&&(r=t[n])
return r}return null},_functionMin:function(e){if(e[0].length>0){
if(this._getTypeName(e[0][0])===a)return Math.min.apply(Math,e[0])
for(var t=e[0],r=t[0],n=1;n<t.length;n++)t[n].localeCompare(r)<0&&(r=t[n])
return r}return null},_functionSum:function(e){for(var t=0,r=e[0],n=0;n<r.length;n++)t+=r[n]
return t},_functionType:function(e){switch(this._getTypeName(e[0])){case a:return"number"
case s:return"string"
case 3:return"array"
case 4:return"object"
case 5:return"boolean"
case 6:return"expref"
case 7:return"null"}},_functionKeys:function(e){return Object.keys(e[0])},
_functionValues:function(e){for(var t=e[0],r=Object.keys(t),n=[],i=0;i<r.length;i++)n.push(t[r[i]])
return n},_functionJoin:function(e){var t=e[0]
return e[1].join(t)},_functionToArray:function(e){return 3===this._getTypeName(e[0])?e[0]:[e[0]]},
_functionToString:function(e){return this._getTypeName(e[0])===s?e[0]:JSON.stringify(e[0])},
_functionToNumber:function(e){var t,r=this._getTypeName(e[0])
return r===a?e[0]:r!==s||(t=+e[0],isNaN(t))?null:t},_functionNotNull:function(e){
for(var t=0;t<e.length;t++)if(7!==this._getTypeName(e[t]))return e[t]
return null},_functionSort:function(e){var t=e[0].slice(0)
return t.sort(),t},_functionSortBy:function(e){var t=e[0].slice(0)
if(0===t.length)return t
var r=this._interpreter,n=e[1],i=this._getTypeName(r.visit(n,t[0]))
if([a,s].indexOf(i)<0)throw new Error("TypeError")
for(var o=this,u=[],c=0;c<t.length;c++)u.push([c,t[c]])
u.sort((function(e,t){var a=r.visit(n,e[1]),s=r.visit(n,t[1])
if(o._getTypeName(a)!==i)throw new Error("TypeError: expected "+i+", received "+o._getTypeName(a))
if(o._getTypeName(s)!==i)throw new Error("TypeError: expected "+i+", received "+o._getTypeName(s))
return a>s?1:a<s?-1:e[0]-t[0]}))
for(var p=0;p<u.length;p++)t[p]=u[p][1]
return t},_functionMaxBy:function(e){
for(var t,r,n=e[1],i=e[0],o=this.createKeyFunction(n,[a,s]),u=-1/0,c=0;c<i.length;c++)(r=o(i[c]))>u&&(u=r,
t=i[c])
return t},_functionMinBy:function(e){
for(var t,r,n=e[1],i=e[0],o=this.createKeyFunction(n,[a,s]),u=1/0,c=0;c<i.length;c++)(r=o(i[c]))<u&&(u=r,
t=i[c])
return t},createKeyFunction:function(e,t){var r=this,n=this._interpreter
return function(i){var o=n.visit(e,i)
if(t.indexOf(r._getTypeName(o))<0){
var a="TypeError: expected one of "+t+", received "+r._getTypeName(o)
throw new Error(a)}return o}}},e.tokenize=function(e){return(new U).tokenize(e)},
e.compile=function(e){return(new H).parse(e)},e.search=function(e,t){var r=new H,n=new K,i=new V(n)
n._interpreter=i
var o=r.parse(t)
return i.search(o,e)},e.strictDeepEqual=n}(t)},6578:e=>{"use strict"
e.exports=["Float32Array","Float64Array","Int8Array","Int16Array","Int32Array","Uint8Array","Uint8ClampedArray","Uint16Array","Uint32Array","BigInt64Array","BigUint64Array"]
},6897:(e,t,r)=>{"use strict"
var n=r(453),i=r(41),o=r(592)(),a=r(5795),s=r(9675),u=n("%Math.floor%")
e.exports=function(e,t){if("function"!=typeof e)throw new s("`fn` is not a function")
if("number"!=typeof t||t<0||t>4294967295||u(t)!==t)throw new s("`length` must be a positive 32-bit integer")
var r=arguments.length>2&&!!arguments[2],n=!0,c=!0
if("length"in e&&a){var p=a(e,"length")
p&&!p.configurable&&(n=!1),p&&!p.writable&&(c=!1)}
return(n||c||!r)&&(o?i(e,"length",t,!0,!0):i(e,"length",t)),e}},1135:e=>{e.exports=function(e){
return e&&"object"==typeof e&&"function"==typeof e.copy&&"function"==typeof e.fill&&"function"==typeof e.readUInt8
}},9032:(e,t,r)=>{"use strict"
var n=r(7244),i=r(8184),o=r(5767),a=r(5680)
function s(e){return e.call.bind(e)}
var u="undefined"!=typeof BigInt,c="undefined"!=typeof Symbol,p=s(Object.prototype.toString),l=s(Number.prototype.valueOf),f=s(String.prototype.valueOf),d=s(Boolean.prototype.valueOf)
if(u)var h=s(BigInt.prototype.valueOf)
if(c)var m=s(Symbol.prototype.valueOf)
function v(e,t){if("object"!=typeof e)return!1
try{return t(e),!0}catch(e){return!1}}function y(e){return"[object Map]"===p(e)}function g(e){
return"[object Set]"===p(e)}function b(e){return"[object WeakMap]"===p(e)}function S(e){
return"[object WeakSet]"===p(e)}function E(e){return"[object ArrayBuffer]"===p(e)}function w(e){
return"undefined"!=typeof ArrayBuffer&&(E.working?E(e):e instanceof ArrayBuffer)}function R(e){
return"[object DataView]"===p(e)}function x(e){
return"undefined"!=typeof DataView&&(R.working?R(e):e instanceof DataView)}t.isArgumentsObject=n,
t.isGeneratorFunction=i,t.isTypedArray=a,t.isPromise=function(e){
return"undefined"!=typeof Promise&&e instanceof Promise||null!==e&&"object"==typeof e&&"function"==typeof e.then&&"function"==typeof e.catch
},t.isArrayBufferView=function(e){
return"undefined"!=typeof ArrayBuffer&&ArrayBuffer.isView?ArrayBuffer.isView(e):a(e)||x(e)},
t.isUint8Array=function(e){return"Uint8Array"===o(e)},t.isUint8ClampedArray=function(e){
return"Uint8ClampedArray"===o(e)},t.isUint16Array=function(e){return"Uint16Array"===o(e)},
t.isUint32Array=function(e){return"Uint32Array"===o(e)},t.isInt8Array=function(e){
return"Int8Array"===o(e)},t.isInt16Array=function(e){return"Int16Array"===o(e)},
t.isInt32Array=function(e){return"Int32Array"===o(e)},t.isFloat32Array=function(e){
return"Float32Array"===o(e)},t.isFloat64Array=function(e){return"Float64Array"===o(e)},
t.isBigInt64Array=function(e){return"BigInt64Array"===o(e)},t.isBigUint64Array=function(e){
return"BigUint64Array"===o(e)},y.working="undefined"!=typeof Map&&y(new Map),t.isMap=function(e){
return"undefined"!=typeof Map&&(y.working?y(e):e instanceof Map)
},g.working="undefined"!=typeof Set&&g(new Set),t.isSet=function(e){
return"undefined"!=typeof Set&&(g.working?g(e):e instanceof Set)
},b.working="undefined"!=typeof WeakMap&&b(new WeakMap),t.isWeakMap=function(e){
return"undefined"!=typeof WeakMap&&(b.working?b(e):e instanceof WeakMap)
},S.working="undefined"!=typeof WeakSet&&S(new WeakSet),t.isWeakSet=function(e){return S(e)},
E.working="undefined"!=typeof ArrayBuffer&&E(new ArrayBuffer),t.isArrayBuffer=w,
R.working="undefined"!=typeof ArrayBuffer&&"undefined"!=typeof DataView&&R(new DataView(new ArrayBuffer(1),0,1)),
t.isDataView=x
var _="undefined"!=typeof SharedArrayBuffer?SharedArrayBuffer:void 0
function A(e){return"[object SharedArrayBuffer]"===p(e)}function C(e){
return void 0!==_&&(void 0===A.working&&(A.working=A(new _)),A.working?A(e):e instanceof _)}
function k(e){return v(e,l)}function T(e){return v(e,f)}function O(e){return v(e,d)}function P(e){
return u&&v(e,h)}function M(e){return c&&v(e,m)}
t.isSharedArrayBuffer=C,t.isAsyncFunction=function(e){return"[object AsyncFunction]"===p(e)},
t.isMapIterator=function(e){return"[object Map Iterator]"===p(e)},t.isSetIterator=function(e){
return"[object Set Iterator]"===p(e)},t.isGeneratorObject=function(e){
return"[object Generator]"===p(e)},t.isWebAssemblyCompiledModule=function(e){
return"[object WebAssembly.Module]"===p(e)},t.isNumberObject=k,t.isStringObject=T,
t.isBooleanObject=O,t.isBigIntObject=P,t.isSymbolObject=M,t.isBoxedPrimitive=function(e){
return k(e)||T(e)||O(e)||P(e)||M(e)},t.isAnyArrayBuffer=function(e){
return"undefined"!=typeof Uint8Array&&(w(e)||C(e))
},["isProxy","isExternal","isModuleNamespaceObject"].forEach((function(e){
Object.defineProperty(t,e,{enumerable:!1,value:function(){
throw new Error(e+" is not supported in userland")}})}))},537:(e,t,r)=>{
var n=Object.getOwnPropertyDescriptors||function(e){
for(var t=Object.keys(e),r={},n=0;n<t.length;n++)r[t[n]]=Object.getOwnPropertyDescriptor(e,t[n])
return r},i=/%[sdj%]/g
t.format=function(e){if(!g(e)){for(var t=[],r=0;r<arguments.length;r++)t.push(u(arguments[r]))
return t.join(" ")}r=1
for(var n=arguments,o=n.length,a=String(e).replace(i,(function(e){if("%%"===e)return"%"
if(r>=o)return e
switch(e){case"%s":return String(n[r++])
case"%d":return Number(n[r++])
case"%j":try{return JSON.stringify(n[r++])}catch(e){return"[Circular]"}default:return e}
})),s=n[r];r<o;s=n[++r])v(s)||!E(s)?a+=" "+s:a+=" "+u(s)
return a},t.deprecate=function(e,r){
if("undefined"!=typeof process&&!0===process.noDeprecation)return e
if("undefined"==typeof process)return function(){return t.deprecate(e,r).apply(this,arguments)}
var n=!1
return function(){if(!n){if(process.throwDeprecation)throw new Error(r)
process.traceDeprecation?console.trace(r):console.error(r),n=!0}return e.apply(this,arguments)}}
var o={},a=/^$/
if(process.env.NODE_DEBUG){var s=process.env.NODE_DEBUG
s=s.replace(/[|\\{}()[\]^$+?.]/g,"\\$&").replace(/\*/g,".*").replace(/,/g,"$|^").toUpperCase(),
a=new RegExp("^"+s+"$","i")}function u(e,r){var n={seen:[],stylize:p}
return arguments.length>=3&&(n.depth=arguments[2]),arguments.length>=4&&(n.colors=arguments[3]),
m(r)?n.showHidden=r:r&&t._extend(n,r),b(n.showHidden)&&(n.showHidden=!1),b(n.depth)&&(n.depth=2),
b(n.colors)&&(n.colors=!1),b(n.customInspect)&&(n.customInspect=!0),n.colors&&(n.stylize=c),
l(n,e,n.depth)}function c(e,t){var r=u.styles[t]
return r?"["+u.colors[r][0]+"m"+e+"["+u.colors[r][1]+"m":e}function p(e,t){return e}
function l(e,r,n){
if(e.customInspect&&r&&x(r.inspect)&&r.inspect!==t.inspect&&(!r.constructor||r.constructor.prototype!==r)){
var i=r.inspect(n,e)
return g(i)||(i=l(e,i,n)),i}var o=function(e,t){if(b(t))return e.stylize("undefined","undefined")
if(g(t)){
var r="'"+JSON.stringify(t).replace(/^"|"$/g,"").replace(/'/g,"\\'").replace(/\\"/g,'"')+"'"
return e.stylize(r,"string")}
return y(t)?e.stylize(""+t,"number"):m(t)?e.stylize(""+t,"boolean"):v(t)?e.stylize("null","null"):void 0
}(e,r)
if(o)return o
var a=Object.keys(r),s=function(e){var t={}
return e.forEach((function(e,r){t[e]=!0})),t}(a)
if(e.showHidden&&(a=Object.getOwnPropertyNames(r)),R(r)&&(a.indexOf("message")>=0||a.indexOf("description")>=0))return f(r)
if(0===a.length){if(x(r)){var u=r.name?": "+r.name:""
return e.stylize("[Function"+u+"]","special")}
if(S(r))return e.stylize(RegExp.prototype.toString.call(r),"regexp")
if(w(r))return e.stylize(Date.prototype.toString.call(r),"date")
if(R(r))return f(r)}var c,p="",E=!1,_=["{","}"]
return h(r)&&(E=!0,_=["[","]"]),x(r)&&(p=" [Function"+(r.name?": "+r.name:"")+"]"),
S(r)&&(p=" "+RegExp.prototype.toString.call(r)),w(r)&&(p=" "+Date.prototype.toUTCString.call(r)),
R(r)&&(p=" "+f(r)),
0!==a.length||E&&0!=r.length?n<0?S(r)?e.stylize(RegExp.prototype.toString.call(r),"regexp"):e.stylize("[Object]","special"):(e.seen.push(r),
c=E?function(e,t,r,n,i){
for(var o=[],a=0,s=t.length;a<s;++a)k(t,String(a))?o.push(d(e,t,r,n,String(a),!0)):o.push("")
return i.forEach((function(i){i.match(/^\d+$/)||o.push(d(e,t,r,n,i,!0))})),o
}(e,r,n,s,a):a.map((function(t){return d(e,r,n,s,t,E)})),e.seen.pop(),function(e,t,r){
return e.reduce((function(e,t){return t.indexOf("\n"),e+t.replace(/\u001b\[\d\d?m/g,"").length+1
}),0)>60?r[0]+(""===t?"":t+"\n ")+" "+e.join(",\n  ")+" "+r[1]:r[0]+t+" "+e.join(", ")+" "+r[1]
}(c,p,_)):_[0]+p+_[1]}function f(e){return"["+Error.prototype.toString.call(e)+"]"}
function d(e,t,r,n,i,o){var a,s,u
if((u=Object.getOwnPropertyDescriptor(t,i)||{value:t[i]
}).get?s=u.set?e.stylize("[Getter/Setter]","special"):e.stylize("[Getter]","special"):u.set&&(s=e.stylize("[Setter]","special")),
k(n,i)||(a="["+i+"]"),
s||(e.seen.indexOf(u.value)<0?(s=v(r)?l(e,u.value,null):l(e,u.value,r-1)).indexOf("\n")>-1&&(s=o?s.split("\n").map((function(e){
return"  "+e})).join("\n").slice(2):"\n"+s.split("\n").map((function(e){return"   "+e
})).join("\n")):s=e.stylize("[Circular]","special")),b(a)){if(o&&i.match(/^\d+$/))return s
;(a=JSON.stringify(""+i)).match(/^"([a-zA-Z_][a-zA-Z_0-9]*)"$/)?(a=a.slice(1,-1),
a=e.stylize(a,"name")):(a=a.replace(/'/g,"\\'").replace(/\\"/g,'"').replace(/(^"|"$)/g,"'"),
a=e.stylize(a,"string"))}return a+": "+s}function h(e){return Array.isArray(e)}function m(e){
return"boolean"==typeof e}function v(e){return null===e}function y(e){return"number"==typeof e}
function g(e){return"string"==typeof e}function b(e){return void 0===e}function S(e){
return E(e)&&"[object RegExp]"===_(e)}function E(e){return"object"==typeof e&&null!==e}
function w(e){return E(e)&&"[object Date]"===_(e)}function R(e){
return E(e)&&("[object Error]"===_(e)||e instanceof Error)}function x(e){return"function"==typeof e}
function _(e){return Object.prototype.toString.call(e)}function A(e){
return e<10?"0"+e.toString(10):e.toString(10)}t.debuglog=function(e){if(e=e.toUpperCase(),
!o[e])if(a.test(e)){var r=process.pid
o[e]=function(){var n=t.format.apply(t,arguments)
console.error("%s %d: %s",e,r,n)}}else o[e]=function(){}
return o[e]},t.inspect=u,u.colors={bold:[1,22],italic:[3,23],underline:[4,24],inverse:[7,27],
white:[37,39],grey:[90,39],black:[30,39],blue:[34,39],cyan:[36,39],green:[32,39],magenta:[35,39],
red:[31,39],yellow:[33,39]},u.styles={special:"cyan",number:"yellow",boolean:"yellow",
undefined:"grey",null:"bold",string:"green",date:"magenta",regexp:"red"},t.types=r(9032),
t.isArray=h,t.isBoolean=m,t.isNull=v,t.isNullOrUndefined=function(e){return null==e},t.isNumber=y,
t.isString=g,t.isSymbol=function(e){return"symbol"==typeof e},t.isUndefined=b,t.isRegExp=S,
t.types.isRegExp=S,t.isObject=E,t.isDate=w,t.types.isDate=w,t.isError=R,t.types.isNativeError=R,
t.isFunction=x,t.isPrimitive=function(e){
return null===e||"boolean"==typeof e||"number"==typeof e||"string"==typeof e||"symbol"==typeof e||void 0===e
},t.isBuffer=r(1135)
var C=["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"]
function k(e,t){return Object.prototype.hasOwnProperty.call(e,t)}t.log=function(){var e,r
console.log("%s - %s",(r=[A((e=new Date).getHours()),A(e.getMinutes()),A(e.getSeconds())].join(":"),
[e.getDate(),C[e.getMonth()],r].join(" ")),t.format.apply(t,arguments))},t.inherits=r(6698),
t._extend=function(e,t){if(!t||!E(t))return e
for(var r=Object.keys(t),n=r.length;n--;)e[r[n]]=t[r[n]]
return e}
var T="undefined"!=typeof Symbol?Symbol("util.promisify.custom"):void 0
function O(e,t){if(!e){var r=new Error("Promise was rejected with a falsy value")
r.reason=e,e=r}return t(e)}t.promisify=function(e){
if("function"!=typeof e)throw new TypeError('The "original" argument must be of type Function')
if(T&&e[T]){var t
if("function"!=typeof(t=e[T]))throw new TypeError('The "util.promisify.custom" argument must be of type Function')
return Object.defineProperty(t,T,{value:t,enumerable:!1,writable:!1,configurable:!0}),t}
function t(){for(var t,r,n=new Promise((function(e,n){t=e,r=n
})),i=[],o=0;o<arguments.length;o++)i.push(arguments[o])
i.push((function(e,n){e?r(e):t(n)}))
try{e.apply(this,i)}catch(e){r(e)}return n}return Object.setPrototypeOf(t,Object.getPrototypeOf(e)),
T&&Object.defineProperty(t,T,{value:t,enumerable:!1,writable:!1,configurable:!0}),
Object.defineProperties(t,n(e))},t.promisify.custom=T,t.callbackify=function(e){
if("function"!=typeof e)throw new TypeError('The "original" argument must be of type Function')
function t(){for(var t=[],r=0;r<arguments.length;r++)t.push(arguments[r])
var n=t.pop()
if("function"!=typeof n)throw new TypeError("The last argument must be of type Function")
var i=this,o=function(){return n.apply(i,arguments)}
e.apply(this,t).then((function(e){process.nextTick(o.bind(null,null,e))}),(function(e){
process.nextTick(O.bind(null,e,o))}))}return Object.setPrototypeOf(t,Object.getPrototypeOf(e)),
Object.defineProperties(t,n(e)),t}},6906:(e,t)=>{"use strict"
Object.defineProperty(t,"__esModule",{value:!0}),t.default=void 0
for(var r=[],n=0;n<256;++n)r[n]=(n+256).toString(16).substr(1)
t.default=function(e,t){var n=t||0,i=r
return[i[e[n++]],i[e[n++]],i[e[n++]],i[e[n++]],"-",i[e[n++]],i[e[n++]],"-",i[e[n++]],i[e[n++]],"-",i[e[n++]],i[e[n++]],"-",i[e[n++]],i[e[n++]],i[e[n++]],i[e[n++]],i[e[n++]],i[e[n++]]].join("")
}},2107:(e,t,r)=>{"use strict"
Object.defineProperty(t,"v4",{enumerable:!0,get:function(){return n.default}}),i(r(8610)),i(r(3208))
var n=i(r(4061))
function i(e){return e&&e.__esModule?e:{default:e}}i(r(3358))},882:(e,t)=>{"use strict"
function r(e,t){var r=(65535&e)+(65535&t)
return(e>>16)+(t>>16)+(r>>16)<<16|65535&r}function n(e,t,n,i,o,a){
return r((s=r(r(t,e),r(i,a)))<<(u=o)|s>>>32-u,n)
var s,u}function i(e,t,r,i,o,a,s){return n(t&r|~t&i,e,t,o,a,s)}function o(e,t,r,i,o,a,s){
return n(t&i|r&~i,e,t,o,a,s)}function a(e,t,r,i,o,a,s){return n(t^r^i,e,t,o,a,s)}
function s(e,t,r,i,o,a,s){return n(r^(t|~i),e,t,o,a,s)}Object.defineProperty(t,"__esModule",{
value:!0}),t.default=void 0,t.default=function(e){if("string"==typeof e){
var t=unescape(encodeURIComponent(e))
e=new Array(t.length)
for(var n=0;n<t.length;n++)e[n]=t.charCodeAt(n)}return function(e){
var t,r,n,i=[],o=32*e.length,a="0123456789abcdef"
for(t=0;t<o;t+=8)r=e[t>>5]>>>t%32&255,n=parseInt(a.charAt(r>>>4&15)+a.charAt(15&r),16),i.push(n)
return i}(function(e,t){var n,u,c,p,l
e[t>>5]|=128<<t%32,e[14+(t+64>>>9<<4)]=t
var f=1732584193,d=-271733879,h=-1732584194,m=271733878
for(n=0;n<e.length;n+=16)u=f,c=d,p=h,l=m,f=i(f,d,h,m,e[n],7,-680876936),m=i(m,f,d,h,e[n+1],12,-389564586),
h=i(h,m,f,d,e[n+2],17,606105819),
d=i(d,h,m,f,e[n+3],22,-1044525330),f=i(f,d,h,m,e[n+4],7,-176418897),
m=i(m,f,d,h,e[n+5],12,1200080426),
h=i(h,m,f,d,e[n+6],17,-1473231341),d=i(d,h,m,f,e[n+7],22,-45705983),
f=i(f,d,h,m,e[n+8],7,1770035416),m=i(m,f,d,h,e[n+9],12,-1958414417),h=i(h,m,f,d,e[n+10],17,-42063),
d=i(d,h,m,f,e[n+11],22,-1990404162),
f=i(f,d,h,m,e[n+12],7,1804603682),m=i(m,f,d,h,e[n+13],12,-40341101),
h=i(h,m,f,d,e[n+14],17,-1502002290),
f=o(f,d=i(d,h,m,f,e[n+15],22,1236535329),h,m,e[n+1],5,-165796510),m=o(m,f,d,h,e[n+6],9,-1069501632),
h=o(h,m,f,d,e[n+11],14,643717713),d=o(d,h,m,f,e[n],20,-373897302),f=o(f,d,h,m,e[n+5],5,-701558691),
m=o(m,f,d,h,e[n+10],9,38016083),
h=o(h,m,f,d,e[n+15],14,-660478335),d=o(d,h,m,f,e[n+4],20,-405537848),
f=o(f,d,h,m,e[n+9],5,568446438),
m=o(m,f,d,h,e[n+14],9,-1019803690),h=o(h,m,f,d,e[n+3],14,-187363961),
d=o(d,h,m,f,e[n+8],20,1163531501),
f=o(f,d,h,m,e[n+13],5,-1444681467),m=o(m,f,d,h,e[n+2],9,-51403784),
h=o(h,m,f,d,e[n+7],14,1735328473),f=a(f,d=o(d,h,m,f,e[n+12],20,-1926607734),h,m,e[n+5],4,-378558),
m=a(m,f,d,h,e[n+8],11,-2022574463),
h=a(h,m,f,d,e[n+11],16,1839030562),d=a(d,h,m,f,e[n+14],23,-35309556),
f=a(f,d,h,m,e[n+1],4,-1530992060),
m=a(m,f,d,h,e[n+4],11,1272893353),h=a(h,m,f,d,e[n+7],16,-155497632),
d=a(d,h,m,f,e[n+10],23,-1094730640),
f=a(f,d,h,m,e[n+13],4,681279174),m=a(m,f,d,h,e[n],11,-358537222),h=a(h,m,f,d,e[n+3],16,-722521979),
d=a(d,h,m,f,e[n+6],23,76029189),f=a(f,d,h,m,e[n+9],4,-640364487),m=a(m,f,d,h,e[n+12],11,-421815835),
h=a(h,m,f,d,e[n+15],16,530742520),f=s(f,d=a(d,h,m,f,e[n+2],23,-995338651),h,m,e[n],6,-198630844),
m=s(m,f,d,h,e[n+7],10,1126891415),
h=s(h,m,f,d,e[n+14],15,-1416354905),d=s(d,h,m,f,e[n+5],21,-57434055),
f=s(f,d,h,m,e[n+12],6,1700485571),
m=s(m,f,d,h,e[n+3],10,-1894986606),h=s(h,m,f,d,e[n+10],15,-1051523),
d=s(d,h,m,f,e[n+1],21,-2054922799),
f=s(f,d,h,m,e[n+8],6,1873313359),m=s(m,f,d,h,e[n+15],10,-30611744),
h=s(h,m,f,d,e[n+6],15,-1560198380),
d=s(d,h,m,f,e[n+13],21,1309151649),f=s(f,d,h,m,e[n+4],6,-145523070),
m=s(m,f,d,h,e[n+11],10,-1120210379),
h=s(h,m,f,d,e[n+2],15,718787259),d=s(d,h,m,f,e[n+9],21,-343485551),f=r(f,u),d=r(d,c),h=r(h,p),
m=r(m,l)
return[f,d,h,m]}(function(e){var t,r=[]
for(r[(e.length>>2)-1]=void 0,t=0;t<r.length;t+=1)r[t]=0
var n=8*e.length
for(t=0;t<n;t+=8)r[t>>5]|=(255&e[t/8])<<t%32
return r}(e),8*e.length))}},5975:(e,t)=>{"use strict"
Object.defineProperty(t,"__esModule",{value:!0}),t.default=function(){
if(!r)throw new Error("crypto.getRandomValues() not supported. See https://github.com/uuidjs/uuid#getrandomvalues-not-supported")
return r(n)}
var r="undefined"!=typeof crypto&&crypto.getRandomValues&&crypto.getRandomValues.bind(crypto)||"undefined"!=typeof msCrypto&&"function"==typeof msCrypto.getRandomValues&&msCrypto.getRandomValues.bind(msCrypto),n=new Uint8Array(16)
},8135:(e,t)=>{"use strict"
function r(e,t,r,n){switch(e){case 0:return t&r^~t&n
case 1:case 3:return t^r^n
case 2:return t&r^t&n^r&n}}function n(e,t){return e<<t|e>>>32-t}
Object.defineProperty(t,"__esModule",{value:!0}),t.default=void 0,t.default=function(e){
var t=[1518500249,1859775393,2400959708,3395469782],i=[1732584193,4023233417,2562383102,271733878,3285377520]
if("string"==typeof e){var o=unescape(encodeURIComponent(e))
e=new Array(o.length)
for(var a=0;a<o.length;a++)e[a]=o.charCodeAt(a)}e.push(128)
var s=e.length/4+2,u=Math.ceil(s/16),c=new Array(u)
for(a=0;a<u;a++){c[a]=new Array(16)
for(var p=0;p<16;p++)c[a][p]=e[64*a+4*p]<<24|e[64*a+4*p+1]<<16|e[64*a+4*p+2]<<8|e[64*a+4*p+3]}
for(c[u-1][14]=8*(e.length-1)/Math.pow(2,32),
c[u-1][14]=Math.floor(c[u-1][14]),c[u-1][15]=8*(e.length-1)&4294967295,a=0;a<u;a++){
for(var l=new Array(80),f=0;f<16;f++)l[f]=c[a][f]
for(f=16;f<80;f++)l[f]=n(l[f-3]^l[f-8]^l[f-14]^l[f-16],1)
var d=i[0],h=i[1],m=i[2],v=i[3],y=i[4]
for(f=0;f<80;f++){var g=Math.floor(f/20),b=n(d,5)+r(g,h,m,v)+y+t[g]+l[f]>>>0
y=v,v=m,m=n(h,30)>>>0,h=d,d=b}i[0]=i[0]+d>>>0,i[1]=i[1]+h>>>0,i[2]=i[2]+m>>>0,i[3]=i[3]+v>>>0,
i[4]=i[4]+y>>>0}
return[i[0]>>24&255,i[0]>>16&255,i[0]>>8&255,255&i[0],i[1]>>24&255,i[1]>>16&255,i[1]>>8&255,255&i[1],i[2]>>24&255,i[2]>>16&255,i[2]>>8&255,255&i[2],i[3]>>24&255,i[3]>>16&255,i[3]>>8&255,255&i[3],i[4]>>24&255,i[4]>>16&255,i[4]>>8&255,255&i[4]]
}},8610:(e,t,r)=>{"use strict"
Object.defineProperty(t,"__esModule",{value:!0}),t.default=void 0
var n,i,o=s(r(5975)),a=s(r(6906))
function s(e){return e&&e.__esModule?e:{default:e}}var u=0,c=0
t.default=function(e,t,r){
var s=t&&r||0,p=t||[],l=(e=e||{}).node||n,f=void 0!==e.clockseq?e.clockseq:i
if(null==l||null==f){var d=e.random||(e.rng||o.default)()
null==l&&(l=n=[1|d[0],d[1],d[2],d[3],d[4],d[5]]),null==f&&(f=i=16383&(d[6]<<8|d[7]))}
var h=void 0!==e.msecs?e.msecs:(new Date).getTime(),m=void 0!==e.nsecs?e.nsecs:c+1,v=h-u+(m-c)/1e4
if(v<0&&void 0===e.clockseq&&(f=f+1&16383),(v<0||h>u)&&void 0===e.nsecs&&(m=0),m>=1e4)throw new Error("uuid.v1(): Can't create more than 10M uuids/sec")
u=h,c=m,i=f
var y=(1e4*(268435455&(h+=122192928e5))+m)%4294967296
p[s++]=y>>>24&255,p[s++]=y>>>16&255,p[s++]=y>>>8&255,p[s++]=255&y
var g=h/4294967296*1e4&268435455
p[s++]=g>>>8&255,p[s++]=255&g,p[s++]=g>>>24&15|16,p[s++]=g>>>16&255,p[s++]=f>>>8|128,p[s++]=255&f
for(var b=0;b<6;++b)p[s+b]=l[b]
return t||(0,a.default)(p)}},3208:(e,t,r)=>{"use strict"
Object.defineProperty(t,"__esModule",{value:!0}),t.default=void 0
var n=o(r(1525)),i=o(r(882))
function o(e){return e&&e.__esModule?e:{default:e}}var a=(0,n.default)("v3",48,i.default)
t.default=a},1525:(e,t,r)=>{"use strict"
Object.defineProperty(t,"__esModule",{value:!0}),t.default=function(e,t,r){var n=function(e,n,o,a){
var s=o&&a||0
if("string"==typeof e&&(e=function(e){e=unescape(encodeURIComponent(e))
for(var t=new Array(e.length),r=0;r<e.length;r++)t[r]=e.charCodeAt(r)
return t}(e)),"string"==typeof n&&(n=function(e){var t=[]
return e.replace(/[a-fA-F0-9]{2}/g,(function(e){t.push(parseInt(e,16))})),t}(n)),
!Array.isArray(e))throw TypeError("value must be an array of bytes")
if(!Array.isArray(n)||16!==n.length)throw TypeError("namespace must be uuid string or an Array of 16 byte values")
var u=r(n.concat(e))
if(u[6]=15&u[6]|t,u[8]=63&u[8]|128,o)for(var c=0;c<16;++c)o[s+c]=u[c]
return o||(0,i.default)(u)}
try{n.name=e}catch(e){}return n.DNS=o,n.URL=a,n},t.URL=t.DNS=void 0
var n,i=(n=r(6906))&&n.__esModule?n:{default:n}
const o="6ba7b810-9dad-11d1-80b4-00c04fd430c8"
t.DNS=o
const a="6ba7b811-9dad-11d1-80b4-00c04fd430c8"
t.URL=a},4061:(e,t,r)=>{"use strict"
Object.defineProperty(t,"__esModule",{value:!0}),t.default=void 0
var n=o(r(5975)),i=o(r(6906))
function o(e){return e&&e.__esModule?e:{default:e}}t.default=function(e,t,r){var o=t&&r||0
"string"==typeof e&&(t="binary"===e?new Array(16):null,e=null)
var a=(e=e||{}).random||(e.rng||n.default)()
if(a[6]=15&a[6]|64,a[8]=63&a[8]|128,t)for(var s=0;s<16;++s)t[o+s]=a[s]
return t||(0,i.default)(a)}},3358:(e,t,r)=>{"use strict"
Object.defineProperty(t,"__esModule",{value:!0}),t.default=void 0
var n=o(r(1525)),i=o(r(8135))
function o(e){return e&&e.__esModule?e:{default:e}}var a=(0,n.default)("v5",80,i.default)
t.default=a},364:(e,t,r)=>{"use strict"
r.r(t),r.d(t,{getCLS:()=>b,getFCP:()=>v,getFID:()=>A,getLCP:()=>k,getTTFB:()=>T})
var n,i,o,a,s=function(e,t){return{name:e,value:void 0===t?-1:t,delta:0,entries:[],
id:"v2-".concat(Date.now(),"-").concat(Math.floor(8999999999999*Math.random())+1e12)}
},u=function(e,t){try{if(PerformanceObserver.supportedEntryTypes.includes(e)){
if("first-input"===e&&!("PerformanceEventTiming"in self))return
var r=new PerformanceObserver((function(e){return e.getEntries().map(t)}))
return r.observe({type:e,buffered:!0}),r}}catch(e){}},c=function(e,t){var r=function r(n){
"pagehide"!==n.type&&"hidden"!==document.visibilityState||(e(n),
t&&(removeEventListener("visibilitychange",r,!0),removeEventListener("pagehide",r,!0)))}
addEventListener("visibilitychange",r,!0),addEventListener("pagehide",r,!0)},p=function(e){
addEventListener("pageshow",(function(t){t.persisted&&e(t)}),!0)},l=function(e,t,r){var n
return function(i){t.value>=0&&(i||r)&&(t.delta=t.value-(n||0),(t.delta||void 0===n)&&(n=t.value,
e(t)))}},f=-1,d=function(){return"hidden"===document.visibilityState?0:1/0},h=function(){
c((function(e){var t=e.timeStamp
f=t}),!0)},m=function(){return f<0&&(f=d(),h(),p((function(){setTimeout((function(){f=d(),h()}),0)
}))),{get firstHiddenTime(){return f}}},v=function(e,t){var r,n=m(),i=s("FCP"),o=function(e){
"first-contentful-paint"===e.name&&(c&&c.disconnect(),
e.startTime<n.firstHiddenTime&&(i.value=e.startTime,i.entries.push(e),r(!0)))
},a=window.performance&&performance.getEntriesByName&&performance.getEntriesByName("first-contentful-paint")[0],c=a?null:u("paint",o)
;(a||c)&&(r=l(e,i,t),a&&o(a),p((function(n){i=s("FCP"),r=l(e,i,t),requestAnimationFrame((function(){
requestAnimationFrame((function(){i.value=performance.now()-n.timeStamp,r(!0)}))}))})))
},y=!1,g=-1,b=function(e,t){y||(v((function(e){g=e.value})),y=!0)
var r,n=function(t){g>-1&&e(t)},i=s("CLS",0),o=0,a=[],f=function(e){if(!e.hadRecentInput){
var t=a[0],n=a[a.length-1]
o&&e.startTime-n.startTime<1e3&&e.startTime-t.startTime<5e3?(o+=e.value,a.push(e)):(o=e.value,
a=[e]),o>i.value&&(i.value=o,i.entries=a,r())}},d=u("layout-shift",f)
d&&(r=l(n,i,t),c((function(){d.takeRecords().map(f),r(!0)})),p((function(){o=0,g=-1,i=s("CLS",0),
r=l(n,i,t)})))},S={passive:!0,capture:!0},E=new Date,w=function(e,t){n||(n=t,i=e,o=new Date,
_(removeEventListener),R())},R=function(){if(i>=0&&i<o-E){var e={entryType:"first-input",
name:n.type,target:n.target,cancelable:n.cancelable,startTime:n.timeStamp,
processingStart:n.timeStamp+i}
a.forEach((function(t){t(e)})),a=[]}},x=function(e){if(e.cancelable){
var t=(e.timeStamp>1e12?new Date:performance.now())-e.timeStamp
"pointerdown"==e.type?function(e,t){var r=function(){w(e,t),i()},n=function(){i()},i=function(){
removeEventListener("pointerup",r,S),removeEventListener("pointercancel",n,S)}
addEventListener("pointerup",r,S),addEventListener("pointercancel",n,S)}(t,e):w(t,e)}
},_=function(e){["mousedown","keydown","touchstart","pointerdown"].forEach((function(t){
return e(t,x,S)}))},A=function(e,t){var r,o=m(),f=s("FID"),d=function(e){
e.startTime<o.firstHiddenTime&&(f.value=e.processingStart-e.startTime,f.entries.push(e),r(!0))
},h=u("first-input",d)
r=l(e,f,t),h&&c((function(){h.takeRecords().map(d),h.disconnect()}),!0),h&&p((function(){var o
f=s("FID"),r=l(e,f,t),a=[],i=-1,n=null,_(addEventListener),o=d,a.push(o),R()}))
},C={},k=function(e,t){var r,n=m(),i=s("LCP"),o=function(e){var t=e.startTime
t<n.firstHiddenTime&&(i.value=t,i.entries.push(e),r())},a=u("largest-contentful-paint",o)
if(a){r=l(e,i,t)
var f=function(){C[i.id]||(a.takeRecords().map(o),a.disconnect(),C[i.id]=!0,r(!0))}
;["keydown","click"].forEach((function(e){addEventListener(e,f,{once:!0,capture:!0})})),c(f,!0),
p((function(n){i=s("LCP"),r=l(e,i,t),requestAnimationFrame((function(){
requestAnimationFrame((function(){i.value=performance.now()-n.timeStamp,C[i.id]=!0,r(!0)}))}))}))}
},T=function(e){var t,r=s("TTFB")
t=function(){try{var t=performance.getEntriesByType("navigation")[0]||function(){
var e=performance.timing,t={entryType:"navigation",startTime:0}
for(var r in e)"navigationStart"!==r&&"toJSON"!==r&&(t[r]=Math.max(e[r]-e.navigationStart,0))
return t}()
if(r.value=r.delta=t.responseStart,r.value<0||r.value>performance.now())return
r.entries=[t],e(r)}catch(e){}
},"complete"===document.readyState?setTimeout(t,0):addEventListener("load",(function(){
return setTimeout(t,0)}))}},5767:(e,t,r)=>{"use strict"
var n=r(2682),i=r(9209),o=r(487),a=r(8075),s=r(5795),u=a("Object.prototype.toString"),c=r(9092)(),p="undefined"==typeof globalThis?r.g:globalThis,l=i(),f=a("String.prototype.slice"),d=Object.getPrototypeOf,h=a("Array.prototype.indexOf",!0)||function(e,t){
for(var r=0;r<e.length;r+=1)if(e[r]===t)return r
return-1},m={__proto__:null}
n(l,c&&s&&d?function(e){var t=new p[e]
if(Symbol.toStringTag in t){var r=d(t),n=s(r,Symbol.toStringTag)
if(!n){var i=d(r)
n=s(i,Symbol.toStringTag)}m["$"+e]=o(n.get)}}:function(e){var t=new p[e],r=t.slice||t.set
r&&(m["$"+e]=o(r))}),e.exports=function(e){if(!e||"object"!=typeof e)return!1
if(!c){var t=f(u(e),8,-1)
return h(l,t)>-1?t:"Object"===t&&function(e){var t=!1
return n(m,(function(r,n){if(!t)try{r(e),t=f(n,1)}catch(e){}})),t}(e)}return s?function(e){var t=!1
return n(m,(function(r,n){if(!t)try{"$"+r(e)===n&&(t=f(n,1))}catch(e){}})),t}(e):null}},1976:()=>{},
9209:(e,t,r)=>{"use strict"
var n=r(6578),i="undefined"==typeof globalThis?r.g:globalThis
e.exports=function(){for(var e=[],t=0;t<n.length;t++)"function"==typeof i[n[t]]&&(e[e.length]=n[t])
return e}},5087:e=>{"use strict"
e.exports=JSON.parse('{"acm":{"name":"ACM","cors":true},"apigateway":{"name":"APIGateway","cors":true},"applicationautoscaling":{"prefix":"application-autoscaling","name":"ApplicationAutoScaling","cors":true},"appstream":{"name":"AppStream"},"autoscaling":{"name":"AutoScaling","cors":true},"batch":{"name":"Batch"},"budgets":{"name":"Budgets"},"clouddirectory":{"name":"CloudDirectory","versions":["2016-05-10*"]},"cloudformation":{"name":"CloudFormation","cors":true},"cloudfront":{"name":"CloudFront","versions":["2013-05-12*","2013-11-11*","2014-05-31*","2014-10-21*","2014-11-06*","2015-04-17*","2015-07-27*","2015-09-17*","2016-01-13*","2016-01-28*","2016-08-01*","2016-08-20*","2016-09-07*","2016-09-29*","2016-11-25*","2017-03-25*","2017-10-30*","2018-06-18*","2018-11-05*","2019-03-26*"],"cors":true},"cloudhsm":{"name":"CloudHSM","cors":true},"cloudsearch":{"name":"CloudSearch"},"cloudsearchdomain":{"name":"CloudSearchDomain"},"cloudtrail":{"name":"CloudTrail","cors":true},"cloudwatch":{"prefix":"monitoring","name":"CloudWatch","cors":true},"cloudwatchevents":{"prefix":"events","name":"CloudWatchEvents","versions":["2014-02-03*"],"cors":true},"cloudwatchlogs":{"prefix":"logs","name":"CloudWatchLogs","cors":true},"codebuild":{"name":"CodeBuild","cors":true},"codecommit":{"name":"CodeCommit","cors":true},"codedeploy":{"name":"CodeDeploy","cors":true},"codepipeline":{"name":"CodePipeline","cors":true},"cognitoidentity":{"prefix":"cognito-identity","name":"CognitoIdentity","cors":true},"cognitoidentityserviceprovider":{"prefix":"cognito-idp","name":"CognitoIdentityServiceProvider","cors":true},"cognitosync":{"prefix":"cognito-sync","name":"CognitoSync","cors":true},"configservice":{"prefix":"config","name":"ConfigService","cors":true},"cur":{"name":"CUR","cors":true},"datapipeline":{"name":"DataPipeline"},"devicefarm":{"name":"DeviceFarm","cors":true},"directconnect":{"name":"DirectConnect","cors":true},"directoryservice":{"prefix":"ds","name":"DirectoryService"},"discovery":{"name":"Discovery"},"dms":{"name":"DMS"},"dynamodb":{"name":"DynamoDB","cors":true},"dynamodbstreams":{"prefix":"streams.dynamodb","name":"DynamoDBStreams","cors":true},"ec2":{"name":"EC2","versions":["2013-06-15*","2013-10-15*","2014-02-01*","2014-05-01*","2014-06-15*","2014-09-01*","2014-10-01*","2015-03-01*","2015-04-15*","2015-10-01*","2016-04-01*","2016-09-15*"],"cors":true},"ecr":{"name":"ECR","cors":true},"ecs":{"name":"ECS","cors":true},"efs":{"prefix":"elasticfilesystem","name":"EFS","cors":true},"elasticache":{"name":"ElastiCache","versions":["2012-11-15*","2014-03-24*","2014-07-15*","2014-09-30*"],"cors":true},"elasticbeanstalk":{"name":"ElasticBeanstalk","cors":true},"elb":{"prefix":"elasticloadbalancing","name":"ELB","cors":true},"elbv2":{"prefix":"elasticloadbalancingv2","name":"ELBv2","cors":true},"emr":{"prefix":"elasticmapreduce","name":"EMR","cors":true},"es":{"name":"ES"},"elastictranscoder":{"name":"ElasticTranscoder","cors":true},"firehose":{"name":"Firehose","cors":true},"gamelift":{"name":"GameLift","cors":true},"glacier":{"name":"Glacier"},"health":{"name":"Health"},"iam":{"name":"IAM","cors":true},"importexport":{"name":"ImportExport"},"inspector":{"name":"Inspector","versions":["2015-08-18*"],"cors":true},"iot":{"name":"Iot","cors":true},"iotdata":{"prefix":"iot-data","name":"IotData","cors":true},"kinesis":{"name":"Kinesis","cors":true},"kinesisanalytics":{"name":"KinesisAnalytics"},"kms":{"name":"KMS","cors":true},"lambda":{"name":"Lambda","cors":true},"lexruntime":{"prefix":"runtime.lex","name":"LexRuntime","cors":true},"lightsail":{"name":"Lightsail"},"machinelearning":{"name":"MachineLearning","cors":true},"marketplacecommerceanalytics":{"name":"MarketplaceCommerceAnalytics","cors":true},"marketplacemetering":{"prefix":"meteringmarketplace","name":"MarketplaceMetering"},"mturk":{"prefix":"mturk-requester","name":"MTurk","cors":true},"mobileanalytics":{"name":"MobileAnalytics","cors":true},"opsworks":{"name":"OpsWorks","cors":true},"opsworkscm":{"name":"OpsWorksCM"},"organizations":{"name":"Organizations"},"pinpoint":{"name":"Pinpoint"},"polly":{"name":"Polly","cors":true},"rds":{"name":"RDS","versions":["2014-09-01*"],"cors":true},"redshift":{"name":"Redshift","cors":true},"rekognition":{"name":"Rekognition","cors":true},"resourcegroupstaggingapi":{"name":"ResourceGroupsTaggingAPI"},"route53":{"name":"Route53","cors":true},"route53domains":{"name":"Route53Domains","cors":true},"s3":{"name":"S3","dualstackAvailable":true,"cors":true},"s3control":{"name":"S3Control","dualstackAvailable":true,"xmlNoDefaultLists":true},"servicecatalog":{"name":"ServiceCatalog","cors":true},"ses":{"prefix":"email","name":"SES","cors":true},"shield":{"name":"Shield"},"simpledb":{"prefix":"sdb","name":"SimpleDB"},"sms":{"name":"SMS"},"snowball":{"name":"Snowball"},"sns":{"name":"SNS","cors":true},"sqs":{"name":"SQS","cors":true},"ssm":{"name":"SSM","cors":true},"storagegateway":{"name":"StorageGateway","cors":true},"stepfunctions":{"prefix":"states","name":"StepFunctions"},"sts":{"name":"STS","cors":true},"support":{"name":"Support"},"swf":{"name":"SWF"},"xray":{"name":"XRay","cors":true},"waf":{"name":"WAF","cors":true},"wafregional":{"prefix":"waf-regional","name":"WAFRegional"},"workdocs":{"name":"WorkDocs","cors":true},"workspaces":{"name":"WorkSpaces"},"codestar":{"name":"CodeStar"},"lexmodelbuildingservice":{"prefix":"lex-models","name":"LexModelBuildingService","cors":true},"marketplaceentitlementservice":{"prefix":"entitlement.marketplace","name":"MarketplaceEntitlementService"},"athena":{"name":"Athena","cors":true},"greengrass":{"name":"Greengrass"},"dax":{"name":"DAX"},"migrationhub":{"prefix":"AWSMigrationHub","name":"MigrationHub"},"cloudhsmv2":{"name":"CloudHSMV2","cors":true},"glue":{"name":"Glue"},"mobile":{"name":"Mobile"},"pricing":{"name":"Pricing","cors":true},"costexplorer":{"prefix":"ce","name":"CostExplorer","cors":true},"mediaconvert":{"name":"MediaConvert"},"medialive":{"name":"MediaLive"},"mediapackage":{"name":"MediaPackage"},"mediastore":{"name":"MediaStore"},"mediastoredata":{"prefix":"mediastore-data","name":"MediaStoreData","cors":true},"appsync":{"name":"AppSync"},"guardduty":{"name":"GuardDuty"},"mq":{"name":"MQ"},"comprehend":{"name":"Comprehend","cors":true},"iotjobsdataplane":{"prefix":"iot-jobs-data","name":"IoTJobsDataPlane"},"kinesisvideoarchivedmedia":{"prefix":"kinesis-video-archived-media","name":"KinesisVideoArchivedMedia","cors":true},"kinesisvideomedia":{"prefix":"kinesis-video-media","name":"KinesisVideoMedia","cors":true},"kinesisvideo":{"name":"KinesisVideo","cors":true},"sagemakerruntime":{"prefix":"runtime.sagemaker","name":"SageMakerRuntime"},"sagemaker":{"name":"SageMaker"},"translate":{"name":"Translate","cors":true},"resourcegroups":{"prefix":"resource-groups","name":"ResourceGroups","cors":true},"alexaforbusiness":{"name":"AlexaForBusiness"},"cloud9":{"name":"Cloud9"},"serverlessapplicationrepository":{"prefix":"serverlessrepo","name":"ServerlessApplicationRepository"},"servicediscovery":{"name":"ServiceDiscovery"},"workmail":{"name":"WorkMail"},"autoscalingplans":{"prefix":"autoscaling-plans","name":"AutoScalingPlans"},"transcribeservice":{"prefix":"transcribe","name":"TranscribeService"},"connect":{"name":"Connect","cors":true},"acmpca":{"prefix":"acm-pca","name":"ACMPCA"},"fms":{"name":"FMS"},"secretsmanager":{"name":"SecretsManager","cors":true},"iotanalytics":{"name":"IoTAnalytics","cors":true},"iot1clickdevicesservice":{"prefix":"iot1click-devices","name":"IoT1ClickDevicesService"},"iot1clickprojects":{"prefix":"iot1click-projects","name":"IoT1ClickProjects"},"pi":{"name":"PI"},"neptune":{"name":"Neptune"},"mediatailor":{"name":"MediaTailor"},"eks":{"name":"EKS"},"dlm":{"name":"DLM"},"signer":{"name":"Signer"},"chime":{"name":"Chime"},"pinpointemail":{"prefix":"pinpoint-email","name":"PinpointEmail"},"ram":{"name":"RAM"},"route53resolver":{"name":"Route53Resolver"},"pinpointsmsvoice":{"prefix":"sms-voice","name":"PinpointSMSVoice"},"quicksight":{"name":"QuickSight"},"rdsdataservice":{"prefix":"rds-data","name":"RDSDataService"},"amplify":{"name":"Amplify"},"datasync":{"name":"DataSync"},"robomaker":{"name":"RoboMaker"},"transfer":{"name":"Transfer"},"globalaccelerator":{"name":"GlobalAccelerator"},"comprehendmedical":{"name":"ComprehendMedical","cors":true},"kinesisanalyticsv2":{"name":"KinesisAnalyticsV2"},"mediaconnect":{"name":"MediaConnect"},"fsx":{"name":"FSx"},"securityhub":{"name":"SecurityHub"},"appmesh":{"name":"AppMesh","versions":["2018-10-01*"]},"licensemanager":{"prefix":"license-manager","name":"LicenseManager"},"kafka":{"name":"Kafka"},"apigatewaymanagementapi":{"name":"ApiGatewayManagementApi"},"apigatewayv2":{"name":"ApiGatewayV2"},"docdb":{"name":"DocDB"},"backup":{"name":"Backup"},"worklink":{"name":"WorkLink"},"textract":{"name":"Textract"},"managedblockchain":{"name":"ManagedBlockchain"},"mediapackagevod":{"prefix":"mediapackage-vod","name":"MediaPackageVod"},"groundstation":{"name":"GroundStation"},"iotthingsgraph":{"name":"IoTThingsGraph"},"iotevents":{"name":"IoTEvents"},"ioteventsdata":{"prefix":"iotevents-data","name":"IoTEventsData"},"personalize":{"name":"Personalize","cors":true},"personalizeevents":{"prefix":"personalize-events","name":"PersonalizeEvents","cors":true},"personalizeruntime":{"prefix":"personalize-runtime","name":"PersonalizeRuntime","cors":true},"applicationinsights":{"prefix":"application-insights","name":"ApplicationInsights"},"servicequotas":{"prefix":"service-quotas","name":"ServiceQuotas"},"ec2instanceconnect":{"prefix":"ec2-instance-connect","name":"EC2InstanceConnect"},"eventbridge":{"name":"EventBridge"},"lakeformation":{"name":"LakeFormation"},"forecastservice":{"prefix":"forecast","name":"ForecastService","cors":true},"forecastqueryservice":{"prefix":"forecastquery","name":"ForecastQueryService","cors":true},"qldb":{"name":"QLDB"},"qldbsession":{"prefix":"qldb-session","name":"QLDBSession"},"workmailmessageflow":{"name":"WorkMailMessageFlow"},"codestarnotifications":{"prefix":"codestar-notifications","name":"CodeStarNotifications"},"savingsplans":{"name":"SavingsPlans"},"sso":{"name":"SSO"},"ssooidc":{"prefix":"sso-oidc","name":"SSOOIDC"},"marketplacecatalog":{"prefix":"marketplace-catalog","name":"MarketplaceCatalog","cors":true},"dataexchange":{"name":"DataExchange"},"sesv2":{"name":"SESV2"},"migrationhubconfig":{"prefix":"migrationhub-config","name":"MigrationHubConfig"},"connectparticipant":{"name":"ConnectParticipant"},"appconfig":{"name":"AppConfig"},"iotsecuretunneling":{"name":"IoTSecureTunneling"},"wafv2":{"name":"WAFV2"},"elasticinference":{"prefix":"elastic-inference","name":"ElasticInference"},"imagebuilder":{"name":"Imagebuilder"},"schemas":{"name":"Schemas"},"accessanalyzer":{"name":"AccessAnalyzer"},"codegurureviewer":{"prefix":"codeguru-reviewer","name":"CodeGuruReviewer"},"codeguruprofiler":{"name":"CodeGuruProfiler"},"computeoptimizer":{"prefix":"compute-optimizer","name":"ComputeOptimizer"},"frauddetector":{"name":"FraudDetector"},"kendra":{"name":"Kendra"},"networkmanager":{"name":"NetworkManager"},"outposts":{"name":"Outposts"},"augmentedairuntime":{"prefix":"sagemaker-a2i-runtime","name":"AugmentedAIRuntime"},"ebs":{"name":"EBS"},"kinesisvideosignalingchannels":{"prefix":"kinesis-video-signaling","name":"KinesisVideoSignalingChannels","cors":true},"detective":{"name":"Detective"},"codestarconnections":{"prefix":"codestar-connections","name":"CodeStarconnections"},"synthetics":{"name":"Synthetics"},"iotsitewise":{"name":"IoTSiteWise"},"macie2":{"name":"Macie2"},"codeartifact":{"name":"CodeArtifact"},"honeycode":{"name":"Honeycode"},"ivs":{"name":"IVS"},"braket":{"name":"Braket"},"identitystore":{"name":"IdentityStore"},"appflow":{"name":"Appflow"},"redshiftdata":{"prefix":"redshift-data","name":"RedshiftData"},"ssoadmin":{"prefix":"sso-admin","name":"SSOAdmin"},"timestreamquery":{"prefix":"timestream-query","name":"TimestreamQuery"},"timestreamwrite":{"prefix":"timestream-write","name":"TimestreamWrite"},"s3outposts":{"name":"S3Outposts"},"databrew":{"name":"DataBrew"},"servicecatalogappregistry":{"prefix":"servicecatalog-appregistry","name":"ServiceCatalogAppRegistry"},"networkfirewall":{"prefix":"network-firewall","name":"NetworkFirewall"},"mwaa":{"name":"MWAA"},"amplifybackend":{"name":"AmplifyBackend"},"appintegrations":{"name":"AppIntegrations"},"connectcontactlens":{"prefix":"connect-contact-lens","name":"ConnectContactLens"},"devopsguru":{"prefix":"devops-guru","name":"DevOpsGuru"},"ecrpublic":{"prefix":"ecr-public","name":"ECRPUBLIC"},"lookoutvision":{"name":"LookoutVision"},"sagemakerfeaturestoreruntime":{"prefix":"sagemaker-featurestore-runtime","name":"SageMakerFeatureStoreRuntime"},"customerprofiles":{"prefix":"customer-profiles","name":"CustomerProfiles"},"auditmanager":{"name":"AuditManager"},"emrcontainers":{"prefix":"emr-containers","name":"EMRcontainers"},"healthlake":{"name":"HealthLake"},"sagemakeredge":{"prefix":"sagemaker-edge","name":"SagemakerEdge"},"amp":{"name":"Amp","cors":true},"greengrassv2":{"name":"GreengrassV2"},"iotdeviceadvisor":{"name":"IotDeviceAdvisor"},"iotfleethub":{"name":"IoTFleetHub"},"iotwireless":{"name":"IoTWireless"},"location":{"name":"Location","cors":true},"wellarchitected":{"name":"WellArchitected"},"lexmodelsv2":{"prefix":"models.lex.v2","name":"LexModelsV2"},"lexruntimev2":{"prefix":"runtime.lex.v2","name":"LexRuntimeV2","cors":true},"fis":{"name":"Fis"},"lookoutmetrics":{"name":"LookoutMetrics"},"mgn":{"name":"Mgn"},"lookoutequipment":{"name":"LookoutEquipment"},"nimble":{"name":"Nimble"},"finspace":{"name":"Finspace"},"finspacedata":{"prefix":"finspace-data","name":"Finspacedata"},"ssmcontacts":{"prefix":"ssm-contacts","name":"SSMContacts"},"ssmincidents":{"prefix":"ssm-incidents","name":"SSMIncidents"},"applicationcostprofiler":{"name":"ApplicationCostProfiler"},"apprunner":{"name":"AppRunner"},"proton":{"name":"Proton"},"route53recoverycluster":{"prefix":"route53-recovery-cluster","name":"Route53RecoveryCluster"},"route53recoverycontrolconfig":{"prefix":"route53-recovery-control-config","name":"Route53RecoveryControlConfig"},"route53recoveryreadiness":{"prefix":"route53-recovery-readiness","name":"Route53RecoveryReadiness"},"chimesdkidentity":{"prefix":"chime-sdk-identity","name":"ChimeSDKIdentity"},"chimesdkmessaging":{"prefix":"chime-sdk-messaging","name":"ChimeSDKMessaging"},"snowdevicemanagement":{"prefix":"snow-device-management","name":"SnowDeviceManagement"},"memorydb":{"name":"MemoryDB"},"opensearch":{"name":"OpenSearch"},"kafkaconnect":{"name":"KafkaConnect"},"voiceid":{"prefix":"voice-id","name":"VoiceID"},"wisdom":{"name":"Wisdom"},"account":{"name":"Account"},"cloudcontrol":{"name":"CloudControl"},"grafana":{"name":"Grafana"},"panorama":{"name":"Panorama"},"chimesdkmeetings":{"prefix":"chime-sdk-meetings","name":"ChimeSDKMeetings"},"resiliencehub":{"name":"Resiliencehub"},"migrationhubstrategy":{"name":"MigrationHubStrategy"},"appconfigdata":{"name":"AppConfigData"},"drs":{"name":"Drs"},"migrationhubrefactorspaces":{"prefix":"migration-hub-refactor-spaces","name":"MigrationHubRefactorSpaces"},"evidently":{"name":"Evidently"},"inspector2":{"name":"Inspector2"},"rbin":{"name":"Rbin"},"rum":{"name":"RUM"},"backupgateway":{"prefix":"backup-gateway","name":"BackupGateway"},"iottwinmaker":{"name":"IoTTwinMaker"},"workspacesweb":{"prefix":"workspaces-web","name":"WorkSpacesWeb"},"amplifyuibuilder":{"name":"AmplifyUIBuilder"},"keyspaces":{"name":"Keyspaces"},"billingconductor":{"name":"Billingconductor"},"pinpointsmsvoicev2":{"prefix":"pinpoint-sms-voice-v2","name":"PinpointSMSVoiceV2"},"ivschat":{"name":"Ivschat"},"chimesdkmediapipelines":{"prefix":"chime-sdk-media-pipelines","name":"ChimeSDKMediaPipelines"},"emrserverless":{"prefix":"emr-serverless","name":"EMRServerless"},"m2":{"name":"M2"},"connectcampaigns":{"name":"ConnectCampaigns"},"redshiftserverless":{"prefix":"redshift-serverless","name":"RedshiftServerless"},"rolesanywhere":{"name":"RolesAnywhere"},"licensemanagerusersubscriptions":{"prefix":"license-manager-user-subscriptions","name":"LicenseManagerUserSubscriptions"},"backupstorage":{"name":"BackupStorage"},"privatenetworks":{"name":"PrivateNetworks"},"supportapp":{"prefix":"support-app","name":"SupportApp"},"controltower":{"name":"ControlTower"},"iotfleetwise":{"name":"IoTFleetWise"},"migrationhuborchestrator":{"name":"MigrationHubOrchestrator"},"connectcases":{"name":"ConnectCases"},"resourceexplorer2":{"prefix":"resource-explorer-2","name":"ResourceExplorer2"},"scheduler":{"name":"Scheduler"},"chimesdkvoice":{"prefix":"chime-sdk-voice","name":"ChimeSDKVoice"},"ssmsap":{"prefix":"ssm-sap","name":"SsmSap"},"oam":{"name":"OAM"},"arczonalshift":{"prefix":"arc-zonal-shift","name":"ARCZonalShift"},"omics":{"name":"Omics"},"opensearchserverless":{"name":"OpenSearchServerless"},"securitylake":{"name":"SecurityLake"},"simspaceweaver":{"name":"SimSpaceWeaver"},"docdbelastic":{"prefix":"docdb-elastic","name":"DocDBElastic"},"sagemakergeospatial":{"prefix":"sagemaker-geospatial","name":"SageMakerGeospatial"},"codecatalyst":{"name":"CodeCatalyst"},"pipes":{"name":"Pipes"},"sagemakermetrics":{"prefix":"sagemaker-metrics","name":"SageMakerMetrics"},"kinesisvideowebrtcstorage":{"prefix":"kinesis-video-webrtc-storage","name":"KinesisVideoWebRTCStorage"},"licensemanagerlinuxsubscriptions":{"prefix":"license-manager-linux-subscriptions","name":"LicenseManagerLinuxSubscriptions"},"kendraranking":{"prefix":"kendra-ranking","name":"KendraRanking"},"cleanrooms":{"name":"CleanRooms"},"cloudtraildata":{"prefix":"cloudtrail-data","name":"CloudTrailData"},"tnb":{"name":"Tnb"},"internetmonitor":{"name":"InternetMonitor"},"ivsrealtime":{"prefix":"ivs-realtime","name":"IVSRealTime"},"vpclattice":{"prefix":"vpc-lattice","name":"VPCLattice"},"osis":{"name":"OSIS"},"mediapackagev2":{"name":"MediaPackageV2"},"paymentcryptography":{"prefix":"payment-cryptography","name":"PaymentCryptography"},"paymentcryptographydata":{"prefix":"payment-cryptography-data","name":"PaymentCryptographyData"},"codegurusecurity":{"prefix":"codeguru-security","name":"CodeGuruSecurity"},"verifiedpermissions":{"name":"VerifiedPermissions"},"appfabric":{"name":"AppFabric"},"medicalimaging":{"prefix":"medical-imaging","name":"MedicalImaging"},"entityresolution":{"name":"EntityResolution"},"managedblockchainquery":{"prefix":"managedblockchain-query","name":"ManagedBlockchainQuery"},"neptunedata":{"name":"Neptunedata"},"pcaconnectorad":{"prefix":"pca-connector-ad","name":"PcaConnectorAd"},"bedrock":{"name":"Bedrock"},"bedrockruntime":{"prefix":"bedrock-runtime","name":"BedrockRuntime"},"datazone":{"name":"DataZone"},"launchwizard":{"prefix":"launch-wizard","name":"LaunchWizard"},"trustedadvisor":{"name":"TrustedAdvisor"},"inspectorscan":{"prefix":"inspector-scan","name":"InspectorScan"},"bcmdataexports":{"prefix":"bcm-data-exports","name":"BCMDataExports"},"costoptimizationhub":{"prefix":"cost-optimization-hub","name":"CostOptimizationHub"},"eksauth":{"prefix":"eks-auth","name":"EKSAuth"},"freetier":{"name":"FreeTier"},"repostspace":{"name":"Repostspace"},"workspacesthinclient":{"prefix":"workspaces-thin-client","name":"WorkSpacesThinClient"},"b2bi":{"name":"B2bi"},"bedrockagent":{"prefix":"bedrock-agent","name":"BedrockAgent"},"bedrockagentruntime":{"prefix":"bedrock-agent-runtime","name":"BedrockAgentRuntime"},"qbusiness":{"name":"QBusiness"},"qconnect":{"name":"QConnect"},"cleanroomsml":{"name":"CleanRoomsML"},"marketplaceagreement":{"prefix":"marketplace-agreement","name":"MarketplaceAgreement"},"marketplacedeployment":{"prefix":"marketplace-deployment","name":"MarketplaceDeployment"},"networkmonitor":{"name":"NetworkMonitor"},"supplychain":{"name":"SupplyChain"},"artifact":{"name":"Artifact"},"chatbot":{"name":"Chatbot"},"timestreaminfluxdb":{"prefix":"timestream-influxdb","name":"TimestreamInfluxDB"},"codeconnections":{"name":"CodeConnections"},"deadline":{"name":"Deadline"},"controlcatalog":{"name":"ControlCatalog"},"route53profiles":{"name":"Route53Profiles"}}')
},3548:e=>{"use strict"
e.exports=JSON.parse('{"rules":{"*/*":{"endpoint":"{service}.{region}.amazonaws.com"},"cn-*/*":{"endpoint":"{service}.{region}.amazonaws.com.cn"},"eu-isoe-*/*":"euIsoe","us-iso-*/*":"usIso","us-isob-*/*":"usIsob","us-isof-*/*":"usIsof","*/budgets":"globalSSL","*/cloudfront":"globalSSL","*/sts":"globalSSL","*/importexport":{"endpoint":"{service}.amazonaws.com","signatureVersion":"v2","globalEndpoint":true},"*/route53":"globalSSL","cn-*/route53":{"endpoint":"{service}.amazonaws.com.cn","globalEndpoint":true,"signingRegion":"cn-northwest-1"},"us-gov-*/route53":"globalGovCloud","us-iso-*/route53":{"endpoint":"{service}.c2s.ic.gov","globalEndpoint":true,"signingRegion":"us-iso-east-1"},"us-isob-*/route53":{"endpoint":"{service}.sc2s.sgov.gov","globalEndpoint":true,"signingRegion":"us-isob-east-1"},"*/waf":"globalSSL","*/iam":"globalSSL","cn-*/iam":{"endpoint":"{service}.cn-north-1.amazonaws.com.cn","globalEndpoint":true,"signingRegion":"cn-north-1"},"us-iso-*/iam":{"endpoint":"{service}.us-iso-east-1.c2s.ic.gov","globalEndpoint":true,"signingRegion":"us-iso-east-1"},"us-gov-*/iam":"globalGovCloud","*/ce":{"endpoint":"{service}.us-east-1.amazonaws.com","globalEndpoint":true,"signingRegion":"us-east-1"},"cn-*/ce":{"endpoint":"{service}.cn-northwest-1.amazonaws.com.cn","globalEndpoint":true,"signingRegion":"cn-northwest-1"},"us-gov-*/sts":{"endpoint":"{service}.{region}.amazonaws.com"},"us-gov-west-1/s3":"s3signature","us-west-1/s3":"s3signature","us-west-2/s3":"s3signature","eu-west-1/s3":"s3signature","ap-southeast-1/s3":"s3signature","ap-southeast-2/s3":"s3signature","ap-northeast-1/s3":"s3signature","sa-east-1/s3":"s3signature","us-east-1/s3":{"endpoint":"{service}.amazonaws.com","signatureVersion":"s3"},"us-east-1/sdb":{"endpoint":"{service}.amazonaws.com","signatureVersion":"v2"},"*/sdb":{"endpoint":"{service}.{region}.amazonaws.com","signatureVersion":"v2"},"*/resource-explorer-2":"dualstackByDefault","*/kendra-ranking":"dualstackByDefault","*/internetmonitor":"dualstackByDefault","*/codecatalyst":"globalDualstackByDefault"},"fipsRules":{"*/*":"fipsStandard","us-gov-*/*":"fipsStandard","us-iso-*/*":{"endpoint":"{service}-fips.{region}.c2s.ic.gov"},"us-iso-*/dms":"usIso","us-isob-*/*":{"endpoint":"{service}-fips.{region}.sc2s.sgov.gov"},"us-isob-*/dms":"usIsob","cn-*/*":{"endpoint":"{service}-fips.{region}.amazonaws.com.cn"},"*/api.ecr":"fips.api.ecr","*/api.sagemaker":"fips.api.sagemaker","*/batch":"fipsDotPrefix","*/eks":"fipsDotPrefix","*/models.lex":"fips.models.lex","*/runtime.lex":"fips.runtime.lex","*/runtime.sagemaker":{"endpoint":"runtime-fips.sagemaker.{region}.amazonaws.com"},"*/iam":"fipsWithoutRegion","*/route53":"fipsWithoutRegion","*/transcribe":"fipsDotPrefix","*/waf":"fipsWithoutRegion","us-gov-*/transcribe":"fipsDotPrefix","us-gov-*/api.ecr":"fips.api.ecr","us-gov-*/models.lex":"fips.models.lex","us-gov-*/runtime.lex":"fips.runtime.lex","us-gov-*/access-analyzer":"fipsWithServiceOnly","us-gov-*/acm":"fipsWithServiceOnly","us-gov-*/acm-pca":"fipsWithServiceOnly","us-gov-*/api.sagemaker":"fipsWithServiceOnly","us-gov-*/appconfig":"fipsWithServiceOnly","us-gov-*/application-autoscaling":"fipsWithServiceOnly","us-gov-*/autoscaling":"fipsWithServiceOnly","us-gov-*/autoscaling-plans":"fipsWithServiceOnly","us-gov-*/batch":"fipsWithServiceOnly","us-gov-*/cassandra":"fipsWithServiceOnly","us-gov-*/clouddirectory":"fipsWithServiceOnly","us-gov-*/cloudformation":"fipsWithServiceOnly","us-gov-*/cloudshell":"fipsWithServiceOnly","us-gov-*/cloudtrail":"fipsWithServiceOnly","us-gov-*/config":"fipsWithServiceOnly","us-gov-*/connect":"fipsWithServiceOnly","us-gov-*/databrew":"fipsWithServiceOnly","us-gov-*/dlm":"fipsWithServiceOnly","us-gov-*/dms":"fipsWithServiceOnly","us-gov-*/dynamodb":"fipsWithServiceOnly","us-gov-*/ec2":"fipsWithServiceOnly","us-gov-*/eks":"fipsWithServiceOnly","us-gov-*/elasticache":"fipsWithServiceOnly","us-gov-*/elasticbeanstalk":"fipsWithServiceOnly","us-gov-*/elasticloadbalancing":"fipsWithServiceOnly","us-gov-*/elasticmapreduce":"fipsWithServiceOnly","us-gov-*/events":"fipsWithServiceOnly","us-gov-*/fis":"fipsWithServiceOnly","us-gov-*/glacier":"fipsWithServiceOnly","us-gov-*/greengrass":"fipsWithServiceOnly","us-gov-*/guardduty":"fipsWithServiceOnly","us-gov-*/identitystore":"fipsWithServiceOnly","us-gov-*/imagebuilder":"fipsWithServiceOnly","us-gov-*/kafka":"fipsWithServiceOnly","us-gov-*/kinesis":"fipsWithServiceOnly","us-gov-*/logs":"fipsWithServiceOnly","us-gov-*/mediaconvert":"fipsWithServiceOnly","us-gov-*/monitoring":"fipsWithServiceOnly","us-gov-*/networkmanager":"fipsWithServiceOnly","us-gov-*/organizations":"fipsWithServiceOnly","us-gov-*/outposts":"fipsWithServiceOnly","us-gov-*/participant.connect":"fipsWithServiceOnly","us-gov-*/ram":"fipsWithServiceOnly","us-gov-*/rds":"fipsWithServiceOnly","us-gov-*/redshift":"fipsWithServiceOnly","us-gov-*/resource-groups":"fipsWithServiceOnly","us-gov-*/runtime.sagemaker":"fipsWithServiceOnly","us-gov-*/serverlessrepo":"fipsWithServiceOnly","us-gov-*/servicecatalog-appregistry":"fipsWithServiceOnly","us-gov-*/servicequotas":"fipsWithServiceOnly","us-gov-*/sns":"fipsWithServiceOnly","us-gov-*/sqs":"fipsWithServiceOnly","us-gov-*/ssm":"fipsWithServiceOnly","us-gov-*/streams.dynamodb":"fipsWithServiceOnly","us-gov-*/sts":"fipsWithServiceOnly","us-gov-*/support":"fipsWithServiceOnly","us-gov-*/swf":"fipsWithServiceOnly","us-gov-west-1/states":"fipsWithServiceOnly","us-iso-east-1/elasticfilesystem":{"endpoint":"elasticfilesystem-fips.{region}.c2s.ic.gov"},"us-gov-west-1/organizations":"fipsWithServiceOnly","us-gov-west-1/route53":{"endpoint":"route53.us-gov.amazonaws.com"},"*/resource-explorer-2":"fipsDualstackByDefault","*/kendra-ranking":"dualstackByDefault","*/internetmonitor":"dualstackByDefault","*/codecatalyst":"fipsGlobalDualstackByDefault"},"dualstackRules":{"*/*":{"endpoint":"{service}.{region}.api.aws"},"cn-*/*":{"endpoint":"{service}.{region}.api.amazonwebservices.com.cn"},"*/s3":"dualstackLegacy","cn-*/s3":"dualstackLegacyCn","*/s3-control":"dualstackLegacy","cn-*/s3-control":"dualstackLegacyCn","ap-south-1/ec2":"dualstackLegacyEc2","eu-west-1/ec2":"dualstackLegacyEc2","sa-east-1/ec2":"dualstackLegacyEc2","us-east-1/ec2":"dualstackLegacyEc2","us-east-2/ec2":"dualstackLegacyEc2","us-west-2/ec2":"dualstackLegacyEc2"},"dualstackFipsRules":{"*/*":{"endpoint":"{service}-fips.{region}.api.aws"},"cn-*/*":{"endpoint":"{service}-fips.{region}.api.amazonwebservices.com.cn"},"*/s3":"dualstackFipsLegacy","cn-*/s3":"dualstackFipsLegacyCn","*/s3-control":"dualstackFipsLegacy","cn-*/s3-control":"dualstackFipsLegacyCn"},"patterns":{"globalSSL":{"endpoint":"https://{service}.amazonaws.com","globalEndpoint":true,"signingRegion":"us-east-1"},"globalGovCloud":{"endpoint":"{service}.us-gov.amazonaws.com","globalEndpoint":true,"signingRegion":"us-gov-west-1"},"s3signature":{"endpoint":"{service}.{region}.amazonaws.com","signatureVersion":"s3"},"euIsoe":{"endpoint":"{service}.{region}.cloud.adc-e.uk"},"usIso":{"endpoint":"{service}.{region}.c2s.ic.gov"},"usIsob":{"endpoint":"{service}.{region}.sc2s.sgov.gov"},"usIsof":{"endpoint":"{service}.{region}.csp.hci.ic.gov"},"fipsStandard":{"endpoint":"{service}-fips.{region}.amazonaws.com"},"fipsDotPrefix":{"endpoint":"fips.{service}.{region}.amazonaws.com"},"fipsWithoutRegion":{"endpoint":"{service}-fips.amazonaws.com"},"fips.api.ecr":{"endpoint":"ecr-fips.{region}.amazonaws.com"},"fips.api.sagemaker":{"endpoint":"api-fips.sagemaker.{region}.amazonaws.com"},"fips.models.lex":{"endpoint":"models-fips.lex.{region}.amazonaws.com"},"fips.runtime.lex":{"endpoint":"runtime-fips.lex.{region}.amazonaws.com"},"fipsWithServiceOnly":{"endpoint":"{service}.{region}.amazonaws.com"},"dualstackLegacy":{"endpoint":"{service}.dualstack.{region}.amazonaws.com"},"dualstackLegacyCn":{"endpoint":"{service}.dualstack.{region}.amazonaws.com.cn"},"dualstackFipsLegacy":{"endpoint":"{service}-fips.dualstack.{region}.amazonaws.com"},"dualstackFipsLegacyCn":{"endpoint":"{service}-fips.dualstack.{region}.amazonaws.com.cn"},"dualstackLegacyEc2":{"endpoint":"api.ec2.{region}.aws"},"dualstackByDefault":{"endpoint":"{service}.{region}.api.aws"},"fipsDualstackByDefault":{"endpoint":"{service}-fips.{region}.api.aws"},"globalDualstackByDefault":{"endpoint":"{service}.global.api.aws"},"fipsGlobalDualstackByDefault":{"endpoint":"{service}-fips.global.api.aws"}}}')
}},t={}
function r(n){var i=t[n]
if(void 0!==i)return i.exports
var o=t[n]={exports:{}}
return e[n].call(o.exports,o,o.exports,r),o.exports}r.n=e=>{
var t=e&&e.__esModule?()=>e.default:()=>e
return r.d(t,{a:t}),t},r.d=(e,t)=>{for(var n in t)r.o(t,n)&&!r.o(e,n)&&Object.defineProperty(e,n,{
enumerable:!0,get:t[n]})},r.g=function(){if("object"==typeof globalThis)return globalThis
try{return this||new Function("return this")()}catch(e){if("object"==typeof window)return window}
}(),r.o=(e,t)=>Object.prototype.hasOwnProperty.call(e,t),r.r=e=>{
"undefined"!=typeof Symbol&&Symbol.toStringTag&&Object.defineProperty(e,Symbol.toStringTag,{
value:"Module"}),Object.defineProperty(e,"__esModule",{value:!0})}
var n={}
return(()=>{"use strict"
r.r(n),r.d(n,{EventTracker:()=>e.EventTracker,TangerineBox:()=>e.TangerineBox})
var e=r(8424)})(),n})())}))


define("@amzn/cloud9-ide-client/plugins/c9.ide.aws/tangerine-box-adapter",[],(function(require,exports,module){
"use strict"
Object.defineProperty(exports,"__esModule",{value:!0})
const tangerinebox_weblib_bundle_1=require("tangerinebox-weblib-bundle")
!function(ErrorType){
ErrorType.ClientUnavailable="clientUnavailable",ErrorType.ClientTransientError="clientTransientError",
ErrorType.CspViolationError="cspViolationError"}(exports.ErrorType||(exports.ErrorType={})),
function(EventType){EventType.ClientAvailable="clientAvailable"
}(exports.EventType||(exports.EventType={}))
class TangerineBoxAdapter{constructor(){this.tb=new tangerinebox_weblib_bundle_1.TangerineBox}
async getAccountId(){return this.tb.getAccountId()}getCredentials(){return this.tb.getCredentials()}
getCustomContextParameters(){return{stage:this.tb.getCustomContext("stage"),
region:this.tb.getCustomContext("region"),hostName:this.tb.getCustomContext("hostName"),
webviewAssetsAuthority:this.tb.getCustomContext("webviewAssetsAuthority"),
dependenciesBucketName:this.tb.getCustomContext("dependenciesBucketName"),
ideAssetsVersion:this.tb.getCustomContext("ideAssetsVersion"),
ideAssetsBucketName:this.tb.getCustomContext("ideAssetsBucketName"),
useOriginAccount:"true"===this.tb.getCustomContext("useOriginAccount"),
cloud9ApiEndpoint:this.tb.getCustomContext("cloud9ApiEndpoint"),
vfsBaseUrlOverride:this.tb.getCustomContext("vfsBaseUrlOverride"),
vfsConsoleUrlOverride:this.tb.getCustomContext("vfsConsoleUrlOverride"),
buildInfo:this.constructBuildInfo()}}getEventTracker(){return this.tb.getEventTracker()}
emitSdkMetrics(service){this.tb.getEventTracker().emitAwsSdkMetrics(service)}constructBuildInfo(){
const buildInfo={}
return buildInfo.latest=Number(this.tb.getCustomContext("buildInfo_latest")),buildInfo.version=this.tb.getCustomContext("buildInfo_version"),
buildInfo.dependencies={},
this.tb.getCustomContext("buildInfo_dependencyKeys").split(",").forEach(key=>{
buildInfo.dependencies[key]=this.tb.getCustomContext("buildInfo_"+key)}),JSON.stringify(buildInfo)}}
exports.TangerineBoxAdapter=TangerineBoxAdapter}))


define("@amzn/awscloud9-awsjava-script-sdkbundle/dist/aws-sdk-bundle",[],(function(require,exports,module){
var e,t,$build_deps$={require:require,exports:exports,module:module}
function define(name,deps,m){"function"==typeof name&&(m=name,deps=["require","exports","module"],
name=$build_deps$.module.id),"string"!=typeof name&&(m=deps,deps=name,name=$build_deps$.module.id),
m||(m=deps,deps=[])
var ret="function"==typeof m?m.apply($build_deps$.module,deps.map((function(n){
return $build_deps$[n]||require(n)}))):m
null!=ret&&($build_deps$.module.exports=ret),name!=$build_deps$.module.id&&$build_deps$.module.define&&$build_deps$.module.define(name,[],(function(){
return $build_deps$.module.exports}))}exports=void 0,module=void 0,define.amd=!0,e=this,t=()=>(()=>{
var e={2543:(e,t,r)=>{r(7321)
var n=r(9614),i=n.Service,o=n.apiLoader
o.services.cloud9={},n.Cloud9=i.defineService("cloud9",["2017-09-23"]),Object.defineProperty(o.services.cloud9,"2017-09-23",{
get:function(){var e=r(7142)
return e.paginators=r(6770).o,e},enumerable:!0,configurable:!0}),e.exports=n.Cloud9},6105:(e,t,r)=>{
r(7321)
var n=r(9614),i=n.Service,o=n.apiLoader
o.services.cognitoidentity={},n.CognitoIdentity=i.defineService("cognitoidentity",["2014-06-30"]),
Object.defineProperty(o.services.cognitoidentity,"2014-06-30",{get:function(){var e=r(7377)
return e.paginators=r(5010).o,e},enumerable:!0,configurable:!0}),e.exports=n.CognitoIdentity},
3568:(e,t,r)=>{r(7321)
var n=r(9614),i=n.Service,o=n.apiLoader
o.services.sts={},n.STS=i.defineService("sts",["2011-06-15"]),r(4456),Object.defineProperty(o.services.sts,"2011-06-15",{
get:function(){var e=r(753)
return e.paginators=r(3639).o,e},enumerable:!0,configurable:!0}),e.exports=n.STS},6862:e=>{
function t(e,r){
if(!t.services.hasOwnProperty(e))throw new Error("InvalidService: Failed to load api for "+e)
return t.services[e][r]}t.services={},e.exports=t},7821:(e,t,r)=>{
var n=r(9790),i=r(5610),o=r(4314),s=r(1365)
e.exports={createHash:function(e){if("md5"===(e=e.toLowerCase()))return new i
if("sha256"===e)return new s
if("sha1"===e)return new o
throw new Error("Hash algorithm "+e+" is not supported in the browser SDK")},
createHmac:function(e,t){if("md5"===(e=e.toLowerCase()))return new n(i,t)
if("sha256"===e)return new n(s,t)
if("sha1"===e)return new n(o,t)
throw new Error("HMAC algorithm "+e+" is not supported in the browser SDK")},createSign:function(){
throw new Error("createSign is not implemented in the browser")}}},6323:(e,t,r)=>{var n=r(8764).lW
"undefined"!=typeof ArrayBuffer&&void 0===ArrayBuffer.isView&&(ArrayBuffer.isView=function(e){
return i.indexOf(Object.prototype.toString.call(e))>-1})
var i=["[object Int8Array]","[object Uint8Array]","[object Uint8ClampedArray]","[object Int16Array]","[object Uint16Array]","[object Int32Array]","[object Uint32Array]","[object Float32Array]","[object Float64Array]","[object DataView]"]
e.exports={isEmptyData:function(e){return"string"==typeof e?0===e.length:0===e.byteLength},
convertToBuffer:function(e){
return"string"==typeof e&&(e=new n(e,"utf8")),ArrayBuffer.isView(e)?new Uint8Array(e.buffer,e.byteOffset,e.byteLength/Uint8Array.BYTES_PER_ELEMENT):new Uint8Array(e)
}}},9790:(e,t,r)=>{var n=r(6323)
function i(e,t){this.hash=new e,this.outer=new e
var r=function(e,t){var r=n.convertToBuffer(t)
if(r.byteLength>e.BLOCK_SIZE){var i=new e
i.update(r),r=i.digest()}var o=new Uint8Array(e.BLOCK_SIZE)
return o.set(r),o}(e,t),i=new Uint8Array(e.BLOCK_SIZE)
i.set(r)
for(var o=0;o<e.BLOCK_SIZE;o++)r[o]^=54,i[o]^=92
for(this.hash.update(r),this.outer.update(i),o=0;o<r.byteLength;o++)r[o]=0}e.exports=i,
i.prototype.update=function(e){if(n.isEmptyData(e)||this.error)return this
try{this.hash.update(n.convertToBuffer(e))}catch(e){this.error=e}return this
},i.prototype.digest=function(e){return this.outer.finished||this.outer.update(this.hash.digest()),
this.outer.digest(e)}},5610:(e,t,r)=>{var n=r(6323),i=r(8764).lW
function o(){
this.state=[1732584193,4023233417,2562383102,271733878],this.buffer=new DataView(new ArrayBuffer(64)),
this.bufferLength=0,this.bytesHashed=0,this.finished=!1}function s(e,t,r,n,i,o){
return((t=(t+e&4294967295)+(n+o&4294967295)&4294967295)<<i|t>>>32-i)+r&4294967295}
function a(e,t,r,n,i,o,a){return s(t&r|~t&n,e,t,i,o,a)}function u(e,t,r,n,i,o,a){
return s(t&n|r&~n,e,t,i,o,a)}function c(e,t,r,n,i,o,a){return s(t^r^n,e,t,i,o,a)}
function p(e,t,r,n,i,o,a){return s(r^(t|~n),e,t,i,o,a)}e.exports=o,o.BLOCK_SIZE=64,
o.prototype.update=function(e){if(n.isEmptyData(e))return this
if(this.finished)throw new Error("Attempted to update an already finished hash.")
var t=n.convertToBuffer(e),r=0,i=t.byteLength
for(this.bytesHashed+=i;i>0;)this.buffer.setUint8(this.bufferLength++,t[r++]),i--,
64===this.bufferLength&&(this.hashBuffer(),this.bufferLength=0)
return this},o.prototype.digest=function(e){if(!this.finished){
var t=this,r=t.buffer,n=t.bufferLength,o=8*t.bytesHashed
if(r.setUint8(this.bufferLength++,128),n%64>=56){
for(var s=this.bufferLength;s<64;s++)r.setUint8(s,0)
this.hashBuffer(),this.bufferLength=0}for(s=this.bufferLength;s<56;s++)r.setUint8(s,0)
r.setUint32(56,o>>>0,!0),r.setUint32(60,Math.floor(o/4294967296),!0),this.hashBuffer(),
this.finished=!0}var a=new DataView(new ArrayBuffer(16))
for(s=0;s<4;s++)a.setUint32(4*s,this.state[s],!0)
var u=new i(a.buffer,a.byteOffset,a.byteLength)
return e?u.toString(e):u},o.prototype.hashBuffer=function(){
var e=this.buffer,t=this.state,r=t[0],n=t[1],i=t[2],o=t[3]
r=a(r,n,i,o,e.getUint32(0,!0),7,3614090360),o=a(o,r,n,i,e.getUint32(4,!0),12,3905402710),
i=a(i,o,r,n,e.getUint32(8,!0),17,606105819),n=a(n,i,o,r,e.getUint32(12,!0),22,3250441966),
r=a(r,n,i,o,e.getUint32(16,!0),7,4118548399),o=a(o,r,n,i,e.getUint32(20,!0),12,1200080426),
i=a(i,o,r,n,e.getUint32(24,!0),17,2821735955),n=a(n,i,o,r,e.getUint32(28,!0),22,4249261313),
r=a(r,n,i,o,e.getUint32(32,!0),7,1770035416),o=a(o,r,n,i,e.getUint32(36,!0),12,2336552879),
i=a(i,o,r,n,e.getUint32(40,!0),17,4294925233),n=a(n,i,o,r,e.getUint32(44,!0),22,2304563134),
r=a(r,n,i,o,e.getUint32(48,!0),7,1804603682),o=a(o,r,n,i,e.getUint32(52,!0),12,4254626195),
i=a(i,o,r,n,e.getUint32(56,!0),17,2792965006),
r=u(r,n=a(n,i,o,r,e.getUint32(60,!0),22,1236535329),i,o,e.getUint32(4,!0),5,4129170786),
o=u(o,r,n,i,e.getUint32(24,!0),9,3225465664),i=u(i,o,r,n,e.getUint32(44,!0),14,643717713),
n=u(n,i,o,r,e.getUint32(0,!0),20,3921069994),r=u(r,n,i,o,e.getUint32(20,!0),5,3593408605),
o=u(o,r,n,i,e.getUint32(40,!0),9,38016083),i=u(i,o,r,n,e.getUint32(60,!0),14,3634488961),
n=u(n,i,o,r,e.getUint32(16,!0),20,3889429448),r=u(r,n,i,o,e.getUint32(36,!0),5,568446438),
o=u(o,r,n,i,e.getUint32(56,!0),9,3275163606),i=u(i,o,r,n,e.getUint32(12,!0),14,4107603335),
n=u(n,i,o,r,e.getUint32(32,!0),20,1163531501),r=u(r,n,i,o,e.getUint32(52,!0),5,2850285829),
o=u(o,r,n,i,e.getUint32(8,!0),9,4243563512),i=u(i,o,r,n,e.getUint32(28,!0),14,1735328473),
r=c(r,n=u(n,i,o,r,e.getUint32(48,!0),20,2368359562),i,o,e.getUint32(20,!0),4,4294588738),
o=c(o,r,n,i,e.getUint32(32,!0),11,2272392833),i=c(i,o,r,n,e.getUint32(44,!0),16,1839030562),
n=c(n,i,o,r,e.getUint32(56,!0),23,4259657740),r=c(r,n,i,o,e.getUint32(4,!0),4,2763975236),
o=c(o,r,n,i,e.getUint32(16,!0),11,1272893353),i=c(i,o,r,n,e.getUint32(28,!0),16,4139469664),
n=c(n,i,o,r,e.getUint32(40,!0),23,3200236656),r=c(r,n,i,o,e.getUint32(52,!0),4,681279174),
o=c(o,r,n,i,e.getUint32(0,!0),11,3936430074),i=c(i,o,r,n,e.getUint32(12,!0),16,3572445317),
n=c(n,i,o,r,e.getUint32(24,!0),23,76029189),r=c(r,n,i,o,e.getUint32(36,!0),4,3654602809),
o=c(o,r,n,i,e.getUint32(48,!0),11,3873151461),i=c(i,o,r,n,e.getUint32(60,!0),16,530742520),
r=p(r,n=c(n,i,o,r,e.getUint32(8,!0),23,3299628645),i,o,e.getUint32(0,!0),6,4096336452),
o=p(o,r,n,i,e.getUint32(28,!0),10,1126891415),i=p(i,o,r,n,e.getUint32(56,!0),15,2878612391),
n=p(n,i,o,r,e.getUint32(20,!0),21,4237533241),r=p(r,n,i,o,e.getUint32(48,!0),6,1700485571),
o=p(o,r,n,i,e.getUint32(12,!0),10,2399980690),i=p(i,o,r,n,e.getUint32(40,!0),15,4293915773),
n=p(n,i,o,r,e.getUint32(4,!0),21,2240044497),r=p(r,n,i,o,e.getUint32(32,!0),6,1873313359),
o=p(o,r,n,i,e.getUint32(60,!0),10,4264355552),i=p(i,o,r,n,e.getUint32(24,!0),15,2734768916),
n=p(n,i,o,r,e.getUint32(52,!0),21,1309151649),r=p(r,n,i,o,e.getUint32(16,!0),6,4149444226),
o=p(o,r,n,i,e.getUint32(44,!0),10,3174756917),i=p(i,o,r,n,e.getUint32(8,!0),15,718787259),
n=p(n,i,o,r,e.getUint32(36,!0),21,3951481745),t[0]=r+t[0]&4294967295,t[1]=n+t[1]&4294967295,
t[2]=i+t[2]&4294967295,t[3]=o+t[3]&4294967295}},4314:(e,t,r)=>{var n=r(8764).lW,i=r(6323)
function o(){this.h0=1732584193,this.h1=4023233417,this.h2=2562383102,this.h3=271733878,
this.h4=3285377520,this.block=new Uint32Array(80),this.offset=0,this.shift=24,this.totalLength=0}
new Uint32Array([1518500249,1859775393,-1894007588,-899497514]),Math.pow(2,53),e.exports=o,
o.BLOCK_SIZE=64,o.prototype.update=function(e){
if(this.finished)throw new Error("Attempted to update an already finished hash.")
if(i.isEmptyData(e))return this
var t=(e=i.convertToBuffer(e)).length
this.totalLength+=8*t
for(var r=0;r<t;r++)this.write(e[r])
return this},o.prototype.write=function(e){this.block[this.offset]|=(255&e)<<this.shift,
this.shift?this.shift-=8:(this.offset++,this.shift=24),16===this.offset&&this.processBlock()},
o.prototype.digest=function(e){
this.write(128),(this.offset>14||14===this.offset&&this.shift<24)&&this.processBlock(),
this.offset=14,
this.shift=24,this.write(0),this.write(0),this.write(this.totalLength>0xffffffffff?this.totalLength/1099511627776:0),
this.write(this.totalLength>4294967295?this.totalLength/4294967296:0)
for(var t=24;t>=0;t-=8)this.write(this.totalLength>>t)
var r=new n(20),i=new DataView(r.buffer)
return i.setUint32(0,this.h0,!1),i.setUint32(4,this.h1,!1),i.setUint32(8,this.h2,!1),
i.setUint32(12,this.h3,!1),i.setUint32(16,this.h4,!1),e?r.toString(e):r
},o.prototype.processBlock=function(){for(var e=16;e<80;e++){
var t=this.block[e-3]^this.block[e-8]^this.block[e-14]^this.block[e-16]
this.block[e]=t<<1|t>>>31}var r,n,i=this.h0,o=this.h1,s=this.h2,a=this.h3,u=this.h4
for(e=0;e<80;e++){e<20?(r=a^o&(s^a),n=1518500249):e<40?(r=o^s^a,n=1859775393):e<60?(r=o&s|a&(o|s),
n=2400959708):(r=o^s^a,n=3395469782)
var c=(i<<5|i>>>27)+r+u+n+(0|this.block[e])
u=a,a=s,s=o<<30|o>>>2,o=i,i=c}for(this.h0=this.h0+i|0,this.h1=this.h1+o|0,this.h2=this.h2+s|0,
this.h3=this.h3+a|0,this.h4=this.h4+u|0,this.offset=0,e=0;e<16;e++)this.block[e]=0}},1365:(e,t,r)=>{
var n=r(8764).lW,i=r(6323),o=new Uint32Array([1116352408,1899447441,3049323471,3921009573,961987163,1508970993,2453635748,2870763221,3624381080,310598401,607225278,1426881987,1925078388,2162078206,2614888103,3248222580,3835390401,4022224774,264347078,604807628,770255983,1249150122,1555081692,1996064986,2554220882,2821834349,2952996808,3210313671,3336571891,3584528711,113926993,338241895,666307205,773529912,1294757372,1396182291,1695183700,1986661051,2177026350,2456956037,2730485921,2820302411,3259730800,3345764771,3516065817,3600352804,4094571909,275423344,430227734,506948616,659060556,883997877,958139571,1322822218,1537002063,1747873779,1955562222,2024104815,2227730452,2361852424,2428436474,2756734187,3204031479,3329325298]),s=Math.pow(2,53)-1
function a(){
this.state=[1779033703,3144134277,1013904242,2773480762,1359893119,2600822924,528734635,1541459225],
this.temp=new Int32Array(64),this.buffer=new Uint8Array(64),this.bufferLength=0,this.bytesHashed=0,
this.finished=!1}e.exports=a,a.BLOCK_SIZE=64,a.prototype.update=function(e){
if(this.finished)throw new Error("Attempted to update an already finished hash.")
if(i.isEmptyData(e))return this
var t=0,r=(e=i.convertToBuffer(e)).byteLength
if(this.bytesHashed+=r,8*this.bytesHashed>s)throw new Error("Cannot hash more than 2^53 - 1 bits")
for(;r>0;)this.buffer[this.bufferLength++]=e[t++],r--,64===this.bufferLength&&(this.hashBuffer(),
this.bufferLength=0)
return this},a.prototype.digest=function(e){if(!this.finished){
var t=8*this.bytesHashed,r=new DataView(this.buffer.buffer,this.buffer.byteOffset,this.buffer.byteLength),i=this.bufferLength
if(r.setUint8(this.bufferLength++,128),i%64>=56){
for(var o=this.bufferLength;o<64;o++)r.setUint8(o,0)
this.hashBuffer(),this.bufferLength=0}for(o=this.bufferLength;o<56;o++)r.setUint8(o,0)
r.setUint32(56,Math.floor(t/4294967296),!0),r.setUint32(60,t),this.hashBuffer(),this.finished=!0}
var s=new n(32)
for(o=0;o<8;o++)s[4*o]=this.state[o]>>>24&255,s[4*o+1]=this.state[o]>>>16&255,s[4*o+2]=this.state[o]>>>8&255,
s[4*o+3]=this.state[o]>>>0&255
return e?s.toString(e):s},a.prototype.hashBuffer=function(){
for(var e=this.buffer,t=this.state,r=t[0],n=t[1],i=t[2],s=t[3],a=t[4],u=t[5],c=t[6],p=t[7],l=0;l<64;l++){
if(l<16)this.temp[l]=(255&e[4*l])<<24|(255&e[4*l+1])<<16|(255&e[4*l+2])<<8|255&e[4*l+3]
else{
var h=this.temp[l-2],f=(h>>>17|h<<15)^(h>>>19|h<<13)^h>>>10,d=((h=this.temp[l-15])>>>7|h<<25)^(h>>>18|h<<14)^h>>>3
this.temp[l]=(f+this.temp[l-7]|0)+(d+this.temp[l-16]|0)}
var m=(((a>>>6|a<<26)^(a>>>11|a<<21)^(a>>>25|a<<7))+(a&u^~a&c)|0)+(p+(o[l]+this.temp[l]|0)|0)|0,y=((r>>>2|r<<30)^(r>>>13|r<<19)^(r>>>22|r<<10))+(r&n^r&i^n&i)|0
p=c,c=u,u=a,a=s+m|0,s=i,i=n,n=r,r=m+y|0}t[0]+=r,t[1]+=n,t[2]+=i,t[3]+=s,t[4]+=a,t[5]+=u,t[6]+=c,
t[7]+=p}},7321:(e,t,r)=>{var n=r(2662)
n.crypto.lib=r(7821),n.Buffer=r(8764).lW,n.url=r(8575),n.querystring=r(7673),n.realClock=r(1414),
n.environment="js",n.createEventStream=r(2403).createEventStream,n.isBrowser=function(){return!0},
n.isNode=function(){return!1}
var i=r(9614)
if(e.exports=i,r(4465),r(3227),r(6662),r(91),r(7719),r(7372),r(6986),i.XML.Parser=r(5106),r(2631),
void 0===o)var o={browser:!0}},2709:(e,t,r)=>{var n,i=r(9614)
r(4465),r(3227),i.Config=i.util.inherit({constructor:function(e){void 0===e&&(e={}),
e=this.extractCredentials(e),i.util.each.call(this,this.keys,(function(t,r){this.set(t,e[t],r)}))},
getCredentials:function(e){var t,r=this
function n(t){e(t,t?null:r.credentials)}function o(e,t){return new i.util.error(t||new Error,{
code:"CredentialsError",message:e,name:"CredentialsError"})}
r.credentials?"function"==typeof r.credentials.get?r.credentials.get((function(e){
e&&(e=o("Could not load credentials from "+r.credentials.constructor.name,e)),n(e)})):(t=null,
r.credentials.accessKeyId&&r.credentials.secretAccessKey||(t=o("Missing credentials")),
n(t)):r.credentialProvider?r.credentialProvider.resolve((function(e,t){
e&&(e=o("Could not load credentials from any providers",e)),r.credentials=t,n(e)
})):n(o("No credentials to load"))},update:function(e,t){t=t||!1,e=this.extractCredentials(e),
i.util.each.call(this,e,(function(e,r){
(t||Object.prototype.hasOwnProperty.call(this.keys,e)||i.Service.hasService(e))&&this.set(e,r)}))},
loadFromPath:function(e){this.clear()
var t=JSON.parse(i.util.readFileSync(e)),r=new i.FileSystemCredentials(e),n=new i.CredentialProviderChain
return n.providers.unshift(r),n.resolve((function(e,r){if(e)throw e
t.credentials=r})),this.constructor(t),this},clear:function(){
i.util.each.call(this,this.keys,(function(e){delete this[e]})),this.set("credentials",void 0),
this.set("credentialProvider",void 0)},set:function(e,t,r){void 0===t?(void 0===r&&(r=this.keys[e]),
this[e]="function"==typeof r?r.call(this):r):"httpOptions"===e&&this[e]?this[e]=i.util.merge(this[e],t):this[e]=t
},keys:{credentials:null,credentialProvider:null,region:null,logger:null,apiVersions:{},
apiVersion:null,endpoint:void 0,httpOptions:{timeout:12e4},maxRetries:void 0,maxRedirects:10,
paramValidation:!0,sslEnabled:!0,s3ForcePathStyle:!1,s3BucketEndpoint:!1,s3DisableBodySigning:!0,
s3UsEast1RegionalEndpoint:"legacy",s3UseArnRegion:void 0,computeChecksums:!0,
convertResponseTypes:!0,correctClockSkew:!1,customUserAgent:null,dynamoDbCrc32:!0,
systemClockOffset:0,signatureVersion:null,signatureCache:!0,retryDelayOptions:{},
useAccelerateEndpoint:!1,clientSideMonitoring:!1,endpointDiscoveryEnabled:void 0,
endpointCacheSize:1e3,hostPrefixEnabled:!0,stsRegionalEndpoints:"legacy",useFipsEndpoint:!1,
useDualstackEndpoint:!1},extractCredentials:function(e){
return e.accessKeyId&&e.secretAccessKey&&((e=i.util.copy(e)).credentials=new i.Credentials(e)),e},
setPromisesDependency:function(e){n=e,null===e&&"function"==typeof Promise&&(n=Promise)
var t=[i.Request,i.Credentials,i.CredentialProviderChain]
i.S3&&(t.push(i.S3),i.S3.ManagedUpload&&t.push(i.S3.ManagedUpload)),i.util.addPromises(t,n)},
getPromisesDependency:function(){return n}}),i.config=new i.Config},5456:(e,t,r)=>{var n=r(9614)
function i(e,t){if("string"==typeof e){
if(["legacy","regional"].indexOf(e.toLowerCase())>=0)return e.toLowerCase()
throw n.util.error(new Error,t)}}e.exports=function(e,t){var r
if((e=e||{})[t.clientConfig]&&(r=i(e[t.clientConfig],{code:"InvalidConfiguration",
message:'invalid "'+t.clientConfig+'" configuration. Expect "legacy"  or "regional". Got "'+e[t.clientConfig]+'".'
})))return r
if(!n.util.isNode())return r
if(Object.prototype.hasOwnProperty.call(process.env,t.env)&&(r=i(process.env[t.env],{
code:"InvalidEnvironmentalVariable",
message:"invalid "+t.env+' environmental variable. Expect "legacy"  or "regional". Got "'+process.env[t.env]+'".'
})))return r
var o={}
try{
o=n.util.getProfilesFromSharedConfig(n.util.iniLoader)[process.env.AWS_PROFILE||n.util.defaultProfile]
}catch(e){}
return o&&Object.prototype.hasOwnProperty.call(o,t.sharedConfig)&&(r=i(o[t.sharedConfig],{
code:"InvalidConfiguration",
message:"invalid "+t.sharedConfig+' profile config. Expect "legacy"  or "regional". Got "'+o[t.sharedConfig]+'".'
})),r}},9614:(e,t,r)=>{var n={util:r(2662)};({}).toString(),e.exports=n,n.util.update(n,{
VERSION:"2.1107.0",Signers:{},Protocol:{Json:r(6933),Query:r(293),Rest:r(6225),RestJson:r(3699),
RestXml:r(1674)},XML:{Builder:r(2369),Parser:null},JSON:{Builder:r(3658),Parser:r(2622)},Model:{
Api:r(5863),Operation:r(6797),Shape:r(8136),Paginator:r(7937),ResourceWaiter:r(306)},
apiLoader:r(6862),EndpointCache:r(5101).$}),r(6380),r(173),r(2709),r(6344),r(2274),r(3682),r(3975),
r(2413),
r(2604),r(5479),n.events=new n.SequentialExecutor,n.util.memoizedProperty(n,"endpointCache",(function(){
return new n.EndpointCache(n.config.endpointCacheSize)}),!0)},4465:(e,t,r)=>{var n=r(9614)
n.Credentials=n.util.inherit({constructor:function(){
if(n.util.hideProperties(this,["secretAccessKey"]),this.expired=!1,this.expireTime=null,
this.refreshCallbacks=[],1===arguments.length&&"object"==typeof arguments[0]){
var e=arguments[0].credentials||arguments[0]
this.accessKeyId=e.accessKeyId,this.secretAccessKey=e.secretAccessKey,this.sessionToken=e.sessionToken
}else this.accessKeyId=arguments[0],this.secretAccessKey=arguments[1],this.sessionToken=arguments[2]
},expiryWindow:15,needsRefresh:function(){
var e=n.util.date.getDate().getTime(),t=new Date(e+1e3*this.expiryWindow)
return!!(this.expireTime&&t>this.expireTime)||this.expired||!this.accessKeyId||!this.secretAccessKey
},get:function(e){var t=this
this.needsRefresh()?this.refresh((function(r){r||(t.expired=!1),e&&e(r)})):e&&e()},
refresh:function(e){this.expired=!1,e()},coalesceRefresh:function(e,t){var r=this
1===r.refreshCallbacks.push(e)&&r.load((function(e){
n.util.arrayEach(r.refreshCallbacks,(function(r){t?r(e):n.util.defer((function(){r(e)}))})),
r.refreshCallbacks.length=0}))},load:function(e){e()}
}),n.Credentials.addPromisesToClass=function(e){
this.prototype.getPromise=n.util.promisifyMethod("get",e),
this.prototype.refreshPromise=n.util.promisifyMethod("refresh",e)
},n.Credentials.deletePromisesFromClass=function(){delete this.prototype.getPromise,
delete this.prototype.refreshPromise},n.util.addPromises(n.Credentials)},91:(e,t,r)=>{
var n=r(9614),i=r(3568)
n.ChainableTemporaryCredentials=n.util.inherit(n.Credentials,{constructor:function(e){
n.Credentials.call(this),e=e||{},this.errorCode="ChainableTemporaryCredentialsProviderFailure",
this.expired=!0,this.tokenCodeFn=null
var t=n.util.copy(e.params)||{}
if(t.RoleArn&&(t.RoleSessionName=t.RoleSessionName||"temporary-credentials"),t.SerialNumber){
if(!e.tokenCodeFn||"function"!=typeof e.tokenCodeFn)throw new n.util.error(new Error("tokenCodeFn must be a function when params.SerialNumber is given"),{
code:this.errorCode})
this.tokenCodeFn=e.tokenCodeFn}var r=n.util.merge({params:t,
credentials:e.masterCredentials||n.config.credentials},e.stsConfig||{})
this.service=new i(r)},refresh:function(e){this.coalesceRefresh(e||n.util.fn.callback)},
load:function(e){var t=this,r=t.service.config.params.RoleArn?"assumeRole":"getSessionToken"
this.getTokenCode((function(n,i){var o={}
n?e(n):(i&&(o.TokenCode=i),t.service[r](o,(function(r,n){r||t.service.credentialsFrom(n,t),e(r)})))
}))},getTokenCode:function(e){var t=this
this.tokenCodeFn?this.tokenCodeFn(this.service.config.params.SerialNumber,(function(r,i){if(r){
var o=r
return r instanceof Error&&(o=r.message),void e(n.util.error(new Error("Error fetching MFA token: "+o),{
code:t.errorCode}))}e(null,i)})):e(null)}})},7372:(e,t,r)=>{var n=r(9614),i=r(6105),o=r(3568)
n.CognitoIdentityCredentials=n.util.inherit(n.Credentials,{localStorageKey:{
id:"aws.cognito.identity-id.",providers:"aws.cognito.identity-providers."},
constructor:function(e,t){n.Credentials.call(this),this.expired=!0,this.params=e,this.data=null,
this._identityId=null,this._clientConfig=n.util.copy(t||{}),this.loadCachedId()
var r=this
Object.defineProperty(this,"identityId",{get:function(){return r.loadCachedId(),
r._identityId||r.params.IdentityId},set:function(e){r._identityId=e}})},refresh:function(e){
this.coalesceRefresh(e||n.util.fn.callback)},load:function(e){var t=this
t.createClients(),t.data=null,t._identityId=null,t.getId((function(r){
r?(t.clearIdOnNotAuthorized(r),
e(r)):t.params.RoleArn?t.getCredentialsFromSTS(e):t.getCredentialsForIdentity(e)}))},
clearCachedId:function(){this._identityId=null,delete this.params.IdentityId
var e=this.params.IdentityPoolId,t=this.params.LoginId||""
delete this.storage[this.localStorageKey.id+e+t],delete this.storage[this.localStorageKey.providers+e+t]
},clearIdOnNotAuthorized:function(e){"NotAuthorizedException"==e.code&&this.clearCachedId()},
getId:function(e){var t=this
if("string"==typeof t.params.IdentityId)return e(null,t.params.IdentityId)
t.cognito.getId((function(r,n){!r&&n.IdentityId?(t.params.IdentityId=n.IdentityId,
e(null,n.IdentityId)):e(r)}))},loadCredentials:function(e,t){e&&t&&(t.expired=!1,
t.accessKeyId=e.Credentials.AccessKeyId,t.secretAccessKey=e.Credentials.SecretKey,
t.sessionToken=e.Credentials.SessionToken,t.expireTime=e.Credentials.Expiration)},
getCredentialsForIdentity:function(e){var t=this
t.cognito.getCredentialsForIdentity((function(r,n){r?t.clearIdOnNotAuthorized(r):(t.cacheId(n),
t.data=n,t.loadCredentials(t.data,t)),e(r)}))},getCredentialsFromSTS:function(e){var t=this
t.cognito.getOpenIdToken((function(r,n){r?(t.clearIdOnNotAuthorized(r),e(r)):(t.cacheId(n),
t.params.WebIdentityToken=n.Token,t.webIdentityCredentials.refresh((function(r){
r||(t.data=t.webIdentityCredentials.data,t.sts.credentialsFrom(t.data,t)),e(r)})))}))},
loadCachedId:function(){var e=this
if(n.util.isBrowser()&&!e.params.IdentityId){var t=e.getStorage("id")
if(t&&e.params.Logins){var r=Object.keys(e.params.Logins)
0!==(e.getStorage("providers")||"").split(",").filter((function(e){return-1!==r.indexOf(e)
})).length&&(e.params.IdentityId=t)}else t&&(e.params.IdentityId=t)}},createClients:function(){
var e=this._clientConfig
if(this.webIdentityCredentials=this.webIdentityCredentials||new n.WebIdentityCredentials(this.params,e),
!this.cognito){var t=n.util.merge({},e)
t.params=this.params,this.cognito=new i(t)}this.sts=this.sts||new o(e)},cacheId:function(e){
this._identityId=e.IdentityId,
this.params.IdentityId=this._identityId,n.util.isBrowser()&&(this.setStorage("id",e.IdentityId),
this.params.Logins&&this.setStorage("providers",Object.keys(this.params.Logins).join(",")))},
getStorage:function(e){
return this.storage[this.localStorageKey[e]+this.params.IdentityPoolId+(this.params.LoginId||"")]},
setStorage:function(e,t){try{
this.storage[this.localStorageKey[e]+this.params.IdentityPoolId+(this.params.LoginId||"")]=t
}catch(e){}},storage:function(){try{
var e=n.util.isBrowser()&&null!==window.localStorage&&"object"==typeof window.localStorage?window.localStorage:{}
return e["aws.test-storage"]="foobar",delete e["aws.test-storage"],e}catch(e){return{}}}()})},
3227:(e,t,r)=>{var n=r(9614)
n.CredentialProviderChain=n.util.inherit(n.Credentials,{constructor:function(e){
this.providers=e||n.CredentialProviderChain.defaultProviders.slice(0),this.resolveCallbacks=[]},
resolve:function(e){var t=this
if(0===t.providers.length)return e(new Error("No providers")),t
if(1===t.resolveCallbacks.push(e)){var r=0,i=t.providers.slice(0)
!function e(o,s){if(!o&&s||r===i.length)return n.util.arrayEach(t.resolveCallbacks,(function(e){
e(o,s)})),void(t.resolveCallbacks.length=0)
var a=i[r++];(s="function"==typeof a?a.call():a).get?s.get((function(t){e(t,t?null:s)})):e(null,s)
}()}return t}
}),n.CredentialProviderChain.defaultProviders=[],n.CredentialProviderChain.addPromisesToClass=function(e){
this.prototype.resolvePromise=n.util.promisifyMethod("resolve",e)
},n.CredentialProviderChain.deletePromisesFromClass=function(){delete this.prototype.resolvePromise
},n.util.addPromises(n.CredentialProviderChain)},6986:(e,t,r)=>{var n=r(9614),i=r(3568)
n.SAMLCredentials=n.util.inherit(n.Credentials,{constructor:function(e){n.Credentials.call(this),
this.expired=!0,this.params=e},refresh:function(e){this.coalesceRefresh(e||n.util.fn.callback)},
load:function(e){var t=this
t.createClients(),t.service.assumeRoleWithSAML((function(r,n){r||t.service.credentialsFrom(n,t),e(r)
}))},createClients:function(){this.service=this.service||new i({params:this.params})}})},
6662:(e,t,r)=>{var n=r(9614),i=r(3568)
n.TemporaryCredentials=n.util.inherit(n.Credentials,{constructor:function(e,t){
n.Credentials.call(this),this.loadMasterCredentials(t),this.expired=!0,this.params=e||{},
this.params.RoleArn&&(this.params.RoleSessionName=this.params.RoleSessionName||"temporary-credentials")
},refresh:function(e){this.coalesceRefresh(e||n.util.fn.callback)},load:function(e){var t=this
t.createClients(),t.masterCredentials.get((function(){
t.service.config.credentials=t.masterCredentials,
(t.params.RoleArn?t.service.assumeRole:t.service.getSessionToken).call(t.service,(function(r,n){
r||t.service.credentialsFrom(n,t),e(r)}))}))},loadMasterCredentials:function(e){
for(this.masterCredentials=e||n.config.credentials;this.masterCredentials.masterCredentials;)this.masterCredentials=this.masterCredentials.masterCredentials
"function"!=typeof this.masterCredentials.get&&(this.masterCredentials=new n.Credentials(this.masterCredentials))
},createClients:function(){this.service=this.service||new i({params:this.params})}})},
7719:(e,t,r)=>{var n=r(9614),i=r(3568)
n.WebIdentityCredentials=n.util.inherit(n.Credentials,{constructor:function(e,t){
n.Credentials.call(this),
this.expired=!0,this.params=e,this.params.RoleSessionName=this.params.RoleSessionName||"web-identity",
this.data=null,this._clientConfig=n.util.copy(t||{})},refresh:function(e){
this.coalesceRefresh(e||n.util.fn.callback)},load:function(e){var t=this
t.createClients(),t.service.assumeRoleWithWebIdentity((function(r,n){t.data=null,r||(t.data=n,
t.service.credentialsFrom(n,t)),e(r)}))},createClients:function(){if(!this.service){
var e=n.util.merge({},this._clientConfig)
e.params=this.params,this.service=new i(e)}}})},3320:(e,t,r)=>{
var n=r(9614),i=r(2662),o=["AWS_ENABLE_ENDPOINT_DISCOVERY","AWS_ENDPOINT_DISCOVERY_ENABLED"]
function s(e){var t=e.service,r=t.api||{},n=(r.operations,{})
return t.config.region&&(n.region=t.config.region),r.serviceId&&(n.serviceId=r.serviceId),
t.config.credentials.accessKeyId&&(n.accessKeyId=t.config.credentials.accessKeyId),n}
function a(e,t,r){
r&&null!=t&&"structure"===r.type&&r.required&&r.required.length>0&&i.arrayEach(r.required,(function(n){
var i=r.members[n]
if(!0===i.endpointDiscoveryId){var o=i.isLocationName?i.name:n
e[o]=String(t[n])}else a(e,t[n],i)}))}function u(e,t){var r={}
return a(r,e.params,t),r}function c(e){
var t=e.service,r=t.api,o=r.operations?r.operations[e.operation]:void 0,a=u(e,o?o.input:void 0),c=s(e)
Object.keys(a).length>0&&(c=i.update(c,a),o&&(c.operation=o.name))
var p=n.endpointCache.get(c)
if(!p||1!==p.length||""!==p[0].Address)if(p&&p.length>0)e.httpRequest.updateEndpoint(p[0].Address)
else{var l=t.makeRequest(r.endpointOperation,{Operation:o.name,Identifiers:a})
h(l),l.removeListener("validate",n.EventListeners.Core.VALIDATE_PARAMETERS),l.removeListener("retry",n.EventListeners.Core.RETRY_CHECK),
n.endpointCache.put(c,[{Address:"",CachePeriodInMinutes:1}]),l.send((function(e,t){
t&&t.Endpoints?n.endpointCache.put(c,t.Endpoints):e&&n.endpointCache.put(c,[{Address:"",
CachePeriodInMinutes:1}])}))}}var p={}
function l(e,t){
var r=e.service,o=r.api,a=o.operations?o.operations[e.operation]:void 0,c=a?a.input:void 0,l=u(e,c),f=s(e)
Object.keys(l).length>0&&(f=i.update(f,l),a&&(f.operation=a.name))
var d=n.EndpointCache.getKeyString(f),m=n.endpointCache.get(d)
if(m&&1===m.length&&""===m[0].Address)return p[d]||(p[d]=[]),void p[d].push({request:e,callback:t})
if(m&&m.length>0)e.httpRequest.updateEndpoint(m[0].Address),t()
else{var y=r.makeRequest(o.endpointOperation,{Operation:a.name,Identifiers:l})
y.removeListener("validate",n.EventListeners.Core.VALIDATE_PARAMETERS),h(y),n.endpointCache.put(d,[{
Address:"",CachePeriodInMinutes:60}]),y.send((function(r,o){if(r){if(e.response.error=i.error(r,{
retryable:!1}),n.endpointCache.remove(f),p[d]){var s=p[d]
i.arrayEach(s,(function(e){e.request.response.error=i.error(r,{retryable:!1}),e.callback()})),
delete p[d]}
}else o&&(n.endpointCache.put(d,o.Endpoints),e.httpRequest.updateEndpoint(o.Endpoints[0].Address),
p[d])&&(s=p[d],i.arrayEach(s,(function(e){
e.request.httpRequest.updateEndpoint(o.Endpoints[0].Address),e.callback()})),delete p[d])
t()}))}}function h(e){var t=e.service.api.apiVersion
t&&!e.httpRequest.headers["x-amz-api-version"]&&(e.httpRequest.headers["x-amz-api-version"]=t)}
function f(e){var t=e.error,r=e.httpResponse
if(t&&("InvalidEndpointException"===t.code||421===r.statusCode)){
var o=e.request,a=o.service.api.operations||{},c=u(o,a[o.operation]?a[o.operation].input:void 0),p=s(o)
Object.keys(c).length>0&&(p=i.update(p,c),a[o.operation]&&(p.operation=a[o.operation].name)),
n.endpointCache.remove(p)}}function d(e){return["false","0"].indexOf(e)>=0}e.exports={
discoverEndpoint:function(e,t){var r=e.service||{}
if(function(e){
if(e._originalConfig&&e._originalConfig.endpoint&&!0===e._originalConfig.endpointDiscoveryEnabled)throw i.error(new Error,{
code:"ConfigurationException",
message:"Custom endpoint is supplied; endpointDiscoveryEnabled must not be true."})
var t=n.config[e.serviceIdentifier]||{}
return Boolean(n.config.endpoint||t.endpoint||e._originalConfig&&e._originalConfig.endpoint)
}(r)||e.isPresigned())return t()
var s=(r.api.operations||{})[e.operation],a=s?s.endpointDiscoveryRequired:"NULL",u=function(e){
var t=e.service||{}
if(void 0!==t.config.endpointDiscoveryEnabled)return t.config.endpointDiscoveryEnabled
if(!i.isBrowser()){for(var r=0;r<o.length;r++){var s=o[r]
if(Object.prototype.hasOwnProperty.call(process.env,s)){
if(""===process.env[s]||void 0===process.env[s])throw i.error(new Error,{
code:"ConfigurationException",message:"environmental variable "+s+" cannot be set to nothing"})
return!d(process.env[s])}}var a={}
try{a=n.util.iniLoader?n.util.iniLoader.loadFrom({isConfig:!0,
filename:process.env[n.util.sharedConfigFileEnv]}):{}}catch(e){}
var u=a[process.env.AWS_PROFILE||n.util.defaultProfile]||{}
if(Object.prototype.hasOwnProperty.call(u,"endpoint_discovery_enabled")){
if(void 0===u.endpoint_discovery_enabled)throw i.error(new Error,{code:"ConfigurationException",
message:"config file entry 'endpoint_discovery_enabled' cannot be set to nothing"})
return!d(u.endpoint_discovery_enabled)}}}(e),p=r.api.hasRequiredEndpointDiscovery
switch((u||p)&&e.httpRequest.appendToUserAgent("endpoint-discovery"),a){case"OPTIONAL":
(u||p)&&(c(e),e.addNamedListener("INVALIDATE_CACHED_ENDPOINTS","extractError",f)),t()
break
case"REQUIRED":if(!1===u){e.response.error=i.error(new Error,{code:"ConfigurationException",
message:"Endpoint Discovery is disabled but "+r.api.className+"."+e.operation+"() requires it. Please check your configurations."
}),t()
break}e.addNamedListener("INVALIDATE_CACHED_ENDPOINTS","extractError",f),l(e,t)
break
default:t()}},requiredDiscoverEndpoint:l,optionalDiscoverEndpoint:c,marshallCustomIdentifiers:u,
getCacheKey:s,invalidateCachedEndpoint:f}},2403:(e,t,r)=>{
var n=r(7550).eventMessageChunker,i=r(3851).parseEvent
e.exports={createEventStream:function(e,t,r){
for(var o=n(e),s=[],a=0;a<o.length;a++)s.push(i(t,o[a],r))
return s}}},7550:e=>{e.exports={eventMessageChunker:function(e){for(var t=[],r=0;r<e.length;){
var n=e.readInt32BE(r),i=e.slice(r,n+r)
r+=n,t.push(i)}return t}}},1231:(e,t,r)=>{var n=r(9614).util,i=n.buffer.toBuffer
function o(e){if(8!==e.length)throw new Error("Int64 buffers must be exactly 8 bytes")
n.Buffer.isBuffer(e)||(e=i(e)),this.bytes=e}function s(e){for(var t=0;t<8;t++)e[t]^=255
for(t=7;t>-1&&(e[t]++,0===e[t]);t--);}o.fromNumber=function(e){
if(e>0x8000000000000000||e<-0x8000000000000000)throw new Error(e+" is too large (or, if negative, too small) to represent as an Int64")
for(var t=new Uint8Array(8),r=7,n=Math.abs(Math.round(e));r>-1&&n>0;r--,n/=256)t[r]=n
return e<0&&s(t),new o(t)},o.prototype.valueOf=function(){var e=this.bytes.slice(0),t=128&e[0]
return t&&s(e),parseInt(e.toString("hex"),16)*(t?-1:1)},o.prototype.toString=function(){
return String(this.valueOf())},e.exports={Int64:o}},3851:(e,t,r)=>{var n=r(9524).parseMessage
e.exports={parseEvent:function(e,t,r){var i=n(t),o=i.headers[":message-type"]
if(o){if("error"===o.value)throw function(e){
var t=e.headers[":error-code"],r=e.headers[":error-message"],n=new Error(r.value||r)
return n.code=n.name=t.value||t,n}(i)
if("event"!==o.value)return}var s=i.headers[":event-type"],a=r.members[s.value]
if(a){var u={},c=a.eventPayloadMemberName
if(c){var p=a.members[c]
"binary"===p.type?u[c]=i.body:u[c]=e.parse(i.body.toString(),p)}
for(var l=a.eventHeaderMemberNames,h=0;h<l.length;h++){var f=l[h]
i.headers[f]&&(u[f]=a.members[f].toType(i.headers[f].value))}var d={}
return d[s.value]=u,d}}}},9524:(e,t,r)=>{var n=r(1231).Int64,i=r(4441).splitMessage,o="boolean"
function s(e){for(var t={},r=0;r<e.length;){var i=e.readUInt8(r++),s=e.slice(r,r+i).toString()
switch(r+=i,e.readUInt8(r++)){case 0:t[s]={type:o,value:!0}
break
case 1:t[s]={type:o,value:!1}
break
case 2:t[s]={type:"byte",value:e.readInt8(r++)}
break
case 3:t[s]={type:"short",value:e.readInt16BE(r)},r+=2
break
case 4:t[s]={type:"integer",value:e.readInt32BE(r)},r+=4
break
case 5:t[s]={type:"long",value:new n(e.slice(r,r+8))},r+=8
break
case 6:var a=e.readUInt16BE(r)
r+=2,t[s]={type:"binary",value:e.slice(r,r+a)},r+=a
break
case 7:var u=e.readUInt16BE(r)
r+=2,t[s]={type:"string",value:e.slice(r,r+u).toString()},r+=u
break
case 8:t[s]={type:"timestamp",value:new Date(new n(e.slice(r,r+8)).valueOf())},r+=8
break
case 9:var c=e.slice(r,r+16).toString("hex")
r+=16,t[s]={type:"uuid",
value:c.substr(0,8)+"-"+c.substr(8,4)+"-"+c.substr(12,4)+"-"+c.substr(16,4)+"-"+c.substr(20)}
break
default:throw new Error("Unrecognized header type tag")}}return t}e.exports={
parseMessage:function(e){var t=i(e)
return{headers:s(t.headers),body:t.body}}}},4441:(e,t,r)=>{var n=r(9614).util,i=n.buffer.toBuffer
e.exports={splitMessage:function(e){
if(n.Buffer.isBuffer(e)||(e=i(e)),e.length<16)throw new Error("Provided message too short to accommodate event stream message overhead")
if(e.length!==e.readUInt32BE(0))throw new Error("Reported message length does not match received message length")
var t=e.readUInt32BE(8)
if(t!==n.crypto.crc32(e.slice(0,8)))throw new Error("The prelude checksum specified in the message ("+t+") does not match the calculated CRC32 checksum.")
var r=e.readUInt32BE(e.length-4)
if(r!==n.crypto.crc32(e.slice(0,e.length-4)))throw new Error("The message checksum did not match the expected value of "+r)
var o=12+e.readUInt32BE(4)
return{headers:e.slice(12,o),body:e.slice(o,e.length-4)}}}},2274:(e,t,r)=>{
var n=r(9614),i=r(6380),o=r(3320).discoverEndpoint
n.EventListeners={Core:{}},n.EventListeners={Core:(new i).addNamedListeners((function(e,t){
t("VALIDATE_CREDENTIALS","validate",(function(e,t){
if(!e.service.api.signatureVersion&&!e.service.config.signatureVersion)return t()
e.service.config.getCredentials((function(r){r&&(e.response.error=n.util.error(r,{
code:"CredentialsError",
message:"Missing credentials in config, if using AWS_CONFIG_FILE, set AWS_SDK_LOAD_CONFIG=1"})),t()
}))})),e("VALIDATE_REGION","validate",(function(e){if(!e.service.isGlobalEndpoint){
var t=new RegExp(/^([a-zA-Z0-9]|[a-zA-Z0-9][a-zA-Z0-9-]{0,61}[a-zA-Z0-9])$/)
e.service.config.region?t.test(e.service.config.region)||(e.response.error=n.util.error(new Error,{
code:"ConfigError",message:"Invalid region in config"})):e.response.error=n.util.error(new Error,{
code:"ConfigError",message:"Missing region in config"})}
})),e("BUILD_IDEMPOTENCY_TOKENS","validate",(function(e){if(e.service.api.operations){
var t=e.service.api.operations[e.operation]
if(t){var r=t.idempotentMembers
if(r.length){
for(var i=n.util.copy(e.params),o=0,s=r.length;o<s;o++)i[r[o]]||(i[r[o]]=n.util.uuid.v4())
e.params=i}}}})),e("VALIDATE_PARAMETERS","validate",(function(e){if(e.service.api.operations){
var t=e.service.api.operations[e.operation].input,r=e.service.config.paramValidation
new n.ParamValidator(r).validate(t,e.params)}})),e("COMPUTE_CHECKSUM","afterBuild",(function(e){
if(e.service.api.operations){var t=e.service.api.operations[e.operation]
if(t){
var r=e.httpRequest.body,i=r&&(n.util.Buffer.isBuffer(r)||"string"==typeof r),o=e.httpRequest.headers
if(t.httpChecksumRequired&&e.service.config.computeChecksums&&i&&!o["Content-MD5"]){
var s=n.util.crypto.md5(r,"base64")
o["Content-MD5"]=s}}}})),t("COMPUTE_SHA256","afterBuild",(function(e,t){if(e.haltHandlersOnError(),
e.service.api.operations){var r=e.service.api.operations[e.operation],i=r?r.authtype:""
if(!e.service.api.signatureVersion&&!i&&!e.service.config.signatureVersion)return t()
if(e.service.getSignerClass(e)===n.Signers.V4){var o=e.httpRequest.body||""
if(i.indexOf("unsigned-body")>=0)return e.httpRequest.headers["X-Amz-Content-Sha256"]="UNSIGNED-PAYLOAD",
t()
n.util.computeSha256(o,(function(r,n){r?t(r):(e.httpRequest.headers["X-Amz-Content-Sha256"]=n,t())
}))}else t()}})),e("SET_CONTENT_LENGTH","afterBuild",(function(e){var t=function(e){
if(!e.service.api.operations)return""
var t=e.service.api.operations[e.operation]
return t?t.authtype:""}(e),r=n.util.getRequestPayloadShape(e)
if(void 0===e.httpRequest.headers["Content-Length"])try{
var i=n.util.string.byteLength(e.httpRequest.body)
e.httpRequest.headers["Content-Length"]=i}catch(n){if(r&&r.isStreaming){if(r.requiresLength)throw n
if(t.indexOf("unsigned-body")>=0)return void(e.httpRequest.headers["Transfer-Encoding"]="chunked")
throw n}throw n}})),e("SET_HTTP_HOST","afterBuild",(function(e){
e.httpRequest.headers.Host=e.httpRequest.endpoint.host})),e("RESTART","restart",(function(){
var e=this.response.error
e&&e.retryable&&(this.httpRequest=new n.HttpRequest(this.service.endpoint,this.service.region),
this.response.retryCount<this.service.config.maxRetries?this.response.retryCount++:this.response.error=null)
})),t("DISCOVER_ENDPOINT","sign",o,!0),t("SIGN","sign",(function(e,t){
var r=e.service,n=(e.service.api.operations||{})[e.operation],i=n?n.authtype:""
if(!r.api.signatureVersion&&!i&&!r.config.signatureVersion)return t()
r.config.getCredentials((function(i,o){if(i)return e.response.error=i,t()
try{var s=r.getSkewCorrectedDate(),a=new(r.getSignerClass(e))(e.httpRequest,r.getSigningName(e),{
signatureCache:r.config.signatureCache,operation:n,signatureVersion:r.api.signatureVersion})
a.setServiceClientId(r._clientId),delete e.httpRequest.headers.Authorization,delete e.httpRequest.headers.Date,
delete e.httpRequest.headers["X-Amz-Date"],a.addAuthorization(o,s),e.signedAt=s}catch(t){
e.response.error=t}t()}))})),e("VALIDATE_RESPONSE","validateResponse",(function(e){
this.service.successfulResponse(e,this)?(e.data={},
e.error=null):(e.data=null,e.error=n.util.error(new Error,{code:"UnknownError",
message:"An unknown error occurred."}))})),t("SEND","send",(function(e,t){function r(r){
e.httpResponse.stream=r
var i=e.request.httpRequest.stream,o=e.request.service,s=o.api,a=e.request.operation,u=s.operations[a]||{}
r.on("headers",(function(i,s,a){
if(e.request.emit("httpHeaders",[i,s,e,a]),!e.httpResponse.streaming)if(2===n.HttpClient.streamsApiVersion){
if(u.hasEventOutput&&o.successfulResponse(e))return e.request.emit("httpDone"),void t()
r.on("readable",(function(){var t=r.read()
null!==t&&e.request.emit("httpData",[t,e])}))}else r.on("data",(function(t){
e.request.emit("httpData",[t,e])}))})),r.on("end",(function(){if(!i||!i.didCallback){
if(2===n.HttpClient.streamsApiVersion&&u.hasEventOutput&&o.successfulResponse(e))return
e.request.emit("httpDone"),t()}}))}function i(r){if("RequestAbortedError"!==r.code){
var i="TimeoutError"===r.code?r.code:"NetworkingError"
r=n.util.error(r,{code:i,region:e.request.httpRequest.region,
hostname:e.request.httpRequest.endpoint.hostname,retryable:!0})}
e.error=r,e.request.emit("httpError",[e.error,e],(function(){t()}))}function o(){
var t,o=n.HttpClient.getInstance(),s=e.request.service.config.httpOptions||{}
try{(t=o.handleRequest(e.request.httpRequest,s,r,i)).on("sendProgress",(function(t){
e.request.emit("httpUploadProgress",[t,e])})),t.on("receiveProgress",(function(t){
e.request.emit("httpDownloadProgress",[t,e])}))}catch(e){i(e)}}e.httpResponse._abortCallback=t,
e.error=null,
e.data=null,(e.request.service.getSkewCorrectedDate()-this.signedAt)/1e3>=600?this.emit("sign",[this],(function(e){
e?t(e):o()})):o()})),e("HTTP_HEADERS","httpHeaders",(function(e,t,r,i){r.httpResponse.statusCode=e,
r.httpResponse.statusMessage=i,
r.httpResponse.headers=t,r.httpResponse.body=n.util.buffer.toBuffer(""),r.httpResponse.buffers=[],
r.httpResponse.numBytes=0
var o=t.date||t.Date,s=r.request.service
if(o){var a=Date.parse(o)
s.config.correctClockSkew&&s.isClockSkewed(a)&&s.applyClockOffset(a)}
})),e("HTTP_DATA","httpData",(function(e,t){if(e){if(n.util.isNode()){
t.httpResponse.numBytes+=e.length
var r=t.httpResponse.headers["content-length"],i={loaded:t.httpResponse.numBytes,total:r}
t.request.emit("httpDownloadProgress",[i,t])}t.httpResponse.buffers.push(n.util.buffer.toBuffer(e))}
})),e("HTTP_DONE","httpDone",(function(e){
if(e.httpResponse.buffers&&e.httpResponse.buffers.length>0){
var t=n.util.buffer.concat(e.httpResponse.buffers)
e.httpResponse.body=t}delete e.httpResponse.numBytes,delete e.httpResponse.buffers})),
e("FINALIZE_ERROR","retry",(function(e){
e.httpResponse.statusCode&&(e.error.statusCode=e.httpResponse.statusCode,
void 0===e.error.retryable&&(e.error.retryable=this.service.retryableError(e.error,this)))})),
e("INVALIDATE_CREDENTIALS","retry",(function(e){if(e.error)switch(e.error.code){
case"RequestExpired":case"ExpiredTokenException":case"ExpiredToken":e.error.retryable=!0,
e.request.service.config.credentials.expired=!0}})),e("EXPIRED_SIGNATURE","retry",(function(e){
var t=e.error
t&&"string"==typeof t.code&&"string"==typeof t.message&&t.code.match(/Signature/)&&t.message.match(/expired/)&&(e.error.retryable=!0)
})),e("CLOCK_SKEWED","retry",(function(e){
e.error&&this.service.clockSkewError(e.error)&&this.service.config.correctClockSkew&&(e.error.retryable=!0)
})),e("REDIRECT","retry",(function(e){
e.error&&e.error.statusCode>=300&&e.error.statusCode<400&&e.httpResponse.headers.location&&(this.httpRequest.endpoint=new n.Endpoint(e.httpResponse.headers.location),
this.httpRequest.headers.Host=this.httpRequest.endpoint.host,e.error.redirect=!0,
e.error.retryable=!0)})),e("RETRY_CHECK","retry",(function(e){
e.error&&(e.error.redirect&&e.redirectCount<e.maxRedirects?e.error.retryDelay=0:e.retryCount<e.maxRetries&&(e.error.retryDelay=this.service.retryDelays(e.retryCount,e.error)||0))
})),t("RESET_RETRY_STATE","afterRetry",(function(e,t){var r,n=!1
e.error&&(r=e.error.retryDelay||0,e.error.retryable&&e.retryCount<e.maxRetries?(e.retryCount++,
n=!0):e.error.redirect&&e.redirectCount<e.maxRedirects&&(e.redirectCount++,n=!0)),
n&&r>=0?(e.error=null,setTimeout(t,r)):t()}))})),CorePost:(new i).addNamedListeners((function(e){
e("EXTRACT_REQUEST_ID","extractData",n.util.extractRequestId),
e("EXTRACT_REQUEST_ID","extractError",n.util.extractRequestId),
e("ENOTFOUND_ERROR","httpError",(function(e){if("NetworkingError"===e.code&&function(e){
return"ENOTFOUND"===e.errno||"number"==typeof e.errno&&"function"==typeof n.util.getSystemErrorName&&["EAI_NONAME","EAI_NODATA"].indexOf(n.util.getSystemErrorName(e.errno)>=0)
}(e)){
var t="Inaccessible host: `"+e.hostname+"' at port `"+e.port+"'. This service may not be available in the `"+e.region+"' region."
this.response.error=n.util.error(new Error(t),{code:"UnknownEndpoint",region:e.region,
hostname:e.hostname,retryable:!0,originalError:e})}}))})),
Logger:(new i).addNamedListeners((function(e){e("LOG_REQUEST","complete",(function(e){
var t=e.request,i=t.service.config.logger
if(i){var o=function(){
var o=(e.request.service.getSkewCorrectedDate().getTime()-t.startTime.getTime())/1e3,a=!!i.isTTY,u=e.httpResponse.statusCode,c=t.params
t.service.api.operations&&t.service.api.operations[t.operation]&&t.service.api.operations[t.operation].input&&(c=s(t.service.api.operations[t.operation].input,t.params))
var p=r(9539).inspect(c,!0,null),l=""
return a&&(l+="[33m"),l+="[AWS "+t.service.serviceIdentifier+" "+u,l+=" "+o.toString()+"s "+e.retryCount+" retries]",
a&&(l+="[0;1m"),l+=" "+n.util.string.lowerFirst(t.operation),l+="("+p+")",a&&(l+="[0m"),l}()
"function"==typeof i.log?i.log(o):"function"==typeof i.write&&i.write(o+"\n")}function s(e,t){
if(!t)return t
if(e.isSensitive)return"***SensitiveInformation***"
switch(e.type){case"structure":var r={}
return n.util.each(t,(function(t,n){
Object.prototype.hasOwnProperty.call(e.members,t)?r[t]=s(e.members[t],n):r[t]=n})),r
case"list":var i=[]
return n.util.arrayEach(t,(function(t,r){i.push(s(e.member,t))})),i
case"map":var o={}
return n.util.each(t,(function(t,r){o[t]=s(e.value,r)})),o
default:return t}}}))})),Json:(new i).addNamedListeners((function(e){var t=r(6933)
e("BUILD","build",t.buildRequest),e("EXTRACT_DATA","extractData",t.extractData),
e("EXTRACT_ERROR","extractError",t.extractError)})),Rest:(new i).addNamedListeners((function(e){
var t=r(6225)
e("BUILD","build",t.buildRequest),e("EXTRACT_DATA","extractData",t.extractData),
e("EXTRACT_ERROR","extractError",t.extractError)})),RestJson:(new i).addNamedListeners((function(e){
var t=r(3699)
e("BUILD","build",t.buildRequest),e("EXTRACT_DATA","extractData",t.extractData),
e("EXTRACT_ERROR","extractError",t.extractError)})),RestXml:(new i).addNamedListeners((function(e){
var t=r(1674)
e("BUILD","build",t.buildRequest),e("EXTRACT_DATA","extractData",t.extractData),
e("EXTRACT_ERROR","extractError",t.extractError)})),Query:(new i).addNamedListeners((function(e){
var t=r(293)
e("BUILD","build",t.buildRequest),e("EXTRACT_DATA","extractData",t.extractData),
e("EXTRACT_ERROR","extractError",t.extractError)}))}},6344:(e,t,r)=>{var n=r(9614),i=n.util.inherit
n.Endpoint=i({constructor:function(e,t){
if(n.util.hideProperties(this,["slashes","auth","hash","search","query"]),
null==e)throw new Error("Invalid endpoint: "+e)
if("string"!=typeof e)return n.util.copy(e)
e.match(/^http/)||(e=((t&&void 0!==t.sslEnabled?t.sslEnabled:n.config.sslEnabled)?"https":"http")+"://"+e),
n.util.update(this,n.util.urlParse(e)),
this.port?this.port=parseInt(this.port,10):this.port="https:"===this.protocol?443:80}}),
n.HttpRequest=i({constructor:function(e,t){e=new n.Endpoint(e),this.method="POST",
this.path=e.path||"/",this.headers={},this.body="",this.endpoint=e,this.region=t,this._userAgent="",
this.setUserAgent()},setUserAgent:function(){
this._userAgent=this.headers[this.getUserAgentHeaderName()]=n.util.userAgent()},
getUserAgentHeaderName:function(){return(n.util.isBrowser()?"X-Amz-":"")+"User-Agent"},
appendToUserAgent:function(e){
"string"==typeof e&&e&&(this._userAgent+=" "+e),this.headers[this.getUserAgentHeaderName()]=this._userAgent
},getUserAgent:function(){return this._userAgent},pathname:function(){
return this.path.split("?",1)[0]},search:function(){var e=this.path.split("?",2)[1]
return e?(e=n.util.queryStringParse(e),n.util.queryParamsToString(e)):""},
updateEndpoint:function(e){var t=new n.Endpoint(e)
this.endpoint=t,this.path=t.path||"/",this.headers.Host&&(this.headers.Host=t.host)}}),
n.HttpResponse=i({constructor:function(){this.statusCode=void 0,this.headers={},this.body=void 0,
this.streaming=!1,this.stream=null},createUnbufferedStream:function(){return this.streaming=!0,
this.stream}}),n.HttpClient=i({}),n.HttpClient.getInstance=function(){
return void 0===this.singleton&&(this.singleton=new this),this.singleton}},2631:(e,t,r)=>{
var n=r(9614),i=r(7187).EventEmitter
r(6344),n.XHRClient=n.util.inherit({handleRequest:function(e,t,r,o){
var s=this,a=e.endpoint,u=new i,c=a.protocol+"//"+a.hostname
80!==a.port&&443!==a.port&&(c+=":"+a.port),c+=e.path
var p=new XMLHttpRequest,l=!1
e.stream=p,p.addEventListener("readystatechange",(function(){try{if(0===p.status)return}catch(e){
return}
this.readyState>=this.HEADERS_RECEIVED&&!l&&(u.statusCode=p.status,u.headers=s.parseHeaders(p.getAllResponseHeaders()),
u.emit("headers",u.statusCode,u.headers,p.statusText),
l=!0),this.readyState===this.DONE&&s.finishRequest(p,u)
}),!1),p.upload.addEventListener("progress",(function(e){u.emit("sendProgress",e)})),
p.addEventListener("progress",(function(e){u.emit("receiveProgress",e)
}),!1),p.addEventListener("timeout",(function(){o(n.util.error(new Error("Timeout"),{
code:"TimeoutError"}))}),!1),p.addEventListener("error",(function(){
o(n.util.error(new Error("Network Failure"),{code:"NetworkingError"}))
}),!1),p.addEventListener("abort",(function(){o(n.util.error(new Error("Request aborted"),{
code:"RequestAbortedError"}))
}),!1),r(u),p.open(e.method,c,!1!==t.xhrAsync),n.util.each(e.headers,(function(e,t){
"Content-Length"!==e&&"User-Agent"!==e&&"Host"!==e&&p.setRequestHeader(e,t)
})),t.timeout&&!1!==t.xhrAsync&&(p.timeout=t.timeout),t.xhrWithCredentials&&(p.withCredentials=!0)
try{p.responseType="arraybuffer"}catch(e){}try{e.body?p.send(e.body):p.send()}catch(t){
if(!e.body||"object"!=typeof e.body.buffer)throw t
p.send(e.body.buffer)}return u},parseHeaders:function(e){var t={}
return n.util.arrayEach(e.split(/\r?\n/),(function(e){
var r=e.split(":",1)[0],n=e.substring(r.length+2)
r.length>0&&(t[r.toLowerCase()]=n)})),t},finishRequest:function(e,t){var r
if("arraybuffer"===e.responseType&&e.response){var i=e.response
r=new n.util.Buffer(i.byteLength)
for(var o=new Uint8Array(i),s=0;s<r.length;++s)r[s]=o[s]}try{
r||"string"!=typeof e.responseText||(r=new n.util.Buffer(e.responseText))}catch(e){}
r&&t.emit("data",r),t.emit("end")}}),n.HttpClient.prototype=n.XHRClient.prototype,
n.HttpClient.streamsApiVersion=1},3658:(e,t,r)=>{var n=r(2662)
function i(){}function o(e,t){if(t&&null!=e)switch(t.type){case"structure":return function(e,t){
if(t.isDocument)return e
var r={}
return n.each(e,(function(e,n){var i=t.members[e]
if(i){if("body"!==i.location)return
var s=i.isLocationName?i.name:e,a=o(n,i)
void 0!==a&&(r[s]=a)}})),r}(e,t)
case"map":return function(e,t){var r={}
return n.each(e,(function(e,n){var i=o(n,t.value)
void 0!==i&&(r[e]=i)})),r}(e,t)
case"list":return function(e,t){var r=[]
return n.arrayEach(e,(function(e){var n=o(e,t.member)
void 0!==n&&r.push(n)})),r}(e,t)
default:return function(e,t){return t.toWireFormat(e)}(e,t)}}i.prototype.build=function(e,t){
return JSON.stringify(o(e,t))},e.exports=i},2622:(e,t,r)=>{var n=r(2662)
function i(){}function o(e,t){if(t&&void 0!==e)switch(t.type){case"structure":return function(e,t){
if(null!=e){if(t.isDocument)return e
var r={},i=t.members
return n.each(i,(function(t,n){var i=n.isLocationName?n.name:t
if(Object.prototype.hasOwnProperty.call(e,i)){var s=o(e[i],n)
void 0!==s&&(r[t]=s)}})),r}}(e,t)
case"map":return function(e,t){if(null!=e){var r={}
return n.each(e,(function(e,n){var i=o(n,t.value)
r[e]=void 0===i?null:i})),r}}(e,t)
case"list":return function(e,t){if(null!=e){var r=[]
return n.arrayEach(e,(function(e){var n=o(e,t.member)
void 0===n?r.push(null):r.push(n)})),r}}(e,t)
default:return function(e,t){return t.toType(e)}(e,t)}}i.prototype.parse=function(e,t){
return o(JSON.parse(e),t)},e.exports=i},5863:(e,t,r)=>{
var n=r(4351),i=r(6797),o=r(8136),s=r(7937),a=r(306),u=r(7752),c=r(2662),p=c.property,l=c.memoizedProperty
e.exports=function(e,t){var r=this
e=e||{},(t=t||{}).api=this,e.metadata=e.metadata||{}
var h=t.serviceIdentifier
delete t.serviceIdentifier,p(this,"isApi",!0,!1),p(this,"apiVersion",e.metadata.apiVersion),
p(this,"endpointPrefix",e.metadata.endpointPrefix),p(this,"signingName",e.metadata.signingName),
p(this,"globalEndpoint",e.metadata.globalEndpoint),
p(this,"signatureVersion",e.metadata.signatureVersion),p(this,"jsonVersion",e.metadata.jsonVersion),
p(this,"targetPrefix",e.metadata.targetPrefix),p(this,"protocol",e.metadata.protocol),
p(this,"timestampFormat",e.metadata.timestampFormat),
p(this,"xmlNamespaceUri",e.metadata.xmlNamespace),
p(this,"abbreviation",e.metadata.serviceAbbreviation),p(this,"fullName",e.metadata.serviceFullName),
p(this,"serviceId",e.metadata.serviceId),
h&&u[h]&&p(this,"xmlNoDefaultLists",u[h].xmlNoDefaultLists,!1),l(this,"className",(function(){
var t=e.metadata.serviceAbbreviation||e.metadata.serviceFullName
return t?("ElasticLoadBalancing"===(t=t.replace(/^Amazon|AWS\s*|\(.*|\s+|\W+/g,""))&&(t="ELB"),
t):null})),p(this,"operations",new n(e.operations,t,(function(e,r){return new i(e,r,t)
}),c.string.lowerFirst,(function(e,t){
!0===t.endpointoperation&&p(r,"endpointOperation",c.string.lowerFirst(e)),
t.endpointdiscovery&&!r.hasRequiredEndpointDiscovery&&p(r,"hasRequiredEndpointDiscovery",!0===t.endpointdiscovery.required)
}))),p(this,"shapes",new n(e.shapes,t,(function(e,r){return o.create(r,t)
}))),p(this,"paginators",new n(e.paginators,t,(function(e,r){return new s(e,r,t)}))),
p(this,"waiters",new n(e.waiters,t,(function(e,r){return new a(e,r,t)}),c.string.lowerFirst)),
t.documentation&&(p(this,"documentation",e.documentation),
p(this,"documentationUrl",e.documentationUrl))}},4351:(e,t,r)=>{var n=r(2662).memoizedProperty
function i(e,t,r,i){n(this,i(e),(function(){return r(e,t)}))}e.exports=function(e,t,r,n,o){
for(var s in n=n||String,e)Object.prototype.hasOwnProperty.call(e,s)&&(i.call(this,s,e[s],r,n),
o&&o(s,e[s]))}},6797:(e,t,r)=>{var n=r(8136),i=r(2662),o=i.property,s=i.memoizedProperty
e.exports=function(e,t,r){var i=this
r=r||{},o(this,"name",t.name||e),o(this,"api",r.api,!1),t.http=t.http||{},o(this,"endpoint",t.endpoint),
o(this,"httpMethod",t.http.method||"POST"),o(this,"httpPath",t.http.requestUri||"/"),
o(this,"authtype",t.authtype||""),
o(this,"endpointDiscoveryRequired",t.endpointdiscovery?t.endpointdiscovery.required?"REQUIRED":"OPTIONAL":"NULL")
var a=t.httpChecksumRequired||t.httpChecksum&&t.httpChecksum.requestChecksumRequired
o(this,"httpChecksumRequired",a,!1),s(this,"input",(function(){
return t.input?n.create(t.input,r):new n.create({type:"structure"},r)
})),s(this,"output",(function(){return t.output?n.create(t.output,r):new n.create({type:"structure"
},r)})),s(this,"errors",(function(){var e=[]
if(!t.errors)return null
for(var i=0;i<t.errors.length;i++)e.push(n.create(t.errors[i],r))
return e})),s(this,"paginator",(function(){return r.api.paginators[e]
})),r.documentation&&(o(this,"documentation",t.documentation),
o(this,"documentationUrl",t.documentationUrl)),s(this,"idempotentMembers",(function(){
var e=[],t=i.input,r=t.members
if(!t.members)return e
for(var n in r)r.hasOwnProperty(n)&&!0===r[n].isIdempotent&&e.push(n)
return e})),s(this,"hasEventOutput",(function(){return function(e){var t=e.members,r=e.payload
if(!e.members)return!1
if(r)return t[r].isEventStream
for(var n in t)if(!t.hasOwnProperty(n)&&!0===t[n].isEventStream)return!0
return!1}(i.output)}))}},7937:(e,t,r)=>{var n=r(2662).property
e.exports=function(e,t){n(this,"inputToken",t.input_token),n(this,"limitKey",t.limit_key),
n(this,"moreResults",t.more_results),
n(this,"outputToken",t.output_token),n(this,"resultKey",t.result_key)}},306:(e,t,r)=>{
var n=r(2662),i=n.property
e.exports=function(e,t,r){
r=r||{},i(this,"name",e),i(this,"api",r.api,!1),t.operation&&i(this,"operation",n.string.lowerFirst(t.operation))
var o=this;["type","description","delay","maxAttempts","acceptors"].forEach((function(e){var r=t[e]
r&&i(o,e,r)}))}},8136:(e,t,r)=>{var n=r(4351),i=r(2662)
function o(e,t,r){null!=r&&i.property.apply(this,arguments)}function s(e,t){
e.constructor.prototype[t]||i.memoizedProperty.apply(this,arguments)}function a(e,t,r){t=t||{},
o(this,"shape",e.shape),o(this,"api",t.api,!1),o(this,"type",e.type),o(this,"enum",e.enum),
o(this,"min",e.min),
o(this,"max",e.max),o(this,"pattern",e.pattern),o(this,"location",e.location||this.location||"body"),
o(this,"name",this.name||e.xmlName||e.queryName||e.locationName||r),
o(this,"isStreaming",e.streaming||this.isStreaming||!1),
o(this,"requiresLength",e.requiresLength,!1),o(this,"isComposite",e.isComposite||!1),
o(this,"isShape",!0,!1),
o(this,"isQueryName",Boolean(e.queryName),!1),o(this,"isLocationName",Boolean(e.locationName),!1),
o(this,"isIdempotent",!0===e.idempotencyToken),o(this,"isJsonValue",!0===e.jsonvalue),
o(this,"isSensitive",!0===e.sensitive||e.prototype&&!0===e.prototype.sensitive),
o(this,"isEventStream",Boolean(e.eventstream),!1),o(this,"isEvent",Boolean(e.event),!1),
o(this,"isEventPayload",Boolean(e.eventpayload),!1),
o(this,"isEventHeader",Boolean(e.eventheader),!1),
o(this,"isTimestampFormatSet",Boolean(e.timestampFormat)||e.prototype&&!0===e.prototype.isTimestampFormatSet,!1),
o(this,"endpointDiscoveryId",Boolean(e.endpointdiscoveryid),!1),
o(this,"hostLabel",Boolean(e.hostLabel),!1),
t.documentation&&(o(this,"documentation",e.documentation),
o(this,"documentationUrl",e.documentationUrl)),
e.xmlAttribute&&o(this,"isXmlAttribute",e.xmlAttribute||!1),o(this,"defaultValue",null),
this.toWireFormat=function(e){return null==e?"":e},this.toType=function(e){return e}}function u(e){
a.apply(this,arguments),o(this,"isComposite",!0),e.flattened&&o(this,"flattened",e.flattened||!1)}
function c(e,t){var r=this,i=null,c=!this.isShape
u.apply(this,arguments),c&&(o(this,"defaultValue",(function(){return{}})),o(this,"members",{}),
o(this,"memberNames",[]),o(this,"required",[]),o(this,"isRequired",(function(){return!1})),
o(this,"isDocument",Boolean(e.document))),
e.members&&(o(this,"members",new n(e.members,t,(function(e,r){return a.create(r,t,e)}))),
s(this,"memberNames",(function(){return e.xmlOrder||Object.keys(e.members)
})),e.event&&(s(this,"eventPayloadMemberName",(function(){
for(var e=r.members,t=r.memberNames,n=0,i=t.length;n<i;n++)if(e[t[n]].isEventPayload)return t[n]})),
s(this,"eventHeaderMemberNames",(function(){
for(var e=r.members,t=r.memberNames,n=[],i=0,o=t.length;i<o;i++)e[t[i]].isEventHeader&&n.push(t[i])
return n})))),e.required&&(o(this,"required",e.required),o(this,"isRequired",(function(t){if(!i){
i={}
for(var r=0;r<e.required.length;r++)i[e.required[r]]=!0}return i[t]
}),!1,!0)),o(this,"resultWrapper",e.resultWrapper||null),e.payload&&o(this,"payload",e.payload),
"string"==typeof e.xmlNamespace?o(this,"xmlNamespaceUri",e.xmlNamespace):"object"==typeof e.xmlNamespace&&(o(this,"xmlNamespacePrefix",e.xmlNamespace.prefix),
o(this,"xmlNamespaceUri",e.xmlNamespace.uri))}function p(e,t){var r=this,n=!this.isShape
if(u.apply(this,arguments),n&&o(this,"defaultValue",(function(){return[]
})),e.member&&s(this,"member",(function(){return a.create(e.member,t)})),this.flattened){
var i=this.name
s(this,"name",(function(){return r.member.name||i}))}}function l(e,t){var r=!this.isShape
u.apply(this,arguments),r&&(o(this,"defaultValue",(function(){return{}})),o(this,"key",a.create({
type:"string"},t)),o(this,"value",a.create({type:"string"},t))),e.key&&s(this,"key",(function(){
return a.create(e.key,t)})),e.value&&s(this,"value",(function(){return a.create(e.value,t)}))}
function h(){a.apply(this,arguments)
var e=["rest-xml","query","ec2"]
this.toType=function(t){return t=this.api&&e.indexOf(this.api.protocol)>-1?t||"":t,
this.isJsonValue?JSON.parse(t):t&&"function"==typeof t.toString?t.toString():t},
this.toWireFormat=function(e){return this.isJsonValue?JSON.stringify(e):e}}function f(){
a.apply(this,arguments),this.toType=function(e){var t=i.base64.decode(e)
if(this.isSensitive&&i.isNode()&&"function"==typeof i.Buffer.alloc){var r=i.Buffer.alloc(t.length,t)
t.fill(0),t=r}return t},this.toWireFormat=i.base64.encode}function d(){f.apply(this,arguments)}
function m(){a.apply(this,arguments),this.toType=function(e){
return"boolean"==typeof e?e:null==e?null:"true"===e}}a.normalizedTypes={character:"string",
double:"float",long:"integer",short:"integer",biginteger:"integer",bigdecimal:"float",blob:"binary"
},a.types={structure:c,list:p,map:l,boolean:m,timestamp:function(e){var t=this
if(a.apply(this,arguments),e.timestampFormat)o(this,"timestampFormat",e.timestampFormat)
else if(t.isTimestampFormatSet&&this.timestampFormat)o(this,"timestampFormat",this.timestampFormat)
else if("header"===this.location)o(this,"timestampFormat","rfc822")
else if("querystring"===this.location)o(this,"timestampFormat","iso8601")
else if(this.api)switch(this.api.protocol){case"json":case"rest-json":
o(this,"timestampFormat","unixTimestamp")
break
case"rest-xml":case"query":case"ec2":o(this,"timestampFormat","iso8601")}this.toType=function(e){
return null==e?null:"function"==typeof e.toUTCString?e:"string"==typeof e||"number"==typeof e?i.date.parseTimestamp(e):null
},this.toWireFormat=function(e){return i.date.format(e,t.timestampFormat)}},float:function(){
a.apply(this,arguments),this.toType=function(e){return null==e?null:parseFloat(e)},
this.toWireFormat=this.toType},integer:function(){a.apply(this,arguments),this.toType=function(e){
return null==e?null:parseInt(e,10)},this.toWireFormat=this.toType},string:h,base64:d,binary:f},
a.resolve=function(e,t){if(e.shape){var r=t.api.shapes[e.shape]
if(!r)throw new Error("Cannot find shape reference: "+e.shape)
return r}return null},a.create=function(e,t,r){if(e.isShape)return e
var n=a.resolve(e,t)
if(n){var i=Object.keys(e)
t.documentation||(i=i.filter((function(e){return!e.match(/documentation/)})))
var o=function(){n.constructor.call(this,e,t,r)}
return o.prototype=n,new o}
e.type||(e.members?e.type="structure":e.member?e.type="list":e.key?e.type="map":e.type="string")
var s=e.type
if(a.normalizedTypes[e.type]&&(e.type=a.normalizedTypes[e.type]),a.types[e.type])return new a.types[e.type](e,t,r)
throw new Error("Unrecognized shape type: "+s)},a.shapes={StructureShape:c,ListShape:p,MapShape:l,
StringShape:h,BooleanShape:m,Base64Shape:d},e.exports=a},5479:(e,t,r)=>{var n=r(9614)
n.ParamValidator=n.util.inherit({constructor:function(e){!0!==e&&void 0!==e||(e={min:!0}),
this.validation=e},validate:function(e,t,r){
if(this.errors=[],this.validateMember(e,t||{},r||"params"),this.errors.length>1){
var i=this.errors.join("\n* ")
throw i="There were "+this.errors.length+" validation errors:\n* "+i,n.util.error(new Error(i),{
code:"MultipleValidationErrors",errors:this.errors})}if(1===this.errors.length)throw this.errors[0]
return!0},fail:function(e,t){this.errors.push(n.util.error(new Error(t),{code:e}))},
validateStructure:function(e,t,r){if(e.isDocument)return!0
var n
this.validateType(t,r,["object"],"structure")
for(var i=0;e.required&&i<e.required.length;i++)null==t[n=e.required[i]]&&this.fail("MissingRequiredParameter","Missing required key '"+n+"' in "+r)
for(n in t)if(Object.prototype.hasOwnProperty.call(t,n)){var o=t[n],s=e.members[n]
if(void 0!==s){var a=[r,n].join(".")
this.validateMember(s,o,a)
}else null!=o&&this.fail("UnexpectedParameter","Unexpected key '"+n+"' found in "+r)}return!0},
validateMember:function(e,t,r){switch(e.type){case"structure":return this.validateStructure(e,t,r)
case"list":return this.validateList(e,t,r)
case"map":return this.validateMap(e,t,r)
default:return this.validateScalar(e,t,r)}},validateList:function(e,t,r){
if(this.validateType(t,r,[Array])){this.validateRange(e,t.length,r,"list member count")
for(var n=0;n<t.length;n++)this.validateMember(e.member,t[n],r+"["+n+"]")}},
validateMap:function(e,t,r){if(this.validateType(t,r,["object"],"map")){var n=0
for(var i in t)Object.prototype.hasOwnProperty.call(t,i)&&(this.validateMember(e.key,i,r+"[key='"+i+"']"),
this.validateMember(e.value,t[i],r+"['"+i+"']"),n++)
this.validateRange(e,n,r,"map member count")}},validateScalar:function(e,t,r){switch(e.type){
case null:case void 0:case"string":return this.validateString(e,t,r)
case"base64":case"binary":return this.validatePayload(t,r)
case"integer":case"float":return this.validateNumber(e,t,r)
case"boolean":return this.validateType(t,r,["boolean"])
case"timestamp":
return this.validateType(t,r,[Date,/^\d{4}-\d{2}-\d{2}T\d{2}:\d{2}:\d{2}(\.\d+)?Z$/,"number"],"Date object, ISO-8601 string, or a UNIX timestamp")
default:return this.fail("UnkownType","Unhandled type "+e.type+" for "+r)}},
validateString:function(e,t,r){var n=["string"]
e.isJsonValue&&(n=n.concat(["number","object","boolean"])),null!==t&&this.validateType(t,r,n)&&(this.validateEnum(e,t,r),
this.validateRange(e,t.length,r,"string length"),
this.validatePattern(e,t,r),this.validateUri(e,t,r))},validateUri:function(e,t,r){
"uri"===e.location&&0===t.length&&this.fail("UriParameterError",'Expected uri parameter to have length >= 1, but found "'+t+'" for '+r)
},validatePattern:function(e,t,r){
this.validation.pattern&&void 0!==e.pattern&&(new RegExp(e.pattern).test(t)||this.fail("PatternMatchError",'Provided value "'+t+'" does not match regex pattern /'+e.pattern+"/ for "+r))
},validateRange:function(e,t,r,n){
this.validation.min&&void 0!==e.min&&t<e.min&&this.fail("MinRangeError","Expected "+n+" >= "+e.min+", but found "+t+" for "+r),
this.validation.max&&void 0!==e.max&&t>e.max&&this.fail("MaxRangeError","Expected "+n+" <= "+e.max+", but found "+t+" for "+r)
},validateEnum:function(e,t,r){
this.validation.enum&&void 0!==e.enum&&-1===e.enum.indexOf(t)&&this.fail("EnumError","Found string value of "+t+", but expected "+e.enum.join("|")+" for "+r)
},validateType:function(e,t,r,i){if(null==e)return!1
for(var o=!1,s=0;s<r.length;s++){if("string"==typeof r[s]){if(typeof e===r[s])return!0
}else if(r[s]instanceof RegExp){if((e||"").toString().match(r[s]))return!0}else{
if(e instanceof r[s])return!0
if(n.util.isType(e,r[s]))return!0
i||o||(r=r.slice()),r[s]=n.util.typeName(r[s])}o=!0}var a=i
a||(a=r.join(", ").replace(/,([^,]+)$/,", or$1"))
var u=a.match(/^[aeiou]/i)?"n":""
return this.fail("InvalidParameterType","Expected "+t+" to be a"+u+" "+a),!1},
validateNumber:function(e,t,r){if(null!=t){if("string"==typeof t){var n=parseFloat(t)
n.toString()===t&&(t=n)}this.validateType(t,r,["number"])&&this.validateRange(e,t,r,"numeric value")
}},validatePayload:function(e,t){
if(null!=e&&"string"!=typeof e&&(!e||"number"!=typeof e.byteLength)){if(n.util.isNode()){
var r=n.util.stream.Stream
if(n.util.Buffer.isBuffer(e)||e instanceof r)return
}else if(void 0!==typeof Blob&&e instanceof Blob)return
var i=["Buffer","Stream","File","Blob","ArrayBuffer","DataView"]
if(e)for(var o=0;o<i.length;o++){if(n.util.isType(e,i[o]))return
if(n.util.typeName(e.constructor)===i[o])return}
this.fail("InvalidParameterType","Expected "+t+" to be a string, Buffer, Stream, Blob, or typed array object")
}}})},987:(e,t,r)=>{var n=r(2662),i=r(9614)
e.exports={populateHostPrefix:function(e){if(!e.service.config.hostPrefixEnabled)return e
var t,r,o,s,a,u,c,p=e.service.api.operations[e.operation]
return function(e){
var t=e.service.api,r=t.operations[e.operation],i=t.endpointOperation&&t.endpointOperation===n.string.lowerFirst(r.name)
return"NULL"!==r.endpointDiscoveryRequired||!0===i
}(e)||p.endpoint&&p.endpoint.hostPrefix&&(a=p.endpoint.hostPrefix,u=e.params,c=p.input,
n.each(c.members,(function(e,t){if(!0===t.hostLabel){
if("string"!=typeof u[e]||""===u[e])throw n.error(new Error,{
message:"Parameter "+e+" should be a non-empty string.",code:"InvalidParameter"})
var r=new RegExp("\\{"+e+"\\}","g")
a=a.replace(r,u[e])}
})),s=a,(o=e.httpRequest.endpoint).host&&(o.host=s+o.host),o.hostname&&(o.hostname=s+o.hostname),
t=e.httpRequest.endpoint.hostname.split("."),
r=/^[a-zA-Z0-9]{1}$|^[a-zA-Z0-9][a-zA-Z0-9\-]*[a-zA-Z0-9]$/,n.arrayEach(t,(function(e){
if(!e.length||e.length<1||e.length>63)throw n.error(new Error,{code:"ValidationError",
message:"Hostname label length should be between 1 to 63 characters, inclusive."})
if(!r.test(e))throw i.util.error(new Error,{code:"ValidationError",
message:e+" is not hostname compatible."})}))),e}}},6933:(e,t,r)=>{
var n=r(2662),i=r(3658),o=r(2622),s=r(987).populateHostPrefix
e.exports={buildRequest:function(e){
var t=e.httpRequest,r=e.service.api,n=r.targetPrefix+"."+r.operations[e.operation].name,o=r.jsonVersion||"1.0",a=r.operations[e.operation].input,u=new i
1===o&&(o="1.0"),t.body=u.build(e.params||{},a),t.headers["Content-Type"]="application/x-amz-json-"+o,
t.headers["X-Amz-Target"]=n,s(e)},extractError:function(e){var t={},r=e.httpResponse
if(t.code=r.headers["x-amzn-errortype"]||"UnknownError","string"==typeof t.code&&(t.code=t.code.split(":")[0]),
r.body.length>0)try{var i=JSON.parse(r.body.toString()),o=i.__type||i.code||i.Code
o&&(t.code=o.split("#").pop()),"RequestEntityTooLarge"===t.code?t.message="Request body must be less than 1 MB":t.message=i.message||i.Message||null
}catch(i){t.statusCode=r.statusCode,t.message=r.statusMessage}else t.statusCode=r.statusCode,
t.message=r.statusCode.toString()
e.error=n.error(new Error,t)},extractData:function(e){var t=e.httpResponse.body.toString()||"{}"
if(!1===e.request.service.config.convertResponseTypes)e.data=JSON.parse(t)
else{var r=e.request.service.api.operations[e.request.operation].output||{},n=new o
e.data=n.parse(t,r)}}}},293:(e,t,r)=>{
var n=r(9614),i=r(2662),o=r(864),s=r(8136),a=r(987).populateHostPrefix
e.exports={buildRequest:function(e){var t=e.service.api.operations[e.operation],r=e.httpRequest
r.headers["Content-Type"]="application/x-www-form-urlencoded; charset=utf-8",r.params={
Version:e.service.api.apiVersion,Action:t.name},(new o).serialize(e.params,t.input,(function(e,t){
r.params[e]=t})),r.body=i.queryParamsToString(r.params),a(e)},extractError:function(e){
var t,r=e.httpResponse.body.toString()
if(r.match("<UnknownOperationException"))t={Code:"UnknownOperation",
Message:"Unknown operation "+e.request.operation}
else try{t=(new n.XML.Parser).parse(r)}catch(r){t={Code:e.httpResponse.statusCode,
Message:e.httpResponse.statusMessage}}t.requestId&&!e.requestId&&(e.requestId=t.requestId),
t.Errors&&(t=t.Errors),t.Error&&(t=t.Error),t.Code?e.error=i.error(new Error,{code:t.Code,
message:t.Message}):e.error=i.error(new Error,{code:e.httpResponse.statusCode,message:null})},
extractData:function(e){var t=e.request,r=t.service.api.operations[t.operation].output||{},o=r
if(o.resultWrapper){var a=s.create({type:"structure"})
a.members[o.resultWrapper]=r,a.memberNames=[o.resultWrapper],i.property(r,"name",r.resultWrapper),
r=a}var u=new n.XML.Parser
if(r&&r.members&&!r.members._XAMZRequestId){var c=s.create({type:"string"},{api:{protocol:"query"}
},"requestId")
r.members._XAMZRequestId=c}var p=u.parse(e.httpResponse.body.toString(),r)
e.requestId=p._XAMZRequestId||p.requestId,p._XAMZRequestId&&delete p._XAMZRequestId,
o.resultWrapper&&p[o.resultWrapper]&&(i.update(p,p[o.resultWrapper]),delete p[o.resultWrapper]),
e.data=p}}},6225:(e,t,r)=>{var n=r(2662),i=r(987).populateHostPrefix
function o(e,t,r,i){var o=[e,t].join("/")
o=o.replace(/\/+/g,"/")
var s={},a=!1
if(n.each(r.members,(function(e,t){var r=i[e]
if(null!=r)if("uri"===t.location){var u=new RegExp("\\{"+t.name+"(\\+)?\\}")
o=o.replace(u,(function(e,t){return(t?n.uriEscapePath:n.uriEscape)(String(r))}))
}else"querystring"===t.location&&(a=!0,"list"===t.type?s[t.name]=r.map((function(e){
return n.uriEscape(t.member.toWireFormat(e).toString())})):"map"===t.type?n.each(r,(function(e,t){
Array.isArray(t)?s[e]=t.map((function(e){return n.uriEscape(String(e))
})):s[e]=n.uriEscape(String(t))})):s[t.name]=n.uriEscape(t.toWireFormat(r).toString()))})),a){
o+=o.indexOf("?")>=0?"&":"?"
var u=[]
n.arrayEach(Object.keys(s).sort(),(function(e){Array.isArray(s[e])||(s[e]=[s[e]])
for(var t=0;t<s[e].length;t++)u.push(n.uriEscape(String(e))+"="+s[e][t])})),o+=u.join("&")}return o}
e.exports={buildRequest:function(e){!function(e){
e.httpRequest.method=e.service.api.operations[e.operation].httpMethod}(e),function(e){
var t=e.service.api.operations[e.operation],r=t.input,n=o(e.httpRequest.endpoint.path,t.httpPath,r,e.params)
e.httpRequest.path=n}(e),function(e){var t=e.service.api.operations[e.operation]
n.each(t.input.members,(function(t,r){var i=e.params[t]
null!=i&&("headers"===r.location&&"map"===r.type?n.each(i,(function(t,n){
e.httpRequest.headers[r.name+t]=n})):"header"===r.location&&(i=r.toWireFormat(i).toString(),
r.isJsonValue&&(i=n.base64.encode(i)),e.httpRequest.headers[r.name]=i))}))}(e),i(e)},
extractError:function(){},extractData:function(e){
var t=e.request,r={},i=e.httpResponse,o=t.service.api.operations[t.operation].output,s={}
n.each(i.headers,(function(e,t){s[e.toLowerCase()]=t})),n.each(o.members,(function(e,t){
var o=(t.name||e).toLowerCase()
if("headers"===t.location&&"map"===t.type){r[e]={}
var a=t.isLocationName?t.name:"",u=new RegExp("^"+a+"(.+)","i")
n.each(i.headers,(function(t,n){var i=t.match(u)
null!==i&&(r[e][i[1]]=n)}))}else if("header"===t.location){if(void 0!==s[o]){
var c=t.isJsonValue?n.base64.decode(s[o]):s[o]
r[e]=t.toType(c)}}else"statusCode"===t.location&&(r[e]=parseInt(i.statusCode,10))})),e.data=r},
generateURI:o}},3699:(e,t,r)=>{var n=r(2662),i=r(6225),o=r(6933),s=r(3658),a=r(2622)
function u(e,t){if(!e.httpRequest.headers["Content-Type"]){
var r=t?"binary/octet-stream":"application/json"
e.httpRequest.headers["Content-Type"]=r}}e.exports={buildRequest:function(e){i.buildRequest(e),
["GET","HEAD","DELETE"].indexOf(e.httpRequest.method)<0&&function(e){
var t=new s,r=e.service.api.operations[e.operation].input
if(r.payload){var n,i=r.members[r.payload]
n=e.params[r.payload],"structure"===i.type?(e.httpRequest.body=t.build(n||{},i),
u(e)):void 0!==n&&(e.httpRequest.body=n,("binary"===i.type||i.isStreaming)&&u(e,!0))
}else e.httpRequest.body=t.build(e.params,r),u(e)}(e)},extractError:function(e){o.extractError(e)},
extractData:function(e){i.extractData(e)
var t=e.request,r=t.service.api.operations[t.operation],s=t.service.api.operations[t.operation].output||{}
if(r.hasEventOutput,s.payload){var u=s.members[s.payload],c=e.httpResponse.body
if(u.isEventStream)p=new a,e.data[payload]=n.createEventStream(2===AWS.HttpClient.streamsApiVersion?e.httpResponse.stream:c,p,u)
else if("structure"===u.type||"list"===u.type){var p=new a
e.data[s.payload]=p.parse(c,u)
}else"binary"===u.type||u.isStreaming?e.data[s.payload]=c:e.data[s.payload]=u.toType(c)}else{
var l=e.data
o.extractData(e),e.data=n.merge(l,e.data)}}}},1674:(e,t,r)=>{var n=r(9614),i=r(2662),o=r(6225)
e.exports={buildRequest:function(e){
o.buildRequest(e),["GET","HEAD"].indexOf(e.httpRequest.method)<0&&function(e){
var t=e.service.api.operations[e.operation].input,r=new n.XML.Builder,o=e.params,s=t.payload
if(s){var a=t.members[s]
if(void 0===(o=o[s]))return
if("structure"===a.type){var u=a.name
e.httpRequest.body=r.toXML(o,a,u,!0)}else e.httpRequest.body=o
}else e.httpRequest.body=r.toXML(o,t,t.name||t.shape||i.string.upperFirst(e.operation)+"Request")
}(e)},extractError:function(e){var t
o.extractError(e)
try{t=(new n.XML.Parser).parse(e.httpResponse.body.toString())}catch(r){t={
Code:e.httpResponse.statusCode,Message:e.httpResponse.statusMessage}}t.Errors&&(t=t.Errors),
t.Error&&(t=t.Error),t.Code?e.error=i.error(new Error,{code:t.Code,message:t.Message
}):e.error=i.error(new Error,{code:e.httpResponse.statusCode,message:null})},
extractData:function(e){var t
o.extractData(e)
var r=e.request,s=e.httpResponse.body,a=r.service.api.operations[r.operation],u=a.output,c=(a.hasEventOutput,
u.payload)
if(c){var p=u.members[c]
p.isEventStream?(t=new n.XML.Parser,e.data[c]=i.createEventStream(2===n.HttpClient.streamsApiVersion?e.httpResponse.stream:e.httpResponse.body,t,p)):"structure"===p.type?(t=new n.XML.Parser,
e.data[c]=t.parse(s.toString(),p)):"binary"===p.type||p.isStreaming?e.data[c]=s:e.data[c]=p.toType(s)
}else if(s.length>0){var l=(t=new n.XML.Parser).parse(s.toString(),u)
i.update(e.data,l)}}}},864:(e,t,r)=>{var n=r(2662)
function i(){}function o(e){
return e.isQueryName||"ec2"!==e.api.protocol?e.name:e.name[0].toUpperCase()+e.name.substr(1)}
function s(e,t,r,i){n.each(r.members,(function(r,n){var s=t[r]
if(null!=s){var u=o(n)
a(u=e?e+"."+u:u,s,n,i)}}))}function a(e,t,r,i){
null!=t&&("structure"===r.type?s(e,t,r,i):"list"===r.type?function(e,t,r,i){var s=r.member||{}
0!==t.length?n.arrayEach(t,(function(t,n){var u="."+(n+1)
if("ec2"===r.api.protocol)u+=""
else if(r.flattened){if(s.name){var c=e.split(".")
c.pop(),c.push(o(s)),e=c.join(".")}}else u="."+(s.name?s.name:"member")+u
a(e+u,t,s,i)})):i.call(this,e,null)}(e,t,r,i):"map"===r.type?function(e,t,r,i){var o=1
n.each(t,(function(t,n){
var s=(r.flattened?".":".entry.")+o+++".",u=s+(r.key.name||"key"),c=s+(r.value.name||"value")
a(e+u,t,r.key,i),a(e+c,n,r.value,i)}))}(e,t,r,i):i(e,r.toWireFormat(t).toString()))}
i.prototype.serialize=function(e,t,r){s("",e,t,r)},e.exports=i},1414:e=>{e.exports={now:function(){
return"undefined"!=typeof performance&&"function"==typeof performance.now?performance.now():Date.now()
}}},4040:e=>{e.exports={isFipsRegion:function(e){
return"string"==typeof e&&(e.startsWith("fips-")||e.endsWith("-fips"))},isGlobalRegion:function(e){
return"string"==typeof e&&["aws-global","aws-us-gov-global"].includes(e)},getRealRegion:function(e){
return["fips-aws-global","aws-fips","aws-global"].includes(e)?"us-east-1":["fips-aws-us-gov-global","aws-us-gov-global"].includes(e)?"us-gov-west-1":e.replace(/fips-(dkr-|prod-)?|-fips/,"")
}}},1404:(e,t,r)=>{var n=r(2662),i=r(738)
function o(e,t){n.each(t,(function(t,r){
"globalEndpoint"!==t&&(void 0!==e.config[t]&&null!==e.config[t]||(e.config[t]=r))}))}e.exports={
configureEndpoint:function(e){for(var t=function(e){var t=e.config.region,r=function(e){
if(!e)return null
var t=e.split("-")
return t.length<3?null:t.slice(0,t.length-2).join("-")+"-*"}(t),n=e.api.endpointPrefix
return[[t,n],[r,n],[t,"*"],[r,"*"],["*",n],["*","*"]].map((function(e){
return e[0]&&e[1]?e.join("/"):null}))
}(e),r=e.config.useFipsEndpoint,n=e.config.useDualstackEndpoint,s=0;s<t.length;s++){var a=t[s]
if(a){var u=r?n?i.dualstackFipsRules:i.fipsRules:n?i.dualstackRules:i.rules
if(Object.prototype.hasOwnProperty.call(u,a)){var c=u[a]
return"string"==typeof c&&(c=i.patterns[c]),e.isGlobalEndpoint=!!c.globalEndpoint,
c.signingRegion&&(e.signingRegion=c.signingRegion),c.signatureVersion||(c.signatureVersion="v4"),
void o(e,c)}}}},getEndpointSuffix:function(e){for(var t={
"^(us|eu|ap|sa|ca|me)\\-\\w+\\-\\d+$":"amazonaws.com","^cn\\-\\w+\\-\\d+$":"amazonaws.com.cn",
"^us\\-gov\\-\\w+\\-\\d+$":"amazonaws.com","^us\\-iso\\-\\w+\\-\\d+$":"c2s.ic.gov",
"^us\\-isob\\-\\w+\\-\\d+$":"sc2s.sgov.gov"},r=Object.keys(t),n=0;n<r.length;n++){
var i=RegExp(r[n]),o=t[r[n]]
if(i.test(e))return o}return"amazonaws.com"}}},3682:(e,t,r)=>{
var n=r(9614),i=r(1793),o=n.util.inherit,s=n.util.domain,a=r(4509),u={success:1,error:1,complete:1
},c=new i
c.setupStates=function(){var e=function(e,t){var r=this
r._haltHandlersOnError=!1,r.emit(r._asm.currentState,(function(e){
if(e)if(n=r,Object.prototype.hasOwnProperty.call(u,n._asm.currentState)){
if(!(s&&r.domain instanceof s.Domain))throw e
e.domainEmitter=r,e.domain=r.domain,e.domainThrown=!1,r.domain.emit("error",e)
}else r.response.error=e,t(e)
else t(r.response.error)
var n}))}
this.addState("validate","build","error",e),this.addState("build","afterBuild","restart",e),
this.addState("afterBuild","sign","restart",e),this.addState("sign","send","retry",e),
this.addState("retry","afterRetry","afterRetry",e),this.addState("afterRetry","sign","error",e),
this.addState("send","validateResponse","retry",e),
this.addState("validateResponse","extractData","extractError",e),
this.addState("extractError","extractData","retry",e),
this.addState("extractData","success","retry",e),this.addState("restart","build","error",e),
this.addState("success","complete","complete",e),this.addState("error","complete","complete",e),
this.addState("complete",null,null,e)},c.setupStates(),n.Request=o({constructor:function(e,t,r){
var o=e.endpoint,a=e.config.region,u=e.config.customUserAgent
e.signingRegion?a=e.signingRegion:e.isGlobalEndpoint&&(a="us-east-1"),this.domain=s&&s.active,
this.service=e,this.operation=t,this.params=r||{},this.httpRequest=new n.HttpRequest(o,a),
this.httpRequest.appendToUserAgent(u),
this.startTime=e.getSkewCorrectedDate(),this.response=new n.Response(this),
this._asm=new i(c.states,"validate"),this._haltHandlersOnError=!1,n.SequentialExecutor.call(this),
this.emit=this.emitEvent},send:function(e){
return e&&(this.httpRequest.appendToUserAgent("callback"),this.on("complete",(function(t){
e.call(t,t.error,t.data)}))),this.runTo(),this.response},build:function(e){
return this.runTo("send",e)},runTo:function(e,t){return this._asm.runTo(e,t,this),this},
abort:function(){
return this.removeAllListeners("validateResponse"),this.removeAllListeners("extractError"),
this.on("validateResponse",(function(e){e.error=n.util.error(new Error("Request aborted by user"),{
code:"RequestAbortedError",retryable:!1})
})),this.httpRequest.stream&&!this.httpRequest.stream.didCallback&&(this.httpRequest.stream.abort(),
this.httpRequest._abortCallback?this.httpRequest._abortCallback():this.removeAllListeners("send")),
this},eachPage:function(e){e=n.util.fn.makeAsync(e,3),this.on("complete",(function t(r){
e.call(r,r.error,r.data,(function(i){
!1!==i&&(r.hasNextPage()?r.nextPage().on("complete",t).send():e.call(r,null,null,n.util.fn.noop))}))
})).send()},eachItem:function(e){var t=this
this.eachPage((function(r,i){if(r)return e(r,null)
if(null===i)return e(null,null)
var o=t.service.paginationConfig(t.operation).resultKey
Array.isArray(o)&&(o=o[0])
var s=a.search(i,o),u=!0
return n.util.arrayEach(s,(function(t){if(!1===(u=e(null,t)))return n.util.abort})),u}))},
isPageable:function(){return!!this.service.paginationConfig(this.operation)},
createReadStream:function(){var e=n.util.stream,t=this,r=null
return 2===n.HttpClient.streamsApiVersion?(r=new e.PassThrough,process.nextTick((function(){t.send()
}))):((r=new e.Stream).readable=!0,r.sent=!1,r.on("newListener",(function(e){
r.sent||"data"!==e||(r.sent=!0,process.nextTick((function(){t.send()})))
}))),this.on("error",(function(e){r.emit("error",e)})),this.on("httpHeaders",(function(i,o,s){
if(i<300){
t.removeListener("httpData",n.EventListeners.Core.HTTP_DATA),t.removeListener("httpError",n.EventListeners.Core.HTTP_ERROR),
t.on("httpError",(function(e){s.error=e,s.error.retryable=!1}))
var a,u=!1
if("HEAD"!==t.httpRequest.method&&(a=parseInt(o["content-length"],10)),void 0!==a&&!isNaN(a)&&a>=0){
u=!0
var c=0}var p=function(){
u&&c!==a?r.emit("error",n.util.error(new Error("Stream content length mismatch. Received "+c+" of "+a+" bytes."),{
code:"StreamContentLengthMismatch"})):2===n.HttpClient.streamsApiVersion?r.end():r.emit("end")
},l=s.httpResponse.createUnbufferedStream()
if(2===n.HttpClient.streamsApiVersion)if(u){var h=new e.PassThrough
h._write=function(t){
return t&&t.length&&(c+=t.length),e.PassThrough.prototype._write.apply(this,arguments)},
h.on("end",p),r.on("error",(function(e){u=!1,l.unpipe(h),h.emit("end"),h.end()})),l.pipe(h).pipe(r,{
end:!1})}else l.pipe(r)
else u&&l.on("data",(function(e){e&&e.length&&(c+=e.length)})),l.on("data",(function(e){
r.emit("data",e)})),l.on("end",p)
l.on("error",(function(e){u=!1,r.emit("error",e)}))}})),r},emitEvent:function(e,t,r){
"function"==typeof t&&(r=t,t=null),r||(r=function(){}),t||(t=this.eventParameters(e,this.response)),
n.SequentialExecutor.prototype.emit.call(this,e,t,(function(e){e&&(this.response.error=e),
r.call(this,e)}))},eventParameters:function(e){switch(e){case"restart":case"validate":case"sign":
case"build":case"afterValidate":case"afterBuild":return[this]
case"error":return[this.response.error,this.response]
default:return[this.response]}},presign:function(e,t){return t||"function"!=typeof e||(t=e,e=null),
(new n.Signers.Presign).sign(this.toGet(),e,t)},isPresigned:function(){
return Object.prototype.hasOwnProperty.call(this.httpRequest.headers,"presigned-expires")},
toUnauthenticated:function(){
return this._unAuthenticated=!0,this.removeListener("validate",n.EventListeners.Core.VALIDATE_CREDENTIALS),
this.removeListener("sign",n.EventListeners.Core.SIGN),this},toGet:function(){
return"query"!==this.service.api.protocol&&"ec2"!==this.service.api.protocol||(this.removeListener("build",this.buildAsGet),
this.addListener("build",this.buildAsGet)),this},buildAsGet:function(e){e.httpRequest.method="GET",
e.httpRequest.path=e.service.endpoint.path+"?"+e.httpRequest.body,e.httpRequest.body="",
delete e.httpRequest.headers["Content-Length"],delete e.httpRequest.headers["Content-Type"]},
haltHandlersOnError:function(){this._haltHandlersOnError=!0}
}),n.Request.addPromisesToClass=function(e){this.prototype.promise=function(){var t=this
return this.httpRequest.appendToUserAgent("promise"),new e((function(e,r){
t.on("complete",(function(t){t.error?r(t.error):e(Object.defineProperty(t.data||{},"$response",{
value:t}))})),t.runTo()}))}},n.Request.deletePromisesFromClass=function(){
delete this.prototype.promise
},n.util.addPromises(n.Request),n.util.mixin(n.Request,n.SequentialExecutor)},2413:(e,t,r)=>{
var n=r(9614),i=n.util.inherit,o=r(4509)
function s(e){var t=e.request._waiter,r=t.config.acceptors,n=!1,i="retry"
r.forEach((function(r){if(!n){var o=t.matchers[r.matcher]
o&&o(e,r.expected,r.argument)&&(n=!0,i=r.state)}
})),!n&&e.error&&(i="failure"),"success"===i?t.setSuccess(e):t.setError(e,"retry"===i)}
n.ResourceWaiter=i({constructor:function(e,t){
this.service=e,this.state=t,this.loadWaiterConfig(this.state)},service:null,state:null,config:null,
matchers:{path:function(e,t,r){try{var n=o.search(e.data,r)}catch(e){return!1}
return o.strictDeepEqual(n,t)},pathAll:function(e,t,r){try{var n=o.search(e.data,r)}catch(e){
return!1}Array.isArray(n)||(n=[n])
var i=n.length
if(!i)return!1
for(var s=0;s<i;s++)if(!o.strictDeepEqual(n[s],t))return!1
return!0},pathAny:function(e,t,r){try{var n=o.search(e.data,r)}catch(e){return!1}
Array.isArray(n)||(n=[n])
for(var i=n.length,s=0;s<i;s++)if(o.strictDeepEqual(n[s],t))return!0
return!1},status:function(e,t){var r=e.httpResponse.statusCode
return"number"==typeof r&&r===t},error:function(e,t){
return"string"==typeof t&&e.error?t===e.error.code:t===!!e.error}},
listeners:(new n.SequentialExecutor).addNamedListeners((function(e){
e("RETRY_CHECK","retry",(function(e){var t=e.request._waiter
e.error&&"ResourceNotReady"===e.error.code&&(e.error.retryDelay=1e3*(t.config.delay||0))})),
e("CHECK_OUTPUT","extractData",s),e("CHECK_ERROR","extractError",s)})),wait:function(e,t){
"function"==typeof e&&(t=e,
e=void 0),e&&e.$waiter&&("number"==typeof(e=n.util.copy(e)).$waiter.delay&&(this.config.delay=e.$waiter.delay),
"number"==typeof e.$waiter.maxAttempts&&(this.config.maxAttempts=e.$waiter.maxAttempts),
delete e.$waiter)
var r=this.service.makeRequest(this.config.operation,e)
return r._waiter=this,r.response.maxRetries=this.config.maxAttempts,r.addListeners(this.listeners),
t&&r.send(t),r},setSuccess:function(e){
e.error=null,e.data=e.data||{},e.request.removeAllListeners("extractData")},setError:function(e,t){
e.data=null,e.error=n.util.error(e.error||new Error,{code:"ResourceNotReady",
message:"Resource is not in the state "+this.state,retryable:t})},loadWaiterConfig:function(e){
if(!this.service.api.waiters[e])throw new n.util.error(new Error,{code:"StateNotFoundError",
message:"State "+e+" not found."})
this.config=n.util.copy(this.service.api.waiters[e])}})},3975:(e,t,r)=>{
var n=r(9614),i=n.util.inherit,o=r(4509)
n.Response=i({constructor:function(e){this.request=e,this.data=null,this.error=null,
this.retryCount=0,
this.redirectCount=0,this.httpResponse=new n.HttpResponse,e&&(this.maxRetries=e.service.numRetries(),
this.maxRedirects=e.service.config.maxRedirects)},nextPage:function(e){
var t,r=this.request.service,i=this.request.operation
try{t=r.paginationConfig(i,!0)}catch(e){this.error=e}if(!this.hasNextPage()){if(e)e(this.error,null)
else if(this.error)throw this.error
return null}var o=n.util.copy(this.request.params)
if(this.nextPageTokens){var s=t.inputToken
"string"==typeof s&&(s=[s])
for(var a=0;a<s.length;a++)o[s[a]]=this.nextPageTokens[a]
return r.makeRequest(this.request.operation,o,e)}return e?e(null,null):null},hasNextPage:function(){
return this.cacheNextPageTokens(),!!this.nextPageTokens||void 0===this.nextPageTokens&&void 0},
cacheNextPageTokens:function(){
if(Object.prototype.hasOwnProperty.call(this,"nextPageTokens"))return this.nextPageTokens
this.nextPageTokens=void 0
var e=this.request.service.paginationConfig(this.request.operation)
if(!e)return this.nextPageTokens
if(this.nextPageTokens=null,e.moreResults&&!o.search(this.data,e.moreResults))return this.nextPageTokens
var t=e.outputToken
return"string"==typeof t&&(t=[t]),n.util.arrayEach.call(this,t,(function(e){
var t=o.search(this.data,e)
t&&(this.nextPageTokens=this.nextPageTokens||[],this.nextPageTokens.push(t))})),this.nextPageTokens}
})},6380:(e,t,r)=>{var n=r(9614)
n.SequentialExecutor=n.util.inherit({constructor:function(){this._events={}},listeners:function(e){
return this._events[e]?this._events[e].slice(0):[]},on:function(e,t,r){
return this._events[e]?r?this._events[e].unshift(t):this._events[e].push(t):this._events[e]=[t],this
},onAsync:function(e,t,r){return t._isAsync=!0,this.on(e,t,r)},removeListener:function(e,t){
var r=this._events[e]
if(r){for(var n=r.length,i=-1,o=0;o<n;++o)r[o]===t&&(i=o)
i>-1&&r.splice(i,1)}return this},removeAllListeners:function(e){
return e?delete this._events[e]:this._events={},this},emit:function(e,t,r){r||(r=function(){})
var n=this.listeners(e),i=n.length
return this.callListeners(n,t,r),i>0},callListeners:function(e,t,r,i){var o=this,s=i||null
function a(i){if(i&&(s=n.util.error(s||new Error,i),o._haltHandlersOnError))return r.call(o,s)
o.callListeners(e,t,r,s)}for(;e.length>0;){var u=e.shift()
if(u._isAsync)return void u.apply(o,t.concat([a]))
try{u.apply(o,t)}catch(e){s=n.util.error(s||new Error,e)}
if(s&&o._haltHandlersOnError)return void r.call(o,s)}r.call(o,s)},addListeners:function(e){
var t=this
return e._events&&(e=e._events),n.util.each(e,(function(e,r){"function"==typeof r&&(r=[r]),
n.util.arrayEach(r,(function(r){t.on(e,r)}))})),t},addNamedListener:function(e,t,r,n){
return this[e]=r,this.addListener(t,r,n),this},addNamedAsyncListener:function(e,t,r,n){
return r._isAsync=!0,this.addNamedListener(e,t,r,n)},addNamedListeners:function(e){var t=this
return e((function(){t.addNamedListener.apply(t,arguments)}),(function(){
t.addNamedAsyncListener.apply(t,arguments)})),this}
}),n.SequentialExecutor.prototype.addListener=n.SequentialExecutor.prototype.on,
e.exports=n.SequentialExecutor},173:(e,t,r)=>{
var n=r(9614),i=r(5863),o=r(1404),s=n.util.inherit,a=0,u=r(4040)
n.Service=s({constructor:function(e){
if(!this.loadServiceClass)throw n.util.error(new Error,"Service must be constructed with `new' operator")
if(e){if(e.region){var t=e.region
u.isFipsRegion(t)&&(e.region=u.getRealRegion(t),e.useFipsEndpoint=!0),u.isGlobalRegion(t)&&(e.region=u.getRealRegion(t))
}
"boolean"==typeof e.useDualstack&&"boolean"!=typeof e.useDualstackEndpoint&&(e.useDualstackEndpoint=e.useDualstack)
}var r=this.loadServiceClass(e||{})
if(r){var i=n.util.copy(e),o=new r(e)
return Object.defineProperty(o,"_originalConfig",{get:function(){return i},enumerable:!1,
configurable:!0}),o._clientId=++a,o}this.initialize(e)},initialize:function(e){
var t=n.config[this.serviceIdentifier]
if(this.config=new n.Config(n.config),t&&this.config.update(t,!0),e&&this.config.update(e,!0),
this.validateService(),
this.config.endpoint||o.configureEndpoint(this),this.config.endpoint=this.endpointFromTemplate(this.config.endpoint),
this.setEndpoint(this.config.endpoint),
n.SequentialExecutor.call(this),n.Service.addDefaultMonitoringListeners(this),
(this.config.clientSideMonitoring||n.Service._clientSideMonitoring)&&this.publisher){
var r=this.publisher
this.addNamedListener("PUBLISH_API_CALL","apiCall",(function(e){process.nextTick((function(){
r.eventHandler(e)}))})),this.addNamedListener("PUBLISH_API_ATTEMPT","apiCallAttempt",(function(e){
process.nextTick((function(){r.eventHandler(e)}))}))}},validateService:function(){},
loadServiceClass:function(e){var t=e
if(n.util.isEmpty(this.api)){
if(t.apiConfig)return n.Service.defineServiceApi(this.constructor,t.apiConfig)
if(this.constructor.services){(t=new n.Config(n.config)).update(e,!0)
var r=t.apiVersions[this.constructor.serviceIdentifier]
return r=r||t.apiVersion,this.getLatestServiceClass(r)}return null}return null},
getLatestServiceClass:function(e){
return e=this.getLatestServiceVersion(e),null===this.constructor.services[e]&&n.Service.defineServiceApi(this.constructor,e),
this.constructor.services[e]},getLatestServiceVersion:function(e){
if(!this.constructor.services||0===this.constructor.services.length)throw new Error("No services defined on "+this.constructor.serviceIdentifier)
if(e?n.util.isType(e,Date)&&(e=n.util.date.iso8601(e).split("T")[0]):e="latest",
Object.hasOwnProperty(this.constructor.services,e))return e
for(var t=Object.keys(this.constructor.services).sort(),r=null,i=t.length-1;i>=0;i--)if("*"!==t[i][t[i].length-1]&&(r=t[i]),
t[i].substr(0,10)<=e)return r
throw new Error("Could not find "+this.constructor.serviceIdentifier+" API to satisfy version constraint `"+e+"'")
},api:{},defaultRetryCount:3,customizeRequests:function(e){if(e){
if("function"!=typeof e)throw new Error("Invalid callback type '"+typeof e+"' provided in customizeRequests")
this.customRequestHandler=e}else this.customRequestHandler=null},makeRequest:function(e,t,r){
if("function"==typeof t&&(r=t,t=null),t=t||{},this.config.params){var i=this.api.operations[e]
i&&(t=n.util.copy(t),n.util.each(this.config.params,(function(e,r){
i.input.members[e]&&(void 0!==t[e]&&null!==t[e]||(t[e]=r))})))}var o=new n.Request(this,e,t)
return this.addAllRequestListeners(o),this.attachMonitoringEmitter(o),r&&o.send(r),o},
makeUnauthenticatedRequest:function(e,t,r){"function"==typeof t&&(r=t,t={})
var n=this.makeRequest(e,t).toUnauthenticated()
return r?n.send(r):n},waitFor:function(e,t,r){return new n.ResourceWaiter(this,e).wait(t,r)},
addAllRequestListeners:function(e){
for(var t=[n.events,n.EventListeners.Core,this.serviceInterface(),n.EventListeners.CorePost],r=0;r<t.length;r++)t[r]&&e.addListeners(t[r])
this.config.paramValidation||e.removeListener("validate",n.EventListeners.Core.VALIDATE_PARAMETERS),
this.config.logger&&e.addListeners(n.EventListeners.Logger),this.setupRequestListeners(e),
"function"==typeof this.constructor.prototype.customRequestHandler&&this.constructor.prototype.customRequestHandler(e),
Object.prototype.hasOwnProperty.call(this,"customRequestHandler")&&"function"==typeof this.customRequestHandler&&this.customRequestHandler(e)
},apiCallEvent:function(e){var t=e.service.api.operations[e.operation],r={Type:"ApiCall",
Api:t?t.name:e.operation,Version:1,Service:e.service.api.serviceId||e.service.api.endpointPrefix,
Region:e.httpRequest.region,MaxRetriesExceeded:0,UserAgent:e.httpRequest.getUserAgent()
},n=e.response
if(n.httpResponse.statusCode&&(r.FinalHttpStatusCode=n.httpResponse.statusCode),n.error){
var i=n.error
n.httpResponse.statusCode>299?(i.code&&(r.FinalAwsException=i.code),i.message&&(r.FinalAwsExceptionMessage=i.message)):((i.code||i.name)&&(r.FinalSdkException=i.code||i.name),
i.message&&(r.FinalSdkExceptionMessage=i.message))}return r},apiAttemptEvent:function(e){
var t=e.service.api.operations[e.operation],r={Type:"ApiCallAttempt",Api:t?t.name:e.operation,
Version:1,Service:e.service.api.serviceId||e.service.api.endpointPrefix,
Fqdn:e.httpRequest.endpoint.hostname,UserAgent:e.httpRequest.getUserAgent()},n=e.response
return n.httpResponse.statusCode&&(r.HttpStatusCode=n.httpResponse.statusCode),!e._unAuthenticated&&e.service.config.credentials&&e.service.config.credentials.accessKeyId&&(r.AccessKey=e.service.config.credentials.accessKeyId),
n.httpResponse.headers?(e.httpRequest.headers["x-amz-security-token"]&&(r.SessionToken=e.httpRequest.headers["x-amz-security-token"]),
n.httpResponse.headers["x-amzn-requestid"]&&(r.XAmznRequestId=n.httpResponse.headers["x-amzn-requestid"]),
n.httpResponse.headers["x-amz-request-id"]&&(r.XAmzRequestId=n.httpResponse.headers["x-amz-request-id"]),
n.httpResponse.headers["x-amz-id-2"]&&(r.XAmzId2=n.httpResponse.headers["x-amz-id-2"]),r):r},
attemptFailEvent:function(e){var t=this.apiAttemptEvent(e),r=e.response,n=r.error
return r.httpResponse.statusCode>299?(n.code&&(t.AwsException=n.code),n.message&&(t.AwsExceptionMessage=n.message)):((n.code||n.name)&&(t.SdkException=n.code||n.name),
n.message&&(t.SdkExceptionMessage=n.message)),t},attachMonitoringEmitter:function(e){
var t,r,i,o,s,a,u=0,c=this
e.on("validate",(function(){o=n.util.realClock.now(),a=Date.now()}),!0),e.on("sign",(function(){
r=n.util.realClock.now(),t=Date.now(),s=e.httpRequest.region,u++
}),!0),e.on("validateResponse",(function(){i=Math.round(n.util.realClock.now()-r)})),
e.addNamedListener("API_CALL_ATTEMPT","success",(function(){var r=c.apiAttemptEvent(e)
r.Timestamp=t,r.AttemptLatency=i>=0?i:0,r.Region=s,c.emit("apiCallAttempt",[r])})),
e.addNamedListener("API_CALL_ATTEMPT_RETRY","retry",(function(){var o=c.attemptFailEvent(e)
o.Timestamp=t,i=i||Math.round(n.util.realClock.now()-r),o.AttemptLatency=i>=0?i:0,o.Region=s,
c.emit("apiCallAttempt",[o])})),e.addNamedListener("API_CALL","complete",(function(){
var t=c.apiCallEvent(e)
if(t.AttemptCount=u,!(t.AttemptCount<=0)){t.Timestamp=a
var r=Math.round(n.util.realClock.now()-o)
t.Latency=r>=0?r:0
var i=e.response
i.error&&i.error.retryable&&"number"==typeof i.retryCount&&"number"==typeof i.maxRetries&&i.retryCount>=i.maxRetries&&(t.MaxRetriesExceeded=1),
c.emit("apiCall",[t])}}))},setupRequestListeners:function(e){},getSigningName:function(){
return this.api.signingName||this.api.endpointPrefix},getSignerClass:function(e){var t,r=null,i=""
return e&&(i=(r=(e.service.api.operations||{})[e.operation]||null)?r.authtype:""),
t=this.config.signatureVersion?this.config.signatureVersion:"v4"===i||"v4-unsigned-body"===i?"v4":this.api.signatureVersion,
n.Signers.RequestSigner.getVersion(t)},serviceInterface:function(){switch(this.api.protocol){
case"ec2":case"query":return n.EventListeners.Query
case"json":return n.EventListeners.Json
case"rest-json":return n.EventListeners.RestJson
case"rest-xml":return n.EventListeners.RestXml}
if(this.api.protocol)throw new Error("Invalid service `protocol' "+this.api.protocol+" in API config")
},successfulResponse:function(e){return e.httpResponse.statusCode<300},numRetries:function(){
return void 0!==this.config.maxRetries?this.config.maxRetries:this.defaultRetryCount},
retryDelays:function(e,t){return n.util.calculateRetryDelay(e,this.config.retryDelayOptions,t)},
retryableError:function(e){
return!!this.timeoutError(e)||!!this.networkingError(e)||!!this.expiredCredentialsError(e)||!!this.throttledError(e)||e.statusCode>=500
},networkingError:function(e){return"NetworkingError"===e.code},timeoutError:function(e){
return"TimeoutError"===e.code},expiredCredentialsError:function(e){
return"ExpiredTokenException"===e.code},clockSkewError:function(e){switch(e.code){
case"RequestTimeTooSkewed":case"RequestExpired":case"InvalidSignatureException":
case"SignatureDoesNotMatch":case"AuthFailure":case"RequestInTheFuture":return!0
default:return!1}},getSkewCorrectedDate:function(){
return new Date(Date.now()+this.config.systemClockOffset)},applyClockOffset:function(e){
e&&(this.config.systemClockOffset=e-Date.now())},isClockSkewed:function(e){
if(e)return Math.abs(this.getSkewCorrectedDate().getTime()-e)>=3e5},throttledError:function(e){
if(429===e.statusCode)return!0
switch(e.code){case"ProvisionedThroughputExceededException":case"Throttling":
case"ThrottlingException":case"RequestLimitExceeded":case"RequestThrottled":
case"RequestThrottledException":case"TooManyRequestsException":case"TransactionInProgressException":
case"EC2ThrottledException":return!0
default:return!1}},endpointFromTemplate:function(e){
return"string"!=typeof e?e:e.replace(/\{service\}/g,this.api.endpointPrefix).replace(/\{region\}/g,this.config.region).replace(/\{scheme\}/g,this.config.sslEnabled?"https":"http")
},setEndpoint:function(e){this.endpoint=new n.Endpoint(e,this.config)},
paginationConfig:function(e,t){var r=this.api.operations[e].paginator
if(!r){if(t){var i=new Error
throw n.util.error(i,"No pagination configuration for "+e)}return null}return r}}),
n.util.update(n.Service,{defineMethods:function(e){
n.util.each(e.prototype.api.operations,(function(t){
e.prototype[t]||("none"===e.prototype.api.operations[t].authtype?e.prototype[t]=function(e,r){
return this.makeUnauthenticatedRequest(t,e,r)}:e.prototype[t]=function(e,r){
return this.makeRequest(t,e,r)})}))},defineService:function(e,t,r){n.Service._serviceMap[e]=!0,
Array.isArray(t)||(r=t,t=[])
var i=s(n.Service,r||{})
if("string"==typeof e){n.Service.addVersions(i,t)
var o=i.serviceIdentifier||e
i.serviceIdentifier=o}else i.prototype.api=e,n.Service.defineMethods(i)
if(n.SequentialExecutor.call(this.prototype),!this.prototype.publisher&&n.util.clientSideMonitoring){
var a=n.util.clientSideMonitoring.Publisher,u=(0,n.util.clientSideMonitoring.configProvider)()
this.prototype.publisher=new a(u),u.enabled&&(n.Service._clientSideMonitoring=!0)}
return n.SequentialExecutor.call(i.prototype),n.Service.addDefaultMonitoringListeners(i.prototype),i
},addVersions:function(e,t){Array.isArray(t)||(t=[t]),e.services=e.services||{}
for(var r=0;r<t.length;r++)void 0===e.services[t[r]]&&(e.services[t[r]]=null)
e.apiVersions=Object.keys(e.services).sort()},defineServiceApi:function(e,t,r){var o=s(e,{
serviceIdentifier:e.serviceIdentifier})
function a(t){t.isApi?o.prototype.api=t:o.prototype.api=new i(t,{
serviceIdentifier:e.serviceIdentifier})}if("string"==typeof t){if(r)a(r)
else try{a(n.apiLoader(e.serviceIdentifier,t))}catch(r){throw n.util.error(r,{
message:"Could not find API configuration "+e.serviceIdentifier+"-"+t})}
Object.prototype.hasOwnProperty.call(e.services,t)||(e.apiVersions=e.apiVersions.concat(t).sort()),
e.services[t]=o}else a(t)
return n.Service.defineMethods(o),o},hasService:function(e){
return Object.prototype.hasOwnProperty.call(n.Service._serviceMap,e)},
addDefaultMonitoringListeners:function(e){
e.addNamedListener("MONITOR_EVENTS_BUBBLE","apiCallAttempt",(function(t){
var r=Object.getPrototypeOf(e)
r._events&&r.emit("apiCallAttempt",[t])
})),e.addNamedListener("CALL_EVENTS_BUBBLE","apiCall",(function(t){var r=Object.getPrototypeOf(e)
r._events&&r.emit("apiCall",[t])}))},_serviceMap:{}}),n.util.mixin(n.Service,n.SequentialExecutor),
e.exports=n.Service},4456:(e,t,r)=>{var n=r(9614),i=r(5456)
n.util.update(n.STS.prototype,{credentialsFrom:function(e,t){
return e?(t||(t=new n.TemporaryCredentials),t.expired=!1,t.accessKeyId=e.Credentials.AccessKeyId,
t.secretAccessKey=e.Credentials.SecretAccessKey,t.sessionToken=e.Credentials.SessionToken,
t.expireTime=e.Credentials.Expiration,t):null},assumeRoleWithWebIdentity:function(e,t){
return this.makeUnauthenticatedRequest("assumeRoleWithWebIdentity",e,t)},
assumeRoleWithSAML:function(e,t){return this.makeUnauthenticatedRequest("assumeRoleWithSAML",e,t)},
setupRequestListeners:function(e){e.addListener("validate",this.optInRegionalEndpoint,!0)},
optInRegionalEndpoint:function(e){var t=e.service,r=t.config
if(r.stsRegionalEndpoints=i(t._originalConfig,{env:"AWS_STS_REGIONAL_ENDPOINTS",
sharedConfig:"sts_regional_endpoints",clientConfig:"stsRegionalEndpoints"
}),"regional"===r.stsRegionalEndpoints&&t.isGlobalEndpoint){
if(!r.region)throw n.util.error(new Error,{code:"ConfigError",message:"Missing region in config"})
var o=r.endpoint.indexOf(".amazonaws.com"),s=r.endpoint.substring(0,o)+"."+r.region+r.endpoint.substring(o)
e.httpRequest.updateEndpoint(s),e.httpRequest.region=r.region}}})},9688:(e,t,r)=>{
var n=r(9614),i=n.util.inherit,o="presigned-expires"
function s(e){var t=e.httpRequest.headers[o],r=e.service.getSignerClass(e)
if(delete e.httpRequest.headers["User-Agent"],delete e.httpRequest.headers["X-Amz-User-Agent"],
r===n.Signers.V4){if(t>604800)throw n.util.error(new Error,{code:"InvalidExpiryTime",
message:"Presigning does not support expiry time greater than a week with SigV4 signing.",
retryable:!1})
e.httpRequest.headers[o]=t}else{if(r!==n.Signers.S3)throw n.util.error(new Error,{
message:"Presigning only supports S3 or SigV4 signing.",code:"UnsupportedSigner",retryable:!1})
var i=e.service?e.service.getSkewCorrectedDate():n.util.date.getDate()
e.httpRequest.headers[o]=parseInt(n.util.date.unixTimestamp(i)+t,10).toString()}}function a(e){
var t=e.httpRequest.endpoint,r=n.util.urlParse(e.httpRequest.path),i={}
r.search&&(i=n.util.queryStringParse(r.search.substr(1)))
var s=e.httpRequest.headers.Authorization.split(" ")
if("AWS"===s[0])s=s[1].split(":"),i.Signature=s.pop(),i.AWSAccessKeyId=s.join(":"),
n.util.each(e.httpRequest.headers,(function(e,t){
e===o&&(e="Expires"),0===e.indexOf("x-amz-meta-")&&(delete i[e],e=e.toLowerCase()),i[e]=t})),
delete e.httpRequest.headers[o],delete i.Authorization,delete i.Host
else if("AWS4-HMAC-SHA256"===s[0]){s.shift()
var a=s.join(" ").match(/Signature=(.*?)(?:,|\s|\r?\n|$)/)[1]
i["X-Amz-Signature"]=a,delete i.Expires}t.pathname=r.pathname,t.search=n.util.queryParamsToString(i)
}n.Signers.Presign=i({sign:function(e,t,r){if(e.httpRequest.headers[o]=t||3600,e.on("build",s),
e.on("sign",a),e.removeListener("afterBuild",n.EventListeners.Core.SET_CONTENT_LENGTH),
e.removeListener("afterBuild",n.EventListeners.Core.COMPUTE_SHA256),e.emit("beforePresign",[e]),!r){
if(e.build(),e.response.error)throw e.response.error
return n.util.urlFormat(e.httpRequest.endpoint)}e.build((function(){
this.response.error?r(this.response.error):r(null,n.util.urlFormat(e.httpRequest.endpoint))}))}}),
e.exports=n.Signers.Presign},2604:(e,t,r)=>{var n=r(9614),i=n.util.inherit
n.Signers.RequestSigner=i({constructor:function(e){this.request=e},setServiceClientId:function(e){
this.serviceClientId=e},getServiceClientId:function(){return this.serviceClientId}}),
n.Signers.RequestSigner.getVersion=function(e){switch(e){case"v2":return n.Signers.V2
case"v3":return n.Signers.V3
case"s3v4":case"v4":return n.Signers.V4
case"s3":return n.Signers.S3
case"v3https":return n.Signers.V3Https}throw new Error("Unknown signing version "+e)},r(7194),
r(6342),r(416),r(7203),r(1190),r(9688)},1190:(e,t,r)=>{var n=r(9614),i=n.util.inherit
n.Signers.S3=i(n.Signers.RequestSigner,{subResources:{acl:1,accelerate:1,analytics:1,cors:1,
lifecycle:1,delete:1,inventory:1,location:1,logging:1,metrics:1,notification:1,partNumber:1,
policy:1,requestPayment:1,replication:1,restore:1,tagging:1,torrent:1,uploadId:1,uploads:1,
versionId:1,versioning:1,versions:1,website:1},responseHeaders:{"response-content-type":1,
"response-content-language":1,"response-expires":1,"response-cache-control":1,
"response-content-disposition":1,"response-content-encoding":1},addAuthorization:function(e,t){
this.request.headers["presigned-expires"]||(this.request.headers["X-Amz-Date"]=n.util.date.rfc822(t)),
e.sessionToken&&(this.request.headers["x-amz-security-token"]=e.sessionToken)
var r=this.sign(e.secretAccessKey,this.stringToSign()),i="AWS "+e.accessKeyId+":"+r
this.request.headers.Authorization=i},stringToSign:function(){var e=this.request,t=[]
t.push(e.method),t.push(e.headers["Content-MD5"]||""),t.push(e.headers["Content-Type"]||""),
t.push(e.headers["presigned-expires"]||"")
var r=this.canonicalizedAmzHeaders()
return r&&t.push(r),t.push(this.canonicalizedResource()),t.join("\n")},
canonicalizedAmzHeaders:function(){var e=[]
n.util.each(this.request.headers,(function(t){t.match(/^x-amz-/i)&&e.push(t)})),
e.sort((function(e,t){return e.toLowerCase()<t.toLowerCase()?-1:1}))
var t=[]
return n.util.arrayEach.call(this,e,(function(e){
t.push(e.toLowerCase()+":"+String(this.request.headers[e]))})),t.join("\n")},
canonicalizedResource:function(){var e=this.request,t=e.path.split("?"),r=t[0],i=t[1],o=""
if(e.virtualHostedBucket&&(o+="/"+e.virtualHostedBucket),o+=r,i){var s=[]
n.util.arrayEach.call(this,i.split("&"),(function(e){var t=e.split("=")[0],r=e.split("=")[1]
if(this.subResources[t]||this.responseHeaders[t]){var n={name:t}
void 0!==r&&(this.subResources[t]?n.value=r:n.value=decodeURIComponent(r)),s.push(n)}})),
s.sort((function(e,t){return e.name<t.name?-1:1})),s.length&&(i=[],n.util.arrayEach(s,(function(e){
void 0===e.value?i.push(e.name):i.push(e.name+"="+e.value)})),o+="?"+i.join("&"))}return o},
sign:function(e,t){return n.util.crypto.hmac(e,t,"base64","sha1")}}),e.exports=n.Signers.S3},
7194:(e,t,r)=>{var n=r(9614),i=n.util.inherit
n.Signers.V2=i(n.Signers.RequestSigner,{addAuthorization:function(e,t){t||(t=n.util.date.getDate())
var r=this.request
r.params.Timestamp=n.util.date.iso8601(t),r.params.SignatureVersion="2",r.params.SignatureMethod="HmacSHA256",
r.params.AWSAccessKeyId=e.accessKeyId,e.sessionToken&&(r.params.SecurityToken=e.sessionToken),
delete r.params.Signature,
r.params.Signature=this.signature(e),r.body=n.util.queryParamsToString(r.params),
r.headers["Content-Length"]=r.body.length},signature:function(e){
return n.util.crypto.hmac(e.secretAccessKey,this.stringToSign(),"base64")},stringToSign:function(){
var e=[]
return e.push(this.request.method),e.push(this.request.endpoint.host.toLowerCase()),
e.push(this.request.pathname()),e.push(n.util.queryParamsToString(this.request.params)),e.join("\n")
}}),e.exports=n.Signers.V2},6342:(e,t,r)=>{var n=r(9614),i=n.util.inherit
n.Signers.V3=i(n.Signers.RequestSigner,{addAuthorization:function(e,t){var r=n.util.date.rfc822(t)
this.request.headers["X-Amz-Date"]=r,e.sessionToken&&(this.request.headers["x-amz-security-token"]=e.sessionToken),
this.request.headers["X-Amzn-Authorization"]=this.authorization(e,r)},authorization:function(e){
return"AWS3 AWSAccessKeyId="+e.accessKeyId+",Algorithm=HmacSHA256,SignedHeaders="+this.signedHeaders()+",Signature="+this.signature(e)
},signedHeaders:function(){var e=[]
return n.util.arrayEach(this.headersToSign(),(function(t){e.push(t.toLowerCase())})),
e.sort().join(";")},canonicalHeaders:function(){var e=this.request.headers,t=[]
return n.util.arrayEach(this.headersToSign(),(function(r){
t.push(r.toLowerCase().trim()+":"+String(e[r]).trim())})),t.sort().join("\n")+"\n"},
headersToSign:function(){var e=[]
return n.util.each(this.request.headers,(function(t){
("Host"===t||"Content-Encoding"===t||t.match(/^X-Amz/i))&&e.push(t)})),e},signature:function(e){
return n.util.crypto.hmac(e.secretAccessKey,this.stringToSign(),"base64")},stringToSign:function(){
var e=[]
return e.push(this.request.method),e.push("/"),e.push(""),e.push(this.canonicalHeaders()),
e.push(this.request.body),n.util.crypto.sha256(e.join("\n"))}}),e.exports=n.Signers.V3},
416:(e,t,r)=>{var n=r(9614),i=n.util.inherit
r(6342),n.Signers.V3Https=i(n.Signers.V3,{authorization:function(e){
return"AWS3-HTTPS AWSAccessKeyId="+e.accessKeyId+",Algorithm=HmacSHA256,Signature="+this.signature(e)
},stringToSign:function(){return this.request.headers["X-Amz-Date"]}}),e.exports=n.Signers.V3Https},
7203:(e,t,r)=>{var n=r(9614),i=r(6914),o=n.util.inherit,s="presigned-expires"
n.Signers.V4=o(n.Signers.RequestSigner,{constructor:function(e,t,r){
n.Signers.RequestSigner.call(this,e),
this.serviceName=t,r=r||{},this.signatureCache="boolean"!=typeof r.signatureCache||r.signatureCache,
this.operation=r.operation,this.signatureVersion=r.signatureVersion},algorithm:"AWS4-HMAC-SHA256",
addAuthorization:function(e,t){var r=n.util.date.iso8601(t).replace(/[:\-]|\.\d{3}/g,"")
this.isPresigned()?this.updateForPresigned(e,r):this.addHeaders(e,r),this.request.headers.Authorization=this.authorization(e,r)
},addHeaders:function(e,t){
this.request.headers["X-Amz-Date"]=t,e.sessionToken&&(this.request.headers["x-amz-security-token"]=e.sessionToken)
},updateForPresigned:function(e,t){var r=this.credentialString(t),i={"X-Amz-Date":t,
"X-Amz-Algorithm":this.algorithm,"X-Amz-Credential":e.accessKeyId+"/"+r,
"X-Amz-Expires":this.request.headers[s],"X-Amz-SignedHeaders":this.signedHeaders()}
e.sessionToken&&(i["X-Amz-Security-Token"]=e.sessionToken),this.request.headers["Content-Type"]&&(i["Content-Type"]=this.request.headers["Content-Type"]),
this.request.headers["Content-MD5"]&&(i["Content-MD5"]=this.request.headers["Content-MD5"]),
this.request.headers["Cache-Control"]&&(i["Cache-Control"]=this.request.headers["Cache-Control"]),
n.util.each.call(this,this.request.headers,(function(e,t){if(e!==s&&this.isSignableHeader(e)){
var r=e.toLowerCase()
0===r.indexOf("x-amz-meta-")?i[r]=t:0===r.indexOf("x-amz-")&&(i[e]=t)}}))
var o=this.request.path.indexOf("?")>=0?"&":"?"
this.request.path+=o+n.util.queryParamsToString(i)},authorization:function(e,t){
var r=[],n=this.credentialString(t)
return r.push(this.algorithm+" Credential="+e.accessKeyId+"/"+n),r.push("SignedHeaders="+this.signedHeaders()),
r.push("Signature="+this.signature(e,t)),r.join(", ")},signature:function(e,t){
var r=i.getSigningKey(e,t.substr(0,8),this.request.region,this.serviceName,this.signatureCache)
return n.util.crypto.hmac(r,this.stringToSign(t),"hex")},stringToSign:function(e){var t=[]
return t.push("AWS4-HMAC-SHA256"),t.push(e),t.push(this.credentialString(e)),t.push(this.hexEncodedHash(this.canonicalString())),
t.join("\n")},canonicalString:function(){var e=[],t=this.request.pathname()
return"s3"!==this.serviceName&&"s3v4"!==this.signatureVersion&&(t=n.util.uriEscapePath(t)),
e.push(this.request.method),
e.push(t),e.push(this.request.search()),e.push(this.canonicalHeaders()+"\n"),
e.push(this.signedHeaders()),e.push(this.hexEncodedBodyHash()),e.join("\n")},
canonicalHeaders:function(){var e=[]
n.util.each.call(this,this.request.headers,(function(t,r){e.push([t,r])})),e.sort((function(e,t){
return e[0].toLowerCase()<t[0].toLowerCase()?-1:1}))
var t=[]
return n.util.arrayEach.call(this,e,(function(e){var r=e[0].toLowerCase()
if(this.isSignableHeader(r)){var i=e[1]
if(null==i||"function"!=typeof i.toString)throw n.util.error(new Error("Header "+r+" contains invalid value"),{
code:"InvalidHeader"})
t.push(r+":"+this.canonicalHeaderValues(i.toString()))}})),t.join("\n")},
canonicalHeaderValues:function(e){return e.replace(/\s+/g," ").replace(/^\s+|\s+$/g,"")},
signedHeaders:function(){var e=[]
return n.util.each.call(this,this.request.headers,(function(t){t=t.toLowerCase(),
this.isSignableHeader(t)&&e.push(t)})),e.sort().join(";")},credentialString:function(e){
return i.createScope(e.substr(0,8),this.request.region,this.serviceName)},
hexEncodedHash:function(e){return n.util.crypto.sha256(e,"hex")},hexEncodedBodyHash:function(){
var e=this.request
return this.isPresigned()&&["s3","s3-object-lambda"].indexOf(this.serviceName)>-1&&!e.body?"UNSIGNED-PAYLOAD":e.headers["X-Amz-Content-Sha256"]?e.headers["X-Amz-Content-Sha256"]:this.hexEncodedHash(this.request.body||"")
},
unsignableHeaders:["authorization","content-type","content-length","user-agent",s,"expect","x-amzn-trace-id"],
isSignableHeader:function(e){
return 0===e.toLowerCase().indexOf("x-amz-")||this.unsignableHeaders.indexOf(e)<0},
isPresigned:function(){return!!this.request.headers[s]}}),e.exports=n.Signers.V4},6914:(e,t,r)=>{
var n=r(9614),i={},o=[],s="aws4_request"
e.exports={createScope:function(e,t,r){return[e.substr(0,8),t,r,s].join("/")},
getSigningKey:function(e,t,r,a,u){
var c=[n.util.crypto.hmac(e.secretAccessKey,e.accessKeyId,"base64"),t,r,a].join("_")
if((u=!1!==u)&&c in i)return i[c]
var p=n.util.crypto.hmac("AWS4"+e.secretAccessKey,t,"buffer"),l=n.util.crypto.hmac(p,r,"buffer"),h=n.util.crypto.hmac(l,a,"buffer"),f=n.util.crypto.hmac(h,s,"buffer")
return u&&(i[c]=f,o.push(c),o.length>50&&delete i[o.shift()]),f},emptyCache:function(){i={},o=[]}}},
1793:e=>{function t(e,t){this.currentState=t||null,this.states=e||{}}
t.prototype.runTo=function(e,t,r,n){"function"==typeof e&&(n=r,r=t,t=e,e=null)
var i=this,o=i.states[i.currentState]
o.fn.call(r||i,n,(function(n){if(n){if(!o.fail)return t?t.call(r,n):null
i.currentState=o.fail}else{if(!o.accept)return t?t.call(r):null
i.currentState=o.accept}if(i.currentState===e)return t?t.call(r,n):null
i.runTo(e,t,r,n)}))},t.prototype.addState=function(e,t,r,n){return"function"==typeof t?(n=t,t=null,
r=null):"function"==typeof r&&(n=r,r=null),this.currentState||(this.currentState=e),this.states[e]={
accept:t,fail:r,fn:n},this},e.exports=t},2662:(e,t,r)=>{var n,i={environment:"nodejs",
engine:function(){if(i.isBrowser()&&"undefined"!=typeof navigator)return navigator.userAgent
var e=process.platform+"/"+process.version
return process.env.AWS_EXECUTION_ENV&&(e+=" exec-env/"+process.env.AWS_EXECUTION_ENV),e},
userAgent:function(){var e=i.environment,t="aws-sdk-"+e+"/"+r(9614).VERSION
return"nodejs"===e&&(t+=" "+i.engine()),t},uriEscape:function(e){var t=encodeURIComponent(e)
return(t=t.replace(/[^A-Za-z0-9_.~\-%]+/g,escape)).replace(/[*]/g,(function(e){
return"%"+e.charCodeAt(0).toString(16).toUpperCase()}))},uriEscapePath:function(e){var t=[]
return i.arrayEach(e.split("/"),(function(e){t.push(i.uriEscape(e))})),t.join("/")},
urlParse:function(e){return i.url.parse(e)},urlFormat:function(e){return i.url.format(e)},
queryStringParse:function(e){return i.querystring.parse(e)},queryParamsToString:function(e){
var t=[],r=i.uriEscape,n=Object.keys(e).sort()
return i.arrayEach(n,(function(n){var o=e[n],s=r(n),a=s+"="
if(Array.isArray(o)){var u=[]
i.arrayEach(o,(function(e){u.push(r(e))})),a=s+"="+u.sort().join("&"+s+"=")
}else null!=o&&(a=s+"="+r(o))
t.push(a)})),t.join("&")},readFileSync:function(e){
return i.isBrowser()?null:r(8022).readFileSync(e,"utf-8")},base64:{encode:function(e){
if("number"==typeof e)throw i.error(new Error("Cannot base64 encode number "+e))
return null==e?e:i.buffer.toBuffer(e).toString("base64")},decode:function(e){
if("number"==typeof e)throw i.error(new Error("Cannot base64 decode number "+e))
return null==e?e:i.buffer.toBuffer(e,"base64")}},buffer:{toBuffer:function(e,t){
return"function"==typeof i.Buffer.from&&i.Buffer.from!==Uint8Array.from?i.Buffer.from(e,t):new i.Buffer(e,t)
},alloc:function(e,t,r){
if("number"!=typeof e)throw new Error("size passed to alloc must be a number.")
if("function"==typeof i.Buffer.alloc)return i.Buffer.alloc(e,t,r)
var n=new i.Buffer(e)
return void 0!==t&&"function"==typeof n.fill&&n.fill(t,void 0,void 0,r),n},toStream:function(e){
i.Buffer.isBuffer(e)||(e=i.buffer.toBuffer(e))
var t=new i.stream.Readable,r=0
return t._read=function(n){if(r>=e.length)return t.push(null)
var i=r+n
i>e.length&&(i=e.length),t.push(e.slice(r,i)),r=i},t},concat:function(e){var t,r,n=0,o=0
for(r=0;r<e.length;r++)n+=e[r].length
for(t=i.buffer.alloc(n),r=0;r<e.length;r++)e[r].copy(t,o),o+=e[r].length
return t}},string:{byteLength:function(e){if(null==e)return 0
if("string"==typeof e&&(e=i.buffer.toBuffer(e)),"number"==typeof e.byteLength)return e.byteLength
if("number"==typeof e.length)return e.length
if("number"==typeof e.size)return e.size
if("string"==typeof e.path)return r(8022).lstatSync(e.path).size
throw i.error(new Error("Cannot determine length of "+e),{object:e})},upperFirst:function(e){
return e[0].toUpperCase()+e.substr(1)},lowerFirst:function(e){return e[0].toLowerCase()+e.substr(1)}
},ini:{parse:function(e){var t,r={}
return i.arrayEach(e.split(/\r?\n/),(function(e){
var n=(e=e.split(/(^|\s)[;#]/)[0]).match(/^\s*\[([^\[\]]+)\]\s*$/)
if(n){
if("__proto__"===(t=n[1])||"__proto__"===t.split(/\s/)[1])throw i.error(new Error("Cannot load profile name '"+t+"' from shared ini file."))
}else if(t){var o=e.match(/^\s*(.+?)\s*=\s*(.+?)\s*$/)
o&&(r[t]=r[t]||{},r[t][o[1]]=o[2])}})),r}},fn:{noop:function(){},callback:function(e){if(e)throw e},
makeAsync:function(e,t){return t&&t<=e.length?e:function(){
var t=Array.prototype.slice.call(arguments,0)
t.pop()(e.apply(null,t))}}},date:{getDate:function(){
return n||(n=r(9614)),n.config.systemClockOffset?new Date((new Date).getTime()+n.config.systemClockOffset):new Date
},iso8601:function(e){
return void 0===e&&(e=i.date.getDate()),e.toISOString().replace(/\.\d{3}Z$/,"Z")},
rfc822:function(e){return void 0===e&&(e=i.date.getDate()),e.toUTCString()},
unixTimestamp:function(e){return void 0===e&&(e=i.date.getDate()),e.getTime()/1e3},from:function(e){
return"number"==typeof e?new Date(1e3*e):new Date(e)},format:function(e,t){return t||(t="iso8601"),
i.date[t](i.date.from(e))},parseTimestamp:function(e){if("number"==typeof e)return new Date(1e3*e)
if(e.match(/^\d+$/))return new Date(1e3*e)
if(e.match(/^\d{4}/))return new Date(e)
if(e.match(/^\w{3},/))return new Date(e)
throw i.error(new Error("unhandled timestamp format: "+e),{code:"TimestampParserError"})}},crypto:{
crc32Table:[0,1996959894,3993919788,2567524794,124634137,1886057615,3915621685,2657392035,249268274,2044508324,3772115230,2547177864,162941995,2125561021,3887607047,2428444049,498536548,1789927666,4089016648,2227061214,450548861,1843258603,4107580753,2211677639,325883990,1684777152,4251122042,2321926636,335633487,1661365465,4195302755,2366115317,997073096,1281953886,3579855332,2724688242,1006888145,1258607687,3524101629,2768942443,901097722,1119000684,3686517206,2898065728,853044451,1172266101,3705015759,2882616665,651767980,1373503546,3369554304,3218104598,565507253,1454621731,3485111705,3099436303,671266974,1594198024,3322730930,2970347812,795835527,1483230225,3244367275,3060149565,1994146192,31158534,2563907772,4023717930,1907459465,112637215,2680153253,3904427059,2013776290,251722036,2517215374,3775830040,2137656763,141376813,2439277719,3865271297,1802195444,476864866,2238001368,4066508878,1812370925,453092731,2181625025,4111451223,1706088902,314042704,2344532202,4240017532,1658658271,366619977,2362670323,4224994405,1303535960,984961486,2747007092,3569037538,1256170817,1037604311,2765210733,3554079995,1131014506,879679996,2909243462,3663771856,1141124467,855842277,2852801631,3708648649,1342533948,654459306,3188396048,3373015174,1466479909,544179635,3110523913,3462522015,1591671054,702138776,2966460450,3352799412,1504918807,783551873,3082640443,3233442989,3988292384,2596254646,62317068,1957810842,3939845945,2647816111,81470997,1943803523,3814918930,2489596804,225274430,2053790376,3826175755,2466906013,167816743,2097651377,4027552580,2265490386,503444072,1762050814,4150417245,2154129355,426522225,1852507879,4275313526,2312317920,282753626,1742555852,4189708143,2394877945,397917763,1622183637,3604390888,2714866558,953729732,1340076626,3518719985,2797360999,1068828381,1219638859,3624741850,2936675148,906185462,1090812512,3747672003,2825379669,829329135,1181335161,3412177804,3160834842,628085408,1382605366,3423369109,3138078467,570562233,1426400815,3317316542,2998733608,733239954,1555261956,3268935591,3050360625,752459403,1541320221,2607071920,3965973030,1969922972,40735498,2617837225,3943577151,1913087877,83908371,2512341634,3803740692,2075208622,213261112,2463272603,3855990285,2094854071,198958881,2262029012,4057260610,1759359992,534414190,2176718541,4139329115,1873836001,414664567,2282248934,4279200368,1711684554,285281116,2405801727,4167216745,1634467795,376229701,2685067896,3608007406,1308918612,956543938,2808555105,3495958263,1231636301,1047427035,2932959818,3654703836,1088359270,936918e3,2847714899,3736837829,1202900863,817233897,3183342108,3401237130,1404277552,615818150,3134207493,3453421203,1423857449,601450431,3009837614,3294710456,1567103746,711928724,3020668471,3272380065,1510334235,755167117],
crc32:function(e){var t=i.crypto.crc32Table,r=-1
"string"==typeof e&&(e=i.buffer.toBuffer(e))
for(var n=0;n<e.length;n++)r=r>>>8^t[255&(r^e.readUInt8(n))]
return(-1^r)>>>0},hmac:function(e,t,r,n){return r||(r="binary"),"buffer"===r&&(r=void 0),
n||(n="sha256"),
"string"==typeof t&&(t=i.buffer.toBuffer(t)),i.crypto.lib.createHmac(n,e).update(t).digest(r)},
md5:function(e,t,r){return i.crypto.hash("md5",e,t,r)},sha256:function(e,t,r){
return i.crypto.hash("sha256",e,t,r)},hash:function(e,t,r,n){var o=i.crypto.createHash(e)
r||(r="binary"),"buffer"===r&&(r=void 0),"string"==typeof t&&(t=i.buffer.toBuffer(t))
var s=i.arraySliceFn(t),a=i.Buffer.isBuffer(t)
if(i.isBrowser()&&"undefined"!=typeof ArrayBuffer&&t&&t.buffer instanceof ArrayBuffer&&(a=!0),
n&&"object"==typeof t&&"function"==typeof t.on&&!a)t.on("data",(function(e){o.update(e)})),
t.on("error",(function(e){n(e)})),t.on("end",(function(){n(null,o.digest(r))}))
else{if(!n||!s||a||"undefined"==typeof FileReader){
i.isBrowser()&&"object"==typeof t&&!a&&(t=new i.Buffer(new Uint8Array(t)))
var u=o.update(t).digest(r)
return n&&n(null,u),u}var c=0,p=new FileReader
p.onerror=function(){n(new Error("Failed to read data."))},p.onload=function(){
var e=new i.Buffer(new Uint8Array(p.result))
o.update(e),c+=e.length,p._continueReading()},p._continueReading=function(){
if(c>=t.size)n(null,o.digest(r))
else{var e=c+524288
e>t.size&&(e=t.size),p.readAsArrayBuffer(s.call(t,c,e))}},p._continueReading()}},toHex:function(e){
for(var t=[],r=0;r<e.length;r++)t.push(("0"+e.charCodeAt(r).toString(16)).substr(-2,2))
return t.join("")},createHash:function(e){return i.crypto.lib.createHash(e)}},abort:{},
each:function(e,t){
for(var r in e)if(Object.prototype.hasOwnProperty.call(e,r)&&t.call(this,r,e[r])===i.abort)break},
arrayEach:function(e,t){
for(var r in e)if(Object.prototype.hasOwnProperty.call(e,r)&&t.call(this,e[r],parseInt(r,10))===i.abort)break
},update:function(e,t){return i.each(t,(function(t,r){e[t]=r})),e},merge:function(e,t){
return i.update(i.copy(e),t)},copy:function(e){if(null==e)return e
var t={}
for(var r in e)t[r]=e[r]
return t},isEmpty:function(e){for(var t in e)if(Object.prototype.hasOwnProperty.call(e,t))return!1
return!0},arraySliceFn:function(e){var t=e.slice||e.webkitSlice||e.mozSlice
return"function"==typeof t?t:null},isType:function(e,t){
return"function"==typeof t&&(t=i.typeName(t)),Object.prototype.toString.call(e)==="[object "+t+"]"},
typeName:function(e){if(Object.prototype.hasOwnProperty.call(e,"name"))return e.name
var t=e.toString(),r=t.match(/^\s*function (.+)\(/)
return r?r[1]:t},error:function(e,t){var r=null
return"string"==typeof e.message&&""!==e.message&&("string"==typeof t||t&&t.message)&&((r=i.copy(e)).message=e.message),
e.message=e.message||null,
"string"==typeof t?e.message=t:"object"==typeof t&&null!==t&&(i.update(e,t),
t.message&&(e.message=t.message),
(t.code||t.name)&&(e.code=t.code||t.name),t.stack&&(e.stack=t.stack)),
"function"==typeof Object.defineProperty&&(Object.defineProperty(e,"name",{writable:!0,enumerable:!1
}),Object.defineProperty(e,"message",{enumerable:!0
})),e.name=String(t&&t.name||e.name||e.code||"Error"),e.time=new Date,r&&(e.originalError=r),e},
inherit:function(e,t){var r=null
if(void 0===t)t=e,e=Object,r={}
else{var n=function(){}
n.prototype=e.prototype,r=new n}return t.constructor===Object&&(t.constructor=function(){
if(e!==Object)return e.apply(this,arguments)
}),t.constructor.prototype=r,i.update(t.constructor.prototype,t),t.constructor.__super__=e,
t.constructor},mixin:function(){
for(var e=arguments[0],t=1;t<arguments.length;t++)for(var r in arguments[t].prototype){
var n=arguments[t].prototype[r]
"constructor"!==r&&(e.prototype[r]=n)}return e},hideProperties:function(e,t){
"function"==typeof Object.defineProperty&&i.arrayEach(t,(function(t){Object.defineProperty(e,t,{
enumerable:!1,writable:!0,configurable:!0})}))},property:function(e,t,r,n,i){var o={configurable:!0,
enumerable:void 0===n||n}
"function"!=typeof r||i?(o.value=r,o.writable=!0):o.get=r,Object.defineProperty(e,t,o)},
memoizedProperty:function(e,t,r,n){var o=null
i.property(e,t,(function(){return null===o&&(o=r()),o}),n)},hoistPayloadMember:function(e){
var t=e.request,r=t.operation,n=t.service.api.operations[r],o=n.output
if(o.payload&&!n.hasEventOutput){var s=o.members[o.payload],a=e.data[o.payload]
"structure"===s.type&&i.each(a,(function(t,r){i.property(e.data,t,r,!1)}))}},
computeSha256:function(e,t){if(i.isNode()){var n=i.stream.Stream,o=r(8022)
if("function"==typeof n&&e instanceof n){
if("string"!=typeof e.path)return t(new Error("Non-file stream objects are not supported with SigV4"))
var s={}
"number"==typeof e.start&&(s.start=e.start),"number"==typeof e.end&&(s.end=e.end),
e=o.createReadStream(e.path,s)}}i.crypto.sha256(e,"hex",(function(e,r){e?t(e):t(null,r)}))},
isClockSkewed:function(e){
if(e)return i.property(n.config,"isClockSkewed",Math.abs((new Date).getTime()-e)>=3e5,!1),
n.config.isClockSkewed},applyClockOffset:function(e){
e&&(n.config.systemClockOffset=e-(new Date).getTime())},extractRequestId:function(e){
var t=e.httpResponse.headers["x-amz-request-id"]||e.httpResponse.headers["x-amzn-requestid"]
!t&&e.data&&e.data.ResponseMetadata&&(t=e.data.ResponseMetadata.RequestId),t&&(e.requestId=t),
e.error&&(e.error.requestId=t)},addPromises:function(e,t){var r=!1
void 0===t&&n&&n.config&&(t=n.config.getPromisesDependency()),void 0===t&&"undefined"!=typeof Promise&&(t=Promise),
"function"!=typeof t&&(r=!0),Array.isArray(e)||(e=[e])
for(var i=0;i<e.length;i++){var o=e[i]
r?o.deletePromisesFromClass&&o.deletePromisesFromClass():o.addPromisesToClass&&o.addPromisesToClass(t)
}},promisifyMethod:function(e,t){return function(){
var r=this,n=Array.prototype.slice.call(arguments)
return new t((function(t,i){n.push((function(e,r){e?i(e):t(r)})),r[e].apply(r,n)}))}},
isDualstackAvailable:function(e){if(!e)return!1
var t=r(7752)
return"string"!=typeof e&&(e=e.serviceIdentifier),!("string"!=typeof e||!t.hasOwnProperty(e)||!t[e].dualstackAvailable)
},calculateRetryDelay:function(e,t,r){t||(t={})
var n=t.customBackoff||null
if("function"==typeof n)return n(e,r)
var i="number"==typeof t.base?t.base:100
return Math.random()*(Math.pow(2,e)*i)},handleRequestWithRetries:function(e,t,r){t||(t={})
var o=n.HttpClient.getInstance(),s=t.httpOptions||{},a=0,u=function(e){var n=t.maxRetries||0
if(e&&"TimeoutError"===e.code&&(e.retryable=!0),e&&e.retryable&&a<n){
var o=i.calculateRetryDelay(a,t.retryDelayOptions,e)
if(o>=0)return a++,void setTimeout(c,o+(e.retryAfter||0))}r(e)},c=function(){var t=""
o.handleRequest(e,s,(function(e){e.on("data",(function(e){t+=e.toString()})),e.on("end",(function(){
var n=e.statusCode
if(n<300)r(null,t)
else{var o=1e3*parseInt(e.headers["retry-after"],10)||0,s=i.error(new Error,{statusCode:n,
retryable:n>=500||429===n})
o&&s.retryable&&(s.retryAfter=o),u(s)}}))}),u)}
n.util.defer(c)},uuid:{v4:function(){return r(5877).v4()}},convertPayloadToString:function(e){
var t=e.request,r=t.operation,n=t.service.api.operations[r].output||{}
n.payload&&e.data[n.payload]&&(e.data[n.payload]=e.data[n.payload].toString())},defer:function(e){
"object"==typeof process&&"function"==typeof process.nextTick?process.nextTick(e):"function"==typeof setImmediate?setImmediate(e):setTimeout(e,0)
},getRequestPayloadShape:function(e){var t=e.service.api.operations
if(t){var r=(t||{})[e.operation]
if(r&&r.input&&r.input.payload)return r.input.members[r.input.payload]}},
getProfilesFromSharedConfig:function(e,t){var r={},n={}
process.env[i.configOptInEnv]&&(n=e.loadFrom({isConfig:!0,
filename:process.env[i.sharedConfigFileEnv]}))
var o={}
try{o=e.loadFrom({filename:t||process.env[i.configOptInEnv]&&process.env[i.sharedCredentialsFileEnv]
})}catch(e){if(!process.env[i.configOptInEnv])throw e}
for(var s=0,a=Object.keys(n);s<a.length;s++)r[a[s]]=u(r[a[s]]||{},n[a[s]])
for(s=0,a=Object.keys(o);s<a.length;s++)r[a[s]]=u(r[a[s]]||{},o[a[s]])
return r
function u(e,t){for(var r=0,n=Object.keys(t);r<n.length;r++)e[n[r]]=t[n[r]]
return e}},ARN:{validate:function(e){return e&&0===e.indexOf("arn:")&&e.split(":").length>=6},
parse:function(e){var t=e.split(":")
return{partition:t[1],service:t[2],region:t[3],accountId:t[4],resource:t.slice(5).join(":")}},
build:function(e){
if(void 0===e.service||void 0===e.region||void 0===e.accountId||void 0===e.resource)throw i.error(new Error("Input ARN object is invalid"))
return"arn:"+(e.partition||"aws")+":"+e.service+":"+e.region+":"+e.accountId+":"+e.resource}},
defaultProfile:"default",configOptInEnv:"AWS_SDK_LOAD_CONFIG",
sharedCredentialsFileEnv:"AWS_SHARED_CREDENTIALS_FILE",sharedConfigFileEnv:"AWS_CONFIG_FILE",
imdsDisabledEnv:"AWS_EC2_METADATA_DISABLED"}
e.exports=i},5106:(e,t,r)=>{var n=r(2662),i=r(8136)
function o(){}function s(e,t){
for(var r=e.getElementsByTagName(t),n=0,i=r.length;n<i;n++)if(r[n].parentNode===e)return r[n]}
function a(e,t){switch(t||(t={}),t.type){case"structure":return u(e,t)
case"map":return function(e,t){
for(var r={},n=t.key.name||"key",i=t.value.name||"value",o=t.flattened?t.name:"entry",u=e.firstElementChild;u;){
if(u.nodeName===o){var c=s(u,n).textContent,p=s(u,i)
r[c]=a(p,t.value)}u=u.nextElementSibling}return r}(e,t)
case"list":return function(e,t){
for(var r=[],n=t.flattened?t.name:t.member.name||"member",i=e.firstElementChild;i;)i.nodeName===n&&r.push(a(i,t.member)),
i=i.nextElementSibling
return r}(e,t)
case void 0:case null:return function(e){if(null==e)return""
if(!e.firstElementChild)return null===e.parentNode.parentNode?{}:0===e.childNodes.length?"":e.textContent
for(var t={type:"structure",members:{}},r=e.firstElementChild;r;){var n=r.nodeName
Object.prototype.hasOwnProperty.call(t.members,n)?t.members[n].type="list":t.members[n]={name:n},
r=r.nextElementSibling}return u(e,t)}(e)
default:return function(e,t){if(e.getAttribute){var r=e.getAttribute("encoding")
"base64"===r&&(t=new i.create({type:r}))}var n=e.textContent
return""===n&&(n=null),"function"==typeof t.toType?t.toType(n):n}(e,t)}}function u(e,t){var r={}
return null===e||n.each(t.members,(function(n,i){if(i.isXmlAttribute){
if(Object.prototype.hasOwnProperty.call(e.attributes,i.name)){var o=e.attributes[i.name].value
r[n]=a({textContent:o},i)}}else{var u=i.flattened?e:s(e,i.name)
u?r[n]=a(u,i):i.flattened||"list"!==i.type||t.api.xmlNoDefaultLists||(r[n]=i.defaultValue)}})),r}
o.prototype.parse=function(e,t){if(""===e.replace(/^\s+/,""))return{}
var r,i
try{if(window.DOMParser){try{r=(new DOMParser).parseFromString(e,"text/xml")}catch(e){
throw n.error(new Error("Parse error in document"),{originalError:e,code:"XMLParserError",
retryable:!0})}if(null===r.documentElement)throw n.error(new Error("Cannot parse empty document."),{
code:"XMLParserError",retryable:!0})
var o=r.getElementsByTagName("parsererror")[0]
if(o&&(o.parentNode===r||"body"===o.parentNode.nodeName||o.parentNode.parentNode===r||"body"===o.parentNode.parentNode.nodeName)){
var u=o.getElementsByTagName("div")[0]||o
throw n.error(new Error(u.textContent||"Parser error in document"),{code:"XMLParserError",
retryable:!0})}}else{if(!window.ActiveXObject)throw new Error("Cannot load XML parser")
if((r=new window.ActiveXObject("Microsoft.XMLDOM")).async=!1,!r.loadXML(e))throw n.error(new Error("Parse error in document"),{
code:"XMLParserError",retryable:!0})}}catch(e){i=e}if(r&&r.documentElement&&!i){
var c=a(r.documentElement,t),p=s(r.documentElement,"ResponseMetadata")
return p&&(c.ResponseMetadata=a(p,{})),c}if(i)throw n.error(i||new Error,{code:"XMLParserError",
retryable:!0})
return{}},e.exports=o},2369:(e,t,r)=>{var n=r(2662),i=r(8700).XmlNode,o=r(5009).XmlText
function s(){}function a(e,t,r){switch(r.type){case"structure":return function(e,t,r){
n.arrayEach(r.memberNames,(function(n){var o=r.members[n]
if("body"===o.location){var s=t[n],c=o.name
if(null!=s)if(o.isXmlAttribute)e.addAttribute(c,s)
else if(o.flattened)a(e,s,o)
else{var p=new i(c)
e.addChildNode(p),u(p,o),a(p,s,o)}}}))}(e,t,r)
case"map":return function(e,t,r){var o=r.key.name||"key",s=r.value.name||"value"
n.each(t,(function(t,n){var u=new i(r.flattened?r.name:"entry")
e.addChildNode(u)
var c=new i(o),p=new i(s)
u.addChildNode(c),u.addChildNode(p),a(c,t,r.key),a(p,n,r.value)}))}(e,t,r)
case"list":return function(e,t,r){r.flattened?n.arrayEach(t,(function(t){
var n=r.member.name||r.name,o=new i(n)
e.addChildNode(o),a(o,t,r.member)})):n.arrayEach(t,(function(t){
var n=r.member.name||"member",o=new i(n)
e.addChildNode(o),a(o,t,r.member)}))}(e,t,r)
default:return function(e,t,r){e.addChildNode(new o(r.toWireFormat(t)))}(e,t,r)}}function u(e,t,r){
var n,i="xmlns"
t.xmlNamespaceUri?(n=t.xmlNamespaceUri,t.xmlNamespacePrefix&&(i+=":"+t.xmlNamespacePrefix)):r&&t.api.xmlNamespaceUri&&(n=t.api.xmlNamespaceUri),
n&&e.addAttribute(i,n)}s.prototype.toXML=function(e,t,r,n){var o=new i(r)
return u(o,t,!0),a(o,e,t),o.children.length>0||n?o.toString():""},e.exports=s},5373:e=>{e.exports={
escapeAttribute:function(e){
return e.replace(/&/g,"&amp;").replace(/'/g,"&apos;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/"/g,"&quot;")
}}},5077:e=>{e.exports={escapeElement:function(e){
return e.replace(/&/g,"&amp;").replace(/</g,"&lt;").replace(/>/g,"&gt;").replace(/\r/g,"&#x0D;").replace(/\n/g,"&#x0A;").replace(/\u0085/g,"&#x85;").replace(/\u2028/,"&#x2028;")
}}},8700:(e,t,r)=>{var n=r(5373).escapeAttribute
function i(e,t){void 0===t&&(t=[]),this.name=e,this.children=t,this.attributes={}}
i.prototype.addAttribute=function(e,t){return this.attributes[e]=t,this
},i.prototype.addChildNode=function(e){return this.children.push(e),this
},i.prototype.removeAttribute=function(e){return delete this.attributes[e],this},
i.prototype.toString=function(){
for(var e=Boolean(this.children.length),t="<"+this.name,r=this.attributes,i=0,o=Object.keys(r);i<o.length;i++){
var s=o[i],a=r[s]
null!=a&&(t+=" "+s+'="'+n(""+a)+'"')}return t+(e?">"+this.children.map((function(e){
return e.toString()})).join("")+"</"+this.name+">":"/>")},e.exports={XmlNode:i}},5009:(e,t,r)=>{
var n=r(5077).escapeElement
function i(e){this.value=e}i.prototype.toString=function(){return n(""+this.value)},e.exports={
XmlText:i}},5101:(e,t,r)=>{"use strict"
var n=r(9697),i=function(){function e(e){
void 0===e&&(e=1e3),this.maxSize=e,this.cache=new n.LRUCache(e)}
return Object.defineProperty(e.prototype,"size",{get:function(){return this.cache.length},
enumerable:!0,configurable:!0}),e.prototype.put=function(t,r){
var n="string"!=typeof t?e.getKeyString(t):t,i=this.populateValue(r)
this.cache.put(n,i)},e.prototype.get=function(t){
var r="string"!=typeof t?e.getKeyString(t):t,n=Date.now(),i=this.cache.get(r)
if(i){for(var o=i.length-1;o>=0;o--)i[o].Expire<n&&i.splice(o,1)
if(0===i.length)return void this.cache.remove(r)}return i},e.getKeyString=function(e){
for(var t=[],r=Object.keys(e).sort(),n=0;n<r.length;n++){var i=r[n]
void 0!==e[i]&&t.push(e[i])}return t.join(" ")},e.prototype.populateValue=function(e){
var t=Date.now()
return e.map((function(e){return{Address:e.Address||"",Expire:t+60*(e.CachePeriodInMinutes||1)*1e3}
}))},e.prototype.empty=function(){this.cache.empty()},e.prototype.remove=function(t){
var r="string"!=typeof t?e.getKeyString(t):t
this.cache.remove(r)},e}()
t.$=i},9697:(e,t)=>{"use strict"
Object.defineProperty(t,"__esModule",{value:!0})
var r=function(e,t){this.key=e,this.value=t},n=function(){function e(e){if(this.nodeMap={},
this.size=0,"number"!=typeof e||e<1)throw new Error("Cache size can only be positive number")
this.sizeLimit=e}return Object.defineProperty(e.prototype,"length",{get:function(){return this.size
},enumerable:!0,configurable:!0}),e.prototype.prependToList=function(e){
this.headerNode?(this.headerNode.prev=e,e.next=this.headerNode):this.tailNode=e,this.headerNode=e,
this.size++},e.prototype.removeFromTail=function(){if(this.tailNode){var e=this.tailNode,t=e.prev
return t&&(t.next=void 0),e.prev=void 0,this.tailNode=t,this.size--,e}
},e.prototype.detachFromList=function(e){this.headerNode===e&&(this.headerNode=e.next),
this.tailNode===e&&(this.tailNode=e.prev),e.prev&&(e.prev.next=e.next),e.next&&(e.next.prev=e.prev),
e.next=void 0,e.prev=void 0,this.size--},e.prototype.get=function(e){if(this.nodeMap[e]){
var t=this.nodeMap[e]
return this.detachFromList(t),this.prependToList(t),t.value}},e.prototype.remove=function(e){
if(this.nodeMap[e]){var t=this.nodeMap[e]
this.detachFromList(t),delete this.nodeMap[e]}},e.prototype.put=function(e,t){
if(this.nodeMap[e])this.remove(e)
else if(this.size===this.sizeLimit){var n=this.removeFromTail().key
delete this.nodeMap[n]}var i=new r(e,t)
this.nodeMap[e]=i,this.prependToList(i)},e.prototype.empty=function(){
for(var e=Object.keys(this.nodeMap),t=0;t<e.length;t++){var r=e[t],n=this.nodeMap[r]
this.detachFromList(n),delete this.nodeMap[r]}},e}()
t.LRUCache=n},9742:(e,t)=>{"use strict"
t.byteLength=function(e){var t=u(e),r=t[0],n=t[1]
return 3*(r+n)/4-n},t.toByteArray=function(e){var t,r,o=u(e),s=o[0],a=o[1],c=new i(function(e,t,r){
return 3*(t+r)/4-r}(0,s,a)),p=0,l=a>0?s-4:s
for(r=0;r<l;r+=4)t=n[e.charCodeAt(r)]<<18|n[e.charCodeAt(r+1)]<<12|n[e.charCodeAt(r+2)]<<6|n[e.charCodeAt(r+3)],
c[p++]=t>>16&255,c[p++]=t>>8&255,c[p++]=255&t
return 2===a&&(t=n[e.charCodeAt(r)]<<2|n[e.charCodeAt(r+1)]>>4,c[p++]=255&t),1===a&&(t=n[e.charCodeAt(r)]<<10|n[e.charCodeAt(r+1)]<<4|n[e.charCodeAt(r+2)]>>2,
c[p++]=t>>8&255,c[p++]=255&t),c},t.fromByteArray=function(e){
for(var t,n=e.length,i=n%3,o=[],s=16383,a=0,u=n-i;a<u;a+=s)o.push(c(e,a,a+s>u?u:a+s))
return 1===i?(t=e[n-1],o.push(r[t>>2]+r[t<<4&63]+"==")):2===i&&(t=(e[n-2]<<8)+e[n-1],
o.push(r[t>>10]+r[t>>4&63]+r[t<<2&63]+"=")),o.join("")}
for(var r=[],n=[],i="undefined"!=typeof Uint8Array?Uint8Array:Array,o="ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/",s=0,a=o.length;s<a;++s)r[s]=o[s],
n[o.charCodeAt(s)]=s
function u(e){var t=e.length
if(t%4>0)throw new Error("Invalid string. Length must be a multiple of 4")
var r=e.indexOf("=")
return-1===r&&(r=t),[r,r===t?0:4-r%4]}function c(e,t,n){
for(var i,o,s=[],a=t;a<n;a+=3)i=(e[a]<<16&16711680)+(e[a+1]<<8&65280)+(255&e[a+2]),
s.push(r[(o=i)>>18&63]+r[o>>12&63]+r[o>>6&63]+r[63&o])
return s.join("")}n["-".charCodeAt(0)]=62,n["_".charCodeAt(0)]=63},8764:(e,t,r)=>{"use strict"
var n=r(9742),i=r(645),o=r(5826)
function s(){return u.TYPED_ARRAY_SUPPORT?2147483647:1073741823}function a(e,t){
if(s()<t)throw new RangeError("Invalid typed array length")
return u.TYPED_ARRAY_SUPPORT?(e=new Uint8Array(t)).__proto__=u.prototype:(null===e&&(e=new u(t)),
e.length=t),e}function u(e,t,r){if(!(u.TYPED_ARRAY_SUPPORT||this instanceof u))return new u(e,t,r)
if("number"==typeof e){
if("string"==typeof t)throw new Error("If encoding is specified then the first argument must be a string")
return l(this,e)}return c(this,e,t,r)}function c(e,t,r,n){
if("number"==typeof t)throw new TypeError('"value" argument must not be a number')
return"undefined"!=typeof ArrayBuffer&&t instanceof ArrayBuffer?function(e,t,r,n){if(t.byteLength,
r<0||t.byteLength<r)throw new RangeError("'offset' is out of bounds")
if(t.byteLength<r+(n||0))throw new RangeError("'length' is out of bounds")
return t=void 0===r&&void 0===n?new Uint8Array(t):void 0===n?new Uint8Array(t,r):new Uint8Array(t,r,n),
u.TYPED_ARRAY_SUPPORT?(e=t).__proto__=u.prototype:e=h(e,t),e
}(e,t,r,n):"string"==typeof t?function(e,t,r){if("string"==typeof r&&""!==r||(r="utf8"),
!u.isEncoding(r))throw new TypeError('"encoding" must be a valid string encoding')
var n=0|d(t,r),i=(e=a(e,n)).write(t,r)
return i!==n&&(e=e.slice(0,i)),e}(e,t,r):function(e,t){if(u.isBuffer(t)){var r=0|f(t.length)
return 0===(e=a(e,r)).length||t.copy(e,0,0,r),e}if(t){
if("undefined"!=typeof ArrayBuffer&&t.buffer instanceof ArrayBuffer||"length"in t)return"number"!=typeof t.length||(n=t.length)!=n?a(e,0):h(e,t)
if("Buffer"===t.type&&o(t.data))return h(e,t.data)}var n
throw new TypeError("First argument must be a string, Buffer, ArrayBuffer, Array, or array-like object.")
}(e,t)}function p(e){if("number"!=typeof e)throw new TypeError('"size" argument must be a number')
if(e<0)throw new RangeError('"size" argument must not be negative')}function l(e,t){if(p(t),
e=a(e,t<0?0:0|f(t)),!u.TYPED_ARRAY_SUPPORT)for(var r=0;r<t;++r)e[r]=0
return e}function h(e,t){var r=t.length<0?0:0|f(t.length)
e=a(e,r)
for(var n=0;n<r;n+=1)e[n]=255&t[n]
return e}function f(e){
if(e>=s())throw new RangeError("Attempt to allocate Buffer larger than maximum size: 0x"+s().toString(16)+" bytes")
return 0|e}function d(e,t){if(u.isBuffer(e))return e.length
if("undefined"!=typeof ArrayBuffer&&"function"==typeof ArrayBuffer.isView&&(ArrayBuffer.isView(e)||e instanceof ArrayBuffer))return e.byteLength
"string"!=typeof e&&(e=""+e)
var r=e.length
if(0===r)return 0
for(var n=!1;;)switch(t){case"ascii":case"latin1":case"binary":return r
case"utf8":case"utf-8":case void 0:return B(e).length
case"ucs2":case"ucs-2":case"utf16le":case"utf-16le":return 2*r
case"hex":return r>>>1
case"base64":return F(e).length
default:if(n)return B(e).length
t=(""+t).toLowerCase(),n=!0}}function m(e,t,r){var n=!1
if((void 0===t||t<0)&&(t=0),t>this.length)return""
if((void 0===r||r>this.length)&&(r=this.length),r<=0)return""
if((r>>>=0)<=(t>>>=0))return""
for(e||(e="utf8");;)switch(e){case"hex":return T(this,t,r)
case"utf8":case"utf-8":return C(this,t,r)
case"ascii":return _(this,t,r)
case"latin1":case"binary":return k(this,t,r)
case"base64":return x(this,t,r)
case"ucs2":case"ucs-2":case"utf16le":case"utf-16le":return P(this,t,r)
default:if(n)throw new TypeError("Unknown encoding: "+e)
e=(e+"").toLowerCase(),n=!0}}function y(e,t,r){var n=e[t]
e[t]=e[r],e[r]=n}function g(e,t,r,n,i){if(0===e.length)return-1
if("string"==typeof r?(n=r,r=0):r>2147483647?r=2147483647:r<-2147483648&&(r=-2147483648),r=+r,
isNaN(r)&&(r=i?0:e.length-1),r<0&&(r=e.length+r),r>=e.length){if(i)return-1
r=e.length-1}else if(r<0){if(!i)return-1
r=0}if("string"==typeof t&&(t=u.from(t,n)),u.isBuffer(t))return 0===t.length?-1:v(e,t,r,n,i)
if("number"==typeof t)return t&=255,u.TYPED_ARRAY_SUPPORT&&"function"==typeof Uint8Array.prototype.indexOf?i?Uint8Array.prototype.indexOf.call(e,t,r):Uint8Array.prototype.lastIndexOf.call(e,t,r):v(e,[t],r,n,i)
throw new TypeError("val must be string, number or Buffer")}function v(e,t,r,n,i){
var o,s=1,a=e.length,u=t.length
if(void 0!==n&&("ucs2"===(n=String(n).toLowerCase())||"ucs-2"===n||"utf16le"===n||"utf-16le"===n)){
if(e.length<2||t.length<2)return-1
s=2,a/=2,u/=2,r/=2}function c(e,t){return 1===s?e[t]:e.readUInt16BE(t*s)}if(i){var p=-1
for(o=r;o<a;o++)if(c(e,o)===c(t,-1===p?0:o-p)){if(-1===p&&(p=o),o-p+1===u)return p*s
}else-1!==p&&(o-=o-p),p=-1}else for(r+u>a&&(r=a-u),o=r;o>=0;o--){
for(var l=!0,h=0;h<u;h++)if(c(e,o+h)!==c(t,h)){l=!1
break}if(l)return o}return-1}function b(e,t,r,n){r=Number(r)||0
var i=e.length-r
n?(n=Number(n))>i&&(n=i):n=i
var o=t.length
if(o%2!=0)throw new TypeError("Invalid hex string")
n>o/2&&(n=o/2)
for(var s=0;s<n;++s){var a=parseInt(t.substr(2*s,2),16)
if(isNaN(a))return s
e[r+s]=a}return s}function S(e,t,r,n){return z(B(t,e.length-r),e,r,n)}function w(e,t,r,n){
return z(function(e){for(var t=[],r=0;r<e.length;++r)t.push(255&e.charCodeAt(r))
return t}(t),e,r,n)}function E(e,t,r,n){return w(e,t,r,n)}function A(e,t,r,n){return z(F(t),e,r,n)}
function R(e,t,r,n){return z(function(e,t){
for(var r,n,i,o=[],s=0;s<e.length&&!((t-=2)<0);++s)n=(r=e.charCodeAt(s))>>8,i=r%256,o.push(i),
o.push(n)
return o}(t,e.length-r),e,r,n)}function x(e,t,r){
return 0===t&&r===e.length?n.fromByteArray(e):n.fromByteArray(e.slice(t,r))}function C(e,t,r){
r=Math.min(e.length,r)
for(var n=[],i=t;i<r;){var o,s,a,u,c=e[i],p=null,l=c>239?4:c>223?3:c>191?2:1
if(i+l<=r)switch(l){case 1:c<128&&(p=c)
break
case 2:128==(192&(o=e[i+1]))&&(u=(31&c)<<6|63&o)>127&&(p=u)
break
case 3:
o=e[i+1],s=e[i+2],128==(192&o)&&128==(192&s)&&(u=(15&c)<<12|(63&o)<<6|63&s)>2047&&(u<55296||u>57343)&&(p=u)
break
case 4:
o=e[i+1],s=e[i+2],a=e[i+3],128==(192&o)&&128==(192&s)&&128==(192&a)&&(u=(15&c)<<18|(63&o)<<12|(63&s)<<6|63&a)>65535&&u<1114112&&(p=u)
}null===p?(p=65533,l=1):p>65535&&(p-=65536,n.push(p>>>10&1023|55296),p=56320|1023&p),n.push(p),i+=l}
return function(e){var t=e.length
if(t<=I)return String.fromCharCode.apply(String,e)
for(var r="",n=0;n<t;)r+=String.fromCharCode.apply(String,e.slice(n,n+=I))
return r}(n)}
t.lW=u,t.h2=50,u.TYPED_ARRAY_SUPPORT=void 0!==r.g.TYPED_ARRAY_SUPPORT?r.g.TYPED_ARRAY_SUPPORT:function(){
try{var e=new Uint8Array(1)
return e.__proto__={__proto__:Uint8Array.prototype,foo:function(){return 42}
},42===e.foo()&&"function"==typeof e.subarray&&0===e.subarray(1,1).byteLength}catch(e){return!1}}(),
s(),u.poolSize=8192,u._augment=function(e){return e.__proto__=u.prototype,e},u.from=function(e,t,r){
return c(null,e,t,r)},u.TYPED_ARRAY_SUPPORT&&(u.prototype.__proto__=Uint8Array.prototype,
u.__proto__=Uint8Array,
"undefined"!=typeof Symbol&&Symbol.species&&u[Symbol.species]===u&&Object.defineProperty(u,Symbol.species,{
value:null,configurable:!0})),u.alloc=function(e,t,r){return function(e,t,r,n){return p(t),
t<=0?a(e,t):void 0!==r?"string"==typeof n?a(e,t).fill(r,n):a(e,t).fill(r):a(e,t)}(null,e,t,r)},
u.allocUnsafe=function(e){return l(null,e)},u.allocUnsafeSlow=function(e){return l(null,e)},
u.isBuffer=function(e){return!(null==e||!e._isBuffer)},u.compare=function(e,t){
if(!u.isBuffer(e)||!u.isBuffer(t))throw new TypeError("Arguments must be Buffers")
if(e===t)return 0
for(var r=e.length,n=t.length,i=0,o=Math.min(r,n);i<o;++i)if(e[i]!==t[i]){r=e[i],n=t[i]
break}return r<n?-1:n<r?1:0},u.isEncoding=function(e){switch(String(e).toLowerCase()){case"hex":
case"utf8":case"utf-8":case"ascii":case"latin1":case"binary":case"base64":case"ucs2":case"ucs-2":
case"utf16le":case"utf-16le":return!0
default:return!1}},u.concat=function(e,t){
if(!o(e))throw new TypeError('"list" argument must be an Array of Buffers')
if(0===e.length)return u.alloc(0)
var r
if(void 0===t)for(t=0,r=0;r<e.length;++r)t+=e[r].length
var n=u.allocUnsafe(t),i=0
for(r=0;r<e.length;++r){var s=e[r]
if(!u.isBuffer(s))throw new TypeError('"list" argument must be an Array of Buffers')
s.copy(n,i),i+=s.length}return n
},u.byteLength=d,u.prototype._isBuffer=!0,u.prototype.swap16=function(){var e=this.length
if(e%2!=0)throw new RangeError("Buffer size must be a multiple of 16-bits")
for(var t=0;t<e;t+=2)y(this,t,t+1)
return this},u.prototype.swap32=function(){var e=this.length
if(e%4!=0)throw new RangeError("Buffer size must be a multiple of 32-bits")
for(var t=0;t<e;t+=4)y(this,t,t+3),y(this,t+1,t+2)
return this},u.prototype.swap64=function(){var e=this.length
if(e%8!=0)throw new RangeError("Buffer size must be a multiple of 64-bits")
for(var t=0;t<e;t+=8)y(this,t,t+7),y(this,t+1,t+6),y(this,t+2,t+5),y(this,t+3,t+4)
return this},u.prototype.toString=function(){var e=0|this.length
return 0===e?"":0===arguments.length?C(this,0,e):m.apply(this,arguments)
},u.prototype.equals=function(e){if(!u.isBuffer(e))throw new TypeError("Argument must be a Buffer")
return this===e||0===u.compare(this,e)},u.prototype.inspect=function(){var e="",r=t.h2
return this.length>0&&(e=this.toString("hex",0,r).match(/.{2}/g).join(" "),this.length>r&&(e+=" ... ")),
"<Buffer "+e+">"},u.prototype.compare=function(e,t,r,n,i){
if(!u.isBuffer(e))throw new TypeError("Argument must be a Buffer")
if(void 0===t&&(t=0),void 0===r&&(r=e?e.length:0),void 0===n&&(n=0),void 0===i&&(i=this.length),
t<0||r>e.length||n<0||i>this.length)throw new RangeError("out of range index")
if(n>=i&&t>=r)return 0
if(n>=i)return-1
if(t>=r)return 1
if(this===e)return 0
for(var o=(i>>>=0)-(n>>>=0),s=(r>>>=0)-(t>>>=0),a=Math.min(o,s),c=this.slice(n,i),p=e.slice(t,r),l=0;l<a;++l)if(c[l]!==p[l]){
o=c[l],s=p[l]
break}return o<s?-1:s<o?1:0},u.prototype.includes=function(e,t,r){return-1!==this.indexOf(e,t,r)},
u.prototype.indexOf=function(e,t,r){return g(this,e,t,r,!0)
},u.prototype.lastIndexOf=function(e,t,r){return g(this,e,t,r,!1)
},u.prototype.write=function(e,t,r,n){if(void 0===t)n="utf8",r=this.length,t=0
else if(void 0===r&&"string"==typeof t)n=t,r=this.length,t=0
else{
if(!isFinite(t))throw new Error("Buffer.write(string, encoding, offset[, length]) is no longer supported")
t|=0,isFinite(r)?(r|=0,void 0===n&&(n="utf8")):(n=r,r=void 0)}var i=this.length-t
if((void 0===r||r>i)&&(r=i),e.length>0&&(r<0||t<0)||t>this.length)throw new RangeError("Attempt to write outside buffer bounds")
n||(n="utf8")
for(var o=!1;;)switch(n){case"hex":return b(this,e,t,r)
case"utf8":case"utf-8":return S(this,e,t,r)
case"ascii":return w(this,e,t,r)
case"latin1":case"binary":return E(this,e,t,r)
case"base64":return A(this,e,t,r)
case"ucs2":case"ucs-2":case"utf16le":case"utf-16le":return R(this,e,t,r)
default:if(o)throw new TypeError("Unknown encoding: "+n)
n=(""+n).toLowerCase(),o=!0}},u.prototype.toJSON=function(){return{type:"Buffer",
data:Array.prototype.slice.call(this._arr||this,0)}}
var I=4096
function _(e,t,r){var n=""
r=Math.min(e.length,r)
for(var i=t;i<r;++i)n+=String.fromCharCode(127&e[i])
return n}function k(e,t,r){var n=""
r=Math.min(e.length,r)
for(var i=t;i<r;++i)n+=String.fromCharCode(e[i])
return n}function T(e,t,r){var n,i=e.length;(!t||t<0)&&(t=0),(!r||r<0||r>i)&&(r=i)
for(var o="",s=t;s<r;++s)o+=(n=e[s])<16?"0"+n.toString(16):n.toString(16)
return o}function P(e,t,r){
for(var n=e.slice(t,r),i="",o=0;o<n.length;o+=2)i+=String.fromCharCode(n[o]+256*n[o+1])
return i}function O(e,t,r){if(e%1!=0||e<0)throw new RangeError("offset is not uint")
if(e+t>r)throw new RangeError("Trying to access beyond buffer length")}function L(e,t,r,n,i,o){
if(!u.isBuffer(e))throw new TypeError('"buffer" argument must be a Buffer instance')
if(t>i||t<o)throw new RangeError('"value" argument is out of bounds')
if(r+n>e.length)throw new RangeError("Index out of range")}function q(e,t,r,n){t<0&&(t=65535+t+1)
for(var i=0,o=Math.min(e.length-r,2);i<o;++i)e[r+i]=(t&255<<8*(n?i:1-i))>>>8*(n?i:1-i)}
function N(e,t,r,n){t<0&&(t=4294967295+t+1)
for(var i=0,o=Math.min(e.length-r,4);i<o;++i)e[r+i]=t>>>8*(n?i:3-i)&255}function D(e,t,r,n,i,o){
if(r+n>e.length)throw new RangeError("Index out of range")
if(r<0)throw new RangeError("Index out of range")}function U(e,t,r,n,o){return o||D(e,0,r,4),
i.write(e,t,r,n,23,4),r+4}function M(e,t,r,n,o){return o||D(e,0,r,8),i.write(e,t,r,n,52,8),r+8}
u.prototype.slice=function(e,t){var r,n=this.length
if((e=~~e)<0?(e+=n)<0&&(e=0):e>n&&(e=n),(t=void 0===t?n:~~t)<0?(t+=n)<0&&(t=0):t>n&&(t=n),
t<e&&(t=e),u.TYPED_ARRAY_SUPPORT)(r=this.subarray(e,t)).__proto__=u.prototype
else{var i=t-e
r=new u(i,void 0)
for(var o=0;o<i;++o)r[o]=this[o+e]}return r},u.prototype.readUIntLE=function(e,t,r){e|=0,t|=0,
r||O(e,t,this.length)
for(var n=this[e],i=1,o=0;++o<t&&(i*=256);)n+=this[e+o]*i
return n},u.prototype.readUIntBE=function(e,t,r){e|=0,t|=0,r||O(e,t,this.length)
for(var n=this[e+--t],i=1;t>0&&(i*=256);)n+=this[e+--t]*i
return n},u.prototype.readUInt8=function(e,t){return t||O(e,1,this.length),this[e]},
u.prototype.readUInt16LE=function(e,t){return t||O(e,2,this.length),this[e]|this[e+1]<<8},
u.prototype.readUInt16BE=function(e,t){return t||O(e,2,this.length),this[e]<<8|this[e+1]},
u.prototype.readUInt32LE=function(e,t){
return t||O(e,4,this.length),(this[e]|this[e+1]<<8|this[e+2]<<16)+16777216*this[e+3]},
u.prototype.readUInt32BE=function(e,t){
return t||O(e,4,this.length),16777216*this[e]+(this[e+1]<<16|this[e+2]<<8|this[e+3])},
u.prototype.readIntLE=function(e,t,r){e|=0,t|=0,r||O(e,t,this.length)
for(var n=this[e],i=1,o=0;++o<t&&(i*=256);)n+=this[e+o]*i
return n>=(i*=128)&&(n-=Math.pow(2,8*t)),n},u.prototype.readIntBE=function(e,t,r){e|=0,t|=0,
r||O(e,t,this.length)
for(var n=t,i=1,o=this[e+--n];n>0&&(i*=256);)o+=this[e+--n]*i
return o>=(i*=128)&&(o-=Math.pow(2,8*t)),o},u.prototype.readInt8=function(e,t){
return t||O(e,1,this.length),128&this[e]?-1*(255-this[e]+1):this[e]
},u.prototype.readInt16LE=function(e,t){t||O(e,2,this.length)
var r=this[e]|this[e+1]<<8
return 32768&r?4294901760|r:r},u.prototype.readInt16BE=function(e,t){t||O(e,2,this.length)
var r=this[e+1]|this[e]<<8
return 32768&r?4294901760|r:r},u.prototype.readInt32LE=function(e,t){return t||O(e,4,this.length),
this[e]|this[e+1]<<8|this[e+2]<<16|this[e+3]<<24},u.prototype.readInt32BE=function(e,t){
return t||O(e,4,this.length),this[e]<<24|this[e+1]<<16|this[e+2]<<8|this[e+3]
},u.prototype.readFloatLE=function(e,t){return t||O(e,4,this.length),i.read(this,e,!0,23,4)},
u.prototype.readFloatBE=function(e,t){return t||O(e,4,this.length),i.read(this,e,!1,23,4)},
u.prototype.readDoubleLE=function(e,t){return t||O(e,8,this.length),i.read(this,e,!0,52,8)},
u.prototype.readDoubleBE=function(e,t){return t||O(e,8,this.length),i.read(this,e,!1,52,8)},
u.prototype.writeUIntLE=function(e,t,r,n){e=+e,t|=0,r|=0,n||L(this,e,t,r,Math.pow(2,8*r)-1,0)
var i=1,o=0
for(this[t]=255&e;++o<r&&(i*=256);)this[t+o]=e/i&255
return t+r},u.prototype.writeUIntBE=function(e,t,r,n){
e=+e,t|=0,r|=0,n||L(this,e,t,r,Math.pow(2,8*r)-1,0)
var i=r-1,o=1
for(this[t+i]=255&e;--i>=0&&(o*=256);)this[t+i]=e/o&255
return t+r},u.prototype.writeUInt8=function(e,t,r){return e=+e,t|=0,r||L(this,e,t,1,255,0),
u.TYPED_ARRAY_SUPPORT||(e=Math.floor(e)),this[t]=255&e,t+1
},u.prototype.writeUInt16LE=function(e,t,r){return e=+e,t|=0,r||L(this,e,t,2,65535,0),
u.TYPED_ARRAY_SUPPORT?(this[t]=255&e,this[t+1]=e>>>8):q(this,e,t,!0),t+2
},u.prototype.writeUInt16BE=function(e,t,r){return e=+e,t|=0,r||L(this,e,t,2,65535,0),
u.TYPED_ARRAY_SUPPORT?(this[t]=e>>>8,this[t+1]=255&e):q(this,e,t,!1),t+2
},u.prototype.writeUInt32LE=function(e,t,r){return e=+e,t|=0,r||L(this,e,t,4,4294967295,0),
u.TYPED_ARRAY_SUPPORT?(this[t+3]=e>>>24,
this[t+2]=e>>>16,this[t+1]=e>>>8,this[t]=255&e):N(this,e,t,!0),t+4
},u.prototype.writeUInt32BE=function(e,t,r){return e=+e,t|=0,r||L(this,e,t,4,4294967295,0),
u.TYPED_ARRAY_SUPPORT?(this[t]=e>>>24,
this[t+1]=e>>>16,this[t+2]=e>>>8,this[t+3]=255&e):N(this,e,t,!1),t+4
},u.prototype.writeIntLE=function(e,t,r,n){if(e=+e,t|=0,!n){var i=Math.pow(2,8*r-1)
L(this,e,t,r,i-1,-i)}var o=0,s=1,a=0
for(this[t]=255&e;++o<r&&(s*=256);)e<0&&0===a&&0!==this[t+o-1]&&(a=1),this[t+o]=(e/s>>0)-a&255
return t+r},u.prototype.writeIntBE=function(e,t,r,n){if(e=+e,t|=0,!n){var i=Math.pow(2,8*r-1)
L(this,e,t,r,i-1,-i)}var o=r-1,s=1,a=0
for(this[t+o]=255&e;--o>=0&&(s*=256);)e<0&&0===a&&0!==this[t+o+1]&&(a=1),this[t+o]=(e/s>>0)-a&255
return t+r},u.prototype.writeInt8=function(e,t,r){return e=+e,t|=0,r||L(this,e,t,1,127,-128),
u.TYPED_ARRAY_SUPPORT||(e=Math.floor(e)),e<0&&(e=255+e+1),this[t]=255&e,t+1
},u.prototype.writeInt16LE=function(e,t,r){return e=+e,t|=0,r||L(this,e,t,2,32767,-32768),
u.TYPED_ARRAY_SUPPORT?(this[t]=255&e,this[t+1]=e>>>8):q(this,e,t,!0),t+2
},u.prototype.writeInt16BE=function(e,t,r){return e=+e,t|=0,r||L(this,e,t,2,32767,-32768),
u.TYPED_ARRAY_SUPPORT?(this[t]=e>>>8,this[t+1]=255&e):q(this,e,t,!1),t+2
},u.prototype.writeInt32LE=function(e,t,r){return e=+e,t|=0,r||L(this,e,t,4,2147483647,-2147483648),
u.TYPED_ARRAY_SUPPORT?(this[t]=255&e,
this[t+1]=e>>>8,this[t+2]=e>>>16,this[t+3]=e>>>24):N(this,e,t,!0),t+4
},u.prototype.writeInt32BE=function(e,t,r){return e=+e,t|=0,r||L(this,e,t,4,2147483647,-2147483648),
e<0&&(e=4294967295+e+1),u.TYPED_ARRAY_SUPPORT?(this[t]=e>>>24,this[t+1]=e>>>16,this[t+2]=e>>>8,
this[t+3]=255&e):N(this,e,t,!1),t+4},u.prototype.writeFloatLE=function(e,t,r){
return U(this,e,t,!0,r)},u.prototype.writeFloatBE=function(e,t,r){return U(this,e,t,!1,r)},
u.prototype.writeDoubleLE=function(e,t,r){return M(this,e,t,!0,r)
},u.prototype.writeDoubleBE=function(e,t,r){return M(this,e,t,!1,r)
},u.prototype.copy=function(e,t,r,n){
if(r||(r=0),n||0===n||(n=this.length),t>=e.length&&(t=e.length),t||(t=0),n>0&&n<r&&(n=r),
n===r)return 0
if(0===e.length||0===this.length)return 0
if(t<0)throw new RangeError("targetStart out of bounds")
if(r<0||r>=this.length)throw new RangeError("sourceStart out of bounds")
if(n<0)throw new RangeError("sourceEnd out of bounds")
n>this.length&&(n=this.length),e.length-t<n-r&&(n=e.length-t+r)
var i,o=n-r
if(this===e&&r<t&&t<n)for(i=o-1;i>=0;--i)e[i+t]=this[i+r]
else if(o<1e3||!u.TYPED_ARRAY_SUPPORT)for(i=0;i<o;++i)e[i+t]=this[i+r]
else Uint8Array.prototype.set.call(e,this.subarray(r,r+o),t)
return o},u.prototype.fill=function(e,t,r,n){if("string"==typeof e){if("string"==typeof t?(n=t,t=0,
r=this.length):"string"==typeof r&&(n=r,r=this.length),1===e.length){var i=e.charCodeAt(0)
i<256&&(e=i)}if(void 0!==n&&"string"!=typeof n)throw new TypeError("encoding must be a string")
if("string"==typeof n&&!u.isEncoding(n))throw new TypeError("Unknown encoding: "+n)
}else"number"==typeof e&&(e&=255)
if(t<0||this.length<t||this.length<r)throw new RangeError("Out of range index")
if(r<=t)return this
var o
if(t>>>=0,r=void 0===r?this.length:r>>>0,e||(e=0),"number"==typeof e)for(o=t;o<r;++o)this[o]=e
else{var s=u.isBuffer(e)?e:B(new u(e,n).toString()),a=s.length
for(o=0;o<r-t;++o)this[o+t]=s[o%a]}return this}
var j=/[^+\/0-9A-Za-z-_]/g
function B(e,t){var r
t=t||1/0
for(var n=e.length,i=null,o=[],s=0;s<n;++s){if((r=e.charCodeAt(s))>55295&&r<57344){if(!i){
if(r>56319){(t-=3)>-1&&o.push(239,191,189)
continue}if(s+1===n){(t-=3)>-1&&o.push(239,191,189)
continue}i=r
continue}if(r<56320){(t-=3)>-1&&o.push(239,191,189),i=r
continue}r=65536+(i-55296<<10|r-56320)}else i&&(t-=3)>-1&&o.push(239,191,189)
if(i=null,r<128){if((t-=1)<0)break
o.push(r)}else if(r<2048){if((t-=2)<0)break
o.push(r>>6|192,63&r|128)}else if(r<65536){if((t-=3)<0)break
o.push(r>>12|224,r>>6&63|128,63&r|128)}else{if(!(r<1114112))throw new Error("Invalid code point")
if((t-=4)<0)break
o.push(r>>18|240,r>>12&63|128,r>>6&63|128,63&r|128)}}return o}function F(e){
return n.toByteArray(function(e){if((e=function(e){return e.trim?e.trim():e.replace(/^\s+|\s+$/g,"")
}(e).replace(j,"")).length<2)return""
for(;e.length%4!=0;)e+="="
return e}(e))}function z(e,t,r,n){for(var i=0;i<n&&!(i+r>=t.length||i>=e.length);++i)t[i+r]=e[i]
return i}},1924:(e,t,r)=>{"use strict"
var n=r(210),i=r(5559),o=i(n("String.prototype.indexOf"))
e.exports=function(e,t){var r=n(e,!!t)
return"function"==typeof r&&o(e,".prototype.")>-1?i(r):r}},5559:(e,t,r)=>{"use strict"
var n=r(8612),i=r(210),o=i("%Function.prototype.apply%"),s=i("%Function.prototype.call%"),a=i("%Reflect.apply%",!0)||n.call(s,o),u=i("%Object.getOwnPropertyDescriptor%",!0),c=i("%Object.defineProperty%",!0),p=i("%Math.max%")
if(c)try{c({},"a",{value:1})}catch(e){c=null}e.exports=function(e){var t=a(n,s,arguments)
return u&&c&&u(t,"length").configurable&&c(t,"length",{value:1+p(0,e.length-(arguments.length-1))}),
t}
var l=function(){return a(n,o,arguments)}
c?c(e.exports,"apply",{value:l}):e.exports.apply=l},7187:e=>{function t(){
this._events=this._events||{},this._maxListeners=this._maxListeners||void 0}function r(e){
return"function"==typeof e}function n(e){return"object"==typeof e&&null!==e}function i(e){
return void 0===e}
e.exports=t,t.EventEmitter=t,t.prototype._events=void 0,t.prototype._maxListeners=void 0,
t.defaultMaxListeners=10,t.prototype.setMaxListeners=function(e){
if("number"!=typeof e||e<0||isNaN(e))throw TypeError("n must be a positive number")
return this._maxListeners=e,this},t.prototype.emit=function(e){var t,o,s,a,u,c
if(this._events||(this._events={}),"error"===e&&(!this._events.error||n(this._events.error)&&!this._events.error.length)){
if((t=arguments[1])instanceof Error)throw t
var p=new Error('Uncaught, unspecified "error" event. ('+t+")")
throw p.context=t,p}if(i(o=this._events[e]))return!1
if(r(o))switch(arguments.length){case 1:o.call(this)
break
case 2:o.call(this,arguments[1])
break
case 3:o.call(this,arguments[1],arguments[2])
break
default:a=Array.prototype.slice.call(arguments,1),o.apply(this,a)
}else if(n(o))for(a=Array.prototype.slice.call(arguments,1),s=(c=o.slice()).length,
u=0;u<s;u++)c[u].apply(this,a)
return!0},t.prototype.addListener=function(e,o){var s
if(!r(o))throw TypeError("listener must be a function")
return this._events||(this._events={}),this._events.newListener&&this.emit("newListener",e,r(o.listener)?o.listener:o),
this._events[e]?n(this._events[e])?this._events[e].push(o):this._events[e]=[this._events[e],o]:this._events[e]=o,
n(this._events[e])&&!this._events[e].warned&&(s=i(this._maxListeners)?t.defaultMaxListeners:this._maxListeners)&&s>0&&this._events[e].length>s&&(this._events[e].warned=!0,
console.error("(node) warning: possible EventEmitter memory leak detected. %d listeners added. Use emitter.setMaxListeners() to increase limit.",this._events[e].length),
"function"==typeof console.trace&&console.trace()),this},t.prototype.on=t.prototype.addListener,
t.prototype.once=function(e,t){if(!r(t))throw TypeError("listener must be a function")
var n=!1
function i(){this.removeListener(e,i),n||(n=!0,t.apply(this,arguments))}return i.listener=t,
this.on(e,i),this},t.prototype.removeListener=function(e,t){var i,o,s,a
if(!r(t))throw TypeError("listener must be a function")
if(!this._events||!this._events[e])return this
if(s=(i=this._events[e]).length,o=-1,i===t||r(i.listener)&&i.listener===t)delete this._events[e],
this._events.removeListener&&this.emit("removeListener",e,t)
else if(n(i)){for(a=s;a-- >0;)if(i[a]===t||i[a].listener&&i[a].listener===t){o=a
break}if(o<0)return this
1===i.length?(i.length=0,delete this._events[e]):i.splice(o,1),this._events.removeListener&&this.emit("removeListener",e,t)
}return this},t.prototype.removeAllListeners=function(e){var t,n
if(!this._events)return this
if(!this._events.removeListener)return 0===arguments.length?this._events={}:this._events[e]&&delete this._events[e],
this
if(0===arguments.length){for(t in this._events)"removeListener"!==t&&this.removeAllListeners(t)
return this.removeAllListeners("removeListener"),this._events={},this}
if(r(n=this._events[e]))this.removeListener(e,n)
else if(n)for(;n.length;)this.removeListener(e,n[n.length-1])
return delete this._events[e],this},t.prototype.listeners=function(e){
return this._events&&this._events[e]?r(this._events[e])?[this._events[e]]:this._events[e].slice():[]
},t.prototype.listenerCount=function(e){if(this._events){var t=this._events[e]
if(r(t))return 1
if(t)return t.length}return 0},t.listenerCount=function(e,t){return e.listenerCount(t)}},9804:e=>{
var t=Object.prototype.hasOwnProperty,r=Object.prototype.toString
e.exports=function(e,n,i){
if("[object Function]"!==r.call(n))throw new TypeError("iterator must be a function")
var o=e.length
if(o===+o)for(var s=0;s<o;s++)n.call(i,e[s],s,e)
else for(var a in e)t.call(e,a)&&n.call(i,e[a],a,e)}},7648:e=>{"use strict"
var t="Function.prototype.bind called on incompatible ",r=Array.prototype.slice,n=Object.prototype.toString,i="[object Function]"
e.exports=function(e){var o=this
if("function"!=typeof o||n.call(o)!==i)throw new TypeError(t+o)
for(var s,a=r.call(arguments,1),u=function(){if(this instanceof s){
var t=o.apply(this,a.concat(r.call(arguments)))
return Object(t)===t?t:this}return o.apply(e,a.concat(r.call(arguments)))
},c=Math.max(0,o.length-a.length),p=[],l=0;l<c;l++)p.push("$"+l)
if(s=Function("binder","return function ("+p.join(",")+"){ return binder.apply(this,arguments); }")(u),
o.prototype){var h=function(){}
h.prototype=o.prototype,s.prototype=new h,h.prototype=null}return s}},8612:(e,t,r)=>{"use strict"
var n=r(7648)
e.exports=Function.prototype.bind||n},210:(e,t,r)=>{"use strict"
var n,i=SyntaxError,o=Function,s=TypeError,a=function(e){try{
return o('"use strict"; return ('+e+").constructor;")()}catch(e){}
},u=Object.getOwnPropertyDescriptor
if(u)try{u({},"")}catch(e){u=null}var c=function(){throw new s},p=u?function(){try{return c
}catch(e){try{return u(arguments,"callee").get}catch(e){return c}}
}():c,l=r(1405)(),h=Object.getPrototypeOf||function(e){return e.__proto__
},f={},d="undefined"==typeof Uint8Array?n:h(Uint8Array),m={
"%AggregateError%":"undefined"==typeof AggregateError?n:AggregateError,"%Array%":Array,
"%ArrayBuffer%":"undefined"==typeof ArrayBuffer?n:ArrayBuffer,
"%ArrayIteratorPrototype%":l?h([][Symbol.iterator]()):n,"%AsyncFromSyncIteratorPrototype%":n,
"%AsyncFunction%":f,"%AsyncGenerator%":f,"%AsyncGeneratorFunction%":f,"%AsyncIteratorPrototype%":f,
"%Atomics%":"undefined"==typeof Atomics?n:Atomics,"%BigInt%":"undefined"==typeof BigInt?n:BigInt,
"%Boolean%":Boolean,"%DataView%":"undefined"==typeof DataView?n:DataView,"%Date%":Date,
"%decodeURI%":decodeURI,"%decodeURIComponent%":decodeURIComponent,"%encodeURI%":encodeURI,
"%encodeURIComponent%":encodeURIComponent,"%Error%":Error,"%eval%":eval,"%EvalError%":EvalError,
"%Float32Array%":"undefined"==typeof Float32Array?n:Float32Array,
"%Float64Array%":"undefined"==typeof Float64Array?n:Float64Array,
"%FinalizationRegistry%":"undefined"==typeof FinalizationRegistry?n:FinalizationRegistry,
"%Function%":o,"%GeneratorFunction%":f,"%Int8Array%":"undefined"==typeof Int8Array?n:Int8Array,
"%Int16Array%":"undefined"==typeof Int16Array?n:Int16Array,
"%Int32Array%":"undefined"==typeof Int32Array?n:Int32Array,"%isFinite%":isFinite,"%isNaN%":isNaN,
"%IteratorPrototype%":l?h(h([][Symbol.iterator]())):n,"%JSON%":"object"==typeof JSON?JSON:n,
"%Map%":"undefined"==typeof Map?n:Map,
"%MapIteratorPrototype%":"undefined"!=typeof Map&&l?h((new Map)[Symbol.iterator]()):n,"%Math%":Math,
"%Number%":Number,"%Object%":Object,"%parseFloat%":parseFloat,"%parseInt%":parseInt,
"%Promise%":"undefined"==typeof Promise?n:Promise,"%Proxy%":"undefined"==typeof Proxy?n:Proxy,
"%RangeError%":RangeError,"%ReferenceError%":ReferenceError,
"%Reflect%":"undefined"==typeof Reflect?n:Reflect,"%RegExp%":RegExp,
"%Set%":"undefined"==typeof Set?n:Set,
"%SetIteratorPrototype%":"undefined"!=typeof Set&&l?h((new Set)[Symbol.iterator]()):n,
"%SharedArrayBuffer%":"undefined"==typeof SharedArrayBuffer?n:SharedArrayBuffer,"%String%":String,
"%StringIteratorPrototype%":l?h(""[Symbol.iterator]()):n,"%Symbol%":l?Symbol:n,"%SyntaxError%":i,
"%ThrowTypeError%":p,"%TypedArray%":d,"%TypeError%":s,
"%Uint8Array%":"undefined"==typeof Uint8Array?n:Uint8Array,
"%Uint8ClampedArray%":"undefined"==typeof Uint8ClampedArray?n:Uint8ClampedArray,
"%Uint16Array%":"undefined"==typeof Uint16Array?n:Uint16Array,
"%Uint32Array%":"undefined"==typeof Uint32Array?n:Uint32Array,"%URIError%":URIError,
"%WeakMap%":"undefined"==typeof WeakMap?n:WeakMap,"%WeakRef%":"undefined"==typeof WeakRef?n:WeakRef,
"%WeakSet%":"undefined"==typeof WeakSet?n:WeakSet},y=function e(t){var r
if("%AsyncFunction%"===t)r=a("async function () {}")
else if("%GeneratorFunction%"===t)r=a("function* () {}")
else if("%AsyncGeneratorFunction%"===t)r=a("async function* () {}")
else if("%AsyncGenerator%"===t){var n=e("%AsyncGeneratorFunction%")
n&&(r=n.prototype)}else if("%AsyncIteratorPrototype%"===t){var i=e("%AsyncGenerator%")
i&&(r=h(i.prototype))}return m[t]=r,r},g={"%ArrayBufferPrototype%":["ArrayBuffer","prototype"],
"%ArrayPrototype%":["Array","prototype"],"%ArrayProto_entries%":["Array","prototype","entries"],
"%ArrayProto_forEach%":["Array","prototype","forEach"],
"%ArrayProto_keys%":["Array","prototype","keys"],
"%ArrayProto_values%":["Array","prototype","values"],
"%AsyncFunctionPrototype%":["AsyncFunction","prototype"],
"%AsyncGenerator%":["AsyncGeneratorFunction","prototype"],
"%AsyncGeneratorPrototype%":["AsyncGeneratorFunction","prototype","prototype"],
"%BooleanPrototype%":["Boolean","prototype"],"%DataViewPrototype%":["DataView","prototype"],
"%DatePrototype%":["Date","prototype"],"%ErrorPrototype%":["Error","prototype"],
"%EvalErrorPrototype%":["EvalError","prototype"],
"%Float32ArrayPrototype%":["Float32Array","prototype"],
"%Float64ArrayPrototype%":["Float64Array","prototype"],
"%FunctionPrototype%":["Function","prototype"],"%Generator%":["GeneratorFunction","prototype"],
"%GeneratorPrototype%":["GeneratorFunction","prototype","prototype"],
"%Int8ArrayPrototype%":["Int8Array","prototype"],"%Int16ArrayPrototype%":["Int16Array","prototype"],
"%Int32ArrayPrototype%":["Int32Array","prototype"],"%JSONParse%":["JSON","parse"],
"%JSONStringify%":["JSON","stringify"],"%MapPrototype%":["Map","prototype"],
"%NumberPrototype%":["Number","prototype"],"%ObjectPrototype%":["Object","prototype"],
"%ObjProto_toString%":["Object","prototype","toString"],
"%ObjProto_valueOf%":["Object","prototype","valueOf"],"%PromisePrototype%":["Promise","prototype"],
"%PromiseProto_then%":["Promise","prototype","then"],"%Promise_all%":["Promise","all"],
"%Promise_reject%":["Promise","reject"],"%Promise_resolve%":["Promise","resolve"],
"%RangeErrorPrototype%":["RangeError","prototype"],
"%ReferenceErrorPrototype%":["ReferenceError","prototype"],
"%RegExpPrototype%":["RegExp","prototype"],"%SetPrototype%":["Set","prototype"],
"%SharedArrayBufferPrototype%":["SharedArrayBuffer","prototype"],
"%StringPrototype%":["String","prototype"],"%SymbolPrototype%":["Symbol","prototype"],
"%SyntaxErrorPrototype%":["SyntaxError","prototype"],
"%TypedArrayPrototype%":["TypedArray","prototype"],"%TypeErrorPrototype%":["TypeError","prototype"],
"%Uint8ArrayPrototype%":["Uint8Array","prototype"],
"%Uint8ClampedArrayPrototype%":["Uint8ClampedArray","prototype"],
"%Uint16ArrayPrototype%":["Uint16Array","prototype"],
"%Uint32ArrayPrototype%":["Uint32Array","prototype"],"%URIErrorPrototype%":["URIError","prototype"],
"%WeakMapPrototype%":["WeakMap","prototype"],"%WeakSetPrototype%":["WeakSet","prototype"]
},v=r(8612),b=r(7642),S=v.call(Function.call,Array.prototype.concat),w=v.call(Function.apply,Array.prototype.splice),E=v.call(Function.call,String.prototype.replace),A=v.call(Function.call,String.prototype.slice),R=/[^%.[\]]+|\[(?:(-?\d+(?:\.\d+)?)|(["'])((?:(?!\2)[^\\]|\\.)*?)\2)\]|(?=(?:\.|\[\])(?:\.|\[\]|%$))/g,x=/\\(\\)?/g,C=function(e){
var t=A(e,0,1),r=A(e,-1)
if("%"===t&&"%"!==r)throw new i("invalid intrinsic syntax, expected closing `%`")
if("%"===r&&"%"!==t)throw new i("invalid intrinsic syntax, expected opening `%`")
var n=[]
return E(e,R,(function(e,t,r,i){n[n.length]=r?E(i,x,"$1"):t||e})),n},I=function(e,t){var r,n=e
if(b(g,n)&&(n="%"+(r=g[n])[0]+"%"),b(m,n)){var o=m[n]
if(o===f&&(o=y(n)),void 0===o&&!t)throw new s("intrinsic "+e+" exists, but is not available. Please file an issue!")
return{alias:r,name:n,value:o}}throw new i("intrinsic "+e+" does not exist!")}
e.exports=function(e,t){
if("string"!=typeof e||0===e.length)throw new s("intrinsic name must be a non-empty string")
if(arguments.length>1&&"boolean"!=typeof t)throw new s('"allowMissing" argument must be a boolean')
var r=C(e),n=r.length>0?r[0]:"",o=I("%"+n+"%",t),a=o.name,c=o.value,p=!1,l=o.alias
l&&(n=l[0],w(r,S([0,1],l)))
for(var h=1,f=!0;h<r.length;h+=1){var d=r[h],y=A(d,0,1),g=A(d,-1)
if(('"'===y||"'"===y||"`"===y||'"'===g||"'"===g||"`"===g)&&y!==g)throw new i("property names with quotes must have matching quotes")
if("constructor"!==d&&f||(p=!0),b(m,a="%"+(n+="."+d)+"%"))c=m[a]
else if(null!=c){if(!(d in c)){
if(!t)throw new s("base intrinsic for "+e+" exists, but the property is not available.")
return}if(u&&h+1>=r.length){var v=u(c,d)
c=(f=!!v)&&"get"in v&&!("originalValue"in v.get)?v.get:c[d]}else f=b(c,d),c=c[d]
f&&!p&&(m[a]=c)}}return c}},1405:(e,t,r)=>{"use strict"
var n="undefined"!=typeof Symbol&&Symbol,i=r(5419)
e.exports=function(){
return"function"==typeof n&&"function"==typeof Symbol&&"symbol"==typeof n("foo")&&"symbol"==typeof Symbol("bar")&&i()
}},5419:e=>{"use strict"
e.exports=function(){
if("function"!=typeof Symbol||"function"!=typeof Object.getOwnPropertySymbols)return!1
if("symbol"==typeof Symbol.iterator)return!0
var e={},t=Symbol("test"),r=Object(t)
if("string"==typeof t)return!1
if("[object Symbol]"!==Object.prototype.toString.call(t))return!1
if("[object Symbol]"!==Object.prototype.toString.call(r))return!1
for(t in e[t]=42,e)return!1
if("function"==typeof Object.keys&&0!==Object.keys(e).length)return!1
if("function"==typeof Object.getOwnPropertyNames&&0!==Object.getOwnPropertyNames(e).length)return!1
var n=Object.getOwnPropertySymbols(e)
if(1!==n.length||n[0]!==t)return!1
if(!Object.prototype.propertyIsEnumerable.call(e,t))return!1
if("function"==typeof Object.getOwnPropertyDescriptor){var i=Object.getOwnPropertyDescriptor(e,t)
if(42!==i.value||!0!==i.enumerable)return!1}return!0}},6410:(e,t,r)=>{"use strict"
var n=r(5419)
e.exports=function(){return n()&&!!Symbol.toStringTag}},7642:(e,t,r)=>{"use strict"
var n=r(8612)
e.exports=n.call(Function.call,Object.prototype.hasOwnProperty)},645:(e,t)=>{
t.read=function(e,t,r,n,i){var o,s,a=8*i-n-1,u=(1<<a)-1,c=u>>1,p=-7,l=r?i-1:0,h=r?-1:1,f=e[t+l]
for(l+=h,o=f&(1<<-p)-1,f>>=-p,p+=a;p>0;o=256*o+e[t+l],l+=h,p-=8);for(s=o&(1<<-p)-1,o>>=-p,
p+=n;p>0;s=256*s+e[t+l],l+=h,p-=8);if(0===o)o=1-c
else{if(o===u)return s?NaN:1/0*(f?-1:1)
s+=Math.pow(2,n),o-=c}return(f?-1:1)*s*Math.pow(2,o-n)},t.write=function(e,t,r,n,i,o){
var s,a,u,c=8*o-i-1,p=(1<<c)-1,l=p>>1,h=23===i?Math.pow(2,-24)-Math.pow(2,-77):0,f=n?0:o-1,d=n?1:-1,m=t<0||0===t&&1/t<0?1:0
for(t=Math.abs(t),isNaN(t)||t===1/0?(a=isNaN(t)?1:0,s=p):(s=Math.floor(Math.log(t)/Math.LN2),
t*(u=Math.pow(2,-s))<1&&(s--,u*=2),(t+=s+l>=1?h/u:h*Math.pow(2,1-l))*u>=2&&(s++,u/=2),s+l>=p?(a=0,
s=p):s+l>=1?(a=(t*u-1)*Math.pow(2,i),
s+=l):(a=t*Math.pow(2,l-1)*Math.pow(2,i),s=0));i>=8;e[r+f]=255&a,f+=d,a/=256,i-=8);for(s=s<<i|a,
c+=i;c>0;e[r+f]=255&s,f+=d,s/=256,c-=8);e[r+f-d]|=128*m}},5717:e=>{
"function"==typeof Object.create?e.exports=function(e,t){
t&&(e.super_=t,e.prototype=Object.create(t.prototype,{constructor:{value:e,enumerable:!1,
writable:!0,configurable:!0}}))}:e.exports=function(e,t){if(t){e.super_=t
var r=function(){}
r.prototype=t.prototype,e.prototype=new r,e.prototype.constructor=e}}},2584:(e,t,r)=>{"use strict"
var n=r(6410)(),i=r(1924)("Object.prototype.toString"),o=function(e){
return!(n&&e&&"object"==typeof e&&Symbol.toStringTag in e)&&"[object Arguments]"===i(e)
},s=function(e){
return!!o(e)||null!==e&&"object"==typeof e&&"number"==typeof e.length&&e.length>=0&&"[object Array]"!==i(e)&&"[object Function]"===i(e.callee)
},a=function(){return o(arguments)}()
o.isLegacyArguments=s,e.exports=a?o:s},8662:(e,t,r)=>{"use strict"
var n,i=Object.prototype.toString,o=Function.prototype.toString,s=/^\s*(?:function)?\*/,a=r(6410)(),u=Object.getPrototypeOf
e.exports=function(e){if("function"!=typeof e)return!1
if(s.test(o.call(e)))return!0
if(!a)return"[object GeneratorFunction]"===i.call(e)
if(!u)return!1
if(void 0===n){var t=function(){if(!a)return!1
try{return Function("return function*() {}")()}catch(e){}}()
n=!!t&&u(t)}return u(e)===n}},5692:(e,t,r)=>{"use strict"
var n=r(9804),i=r(3083),o=r(1924),s=o("Object.prototype.toString"),a=r(6410)(),u="undefined"==typeof globalThis?r.g:globalThis,c=i(),p=o("Array.prototype.indexOf",!0)||function(e,t){
for(var r=0;r<e.length;r+=1)if(e[r]===t)return r
return-1},l=o("String.prototype.slice"),h={},f=r(882),d=Object.getPrototypeOf
a&&f&&d&&n(c,(function(e){var t=new u[e]
if(Symbol.toStringTag in t){var r=d(t),n=f(r,Symbol.toStringTag)
if(!n){var i=d(r)
n=f(i,Symbol.toStringTag)}h[e]=n.get}})),e.exports=function(e){if(!e||"object"!=typeof e)return!1
if(!a||!(Symbol.toStringTag in e)){var t=l(s(e),8,-1)
return p(c,t)>-1}return!!f&&function(e){var t=!1
return n(h,(function(r,n){if(!t)try{t=r.call(e)===n}catch(e){}})),t}(e)}},5826:e=>{var t={}.toString
e.exports=Array.isArray||function(e){return"[object Array]"==t.call(e)}},4509:(e,t)=>{!function(e){
"use strict"
function t(e){return null!==e&&"[object Array]"===Object.prototype.toString.call(e)}function r(e){
return null!==e&&"[object Object]"===Object.prototype.toString.call(e)}function n(e,i){
if(e===i)return!0
if(Object.prototype.toString.call(e)!==Object.prototype.toString.call(i))return!1
if(!0===t(e)){if(e.length!==i.length)return!1
for(var o=0;o<e.length;o++)if(!1===n(e[o],i[o]))return!1
return!0}if(!0===r(e)){var s={}
for(var a in e)if(hasOwnProperty.call(e,a)){if(!1===n(e[a],i[a]))return!1
s[a]=!0}for(var u in i)if(hasOwnProperty.call(i,u)&&!0!==s[u])return!1
return!0}return!1}function i(e){if(""===e||!1===e||null===e)return!0
if(t(e)&&0===e.length)return!0
if(r(e)){for(var n in e)if(e.hasOwnProperty(n))return!1
return!0}return!1}var o
o="function"==typeof String.prototype.trimLeft?function(e){return e.trimLeft()}:function(e){
return e.match(/^\s*(.*)/)[1]}
var s=0,a=2,u={0:"number",1:"any",2:"string",3:"array",4:"object",5:"boolean",6:"expression",
7:"null",8:"Array<number>",9:"Array<string>"
},c="UnquotedIdentifier",p="QuotedIdentifier",l="Rbracket",h="Rparen",f="Comma",d="Colon",m="Rbrace",y="Number",g="Current",v="Expref",b="Pipe",S="EQ",w="GT",E="LT",A="GTE",R="LTE",x="NE",C="Flatten",I="Star",_="Filter",k="Dot",T="Lbrace",P="Lbracket",O="Lparen",L="Literal",q={
".":k,"*":I,",":f,":":d,"{":T,"}":m,"]":l,"(":O,")":h,"@":g},N={"<":!0,">":!0,"=":!0,"!":!0},D={
" ":!0,"\t":!0,"\n":!0}
function U(e){return e>="0"&&e<="9"||"-"===e}function M(){}M.prototype={tokenize:function(e){
var t,r,n,i,o=[]
for(this._current=0;this._current<e.length;)if((i=e[this._current])>="a"&&i<="z"||i>="A"&&i<="Z"||"_"===i)t=this._current,
r=this._consumeUnquotedIdentifier(e),o.push({type:c,value:r,start:t})
else if(void 0!==q[e[this._current]])o.push({type:q[e[this._current]],value:e[this._current],
start:this._current}),this._current++
else if(U(e[this._current]))n=this._consumeNumber(e),o.push(n)
else if("["===e[this._current])n=this._consumeLBracket(e),o.push(n)
else if('"'===e[this._current])t=this._current,r=this._consumeQuotedIdentifier(e),o.push({type:p,
value:r,start:t})
else if("'"===e[this._current])t=this._current,r=this._consumeRawStringLiteral(e),o.push({type:L,
value:r,start:t})
else if("`"===e[this._current]){t=this._current
var s=this._consumeLiteral(e)
o.push({type:L,value:s,start:t})
}else if(void 0!==N[e[this._current]])o.push(this._consumeOperator(e))
else if(void 0!==D[e[this._current]])this._current++
else if("&"===e[this._current])t=this._current,this._current++,"&"===e[this._current]?(this._current++,
o.push({type:"And",value:"&&",start:t})):o.push({type:v,value:"&",start:t})
else{if("|"!==e[this._current]){var a=new Error("Unknown character:"+e[this._current])
throw a.name="LexerError",a}t=this._current,this._current++,"|"===e[this._current]?(this._current++,
o.push({type:"Or",value:"||",start:t})):o.push({type:b,value:"|",start:t})}return o},
_consumeUnquotedIdentifier:function(e){var t,r=this._current
for(this._current++;this._current<e.length&&((t=e[this._current])>="a"&&t<="z"||t>="A"&&t<="Z"||t>="0"&&t<="9"||"_"===t);)this._current++
return e.slice(r,this._current)},_consumeQuotedIdentifier:function(e){var t=this._current
this._current++
for(var r=e.length;'"'!==e[this._current]&&this._current<r;){var n=this._current
"\\"!==e[n]||"\\"!==e[n+1]&&'"'!==e[n+1]?n++:n+=2,this._current=n}return this._current++,
JSON.parse(e.slice(t,this._current))},_consumeRawStringLiteral:function(e){var t=this._current
this._current++
for(var r=e.length;"'"!==e[this._current]&&this._current<r;){var n=this._current
"\\"!==e[n]||"\\"!==e[n+1]&&"'"!==e[n+1]?n++:n+=2,this._current=n}return this._current++,
e.slice(t+1,this._current-1).replace("\\'","'")},_consumeNumber:function(e){var t=this._current
this._current++
for(var r=e.length;U(e[this._current])&&this._current<r;)this._current++
var n=parseInt(e.slice(t,this._current))
return{type:y,value:n,start:t}},_consumeLBracket:function(e){var t=this._current
return this._current++,"?"===e[this._current]?(this._current++,{type:_,value:"[?",start:t
}):"]"===e[this._current]?(this._current++,{type:C,value:"[]",start:t}):{type:P,value:"[",start:t}},
_consumeOperator:function(e){var t=this._current,r=e[t]
return this._current++,"!"===r?"="===e[this._current]?(this._current++,{type:x,value:"!=",start:t
}):{type:"Not",value:"!",start:t}:"<"===r?"="===e[this._current]?(this._current++,{type:R,
value:"<=",start:t}):{type:E,value:"<",start:t}:">"===r?"="===e[this._current]?(this._current++,{
type:A,value:">=",start:t}):{type:w,value:">",start:t
}:"="===r&&"="===e[this._current]?(this._current++,{type:S,value:"==",start:t}):void 0},
_consumeLiteral:function(e){this._current++
for(var t,r=this._current,n=e.length;"`"!==e[this._current]&&this._current<n;){var i=this._current
"\\"!==e[i]||"\\"!==e[i+1]&&"`"!==e[i+1]?i++:i+=2,this._current=i}var s=o(e.slice(r,this._current))
return s=s.replace("\\`","`"),t=this._looksLikeJSON(s)?JSON.parse(s):JSON.parse('"'+s+'"'),
this._current++,t},_looksLikeJSON:function(e){if(""===e)return!1
if('[{"'.indexOf(e[0])>=0)return!0
if(["true","false","null"].indexOf(e)>=0)return!0
if(!("-0123456789".indexOf(e[0])>=0))return!1
try{return JSON.parse(e),!0}catch(e){return!1}}}
var j={}
function B(){}function F(e){this.runtime=e}function z(e){this._interpreter=e,this.functionTable={
abs:{_func:this._functionAbs,_signature:[{types:[s]}]},avg:{_func:this._functionAvg,_signature:[{
types:[8]}]},ceil:{_func:this._functionCeil,_signature:[{types:[s]}]},contains:{
_func:this._functionContains,_signature:[{types:[a,3]},{types:[1]}]},ends_with:{
_func:this._functionEndsWith,_signature:[{types:[a]},{types:[a]}]},floor:{_func:this._functionFloor,
_signature:[{types:[s]}]},length:{_func:this._functionLength,_signature:[{types:[a,3,4]}]},map:{
_func:this._functionMap,_signature:[{types:[6]},{types:[3]}]},max:{_func:this._functionMax,
_signature:[{types:[8,9]}]},merge:{_func:this._functionMerge,_signature:[{types:[4],variadic:!0}]},
max_by:{_func:this._functionMaxBy,_signature:[{types:[3]},{types:[6]}]},sum:{
_func:this._functionSum,_signature:[{types:[8]}]},starts_with:{_func:this._functionStartsWith,
_signature:[{types:[a]},{types:[a]}]},min:{_func:this._functionMin,_signature:[{types:[8,9]}]},
min_by:{_func:this._functionMinBy,_signature:[{types:[3]},{types:[6]}]},type:{
_func:this._functionType,_signature:[{types:[1]}]},keys:{_func:this._functionKeys,_signature:[{
types:[4]}]},values:{_func:this._functionValues,_signature:[{types:[4]}]},sort:{
_func:this._functionSort,_signature:[{types:[9,8]}]},sort_by:{_func:this._functionSortBy,
_signature:[{types:[3]},{types:[6]}]},join:{_func:this._functionJoin,_signature:[{types:[a]},{
types:[9]}]},reverse:{_func:this._functionReverse,_signature:[{types:[a,3]}]},to_array:{
_func:this._functionToArray,_signature:[{types:[1]}]},to_string:{_func:this._functionToString,
_signature:[{types:[1]}]},to_number:{_func:this._functionToNumber,_signature:[{types:[1]}]},
not_null:{_func:this._functionNotNull,_signature:[{types:[1],variadic:!0}]}}}j.EOF=0,
j.UnquotedIdentifier=0,j.QuotedIdentifier=0,j.Rbracket=0,j.Rparen=0,j.Comma=0,j.Rbrace=0,j.Number=0,
j.Current=0,j.Expref=0,j.Pipe=1,j.Or=2,j.And=3,j.EQ=5,j.GT=5,j.LT=5,j.GTE=5,j.LTE=5,j.NE=5,
j.Flatten=9,j.Star=20,j.Filter=21,j.Dot=40,j.Not=45,j.Lbrace=50,j.Lbracket=55,j.Lparen=60,
B.prototype={parse:function(e){this._loadTokens(e),this.index=0
var t=this.expression(0)
if("EOF"!==this._lookahead(0)){
var r=this._lookaheadToken(0),n=new Error("Unexpected token type: "+r.type+", value: "+r.value)
throw n.name="ParserError",n}return t},_loadTokens:function(e){var t=(new M).tokenize(e)
t.push({type:"EOF",value:"",start:e.length}),this.tokens=t},expression:function(e){
var t=this._lookaheadToken(0)
this._advance()
for(var r=this.nud(t),n=this._lookahead(0);e<j[n];)this._advance(),r=this.led(n,r),
n=this._lookahead(0)
return r},_lookahead:function(e){return this.tokens[this.index+e].type},_lookaheadToken:function(e){
return this.tokens[this.index+e]},_advance:function(){this.index++},nud:function(e){var t,r
switch(e.type){case L:return{type:"Literal",value:e.value}
case c:return{type:"Field",name:e.value}
case p:var n={type:"Field",name:e.value}
if(this._lookahead(0)===O)throw new Error("Quoted identifier not allowed for function names.")
return n
case"Not":return{type:"NotExpression",children:[t=this.expression(j.Not)]}
case I:return t=null,{type:"ValueProjection",children:[{type:"Identity"},t=this._lookahead(0)===l?{
type:"Identity"}:this._parseProjectionRHS(j.Star)]}
case _:return this.led(e.type,{type:"Identity"})
case T:return this._parseMultiselectHash()
case C:return{type:"Projection",children:[{type:C,children:[{type:"Identity"}]
},t=this._parseProjectionRHS(j.Flatten)]}
case P:return this._lookahead(0)===y||this._lookahead(0)===d?(t=this._parseIndexExpression(),
this._projectIfSlice({type:"Identity"
},t)):this._lookahead(0)===I&&this._lookahead(1)===l?(this._advance(),this._advance(),{
type:"Projection",children:[{type:"Identity"},t=this._parseProjectionRHS(j.Star)]
}):this._parseMultiselectList()
case g:return{type:g}
case v:return{type:"ExpressionReference",children:[r=this.expression(j.Expref)]}
case O:for(var i=[];this._lookahead(0)!==h;)this._lookahead(0)===g?(r={type:g
},this._advance()):r=this.expression(0),i.push(r)
return this._match(h),i[0]
default:this._errorToken(e)}},led:function(e,t){var r
switch(e){case k:var n=j.Dot
return this._lookahead(0)!==I?{type:"Subexpression",children:[t,r=this._parseDotRHS(n)]
}:(this._advance(),{type:"ValueProjection",children:[t,r=this._parseProjectionRHS(n)]})
case b:return r=this.expression(j.Pipe),{type:b,children:[t,r]}
case"Or":return{type:"OrExpression",children:[t,r=this.expression(j.Or)]}
case"And":return{type:"AndExpression",children:[t,r=this.expression(j.And)]}
case O:for(var i,o=t.name,s=[];this._lookahead(0)!==h;)this._lookahead(0)===g?(i={type:g},
this._advance()):i=this.expression(0),this._lookahead(0)===f&&this._match(f),s.push(i)
return this._match(h),{type:"Function",name:o,children:s}
case _:var a=this.expression(0)
return this._match(l),{type:"FilterProjection",children:[t,r=this._lookahead(0)===C?{type:"Identity"
}:this._parseProjectionRHS(j.Filter),a]}
case C:return{type:"Projection",children:[{type:C,children:[t]},this._parseProjectionRHS(j.Flatten)]
}
case S:case x:case w:case A:case E:case R:return this._parseComparator(t,e)
case P:var u=this._lookaheadToken(0)
return u.type===y||u.type===d?(r=this._parseIndexExpression(),this._projectIfSlice(t,r)):(this._match(I),
this._match(l),{type:"Projection",children:[t,r=this._parseProjectionRHS(j.Star)]})
default:this._errorToken(this._lookaheadToken(0))}},_match:function(e){if(this._lookahead(0)!==e){
var t=this._lookaheadToken(0),r=new Error("Expected "+e+", got: "+t.type)
throw r.name="ParserError",r}this._advance()},_errorToken:function(e){
var t=new Error("Invalid token ("+e.type+'): "'+e.value+'"')
throw t.name="ParserError",t},_parseIndexExpression:function(){
if(this._lookahead(0)===d||this._lookahead(1)===d)return this._parseSliceExpression()
var e={type:"Index",value:this._lookaheadToken(0).value}
return this._advance(),this._match(l),e},_projectIfSlice:function(e,t){var r={
type:"IndexExpression",children:[e,t]}
return"Slice"===t.type?{type:"Projection",children:[r,this._parseProjectionRHS(j.Star)]}:r},
_parseSliceExpression:function(){for(var e=[null,null,null],t=0,r=this._lookahead(0);r!==l&&t<3;){
if(r===d)t++,this._advance()
else{if(r!==y){
var n=this._lookahead(0),i=new Error("Syntax error, unexpected token: "+n.value+"("+n.type+")")
throw i.name="Parsererror",i}e[t]=this._lookaheadToken(0).value,this._advance()}r=this._lookahead(0)
}return this._match(l),{type:"Slice",children:e}},_parseComparator:function(e,t){return{
type:"Comparator",name:t,children:[e,this.expression(j[t])]}},_parseDotRHS:function(e){
var t=this._lookahead(0)
return[c,p,I].indexOf(t)>=0?this.expression(e):t===P?(this._match(P),this._parseMultiselectList()):t===T?(this._match(T),
this._parseMultiselectHash()):void 0},_parseProjectionRHS:function(e){var t
if(j[this._lookahead(0)]<10)t={type:"Identity"}
else if(this._lookahead(0)===P)t=this.expression(e)
else if(this._lookahead(0)===_)t=this.expression(e)
else{if(this._lookahead(0)!==k){
var r=this._lookaheadToken(0),n=new Error("Sytanx error, unexpected token: "+r.value+"("+r.type+")")
throw n.name="ParserError",n}this._match(k),t=this._parseDotRHS(e)}return t},
_parseMultiselectList:function(){for(var e=[];this._lookahead(0)!==l;){var t=this.expression(0)
if(e.push(t),this._lookahead(0)===f&&(this._match(f),this._lookahead(0)===l))throw new Error("Unexpected token Rbracket")
}return this._match(l),{type:"MultiSelectList",children:e}},_parseMultiselectHash:function(){
for(var e,t,r,n=[],i=[c,p];;){
if(e=this._lookaheadToken(0),i.indexOf(e.type)<0)throw new Error("Expecting an identifier token, got: "+e.type)
if(t=e.value,this._advance(),this._match(d),r={type:"KeyValuePair",name:t,value:this.expression(0)},
n.push(r),this._lookahead(0)===f)this._match(f)
else if(this._lookahead(0)===m){this._match(m)
break}}return{type:"MultiSelectHash",children:n}}},F.prototype={search:function(e,t){
return this.visit(e,t)},visit:function(e,o){var s,a,u,c,p,l,h,f,d
switch(e.type){case"Field":return null!==o&&r(o)?void 0===(l=o[e.name])?null:l:null
case"Subexpression":
for(u=this.visit(e.children[0],o),d=1;d<e.children.length;d++)if(null===(u=this.visit(e.children[1],u)))return null
return u
case"IndexExpression":return h=this.visit(e.children[0],o),this.visit(e.children[1],h)
case"Index":if(!t(o))return null
var m=e.value
return m<0&&(m=o.length+m),void 0===(u=o[m])&&(u=null),u
case"Slice":if(!t(o))return null
var y=e.children.slice(0),I=this.computeSliceParams(o.length,y),_=I[0],k=I[1],T=I[2]
if(u=[],T>0)for(d=_;d<k;d+=T)u.push(o[d])
else for(d=_;d>k;d+=T)u.push(o[d])
return u
case"Projection":var P=this.visit(e.children[0],o)
if(!t(P))return null
for(f=[],d=0;d<P.length;d++)null!==(a=this.visit(e.children[1],P[d]))&&f.push(a)
return f
case"ValueProjection":if(!r(P=this.visit(e.children[0],o)))return null
f=[]
var O=function(e){for(var t=Object.keys(e),r=[],n=0;n<t.length;n++)r.push(e[t[n]])
return r}(P)
for(d=0;d<O.length;d++)null!==(a=this.visit(e.children[1],O[d]))&&f.push(a)
return f
case"FilterProjection":if(!t(P=this.visit(e.children[0],o)))return null
var L=[],q=[]
for(d=0;d<P.length;d++)i(s=this.visit(e.children[2],P[d]))||L.push(P[d])
for(var N=0;N<L.length;N++)null!==(a=this.visit(e.children[1],L[N]))&&q.push(a)
return q
case"Comparator":switch(c=this.visit(e.children[0],o),p=this.visit(e.children[1],o),e.name){case S:
u=n(c,p)
break
case x:u=!n(c,p)
break
case w:u=c>p
break
case A:u=c>=p
break
case E:u=c<p
break
case R:u=c<=p
break
default:throw new Error("Unknown comparator: "+e.name)}return u
case C:var D=this.visit(e.children[0],o)
if(!t(D))return null
var U=[]
for(d=0;d<D.length;d++)t(a=D[d])?U.push.apply(U,a):U.push(a)
return U
case"Identity":return o
case"MultiSelectList":if(null===o)return null
for(f=[],d=0;d<e.children.length;d++)f.push(this.visit(e.children[d],o))
return f
case"MultiSelectHash":if(null===o)return null
var M
for(f={},d=0;d<e.children.length;d++)f[(M=e.children[d]).name]=this.visit(M.value,o)
return f
case"OrExpression":return i(s=this.visit(e.children[0],o))&&(s=this.visit(e.children[1],o)),s
case"AndExpression":return!0===i(c=this.visit(e.children[0],o))?c:this.visit(e.children[1],o)
case"NotExpression":return i(c=this.visit(e.children[0],o))
case"Literal":return e.value
case b:return h=this.visit(e.children[0],o),this.visit(e.children[1],h)
case g:return o
case"Function":var j=[]
for(d=0;d<e.children.length;d++)j.push(this.visit(e.children[d],o))
return this.runtime.callFunction(e.name,j)
case"ExpressionReference":var B=e.children[0]
return B.jmespathType=v,B
default:throw new Error("Unknown node type: "+e.type)}},computeSliceParams:function(e,t){
var r=t[0],n=t[1],i=t[2],o=[null,null,null]
if(null===i)i=1
else if(0===i){var s=new Error("Invalid slice, step cannot be 0")
throw s.name="RuntimeError",s}var a=i<0
return r=null===r?a?e-1:0:this.capSliceRange(e,r,i),n=null===n?a?-1:e:this.capSliceRange(e,n,i),
o[0]=r,o[1]=n,o[2]=i,o},capSliceRange:function(e,t,r){
return t<0?(t+=e)<0&&(t=r<0?-1:0):t>=e&&(t=r<0?e-1:e),t}},z.prototype={callFunction:function(e,t){
var r=this.functionTable[e]
if(void 0===r)throw new Error("Unknown function: "+e+"()")
return this._validateArgs(e,t,r._signature),r._func.call(this,t)},_validateArgs:function(e,t,r){
var n,i,o,s
if(r[r.length-1].variadic){if(t.length<r.length)throw n=1===r.length?" argument":" arguments",
new Error("ArgumentError: "+e+"() takes at least"+r.length+n+" but received "+t.length)
}else if(t.length!==r.length)throw n=1===r.length?" argument":" arguments",
new Error("ArgumentError: "+e+"() takes "+r.length+n+" but received "+t.length)
for(var a=0;a<r.length;a++){s=!1,i=r[a].types,o=this._getTypeName(t[a])
for(var c=0;c<i.length;c++)if(this._typeMatches(o,i[c],t[a])){s=!0
break}if(!s){var p=i.map((function(e){return u[e]})).join(",")
throw new Error("TypeError: "+e+"() expected argument "+(a+1)+" to be type "+p+" but received type "+u[o]+" instead.")
}}},_typeMatches:function(e,t,r){if(1===t)return!0
if(9!==t&&8!==t&&3!==t)return e===t
if(3===t)return 3===e
if(3===e){var n
8===t?n=s:9===t&&(n=a)
for(var i=0;i<r.length;i++)if(!this._typeMatches(this._getTypeName(r[i]),n,r[i]))return!1
return!0}},_getTypeName:function(e){switch(Object.prototype.toString.call(e)){case"[object String]":
return a
case"[object Number]":return s
case"[object Array]":return 3
case"[object Boolean]":return 5
case"[object Null]":return 7
case"[object Object]":return e.jmespathType===v?6:4}},_functionStartsWith:function(e){
return 0===e[0].lastIndexOf(e[1])},_functionEndsWith:function(e){var t=e[0],r=e[1]
return-1!==t.indexOf(r,t.length-r.length)},_functionReverse:function(e){
if(this._getTypeName(e[0])===a){for(var t=e[0],r="",n=t.length-1;n>=0;n--)r+=t[n]
return r}var i=e[0].slice(0)
return i.reverse(),i},_functionAbs:function(e){return Math.abs(e[0])},_functionCeil:function(e){
return Math.ceil(e[0])},_functionAvg:function(e){for(var t=0,r=e[0],n=0;n<r.length;n++)t+=r[n]
return t/r.length},_functionContains:function(e){return e[0].indexOf(e[1])>=0},
_functionFloor:function(e){return Math.floor(e[0])},_functionLength:function(e){
return r(e[0])?Object.keys(e[0]).length:e[0].length},_functionMap:function(e){
for(var t=[],r=this._interpreter,n=e[0],i=e[1],o=0;o<i.length;o++)t.push(r.visit(n,i[o]))
return t},_functionMerge:function(e){for(var t={},r=0;r<e.length;r++){var n=e[r]
for(var i in n)t[i]=n[i]}return t},_functionMax:function(e){if(e[0].length>0){
if(this._getTypeName(e[0][0])===s)return Math.max.apply(Math,e[0])
for(var t=e[0],r=t[0],n=1;n<t.length;n++)r.localeCompare(t[n])<0&&(r=t[n])
return r}return null},_functionMin:function(e){if(e[0].length>0){
if(this._getTypeName(e[0][0])===s)return Math.min.apply(Math,e[0])
for(var t=e[0],r=t[0],n=1;n<t.length;n++)t[n].localeCompare(r)<0&&(r=t[n])
return r}return null},_functionSum:function(e){for(var t=0,r=e[0],n=0;n<r.length;n++)t+=r[n]
return t},_functionType:function(e){switch(this._getTypeName(e[0])){case s:return"number"
case a:return"string"
case 3:return"array"
case 4:return"object"
case 5:return"boolean"
case 6:return"expref"
case 7:return"null"}},_functionKeys:function(e){return Object.keys(e[0])},
_functionValues:function(e){for(var t=e[0],r=Object.keys(t),n=[],i=0;i<r.length;i++)n.push(t[r[i]])
return n},_functionJoin:function(e){var t=e[0]
return e[1].join(t)},_functionToArray:function(e){return 3===this._getTypeName(e[0])?e[0]:[e[0]]},
_functionToString:function(e){return this._getTypeName(e[0])===a?e[0]:JSON.stringify(e[0])},
_functionToNumber:function(e){var t,r=this._getTypeName(e[0])
return r===s?e[0]:r!==a||(t=+e[0],isNaN(t))?null:t},_functionNotNull:function(e){
for(var t=0;t<e.length;t++)if(7!==this._getTypeName(e[t]))return e[t]
return null},_functionSort:function(e){var t=e[0].slice(0)
return t.sort(),t},_functionSortBy:function(e){var t=e[0].slice(0)
if(0===t.length)return t
var r=this._interpreter,n=e[1],i=this._getTypeName(r.visit(n,t[0]))
if([s,a].indexOf(i)<0)throw new Error("TypeError")
for(var o=this,u=[],c=0;c<t.length;c++)u.push([c,t[c]])
u.sort((function(e,t){var s=r.visit(n,e[1]),a=r.visit(n,t[1])
if(o._getTypeName(s)!==i)throw new Error("TypeError: expected "+i+", received "+o._getTypeName(s))
if(o._getTypeName(a)!==i)throw new Error("TypeError: expected "+i+", received "+o._getTypeName(a))
return s>a?1:s<a?-1:e[0]-t[0]}))
for(var p=0;p<u.length;p++)t[p]=u[p][1]
return t},_functionMaxBy:function(e){
for(var t,r,n=e[1],i=e[0],o=this.createKeyFunction(n,[s,a]),u=-1/0,c=0;c<i.length;c++)(r=o(i[c]))>u&&(u=r,
t=i[c])
return t},_functionMinBy:function(e){
for(var t,r,n=e[1],i=e[0],o=this.createKeyFunction(n,[s,a]),u=1/0,c=0;c<i.length;c++)(r=o(i[c]))<u&&(u=r,
t=i[c])
return t},createKeyFunction:function(e,t){var r=this,n=this._interpreter
return function(i){var o=n.visit(e,i)
if(t.indexOf(r._getTypeName(o))<0){
var s="TypeError: expected one of "+t+", received "+r._getTypeName(o)
throw new Error(s)}return o}}},e.tokenize=function(e){return(new M).tokenize(e)},
e.compile=function(e){return(new B).parse(e)},e.search=function(e,t){var r=new B,n=new z,i=new F(n)
n._interpreter=i
var o=r.parse(t)
return i.search(o,e)},e.strictDeepEqual=n}(t)},4971:function(e,t,r){var n
e=r.nmd(e),function(i){t&&t.nodeType,e&&e.nodeType
var o="object"==typeof r.g&&r.g
o.global!==o&&o.window!==o&&o.self
var s,a=2147483647,u=36,c=/^xn--/,p=/[^\x20-\x7E]/,l=/[\x2E\u3002\uFF0E\uFF61]/g,h={
overflow:"Overflow: input needs wider integers to process",
"not-basic":"Illegal input >= 0x80 (not a basic code point)","invalid-input":"Invalid input"
},f=Math.floor,d=String.fromCharCode
function m(e){throw RangeError(h[e])}function y(e,t){for(var r=e.length,n=[];r--;)n[r]=t(e[r])
return n}function g(e,t){var r=e.split("@"),n=""
return r.length>1&&(n=r[0]+"@",e=r[1]),n+y((e=e.replace(l,".")).split("."),t).join(".")}
function v(e){
for(var t,r,n=[],i=0,o=e.length;i<o;)(t=e.charCodeAt(i++))>=55296&&t<=56319&&i<o?56320==(64512&(r=e.charCodeAt(i++)))?n.push(((1023&t)<<10)+(1023&r)+65536):(n.push(t),
i--):n.push(t)
return n}function b(e){return y(e,(function(e){var t=""
return e>65535&&(t+=d((e-=65536)>>>10&1023|55296),e=56320|1023&e),t+d(e)})).join("")}
function S(e,t){return e+22+75*(e<26)-((0!=t)<<5)}function w(e,t,r){var n=0
for(e=r?f(e/700):e>>1,e+=f(e/t);e>455;n+=u)e=f(e/35)
return f(n+36*e/(e+38))}function E(e){var t,r,n,i,o,s,c,p,l,h,d,y=[],g=e.length,v=0,S=128,E=72
for((r=e.lastIndexOf("-"))<0&&(r=0),n=0;n<r;++n)e.charCodeAt(n)>=128&&m("not-basic"),
y.push(e.charCodeAt(n))
for(i=r>0?r+1:0;i<g;){
for(o=v,s=1,c=u;i>=g&&m("invalid-input"),((p=(d=e.charCodeAt(i++))-48<10?d-22:d-65<26?d-65:d-97<26?d-97:u)>=u||p>f((a-v)/s))&&m("overflow"),
v+=p*s,!(p<(l=c<=E?1:c>=E+26?26:c-E));c+=u)s>f(a/(h=u-l))&&m("overflow"),s*=h
E=w(v-o,t=y.length+1,0==o),f(v/t)>a-S&&m("overflow"),S+=f(v/t),v%=t,y.splice(v++,0,S)}return b(y)}
function A(e){var t,r,n,i,o,s,c,p,l,h,y,g,b,E,A,R=[]
for(g=(e=v(e)).length,t=128,r=0,o=72,s=0;s<g;++s)(y=e[s])<128&&R.push(d(y))
for(n=i=R.length,i&&R.push("-");n<g;){for(c=a,s=0;s<g;++s)(y=e[s])>=t&&y<c&&(c=y)
for(c-t>f((a-r)/(b=n+1))&&m("overflow"),r+=(c-t)*b,t=c,s=0;s<g;++s)if((y=e[s])<t&&++r>a&&m("overflow"),
y==t){for(p=r,l=u;!(p<(h=l<=o?1:l>=o+26?26:l-o));l+=u)A=p-h,E=u-h,R.push(d(S(h+A%E,0))),p=f(A/E)
R.push(d(S(p,0))),o=w(r,b,n==i),r=0,++n}++r,++t}return R.join("")}s={version:"1.3.2",ucs2:{decode:v,
encode:b},decode:E,encode:A,toASCII:function(e){return g(e,(function(e){
return p.test(e)?"xn--"+A(e):e}))},toUnicode:function(e){return g(e,(function(e){
return c.test(e)?E(e.slice(4).toLowerCase()):e}))}},void 0===(n=function(){return s
}.call(t,r,t,e))||(e.exports=n)}()},2587:e=>{"use strict"
function t(e,t){return Object.prototype.hasOwnProperty.call(e,t)}e.exports=function(e,r,n,i){
r=r||"&",n=n||"="
var o={}
if("string"!=typeof e||0===e.length)return o
var s=/\+/g
e=e.split(r)
var a=1e3
i&&"number"==typeof i.maxKeys&&(a=i.maxKeys)
var u=e.length
a>0&&u>a&&(u=a)
for(var c=0;c<u;++c){var p,l,h,f,d=e[c].replace(s,"%20"),m=d.indexOf(n)
m>=0?(p=d.substr(0,m),l=d.substr(m+1)):(p=d,l=""),h=decodeURIComponent(p),f=decodeURIComponent(l),
t(o,h)?Array.isArray(o[h])?o[h].push(f):o[h]=[o[h],f]:o[h]=f}return o}},2361:e=>{"use strict"
var t=function(e){switch(typeof e){case"string":return e
case"boolean":return e?"true":"false"
case"number":return isFinite(e)?e:""
default:return""}}
e.exports=function(e,r,n,i){
return r=r||"&",n=n||"=",null===e&&(e=void 0),"object"==typeof e?Object.keys(e).map((function(i){
var o=encodeURIComponent(t(i))+n
return Array.isArray(e[i])?e[i].map((function(e){return o+encodeURIComponent(t(e))
})).join(r):o+encodeURIComponent(t(e[i]))
})).join(r):i?encodeURIComponent(t(i))+n+encodeURIComponent(t(e)):""}},7673:(e,t,r)=>{"use strict"
t.decode=t.parse=r(2587),t.encode=t.stringify=r(2361)},8575:(e,t,r)=>{var n=r(4971)
function i(){this.protocol=null,this.slashes=null,this.auth=null,this.host=null,this.port=null,
this.hostname=null,this.hash=null,this.search=null,this.query=null,this.pathname=null,
this.path=null,this.href=null}t.parse=g,t.resolve=function(e,t){return g(e,!1,!0).resolve(t)},
t.resolveObject=function(e,t){return e?g(e,!1,!0).resolveObject(t):t},t.format=function(e){
return v(e)&&(e=g(e)),e instanceof i?e.format():i.prototype.format.call(e)},t.Url=i
var o=/^([a-z0-9.+-]+:)/i,s=/:[0-9]*$/,a=["{","}","|","\\","^","`"].concat(["<",">",'"',"`"," ","\r","\n","\t"]),u=["'"].concat(a),c=["%","/","?",";","#"].concat(u),p=["/","?","#"],l=/^[a-z0-9A-Z_-]{0,63}$/,h=/^([a-z0-9A-Z_-]{0,63})(.*)$/,f={
javascript:!0,"javascript:":!0},d={javascript:!0,"javascript:":!0},m={http:!0,https:!0,ftp:!0,
gopher:!0,file:!0,"http:":!0,"https:":!0,"ftp:":!0,"gopher:":!0,"file:":!0},y=r(7673)
function g(e,t,r){if(e&&b(e)&&e instanceof i)return e
var n=new i
return n.parse(e,t,r),n}function v(e){return"string"==typeof e}function b(e){
return"object"==typeof e&&null!==e}function S(e){return null===e}i.prototype.parse=function(e,t,r){
if(!v(e))throw new TypeError("Parameter 'url' must be a string, not "+typeof e)
var i=e
i=i.trim()
var s=o.exec(i)
if(s){var a=(s=s[0]).toLowerCase()
this.protocol=a,i=i.substr(s.length)}if(r||s||i.match(/^\/\/[^@\/]+@[^@\/]+/)){
var g="//"===i.substr(0,2)
!g||s&&d[s]||(i=i.substr(2),this.slashes=!0)}if(!d[s]&&(g||s&&!m[s])){
for(var b,S,w=-1,E=0;E<p.length;E++)-1!==(A=i.indexOf(p[E]))&&(-1===w||A<w)&&(w=A)
for(-1!==(S=-1===w?i.lastIndexOf("@"):i.lastIndexOf("@",w))&&(b=i.slice(0,S),i=i.slice(S+1),
this.auth=decodeURIComponent(b)),w=-1,E=0;E<c.length;E++){var A
;-1!==(A=i.indexOf(c[E]))&&(-1===w||A<w)&&(w=A)}-1===w&&(w=i.length),this.host=i.slice(0,w),
i=i.slice(w),this.parseHost(),this.hostname=this.hostname||""
var R="["===this.hostname[0]&&"]"===this.hostname[this.hostname.length-1]
if(!R)for(var x=this.hostname.split(/\./),C=(E=0,x.length);E<C;E++){var I=x[E]
if(I&&!I.match(l)){for(var _="",k=0,T=I.length;k<T;k++)I.charCodeAt(k)>127?_+="x":_+=I[k]
if(!_.match(l)){var P=x.slice(0,E),O=x.slice(E+1),L=I.match(h)
L&&(P.push(L[1]),O.unshift(L[2])),O.length&&(i="/"+O.join(".")+i),this.hostname=P.join(".")
break}}}if(this.hostname.length>255?this.hostname="":this.hostname=this.hostname.toLowerCase(),!R){
var q=this.hostname.split("."),N=[]
for(E=0;E<q.length;++E){var D=q[E]
N.push(D.match(/[^A-Za-z0-9_-]/)?"xn--"+n.encode(D):D)}this.hostname=N.join(".")}
var U=this.port?":"+this.port:"",M=this.hostname||""
this.host=M+U,this.href+=this.host,R&&(this.hostname=this.hostname.substr(1,this.hostname.length-2),
"/"!==i[0]&&(i="/"+i))}if(!f[a])for(E=0,C=u.length;E<C;E++){var j=u[E],B=encodeURIComponent(j)
B===j&&(B=escape(j)),i=i.split(j).join(B)}var F=i.indexOf("#");-1!==F&&(this.hash=i.substr(F),
i=i.slice(0,F))
var z=i.indexOf("?")
return-1!==z?(this.search=i.substr(z),this.query=i.substr(z+1),t&&(this.query=y.parse(this.query)),
i=i.slice(0,z)):t&&(this.search="",
this.query={}),i&&(this.pathname=i),m[a]&&this.hostname&&!this.pathname&&(this.pathname="/"),
(this.pathname||this.search)&&(U=this.pathname||"",D=this.search||"",this.path=U+D),
this.href=this.format(),this},i.prototype.format=function(){var e=this.auth||""
e&&(e=(e=encodeURIComponent(e)).replace(/%3A/i,":"),e+="@")
var t=this.protocol||"",r=this.pathname||"",n=this.hash||"",i=!1,o=""
this.host?i=e+this.host:this.hostname&&(i=e+(-1===this.hostname.indexOf(":")?this.hostname:"["+this.hostname+"]"),
this.port&&(i+=":"+this.port)),
this.query&&b(this.query)&&Object.keys(this.query).length&&(o=y.stringify(this.query))
var s=this.search||o&&"?"+o||""
return t&&":"!==t.substr(-1)&&(t+=":"),this.slashes||(!t||m[t])&&!1!==i?(i="//"+(i||""),
r&&"/"!==r.charAt(0)&&(r="/"+r)):i||(i=""),
n&&"#"!==n.charAt(0)&&(n="#"+n),s&&"?"!==s.charAt(0)&&(s="?"+s),
t+i+(r=r.replace(/[?#]/g,(function(e){return encodeURIComponent(e)})))+(s=s.replace("#","%23"))+n},
i.prototype.resolve=function(e){return this.resolveObject(g(e,!1,!0)).format()},
i.prototype.resolveObject=function(e){if(v(e)){var t=new i
t.parse(e,!1,!0),e=t}var r=new i
if(Object.keys(this).forEach((function(e){r[e]=this[e]
}),this),r.hash=e.hash,""===e.href)return r.href=r.format(),r
if(e.slashes&&!e.protocol)return Object.keys(e).forEach((function(t){"protocol"!==t&&(r[t]=e[t])})),
m[r.protocol]&&r.hostname&&!r.pathname&&(r.path=r.pathname="/"),r.href=r.format(),r
if(e.protocol&&e.protocol!==r.protocol){
if(!m[e.protocol])return Object.keys(e).forEach((function(t){r[t]=e[t]})),r.href=r.format(),r
if(r.protocol=e.protocol,e.host||d[e.protocol])r.pathname=e.pathname
else{for(var n=(e.pathname||"").split("/");n.length&&!(e.host=n.shift()););e.host||(e.host=""),
e.hostname||(e.hostname=""),
""!==n[0]&&n.unshift(""),n.length<2&&n.unshift(""),r.pathname=n.join("/")}if(r.search=e.search,
r.query=e.query,r.host=e.host||"",r.auth=e.auth,r.hostname=e.hostname||e.host,r.port=e.port,
r.pathname||r.search){var o=r.pathname||"",s=r.search||""
r.path=o+s}return r.slashes=r.slashes||e.slashes,r.href=r.format(),r}
var a=r.pathname&&"/"===r.pathname.charAt(0),u=e.host||e.pathname&&"/"===e.pathname.charAt(0),c=u||a||r.host&&e.pathname,p=c,l=r.pathname&&r.pathname.split("/")||[],h=(n=e.pathname&&e.pathname.split("/")||[],
r.protocol&&!m[r.protocol])
if(h&&(r.hostname="",r.port=null,r.host&&(""===l[0]?l[0]=r.host:l.unshift(r.host)),r.host="",
e.protocol&&(e.hostname=null,e.port=null,e.host&&(""===n[0]?n[0]=e.host:n.unshift(e.host)),
e.host=null),c=c&&(""===n[0]||""===l[0])),u)r.host=e.host||""===e.host?e.host:r.host,
r.hostname=e.hostname||""===e.hostname?e.hostname:r.hostname,r.search=e.search,r.query=e.query,l=n
else if(n.length)l||(l=[]),l.pop(),l=l.concat(n),r.search=e.search,r.query=e.query
else if(null!=e.search)return h&&(r.hostname=r.host=l.shift(),(w=!!(r.host&&r.host.indexOf("@")>0)&&r.host.split("@"))&&(r.auth=w.shift(),
r.host=r.hostname=w.shift())),
r.search=e.search,r.query=e.query,S(r.pathname)&&S(r.search)||(r.path=(r.pathname?r.pathname:"")+(r.search?r.search:"")),
r.href=r.format(),r
if(!l.length)return r.pathname=null,r.search?r.path="/"+r.search:r.path=null,r.href=r.format(),r
for(var f=l.slice(-1)[0],y=(r.host||e.host)&&("."===f||".."===f)||""===f,g=0,b=l.length;b>=0;b--)"."==(f=l[b])?l.splice(b,1):".."===f?(l.splice(b,1),
g++):g&&(l.splice(b,1),g--)
if(!c&&!p)for(;g--;g)l.unshift("..")
!c||""===l[0]||l[0]&&"/"===l[0].charAt(0)||l.unshift(""),y&&"/"!==l.join("/").substr(-1)&&l.push("")
var w,E=""===l[0]||l[0]&&"/"===l[0].charAt(0)
return h&&(r.hostname=r.host=E?"":l.length?l.shift():"",(w=!!(r.host&&r.host.indexOf("@")>0)&&r.host.split("@"))&&(r.auth=w.shift(),
r.host=r.hostname=w.shift())),
(c=c||r.host&&l.length)&&!E&&l.unshift(""),l.length?r.pathname=l.join("/"):(r.pathname=null,
r.path=null),S(r.pathname)&&S(r.search)||(r.path=(r.pathname?r.pathname:"")+(r.search?r.search:"")),
r.auth=e.auth||r.auth,r.slashes=r.slashes||e.slashes,r.href=r.format(),r
},i.prototype.parseHost=function(){var e=this.host,t=s.exec(e)
t&&(":"!==(t=t[0])&&(this.port=t.substr(1)),e=e.substr(0,e.length-t.length)),e&&(this.hostname=e)}},
384:e=>{e.exports=function(e){
return e&&"object"==typeof e&&"function"==typeof e.copy&&"function"==typeof e.fill&&"function"==typeof e.readUInt8
}},5955:(e,t,r)=>{"use strict"
var n=r(2584),i=r(8662),o=r(6430),s=r(5692)
function a(e){return e.call.bind(e)}
var u="undefined"!=typeof BigInt,c="undefined"!=typeof Symbol,p=a(Object.prototype.toString),l=a(Number.prototype.valueOf),h=a(String.prototype.valueOf),f=a(Boolean.prototype.valueOf)
if(u)var d=a(BigInt.prototype.valueOf)
if(c)var m=a(Symbol.prototype.valueOf)
function y(e,t){if("object"!=typeof e)return!1
try{return t(e),!0}catch(e){return!1}}function g(e){return"[object Map]"===p(e)}function v(e){
return"[object Set]"===p(e)}function b(e){return"[object WeakMap]"===p(e)}function S(e){
return"[object WeakSet]"===p(e)}function w(e){return"[object ArrayBuffer]"===p(e)}function E(e){
return"undefined"!=typeof ArrayBuffer&&(w.working?w(e):e instanceof ArrayBuffer)}function A(e){
return"[object DataView]"===p(e)}function R(e){
return"undefined"!=typeof DataView&&(A.working?A(e):e instanceof DataView)}t.isArgumentsObject=n,
t.isGeneratorFunction=i,t.isTypedArray=s,t.isPromise=function(e){
return"undefined"!=typeof Promise&&e instanceof Promise||null!==e&&"object"==typeof e&&"function"==typeof e.then&&"function"==typeof e.catch
},t.isArrayBufferView=function(e){
return"undefined"!=typeof ArrayBuffer&&ArrayBuffer.isView?ArrayBuffer.isView(e):s(e)||R(e)},
t.isUint8Array=function(e){return"Uint8Array"===o(e)},t.isUint8ClampedArray=function(e){
return"Uint8ClampedArray"===o(e)},t.isUint16Array=function(e){return"Uint16Array"===o(e)},
t.isUint32Array=function(e){return"Uint32Array"===o(e)},t.isInt8Array=function(e){
return"Int8Array"===o(e)},t.isInt16Array=function(e){return"Int16Array"===o(e)},
t.isInt32Array=function(e){return"Int32Array"===o(e)},t.isFloat32Array=function(e){
return"Float32Array"===o(e)},t.isFloat64Array=function(e){return"Float64Array"===o(e)},
t.isBigInt64Array=function(e){return"BigInt64Array"===o(e)},t.isBigUint64Array=function(e){
return"BigUint64Array"===o(e)},g.working="undefined"!=typeof Map&&g(new Map),t.isMap=function(e){
return"undefined"!=typeof Map&&(g.working?g(e):e instanceof Map)
},v.working="undefined"!=typeof Set&&v(new Set),t.isSet=function(e){
return"undefined"!=typeof Set&&(v.working?v(e):e instanceof Set)
},b.working="undefined"!=typeof WeakMap&&b(new WeakMap),t.isWeakMap=function(e){
return"undefined"!=typeof WeakMap&&(b.working?b(e):e instanceof WeakMap)
},S.working="undefined"!=typeof WeakSet&&S(new WeakSet),t.isWeakSet=function(e){return S(e)},
w.working="undefined"!=typeof ArrayBuffer&&w(new ArrayBuffer),t.isArrayBuffer=E,
A.working="undefined"!=typeof ArrayBuffer&&"undefined"!=typeof DataView&&A(new DataView(new ArrayBuffer(1),0,1)),
t.isDataView=R
var x="undefined"!=typeof SharedArrayBuffer?SharedArrayBuffer:void 0
function C(e){return"[object SharedArrayBuffer]"===p(e)}function I(e){
return void 0!==x&&(void 0===C.working&&(C.working=C(new x)),C.working?C(e):e instanceof x)}
function _(e){return y(e,l)}function k(e){return y(e,h)}function T(e){return y(e,f)}function P(e){
return u&&y(e,d)}function O(e){return c&&y(e,m)}
t.isSharedArrayBuffer=I,t.isAsyncFunction=function(e){return"[object AsyncFunction]"===p(e)},
t.isMapIterator=function(e){return"[object Map Iterator]"===p(e)},t.isSetIterator=function(e){
return"[object Set Iterator]"===p(e)},t.isGeneratorObject=function(e){
return"[object Generator]"===p(e)},t.isWebAssemblyCompiledModule=function(e){
return"[object WebAssembly.Module]"===p(e)},t.isNumberObject=_,t.isStringObject=k,
t.isBooleanObject=T,t.isBigIntObject=P,t.isSymbolObject=O,t.isBoxedPrimitive=function(e){
return _(e)||k(e)||T(e)||P(e)||O(e)},t.isAnyArrayBuffer=function(e){
return"undefined"!=typeof Uint8Array&&(E(e)||I(e))
},["isProxy","isExternal","isModuleNamespaceObject"].forEach((function(e){
Object.defineProperty(t,e,{enumerable:!1,value:function(){
throw new Error(e+" is not supported in userland")}})}))},9539:(e,t,r)=>{
var n=Object.getOwnPropertyDescriptors||function(e){
for(var t=Object.keys(e),r={},n=0;n<t.length;n++)r[t[n]]=Object.getOwnPropertyDescriptor(e,t[n])
return r},i=/%[sdj%]/g
t.format=function(e){if(!v(e)){for(var t=[],r=0;r<arguments.length;r++)t.push(u(arguments[r]))
return t.join(" ")}r=1
for(var n=arguments,o=n.length,s=String(e).replace(i,(function(e){if("%%"===e)return"%"
if(r>=o)return e
switch(e){case"%s":return String(n[r++])
case"%d":return Number(n[r++])
case"%j":try{return JSON.stringify(n[r++])}catch(e){return"[Circular]"}default:return e}
})),a=n[r];r<o;a=n[++r])y(a)||!w(a)?s+=" "+a:s+=" "+u(a)
return s},t.deprecate=function(e,r){
if("undefined"!=typeof process&&!0===process.noDeprecation)return e
if("undefined"==typeof process)return function(){return t.deprecate(e,r).apply(this,arguments)}
var n=!1
return function(){if(!n){if(process.throwDeprecation)throw new Error(r)
process.traceDeprecation?console.trace(r):console.error(r),n=!0}return e.apply(this,arguments)}}
var o={},s=/^$/
if(process.env.NODE_DEBUG){var a=process.env.NODE_DEBUG
a=a.replace(/[|\\{}()[\]^$+?.]/g,"\\$&").replace(/\*/g,".*").replace(/,/g,"$|^").toUpperCase(),
s=new RegExp("^"+a+"$","i")}function u(e,r){var n={seen:[],stylize:p}
return arguments.length>=3&&(n.depth=arguments[2]),arguments.length>=4&&(n.colors=arguments[3]),
m(r)?n.showHidden=r:r&&t._extend(n,r),b(n.showHidden)&&(n.showHidden=!1),b(n.depth)&&(n.depth=2),
b(n.colors)&&(n.colors=!1),b(n.customInspect)&&(n.customInspect=!0),n.colors&&(n.stylize=c),
l(n,e,n.depth)}function c(e,t){var r=u.styles[t]
return r?"["+u.colors[r][0]+"m"+e+"["+u.colors[r][1]+"m":e}function p(e,t){return e}
function l(e,r,n){
if(e.customInspect&&r&&R(r.inspect)&&r.inspect!==t.inspect&&(!r.constructor||r.constructor.prototype!==r)){
var i=r.inspect(n,e)
return v(i)||(i=l(e,i,n)),i}var o=function(e,t){if(b(t))return e.stylize("undefined","undefined")
if(v(t)){
var r="'"+JSON.stringify(t).replace(/^"|"$/g,"").replace(/'/g,"\\'").replace(/\\"/g,'"')+"'"
return e.stylize(r,"string")}
return g(t)?e.stylize(""+t,"number"):m(t)?e.stylize(""+t,"boolean"):y(t)?e.stylize("null","null"):void 0
}(e,r)
if(o)return o
var s=Object.keys(r),a=function(e){var t={}
return e.forEach((function(e,r){t[e]=!0})),t}(s)
if(e.showHidden&&(s=Object.getOwnPropertyNames(r)),A(r)&&(s.indexOf("message")>=0||s.indexOf("description")>=0))return h(r)
if(0===s.length){if(R(r)){var u=r.name?": "+r.name:""
return e.stylize("[Function"+u+"]","special")}
if(S(r))return e.stylize(RegExp.prototype.toString.call(r),"regexp")
if(E(r))return e.stylize(Date.prototype.toString.call(r),"date")
if(A(r))return h(r)}var c,p="",w=!1,x=["{","}"]
return d(r)&&(w=!0,x=["[","]"]),R(r)&&(p=" [Function"+(r.name?": "+r.name:"")+"]"),
S(r)&&(p=" "+RegExp.prototype.toString.call(r)),E(r)&&(p=" "+Date.prototype.toUTCString.call(r)),
A(r)&&(p=" "+h(r)),
0!==s.length||w&&0!=r.length?n<0?S(r)?e.stylize(RegExp.prototype.toString.call(r),"regexp"):e.stylize("[Object]","special"):(e.seen.push(r),
c=w?function(e,t,r,n,i){
for(var o=[],s=0,a=t.length;s<a;++s)k(t,String(s))?o.push(f(e,t,r,n,String(s),!0)):o.push("")
return i.forEach((function(i){i.match(/^\d+$/)||o.push(f(e,t,r,n,i,!0))})),o
}(e,r,n,a,s):s.map((function(t){return f(e,r,n,a,t,w)})),e.seen.pop(),function(e,t,r){
return e.reduce((function(e,t){return t.indexOf("\n"),e+t.replace(/\u001b\[\d\d?m/g,"").length+1
}),0)>60?r[0]+(""===t?"":t+"\n ")+" "+e.join(",\n  ")+" "+r[1]:r[0]+t+" "+e.join(", ")+" "+r[1]
}(c,p,x)):x[0]+p+x[1]}function h(e){return"["+Error.prototype.toString.call(e)+"]"}
function f(e,t,r,n,i,o){var s,a,u
if((u=Object.getOwnPropertyDescriptor(t,i)||{value:t[i]
}).get?a=u.set?e.stylize("[Getter/Setter]","special"):e.stylize("[Getter]","special"):u.set&&(a=e.stylize("[Setter]","special")),
k(n,i)||(s="["+i+"]"),
a||(e.seen.indexOf(u.value)<0?(a=y(r)?l(e,u.value,null):l(e,u.value,r-1)).indexOf("\n")>-1&&(a=o?a.split("\n").map((function(e){
return"  "+e})).join("\n").substr(2):"\n"+a.split("\n").map((function(e){return"   "+e
})).join("\n")):a=e.stylize("[Circular]","special")),b(s)){if(o&&i.match(/^\d+$/))return a
;(s=JSON.stringify(""+i)).match(/^"([a-zA-Z_][a-zA-Z_0-9]*)"$/)?(s=s.substr(1,s.length-2),
s=e.stylize(s,"name")):(s=s.replace(/'/g,"\\'").replace(/\\"/g,'"').replace(/(^"|"$)/g,"'"),
s=e.stylize(s,"string"))}return s+": "+a}function d(e){return Array.isArray(e)}function m(e){
return"boolean"==typeof e}function y(e){return null===e}function g(e){return"number"==typeof e}
function v(e){return"string"==typeof e}function b(e){return void 0===e}function S(e){
return w(e)&&"[object RegExp]"===x(e)}function w(e){return"object"==typeof e&&null!==e}
function E(e){return w(e)&&"[object Date]"===x(e)}function A(e){
return w(e)&&("[object Error]"===x(e)||e instanceof Error)}function R(e){return"function"==typeof e}
function x(e){return Object.prototype.toString.call(e)}function C(e){
return e<10?"0"+e.toString(10):e.toString(10)}t.debuglog=function(e){if(e=e.toUpperCase(),
!o[e])if(s.test(e)){var r=process.pid
o[e]=function(){var n=t.format.apply(t,arguments)
console.error("%s %d: %s",e,r,n)}}else o[e]=function(){}
return o[e]},t.inspect=u,u.colors={bold:[1,22],italic:[3,23],underline:[4,24],inverse:[7,27],
white:[37,39],grey:[90,39],black:[30,39],blue:[34,39],cyan:[36,39],green:[32,39],magenta:[35,39],
red:[31,39],yellow:[33,39]},u.styles={special:"cyan",number:"yellow",boolean:"yellow",
undefined:"grey",null:"bold",string:"green",date:"magenta",regexp:"red"},t.types=r(5955),
t.isArray=d,t.isBoolean=m,t.isNull=y,t.isNullOrUndefined=function(e){return null==e},t.isNumber=g,
t.isString=v,t.isSymbol=function(e){return"symbol"==typeof e},t.isUndefined=b,t.isRegExp=S,
t.types.isRegExp=S,t.isObject=w,t.isDate=E,t.types.isDate=E,t.isError=A,t.types.isNativeError=A,
t.isFunction=R,t.isPrimitive=function(e){
return null===e||"boolean"==typeof e||"number"==typeof e||"string"==typeof e||"symbol"==typeof e||void 0===e
},t.isBuffer=r(384)
var I=["Jan","Feb","Mar","Apr","May","Jun","Jul","Aug","Sep","Oct","Nov","Dec"]
function _(){var e=new Date,t=[C(e.getHours()),C(e.getMinutes()),C(e.getSeconds())].join(":")
return[e.getDate(),I[e.getMonth()],t].join(" ")}function k(e,t){
return Object.prototype.hasOwnProperty.call(e,t)}t.log=function(){
console.log("%s - %s",_(),t.format.apply(t,arguments))},t.inherits=r(5717),t._extend=function(e,t){
if(!t||!w(t))return e
for(var r=Object.keys(t),n=r.length;n--;)e[r[n]]=t[r[n]]
return e}
var T="undefined"!=typeof Symbol?Symbol("util.promisify.custom"):void 0
function P(e,t){if(!e){var r=new Error("Promise was rejected with a falsy value")
r.reason=e,e=r}return t(e)}t.promisify=function(e){
if("function"!=typeof e)throw new TypeError('The "original" argument must be of type Function')
if(T&&e[T]){var t
if("function"!=typeof(t=e[T]))throw new TypeError('The "util.promisify.custom" argument must be of type Function')
return Object.defineProperty(t,T,{value:t,enumerable:!1,writable:!1,configurable:!0}),t}
function t(){for(var t,r,n=new Promise((function(e,n){t=e,r=n
})),i=[],o=0;o<arguments.length;o++)i.push(arguments[o])
i.push((function(e,n){e?r(e):t(n)}))
try{e.apply(this,i)}catch(e){r(e)}return n}return Object.setPrototypeOf(t,Object.getPrototypeOf(e)),
T&&Object.defineProperty(t,T,{value:t,enumerable:!1,writable:!1,configurable:!0}),
Object.defineProperties(t,n(e))},t.promisify.custom=T,t.callbackify=function(e){
if("function"!=typeof e)throw new TypeError('The "original" argument must be of type Function')
function t(){for(var t=[],r=0;r<arguments.length;r++)t.push(arguments[r])
var n=t.pop()
if("function"!=typeof n)throw new TypeError("The last argument must be of type Function")
var i=this,o=function(){return n.apply(i,arguments)}
e.apply(this,t).then((function(e){process.nextTick(o.bind(null,null,e))}),(function(e){
process.nextTick(P.bind(null,e,o))}))}return Object.setPrototypeOf(t,Object.getPrototypeOf(e)),
Object.defineProperties(t,n(e)),t}},5877:(e,t,r)=>{var n=r(3570),i=r(1171),o=i
o.v1=n,o.v4=i,e.exports=o},5327:e=>{for(var t=[],r=0;r<256;++r)t[r]=(r+256).toString(16).substr(1)
e.exports=function(e,r){var n=r||0,i=t
return[i[e[n++]],i[e[n++]],i[e[n++]],i[e[n++]],"-",i[e[n++]],i[e[n++]],"-",i[e[n++]],i[e[n++]],"-",i[e[n++]],i[e[n++]],"-",i[e[n++]],i[e[n++]],i[e[n++]],i[e[n++]],i[e[n++]],i[e[n++]]].join("")
}},5217:e=>{
var t="undefined"!=typeof crypto&&crypto.getRandomValues&&crypto.getRandomValues.bind(crypto)||"undefined"!=typeof msCrypto&&"function"==typeof window.msCrypto.getRandomValues&&msCrypto.getRandomValues.bind(msCrypto)
if(t){var r=new Uint8Array(16)
e.exports=function(){return t(r),r}}else{var n=new Array(16)
e.exports=function(){for(var e,t=0;t<16;t++)0==(3&t)&&(e=4294967296*Math.random()),
n[t]=e>>>((3&t)<<3)&255
return n}}},3570:(e,t,r)=>{var n,i,o=r(5217),s=r(5327),a=0,u=0
e.exports=function(e,t,r){
var c=t&&r||0,p=t||[],l=(e=e||{}).node||n,h=void 0!==e.clockseq?e.clockseq:i
if(null==l||null==h){var f=o()
null==l&&(l=n=[1|f[0],f[1],f[2],f[3],f[4],f[5]]),null==h&&(h=i=16383&(f[6]<<8|f[7]))}
var d=void 0!==e.msecs?e.msecs:(new Date).getTime(),m=void 0!==e.nsecs?e.nsecs:u+1,y=d-a+(m-u)/1e4
if(y<0&&void 0===e.clockseq&&(h=h+1&16383),(y<0||d>a)&&void 0===e.nsecs&&(m=0),m>=1e4)throw new Error("uuid.v1(): Can't create more than 10M uuids/sec")
a=d,u=m,i=h
var g=(1e4*(268435455&(d+=122192928e5))+m)%4294967296
p[c++]=g>>>24&255,p[c++]=g>>>16&255,p[c++]=g>>>8&255,p[c++]=255&g
var v=d/4294967296*1e4&268435455
p[c++]=v>>>8&255,p[c++]=255&v,p[c++]=v>>>24&15|16,p[c++]=v>>>16&255,p[c++]=h>>>8|128,p[c++]=255&h
for(var b=0;b<6;++b)p[c+b]=l[b]
return t||s(p)}},1171:(e,t,r)=>{var n=r(5217),i=r(5327)
e.exports=function(e,t,r){var o=t&&r||0
"string"==typeof e&&(t="binary"===e?new Array(16):null,e=null)
var s=(e=e||{}).random||(e.rng||n)()
if(s[6]=15&s[6]|64,s[8]=63&s[8]|128,t)for(var a=0;a<16;++a)t[o+a]=s[a]
return t||i(s)}},6430:(e,t,r)=>{"use strict"
var n=r(9804),i=r(3083),o=r(1924),s=o("Object.prototype.toString"),a=r(6410)(),u="undefined"==typeof globalThis?r.g:globalThis,c=i(),p=o("String.prototype.slice"),l={},h=r(882),f=Object.getPrototypeOf
a&&h&&f&&n(c,(function(e){if("function"==typeof u[e]){var t=new u[e]
if(Symbol.toStringTag in t){var r=f(t),n=h(r,Symbol.toStringTag)
if(!n){var i=f(r)
n=h(i,Symbol.toStringTag)}l[e]=n.get}}}))
var d=r(5692)
e.exports=function(e){return!!d(e)&&(a&&Symbol.toStringTag in e?function(e){var t=!1
return n(l,(function(r,n){if(!t)try{var i=r.call(e)
i===n&&(t=i)}catch(e){}})),t}(e):p(s(e),8,-1))}},8022:()=>{},3083:(e,t,r)=>{"use strict"
var n=["BigInt64Array","BigUint64Array","Float32Array","Float64Array","Int16Array","Int32Array","Int8Array","Uint16Array","Uint32Array","Uint8Array","Uint8ClampedArray"],i="undefined"==typeof globalThis?r.g:globalThis
e.exports=function(){for(var e=[],t=0;t<n.length;t++)"function"==typeof i[n[t]]&&(e[e.length]=n[t])
return e}},882:(e,t,r)=>{"use strict"
var n=r(210)("%Object.getOwnPropertyDescriptor%",!0)
if(n)try{n([],"length")}catch(e){n=null}e.exports=n},7142:e=>{"use strict"
e.exports=JSON.parse('{"version":"2.0","metadata":{"apiVersion":"2017-09-23","endpointPrefix":"cloud9","jsonVersion":"1.1","protocol":"json","protocols":["json"],"serviceFullName":"AWS Cloud9","serviceId":"Cloud9","signatureVersion":"v4","targetPrefix":"AWSCloud9WorkspaceManagementService","uid":"cloud9-2017-09-23"},"operations":{"ActivateEC2Remote":{"input":{"type":"structure","required":["environmentId"],"members":{"environmentId":{}}},"output":{"type":"structure","members":{}},"internalonly":true},"CreateEnvironmentEC2":{"input":{"type":"structure","required":["name","instanceType","imageId"],"members":{"name":{},"description":{"shape":"S6"},"clientRequestToken":{},"instanceType":{},"subnetId":{},"imageId":{},"automaticStopTimeMinutes":{"type":"integer"},"ownerArn":{},"repositories":{"internalonly":true,"type":"map","key":{},"value":{}},"tags":{"shape":"Sg"},"connectionType":{},"launchTemplate":{"internalonly":true,"type":"structure","members":{"LaunchTemplateId":{},"LaunchTemplateName":{},"Version":{}}},"dryRun":{"type":"boolean"}}},"output":{"type":"structure","members":{"environmentId":{}}},"idempotent":true},"CreateEnvironmentMembership":{"input":{"type":"structure","required":["environmentId","userArn","permissions"],"members":{"environmentId":{},"userArn":{},"permissions":{}}},"output":{"type":"structure","required":["membership"],"members":{"membership":{"shape":"Su"}}},"idempotent":true},"CreateEnvironmentSSH":{"input":{"type":"structure","required":["name","host","loginName"],"members":{"name":{},"description":{"shape":"S6"},"dryRun":{"type":"boolean"},"clientRequestToken":{},"environmentPath":{},"nodePath":{},"host":{},"port":{"type":"integer"},"loginName":{},"bastionHost":{},"ownerArn":{},"tags":{"shape":"Sg"}}},"output":{"type":"structure","members":{"environmentId":{}}},"idempotent":true,"internalonly":true},"CreateEnvironmentToken":{"input":{"type":"structure","required":["environmentId"],"members":{"environmentId":{},"refresh":{"type":"boolean"},"remoteAddress":{"type":"integer"}}},"output":{"type":"structure","members":{"payload":{},"key":{},"authenticationTag":{},"initializationVector":{}}},"idempotent":true,"internalonly":true},"DeleteEnvironment":{"input":{"type":"structure","required":["environmentId"],"members":{"environmentId":{}}},"output":{"type":"structure","members":{}},"idempotent":true},"DeleteEnvironmentMembership":{"input":{"type":"structure","required":["environmentId","userArn"],"members":{"environmentId":{},"userArn":{}}},"output":{"type":"structure","members":{}},"idempotent":true},"DescribeEC2Remote":{"input":{"type":"structure","required":["environmentId"],"members":{"environmentId":{}}},"output":{"type":"structure","members":{"remote":{"type":"structure","members":{"host":{},"port":{"type":"integer"},"loginName":{},"nodePath":{},"environmentPath":{},"instanceType":{},"stackName":{},"publicDns":{},"vpc":{},"subnet":{},"securityGroups":{"type":"list","member":{}}},"internalonly":true}}},"internalonly":true},"DescribeEnvironmentMemberships":{"input":{"type":"structure","members":{"userArn":{},"environmentId":{},"permissions":{"type":"list","member":{}},"nextToken":{},"maxResults":{"type":"integer"}}},"output":{"type":"structure","members":{"memberships":{"type":"list","member":{"shape":"Su"}},"nextToken":{}}}},"DescribeEnvironmentStatus":{"input":{"type":"structure","required":["environmentId"],"members":{"environmentId":{}}},"output":{"type":"structure","required":["status","message"],"members":{"status":{},"message":{}}}},"DescribeEnvironments":{"input":{"type":"structure","required":["environmentIds"],"members":{"environmentIds":{"type":"list","member":{}}}},"output":{"type":"structure","members":{"environments":{"type":"list","member":{"type":"structure","required":["type","arn","ownerArn"],"members":{"id":{},"name":{},"description":{"shape":"S6"},"type":{},"connectionType":{},"arn":{},"ownerArn":{},"lifecycle":{"type":"structure","members":{"status":{},"reason":{},"failureResource":{},"reasonCode":{"internalonly":true}}},"inputImageId":{"internalonly":true},"managedCredentialsStatus":{}}}}}}},"DescribeSSHRemote":{"input":{"type":"structure","required":["environmentId"],"members":{"environmentId":{}}},"output":{"type":"structure","members":{"remote":{"type":"structure","members":{"host":{},"port":{"type":"integer"},"loginName":{},"nodePath":{},"environmentPath":{},"bastionHost":{}}}}},"internalonly":true},"GetEnvironmentConfig":{"input":{"type":"structure","required":["environmentId"],"members":{"environmentId":{},"bundleConfigId":{}}},"output":{"type":"structure","members":{"config":{}}},"idempotent":true,"internalonly":true},"GetEnvironmentSettings":{"input":{"type":"structure","required":["environmentId"],"members":{"environmentId":{}}},"output":{"type":"structure","members":{"settings":{"shape":"S2b"}}},"idempotent":true,"internalonly":true},"GetMembershipSettings":{"input":{"type":"structure","required":["environmentId"],"members":{"environmentId":{}}},"output":{"type":"structure","members":{"settings":{"shape":"S2b"}}},"idempotent":true,"internalonly":true},"GetMigrationExperiences":{"input":{"type":"structure","required":["migrationDestination"],"members":{"migrationDestination":{}}},"output":{"type":"structure","members":{"migrationExperiences":{"type":"list","member":{}}}},"internalonly":true},"GetUserPublicKey":{"input":{"type":"structure","members":{"userArn":{}}},"output":{"type":"structure","members":{"publicKey":{}}},"idempotent":true,"internalonly":true},"GetUserSettings":{"input":{"type":"structure","members":{}},"output":{"type":"structure","members":{"settings":{"shape":"S2b"}}},"idempotent":true,"internalonly":true},"ListEnvironments":{"input":{"type":"structure","members":{"nextToken":{},"maxResults":{"type":"integer"}}},"output":{"type":"structure","members":{"nextToken":{},"environmentIds":{"type":"list","member":{}}}}},"ListTagsForResource":{"input":{"type":"structure","required":["ResourceARN"],"members":{"ResourceARN":{}}},"output":{"type":"structure","members":{"Tags":{"shape":"Sg"}}}},"LockServiceLinkedRole":{"input":{"type":"structure","required":["RoleArn","Timeout"],"members":{"RoleArn":{},"Timeout":{"type":"long"}}},"output":{"type":"structure","required":["CanBeDeleted"],"members":{"CanBeDeleted":{"type":"boolean"},"ReasonOfFailure":{},"RelatedResources":{"type":"list","member":{}}}},"internalonly":true},"ModifyTemporaryCredentialsOnEnvironmentEC2":{"input":{"type":"structure","required":["environmentId"],"members":{"environmentId":{},"remove":{"type":"boolean"},"forceRemove":{"type":"boolean"}}},"output":{"type":"structure","members":{"environmentId":{}}},"idempotent":true,"internalonly":true},"TagResource":{"input":{"type":"structure","required":["ResourceARN","Tags"],"members":{"ResourceARN":{},"Tags":{"shape":"Sg"}}},"output":{"type":"structure","members":{}}},"UnlockServiceLinkedRole":{"input":{"type":"structure","required":["RoleArn"],"members":{"RoleArn":{},"DeletionStatus":{}}},"output":{"type":"structure","members":{}},"internalonly":true},"UntagResource":{"input":{"type":"structure","required":["ResourceARN","TagKeys"],"members":{"ResourceARN":{},"TagKeys":{"type":"list","member":{"shape":"Si"},"sensitive":true}}},"output":{"type":"structure","members":{}}},"UpdateEnvironment":{"input":{"type":"structure","required":["environmentId"],"members":{"environmentId":{},"name":{},"description":{"shape":"S6"},"managedCredentialsAction":{}}},"output":{"type":"structure","members":{}},"idempotent":true},"UpdateEnvironmentMembership":{"input":{"type":"structure","required":["environmentId","userArn","permissions"],"members":{"environmentId":{},"userArn":{},"permissions":{}}},"output":{"type":"structure","members":{"membership":{"shape":"Su"}}},"idempotent":true},"UpdateEnvironmentSettings":{"input":{"type":"structure","required":["environmentId","settings"],"members":{"environmentId":{},"settings":{"shape":"S2b"}}},"output":{"type":"structure","members":{}},"idempotent":true,"internalonly":true},"UpdateMembershipSettings":{"input":{"type":"structure","required":["environmentId","settings"],"members":{"environmentId":{},"settings":{"shape":"S2b"}}},"output":{"type":"structure","members":{}},"idempotent":true,"internalonly":true},"UpdateSSHRemote":{"input":{"type":"structure","required":["environmentId"],"members":{"environmentId":{},"host":{},"port":{"type":"integer"},"loginName":{},"environmentPath":{},"bastionHost":{},"nodePath":{}}},"output":{"type":"structure","members":{"environmentId":{}}},"idempotent":true,"internalonly":true},"UpdateUserSettings":{"input":{"type":"structure","required":["settings"],"members":{"settings":{"shape":"S2b"}}},"output":{"type":"structure","members":{}},"idempotent":true,"internalonly":true},"ValidateEnvironmentName":{"input":{"type":"structure","required":["name"],"members":{"name":{}}},"output":{"type":"structure","members":{"valid":{"type":"boolean"}}},"idempotent":true,"internalonly":true},"VerifyResourcesExistForTagris":{"input":{"type":"structure","required":["TagrisSweepList"],"members":{"TagrisSweepList":{"type":"list","member":{"type":"structure","members":{"TagrisAccountId":{},"TagrisAmazonResourceName":{},"TagrisInternalId":{},"TagrisVersion":{"type":"long"}}}}}},"output":{"type":"structure","required":["TagrisSweepListResult"],"members":{"TagrisSweepListResult":{"type":"map","key":{},"value":{}}}},"internalonly":true}},"shapes":{"S6":{"type":"string","sensitive":true},"Sg":{"type":"list","member":{"type":"structure","required":["Key","Value"],"members":{"Key":{"shape":"Si"},"Value":{"type":"string","sensitive":true}},"sensitive":true},"sensitive":true},"Si":{"type":"string","sensitive":true},"Su":{"type":"structure","required":["permissions","userId","userArn","environmentId"],"members":{"permissions":{},"userId":{},"userArn":{},"environmentId":{},"lastAccess":{"type":"timestamp"}}},"S2b":{"type":"string","sensitive":true}}}')
},6770:e=>{"use strict"
e.exports=JSON.parse('{"o":{"DescribeEnvironmentMemberships":{"input_token":"nextToken","output_token":"nextToken","limit_key":"maxResults"},"ListEnvironments":{"input_token":"nextToken","output_token":"nextToken","limit_key":"maxResults"}}}')
},7377:e=>{"use strict"
e.exports=JSON.parse('{"version":"2.0","metadata":{"apiVersion":"2014-06-30","endpointPrefix":"cognito-identity","jsonVersion":"1.1","protocol":"json","serviceFullName":"Amazon Cognito Identity","serviceId":"Cognito Identity","signatureVersion":"v4","targetPrefix":"AWSCognitoIdentityService","uid":"cognito-identity-2014-06-30"},"operations":{"CreateIdentityPool":{"input":{"type":"structure","required":["IdentityPoolName","AllowUnauthenticatedIdentities"],"members":{"IdentityPoolName":{},"AllowUnauthenticatedIdentities":{"type":"boolean"},"AllowClassicFlow":{"type":"boolean"},"SupportedLoginProviders":{"shape":"S5"},"DeveloperProviderName":{},"OpenIdConnectProviderARNs":{"shape":"S9"},"CognitoIdentityProviders":{"shape":"Sb"},"SamlProviderARNs":{"shape":"Sg"},"IdentityPoolTags":{"shape":"Sh"}}},"output":{"shape":"Sk"}},"DeleteIdentities":{"input":{"type":"structure","required":["IdentityIdsToDelete"],"members":{"IdentityIdsToDelete":{"type":"list","member":{}}}},"output":{"type":"structure","members":{"UnprocessedIdentityIds":{"type":"list","member":{"type":"structure","members":{"IdentityId":{},"ErrorCode":{}}}}}}},"DeleteIdentityPool":{"input":{"type":"structure","required":["IdentityPoolId"],"members":{"IdentityPoolId":{}}}},"DescribeIdentity":{"input":{"type":"structure","required":["IdentityId"],"members":{"IdentityId":{}}},"output":{"shape":"Sv"}},"DescribeIdentityPool":{"input":{"type":"structure","required":["IdentityPoolId"],"members":{"IdentityPoolId":{}}},"output":{"shape":"Sk"}},"GetCredentialsForIdentity":{"input":{"type":"structure","required":["IdentityId"],"members":{"IdentityId":{},"Logins":{"shape":"S10"},"CustomRoleArn":{}}},"output":{"type":"structure","members":{"IdentityId":{},"Credentials":{"type":"structure","members":{"AccessKeyId":{},"SecretKey":{},"SessionToken":{},"Expiration":{"type":"timestamp"}}}}},"authtype":"none"},"GetId":{"input":{"type":"structure","required":["IdentityPoolId"],"members":{"AccountId":{},"IdentityPoolId":{},"Logins":{"shape":"S10"}}},"output":{"type":"structure","members":{"IdentityId":{}}},"authtype":"none"},"GetIdentityPoolRoles":{"input":{"type":"structure","required":["IdentityPoolId"],"members":{"IdentityPoolId":{}}},"output":{"type":"structure","members":{"IdentityPoolId":{},"Roles":{"shape":"S1c"},"RoleMappings":{"shape":"S1e"}}}},"GetOpenIdToken":{"input":{"type":"structure","required":["IdentityId"],"members":{"IdentityId":{},"Logins":{"shape":"S10"}}},"output":{"type":"structure","members":{"IdentityId":{},"Token":{}}},"authtype":"none"},"GetOpenIdTokenForDeveloperIdentity":{"input":{"type":"structure","required":["IdentityPoolId","Logins"],"members":{"IdentityPoolId":{},"IdentityId":{},"Logins":{"shape":"S10"},"PrincipalTags":{"shape":"S1s"},"TokenDuration":{"type":"long"}}},"output":{"type":"structure","members":{"IdentityId":{},"Token":{}}}},"GetPrincipalTagAttributeMap":{"input":{"type":"structure","required":["IdentityPoolId","IdentityProviderName"],"members":{"IdentityPoolId":{},"IdentityProviderName":{}}},"output":{"type":"structure","members":{"IdentityPoolId":{},"IdentityProviderName":{},"UseDefaults":{"type":"boolean"},"PrincipalTags":{"shape":"S1s"}}}},"ListIdentities":{"input":{"type":"structure","required":["IdentityPoolId","MaxResults"],"members":{"IdentityPoolId":{},"MaxResults":{"type":"integer"},"NextToken":{},"HideDisabled":{"type":"boolean"}}},"output":{"type":"structure","members":{"IdentityPoolId":{},"Identities":{"type":"list","member":{"shape":"Sv"}},"NextToken":{}}}},"ListIdentityPools":{"input":{"type":"structure","required":["MaxResults"],"members":{"MaxResults":{"type":"integer"},"NextToken":{}}},"output":{"type":"structure","members":{"IdentityPools":{"type":"list","member":{"type":"structure","members":{"IdentityPoolId":{},"IdentityPoolName":{}}}},"NextToken":{}}}},"ListTagsForResource":{"input":{"type":"structure","required":["ResourceArn"],"members":{"ResourceArn":{}}},"output":{"type":"structure","members":{"Tags":{"shape":"Sh"}}}},"LookupDeveloperIdentity":{"input":{"type":"structure","required":["IdentityPoolId"],"members":{"IdentityPoolId":{},"IdentityId":{},"DeveloperUserIdentifier":{},"MaxResults":{"type":"integer"},"NextToken":{}}},"output":{"type":"structure","members":{"IdentityId":{},"DeveloperUserIdentifierList":{"type":"list","member":{}},"NextToken":{}}}},"MergeDeveloperIdentities":{"input":{"type":"structure","required":["SourceUserIdentifier","DestinationUserIdentifier","DeveloperProviderName","IdentityPoolId"],"members":{"SourceUserIdentifier":{},"DestinationUserIdentifier":{},"DeveloperProviderName":{},"IdentityPoolId":{}}},"output":{"type":"structure","members":{"IdentityId":{}}}},"SetIdentityPoolRoles":{"input":{"type":"structure","required":["IdentityPoolId","Roles"],"members":{"IdentityPoolId":{},"Roles":{"shape":"S1c"},"RoleMappings":{"shape":"S1e"}}}},"SetPrincipalTagAttributeMap":{"input":{"type":"structure","required":["IdentityPoolId","IdentityProviderName"],"members":{"IdentityPoolId":{},"IdentityProviderName":{},"UseDefaults":{"type":"boolean"},"PrincipalTags":{"shape":"S1s"}}},"output":{"type":"structure","members":{"IdentityPoolId":{},"IdentityProviderName":{},"UseDefaults":{"type":"boolean"},"PrincipalTags":{"shape":"S1s"}}}},"TagResource":{"input":{"type":"structure","required":["ResourceArn","Tags"],"members":{"ResourceArn":{},"Tags":{"shape":"Sh"}}},"output":{"type":"structure","members":{}}},"UnlinkDeveloperIdentity":{"input":{"type":"structure","required":["IdentityId","IdentityPoolId","DeveloperProviderName","DeveloperUserIdentifier"],"members":{"IdentityId":{},"IdentityPoolId":{},"DeveloperProviderName":{},"DeveloperUserIdentifier":{}}}},"UnlinkIdentity":{"input":{"type":"structure","required":["IdentityId","Logins","LoginsToRemove"],"members":{"IdentityId":{},"Logins":{"shape":"S10"},"LoginsToRemove":{"shape":"Sw"}}},"authtype":"none"},"UntagResource":{"input":{"type":"structure","required":["ResourceArn","TagKeys"],"members":{"ResourceArn":{},"TagKeys":{"type":"list","member":{}}}},"output":{"type":"structure","members":{}}},"UpdateIdentityPool":{"input":{"shape":"Sk"},"output":{"shape":"Sk"}}},"shapes":{"S5":{"type":"map","key":{},"value":{}},"S9":{"type":"list","member":{}},"Sb":{"type":"list","member":{"type":"structure","members":{"ProviderName":{},"ClientId":{},"ServerSideTokenCheck":{"type":"boolean"}}}},"Sg":{"type":"list","member":{}},"Sh":{"type":"map","key":{},"value":{}},"Sk":{"type":"structure","required":["IdentityPoolId","IdentityPoolName","AllowUnauthenticatedIdentities"],"members":{"IdentityPoolId":{},"IdentityPoolName":{},"AllowUnauthenticatedIdentities":{"type":"boolean"},"AllowClassicFlow":{"type":"boolean"},"SupportedLoginProviders":{"shape":"S5"},"DeveloperProviderName":{},"OpenIdConnectProviderARNs":{"shape":"S9"},"CognitoIdentityProviders":{"shape":"Sb"},"SamlProviderARNs":{"shape":"Sg"},"IdentityPoolTags":{"shape":"Sh"}}},"Sv":{"type":"structure","members":{"IdentityId":{},"Logins":{"shape":"Sw"},"CreationDate":{"type":"timestamp"},"LastModifiedDate":{"type":"timestamp"}}},"Sw":{"type":"list","member":{}},"S10":{"type":"map","key":{},"value":{}},"S1c":{"type":"map","key":{},"value":{}},"S1e":{"type":"map","key":{},"value":{"type":"structure","required":["Type"],"members":{"Type":{},"AmbiguousRoleResolution":{},"RulesConfiguration":{"type":"structure","required":["Rules"],"members":{"Rules":{"type":"list","member":{"type":"structure","required":["Claim","MatchType","Value","RoleARN"],"members":{"Claim":{},"MatchType":{},"Value":{},"RoleARN":{}}}}}}}}},"S1s":{"type":"map","key":{},"value":{}}}}')
},5010:e=>{"use strict"
e.exports=JSON.parse('{"o":{"ListIdentityPools":{"input_token":"NextToken","limit_key":"MaxResults","output_token":"NextToken","result_key":"IdentityPools"}}}')
},7752:e=>{"use strict"
e.exports=JSON.parse('{"acm":{"name":"ACM","cors":true},"apigateway":{"name":"APIGateway","cors":true},"applicationautoscaling":{"prefix":"application-autoscaling","name":"ApplicationAutoScaling","cors":true},"appstream":{"name":"AppStream"},"autoscaling":{"name":"AutoScaling","cors":true},"batch":{"name":"Batch"},"budgets":{"name":"Budgets"},"clouddirectory":{"name":"CloudDirectory","versions":["2016-05-10*"]},"cloudformation":{"name":"CloudFormation","cors":true},"cloudfront":{"name":"CloudFront","versions":["2013-05-12*","2013-11-11*","2014-05-31*","2014-10-21*","2014-11-06*","2015-04-17*","2015-07-27*","2015-09-17*","2016-01-13*","2016-01-28*","2016-08-01*","2016-08-20*","2016-09-07*","2016-09-29*","2016-11-25*","2017-03-25*","2017-10-30*","2018-06-18*","2018-11-05*","2019-03-26*"],"cors":true},"cloudhsm":{"name":"CloudHSM","cors":true},"cloudsearch":{"name":"CloudSearch"},"cloudsearchdomain":{"name":"CloudSearchDomain"},"cloudtrail":{"name":"CloudTrail","cors":true},"cloudwatch":{"prefix":"monitoring","name":"CloudWatch","cors":true},"cloudwatchevents":{"prefix":"events","name":"CloudWatchEvents","versions":["2014-02-03*"],"cors":true},"cloudwatchlogs":{"prefix":"logs","name":"CloudWatchLogs","cors":true},"codebuild":{"name":"CodeBuild","cors":true},"codecommit":{"name":"CodeCommit","cors":true},"codedeploy":{"name":"CodeDeploy","cors":true},"codepipeline":{"name":"CodePipeline","cors":true},"cognitoidentity":{"prefix":"cognito-identity","name":"CognitoIdentity","cors":true},"cognitoidentityserviceprovider":{"prefix":"cognito-idp","name":"CognitoIdentityServiceProvider","cors":true},"cognitosync":{"prefix":"cognito-sync","name":"CognitoSync","cors":true},"configservice":{"prefix":"config","name":"ConfigService","cors":true},"cur":{"name":"CUR","cors":true},"datapipeline":{"name":"DataPipeline"},"devicefarm":{"name":"DeviceFarm","cors":true},"directconnect":{"name":"DirectConnect","cors":true},"directoryservice":{"prefix":"ds","name":"DirectoryService"},"discovery":{"name":"Discovery"},"dms":{"name":"DMS"},"dynamodb":{"name":"DynamoDB","cors":true},"dynamodbstreams":{"prefix":"streams.dynamodb","name":"DynamoDBStreams","cors":true},"ec2":{"name":"EC2","versions":["2013-06-15*","2013-10-15*","2014-02-01*","2014-05-01*","2014-06-15*","2014-09-01*","2014-10-01*","2015-03-01*","2015-04-15*","2015-10-01*","2016-04-01*","2016-09-15*"],"cors":true},"ecr":{"name":"ECR","cors":true},"ecs":{"name":"ECS","cors":true},"efs":{"prefix":"elasticfilesystem","name":"EFS","cors":true},"elasticache":{"name":"ElastiCache","versions":["2012-11-15*","2014-03-24*","2014-07-15*","2014-09-30*"],"cors":true},"elasticbeanstalk":{"name":"ElasticBeanstalk","cors":true},"elb":{"prefix":"elasticloadbalancing","name":"ELB","cors":true},"elbv2":{"prefix":"elasticloadbalancingv2","name":"ELBv2","cors":true},"emr":{"prefix":"elasticmapreduce","name":"EMR","cors":true},"es":{"name":"ES"},"elastictranscoder":{"name":"ElasticTranscoder","cors":true},"firehose":{"name":"Firehose","cors":true},"gamelift":{"name":"GameLift","cors":true},"glacier":{"name":"Glacier"},"health":{"name":"Health"},"iam":{"name":"IAM","cors":true},"importexport":{"name":"ImportExport"},"inspector":{"name":"Inspector","versions":["2015-08-18*"],"cors":true},"iot":{"name":"Iot","cors":true},"iotdata":{"prefix":"iot-data","name":"IotData","cors":true},"kinesis":{"name":"Kinesis","cors":true},"kinesisanalytics":{"name":"KinesisAnalytics"},"kms":{"name":"KMS","cors":true},"lambda":{"name":"Lambda","cors":true},"lexruntime":{"prefix":"runtime.lex","name":"LexRuntime","cors":true},"lightsail":{"name":"Lightsail"},"machinelearning":{"name":"MachineLearning","cors":true},"marketplacecommerceanalytics":{"name":"MarketplaceCommerceAnalytics","cors":true},"marketplacemetering":{"prefix":"meteringmarketplace","name":"MarketplaceMetering"},"mturk":{"prefix":"mturk-requester","name":"MTurk","cors":true},"mobileanalytics":{"name":"MobileAnalytics","cors":true},"opsworks":{"name":"OpsWorks","cors":true},"opsworkscm":{"name":"OpsWorksCM"},"organizations":{"name":"Organizations"},"pinpoint":{"name":"Pinpoint"},"polly":{"name":"Polly","cors":true},"rds":{"name":"RDS","versions":["2014-09-01*"],"cors":true},"redshift":{"name":"Redshift","cors":true},"rekognition":{"name":"Rekognition","cors":true},"resourcegroupstaggingapi":{"name":"ResourceGroupsTaggingAPI"},"route53":{"name":"Route53","cors":true},"route53domains":{"name":"Route53Domains","cors":true},"s3":{"name":"S3","dualstackAvailable":true,"cors":true},"s3control":{"name":"S3Control","dualstackAvailable":true,"xmlNoDefaultLists":true},"servicecatalog":{"name":"ServiceCatalog","cors":true},"ses":{"prefix":"email","name":"SES","cors":true},"shield":{"name":"Shield"},"simpledb":{"prefix":"sdb","name":"SimpleDB"},"sms":{"name":"SMS"},"snowball":{"name":"Snowball"},"sns":{"name":"SNS","cors":true},"sqs":{"name":"SQS","cors":true},"ssm":{"name":"SSM","cors":true},"storagegateway":{"name":"StorageGateway","cors":true},"stepfunctions":{"prefix":"states","name":"StepFunctions"},"sts":{"name":"STS","cors":true},"support":{"name":"Support"},"swf":{"name":"SWF"},"xray":{"name":"XRay","cors":true},"waf":{"name":"WAF","cors":true},"wafregional":{"prefix":"waf-regional","name":"WAFRegional"},"workdocs":{"name":"WorkDocs","cors":true},"workspaces":{"name":"WorkSpaces"},"codestar":{"name":"CodeStar"},"lexmodelbuildingservice":{"prefix":"lex-models","name":"LexModelBuildingService","cors":true},"marketplaceentitlementservice":{"prefix":"entitlement.marketplace","name":"MarketplaceEntitlementService"},"athena":{"name":"Athena","cors":true},"greengrass":{"name":"Greengrass"},"dax":{"name":"DAX"},"migrationhub":{"prefix":"AWSMigrationHub","name":"MigrationHub"},"cloudhsmv2":{"name":"CloudHSMV2","cors":true},"glue":{"name":"Glue"},"mobile":{"name":"Mobile"},"pricing":{"name":"Pricing","cors":true},"costexplorer":{"prefix":"ce","name":"CostExplorer","cors":true},"mediaconvert":{"name":"MediaConvert"},"medialive":{"name":"MediaLive"},"mediapackage":{"name":"MediaPackage"},"mediastore":{"name":"MediaStore"},"mediastoredata":{"prefix":"mediastore-data","name":"MediaStoreData","cors":true},"appsync":{"name":"AppSync"},"guardduty":{"name":"GuardDuty"},"mq":{"name":"MQ"},"comprehend":{"name":"Comprehend","cors":true},"iotjobsdataplane":{"prefix":"iot-jobs-data","name":"IoTJobsDataPlane"},"kinesisvideoarchivedmedia":{"prefix":"kinesis-video-archived-media","name":"KinesisVideoArchivedMedia","cors":true},"kinesisvideomedia":{"prefix":"kinesis-video-media","name":"KinesisVideoMedia","cors":true},"kinesisvideo":{"name":"KinesisVideo","cors":true},"sagemakerruntime":{"prefix":"runtime.sagemaker","name":"SageMakerRuntime"},"sagemaker":{"name":"SageMaker"},"translate":{"name":"Translate","cors":true},"resourcegroups":{"prefix":"resource-groups","name":"ResourceGroups","cors":true},"alexaforbusiness":{"name":"AlexaForBusiness"},"cloud9":{"name":"Cloud9"},"serverlessapplicationrepository":{"prefix":"serverlessrepo","name":"ServerlessApplicationRepository"},"servicediscovery":{"name":"ServiceDiscovery"},"workmail":{"name":"WorkMail"},"autoscalingplans":{"prefix":"autoscaling-plans","name":"AutoScalingPlans"},"transcribeservice":{"prefix":"transcribe","name":"TranscribeService"},"connect":{"name":"Connect","cors":true},"acmpca":{"prefix":"acm-pca","name":"ACMPCA"},"fms":{"name":"FMS"},"secretsmanager":{"name":"SecretsManager","cors":true},"iotanalytics":{"name":"IoTAnalytics","cors":true},"iot1clickdevicesservice":{"prefix":"iot1click-devices","name":"IoT1ClickDevicesService"},"iot1clickprojects":{"prefix":"iot1click-projects","name":"IoT1ClickProjects"},"pi":{"name":"PI"},"neptune":{"name":"Neptune"},"mediatailor":{"name":"MediaTailor"},"eks":{"name":"EKS"},"macie":{"name":"Macie"},"dlm":{"name":"DLM"},"signer":{"name":"Signer"},"chime":{"name":"Chime"},"pinpointemail":{"prefix":"pinpoint-email","name":"PinpointEmail"},"ram":{"name":"RAM"},"route53resolver":{"name":"Route53Resolver"},"pinpointsmsvoice":{"prefix":"sms-voice","name":"PinpointSMSVoice"},"quicksight":{"name":"QuickSight"},"rdsdataservice":{"prefix":"rds-data","name":"RDSDataService"},"amplify":{"name":"Amplify"},"datasync":{"name":"DataSync"},"robomaker":{"name":"RoboMaker"},"transfer":{"name":"Transfer"},"globalaccelerator":{"name":"GlobalAccelerator"},"comprehendmedical":{"name":"ComprehendMedical","cors":true},"kinesisanalyticsv2":{"name":"KinesisAnalyticsV2"},"mediaconnect":{"name":"MediaConnect"},"fsx":{"name":"FSx"},"securityhub":{"name":"SecurityHub"},"appmesh":{"name":"AppMesh","versions":["2018-10-01*"]},"licensemanager":{"prefix":"license-manager","name":"LicenseManager"},"kafka":{"name":"Kafka"},"apigatewaymanagementapi":{"name":"ApiGatewayManagementApi"},"apigatewayv2":{"name":"ApiGatewayV2"},"docdb":{"name":"DocDB"},"backup":{"name":"Backup"},"worklink":{"name":"WorkLink"},"textract":{"name":"Textract"},"managedblockchain":{"name":"ManagedBlockchain"},"mediapackagevod":{"prefix":"mediapackage-vod","name":"MediaPackageVod"},"groundstation":{"name":"GroundStation"},"iotthingsgraph":{"name":"IoTThingsGraph"},"iotevents":{"name":"IoTEvents"},"ioteventsdata":{"prefix":"iotevents-data","name":"IoTEventsData"},"personalize":{"name":"Personalize","cors":true},"personalizeevents":{"prefix":"personalize-events","name":"PersonalizeEvents","cors":true},"personalizeruntime":{"prefix":"personalize-runtime","name":"PersonalizeRuntime","cors":true},"applicationinsights":{"prefix":"application-insights","name":"ApplicationInsights"},"servicequotas":{"prefix":"service-quotas","name":"ServiceQuotas"},"ec2instanceconnect":{"prefix":"ec2-instance-connect","name":"EC2InstanceConnect"},"eventbridge":{"name":"EventBridge"},"lakeformation":{"name":"LakeFormation"},"forecastservice":{"prefix":"forecast","name":"ForecastService","cors":true},"forecastqueryservice":{"prefix":"forecastquery","name":"ForecastQueryService","cors":true},"qldb":{"name":"QLDB"},"qldbsession":{"prefix":"qldb-session","name":"QLDBSession"},"workmailmessageflow":{"name":"WorkMailMessageFlow"},"codestarnotifications":{"prefix":"codestar-notifications","name":"CodeStarNotifications"},"savingsplans":{"name":"SavingsPlans"},"sso":{"name":"SSO"},"ssooidc":{"prefix":"sso-oidc","name":"SSOOIDC"},"marketplacecatalog":{"prefix":"marketplace-catalog","name":"MarketplaceCatalog"},"dataexchange":{"name":"DataExchange"},"sesv2":{"name":"SESV2"},"migrationhubconfig":{"prefix":"migrationhub-config","name":"MigrationHubConfig"},"connectparticipant":{"name":"ConnectParticipant"},"appconfig":{"name":"AppConfig"},"iotsecuretunneling":{"name":"IoTSecureTunneling"},"wafv2":{"name":"WAFV2"},"elasticinference":{"prefix":"elastic-inference","name":"ElasticInference"},"imagebuilder":{"name":"Imagebuilder"},"schemas":{"name":"Schemas"},"accessanalyzer":{"name":"AccessAnalyzer"},"codegurureviewer":{"prefix":"codeguru-reviewer","name":"CodeGuruReviewer"},"codeguruprofiler":{"name":"CodeGuruProfiler"},"computeoptimizer":{"prefix":"compute-optimizer","name":"ComputeOptimizer"},"frauddetector":{"name":"FraudDetector"},"kendra":{"name":"Kendra"},"networkmanager":{"name":"NetworkManager"},"outposts":{"name":"Outposts"},"augmentedairuntime":{"prefix":"sagemaker-a2i-runtime","name":"AugmentedAIRuntime"},"ebs":{"name":"EBS"},"kinesisvideosignalingchannels":{"prefix":"kinesis-video-signaling","name":"KinesisVideoSignalingChannels","cors":true},"detective":{"name":"Detective"},"codestarconnections":{"prefix":"codestar-connections","name":"CodeStarconnections"},"synthetics":{"name":"Synthetics"},"iotsitewise":{"name":"IoTSiteWise"},"macie2":{"name":"Macie2"},"codeartifact":{"name":"CodeArtifact"},"honeycode":{"name":"Honeycode"},"ivs":{"name":"IVS"},"braket":{"name":"Braket"},"identitystore":{"name":"IdentityStore"},"appflow":{"name":"Appflow"},"redshiftdata":{"prefix":"redshift-data","name":"RedshiftData"},"ssoadmin":{"prefix":"sso-admin","name":"SSOAdmin"},"timestreamquery":{"prefix":"timestream-query","name":"TimestreamQuery"},"timestreamwrite":{"prefix":"timestream-write","name":"TimestreamWrite"},"s3outposts":{"name":"S3Outposts"},"databrew":{"name":"DataBrew"},"servicecatalogappregistry":{"prefix":"servicecatalog-appregistry","name":"ServiceCatalogAppRegistry"},"networkfirewall":{"prefix":"network-firewall","name":"NetworkFirewall"},"mwaa":{"name":"MWAA"},"amplifybackend":{"name":"AmplifyBackend"},"appintegrations":{"name":"AppIntegrations"},"connectcontactlens":{"prefix":"connect-contact-lens","name":"ConnectContactLens"},"devopsguru":{"prefix":"devops-guru","name":"DevOpsGuru"},"ecrpublic":{"prefix":"ecr-public","name":"ECRPUBLIC"},"lookoutvision":{"name":"LookoutVision"},"sagemakerfeaturestoreruntime":{"prefix":"sagemaker-featurestore-runtime","name":"SageMakerFeatureStoreRuntime"},"customerprofiles":{"prefix":"customer-profiles","name":"CustomerProfiles"},"auditmanager":{"name":"AuditManager"},"emrcontainers":{"prefix":"emr-containers","name":"EMRcontainers"},"healthlake":{"name":"HealthLake"},"sagemakeredge":{"prefix":"sagemaker-edge","name":"SagemakerEdge"},"amp":{"name":"Amp"},"greengrassv2":{"name":"GreengrassV2"},"iotdeviceadvisor":{"name":"IotDeviceAdvisor"},"iotfleethub":{"name":"IoTFleetHub"},"iotwireless":{"name":"IoTWireless"},"location":{"name":"Location","cors":true},"wellarchitected":{"name":"WellArchitected"},"lexmodelsv2":{"prefix":"models.lex.v2","name":"LexModelsV2"},"lexruntimev2":{"prefix":"runtime.lex.v2","name":"LexRuntimeV2","cors":true},"fis":{"name":"Fis"},"lookoutmetrics":{"name":"LookoutMetrics"},"mgn":{"name":"Mgn"},"lookoutequipment":{"name":"LookoutEquipment"},"nimble":{"name":"Nimble"},"finspace":{"name":"Finspace"},"finspacedata":{"prefix":"finspace-data","name":"Finspacedata"},"ssmcontacts":{"prefix":"ssm-contacts","name":"SSMContacts"},"ssmincidents":{"prefix":"ssm-incidents","name":"SSMIncidents"},"applicationcostprofiler":{"name":"ApplicationCostProfiler"},"apprunner":{"name":"AppRunner"},"proton":{"name":"Proton"},"route53recoverycluster":{"prefix":"route53-recovery-cluster","name":"Route53RecoveryCluster"},"route53recoverycontrolconfig":{"prefix":"route53-recovery-control-config","name":"Route53RecoveryControlConfig"},"route53recoveryreadiness":{"prefix":"route53-recovery-readiness","name":"Route53RecoveryReadiness"},"chimesdkidentity":{"prefix":"chime-sdk-identity","name":"ChimeSDKIdentity"},"chimesdkmessaging":{"prefix":"chime-sdk-messaging","name":"ChimeSDKMessaging"},"snowdevicemanagement":{"prefix":"snow-device-management","name":"SnowDeviceManagement"},"memorydb":{"name":"MemoryDB"},"opensearch":{"name":"OpenSearch"},"kafkaconnect":{"name":"KafkaConnect"},"voiceid":{"prefix":"voice-id","name":"VoiceID"},"wisdom":{"name":"Wisdom"},"account":{"name":"Account"},"cloudcontrol":{"name":"CloudControl"},"grafana":{"name":"Grafana"},"panorama":{"name":"Panorama"},"chimesdkmeetings":{"prefix":"chime-sdk-meetings","name":"ChimeSDKMeetings"},"resiliencehub":{"name":"Resiliencehub"},"migrationhubstrategy":{"name":"MigrationHubStrategy"},"appconfigdata":{"name":"AppConfigData"},"drs":{"name":"Drs"},"migrationhubrefactorspaces":{"prefix":"migration-hub-refactor-spaces","name":"MigrationHubRefactorSpaces"},"evidently":{"name":"Evidently"},"inspector2":{"name":"Inspector2"},"rbin":{"name":"Rbin"},"rum":{"name":"RUM"},"backupgateway":{"prefix":"backup-gateway","name":"BackupGateway"},"iottwinmaker":{"name":"IoTTwinMaker"},"workspacesweb":{"prefix":"workspaces-web","name":"WorkSpacesWeb"},"amplifyuibuilder":{"name":"AmplifyUIBuilder"},"keyspaces":{"name":"Keyspaces"},"billingconductor":{"name":"Billingconductor"},"gamesparks":{"name":"GameSparks"},"pinpointsmsvoicev2":{"prefix":"pinpoint-sms-voice-v2","name":"PinpointSMSVoiceV2"}}')
},753:e=>{"use strict"
e.exports=JSON.parse('{"version":"2.0","metadata":{"apiVersion":"2011-06-15","endpointPrefix":"sts","globalEndpoint":"sts.amazonaws.com","protocol":"query","serviceAbbreviation":"AWS STS","serviceFullName":"AWS Security Token Service","serviceId":"STS","signatureVersion":"v4","uid":"sts-2011-06-15","xmlNamespace":"https://sts.amazonaws.com/doc/2011-06-15/"},"operations":{"AssumeRole":{"input":{"type":"structure","required":["RoleArn","RoleSessionName"],"members":{"RoleArn":{},"RoleSessionName":{},"PolicyArns":{"shape":"S4"},"Policy":{},"DurationSeconds":{"type":"integer"},"Tags":{"shape":"S8"},"TransitiveTagKeys":{"type":"list","member":{}},"ExternalId":{},"SerialNumber":{},"TokenCode":{},"SourceIdentity":{}}},"output":{"resultWrapper":"AssumeRoleResult","type":"structure","members":{"Credentials":{"shape":"Si"},"AssumedRoleUser":{"shape":"Sn"},"PackedPolicySize":{"type":"integer"},"SourceIdentity":{}}}},"AssumeRoleWithSAML":{"input":{"type":"structure","required":["RoleArn","PrincipalArn","SAMLAssertion"],"members":{"RoleArn":{},"PrincipalArn":{},"SAMLAssertion":{},"PolicyArns":{"shape":"S4"},"Policy":{},"DurationSeconds":{"type":"integer"}}},"output":{"resultWrapper":"AssumeRoleWithSAMLResult","type":"structure","members":{"Credentials":{"shape":"Si"},"AssumedRoleUser":{"shape":"Sn"},"PackedPolicySize":{"type":"integer"},"Subject":{},"SubjectType":{},"Issuer":{},"Audience":{},"NameQualifier":{},"SourceIdentity":{}}}},"AssumeRoleWithWebIdentity":{"input":{"type":"structure","required":["RoleArn","RoleSessionName","WebIdentityToken"],"members":{"RoleArn":{},"RoleSessionName":{},"WebIdentityToken":{},"ProviderId":{},"PolicyArns":{"shape":"S4"},"Policy":{},"DurationSeconds":{"type":"integer"}}},"output":{"resultWrapper":"AssumeRoleWithWebIdentityResult","type":"structure","members":{"Credentials":{"shape":"Si"},"SubjectFromWebIdentityToken":{},"AssumedRoleUser":{"shape":"Sn"},"PackedPolicySize":{"type":"integer"},"Provider":{},"Audience":{},"SourceIdentity":{}}}},"DecodeAuthorizationMessage":{"input":{"type":"structure","required":["EncodedMessage"],"members":{"EncodedMessage":{}}},"output":{"resultWrapper":"DecodeAuthorizationMessageResult","type":"structure","members":{"DecodedMessage":{}}}},"GetAccessKeyInfo":{"input":{"type":"structure","required":["AccessKeyId"],"members":{"AccessKeyId":{}}},"output":{"resultWrapper":"GetAccessKeyInfoResult","type":"structure","members":{"Account":{}}}},"GetCallerIdentity":{"input":{"type":"structure","members":{}},"output":{"resultWrapper":"GetCallerIdentityResult","type":"structure","members":{"UserId":{},"Account":{},"Arn":{}}}},"GetFederationToken":{"input":{"type":"structure","required":["Name"],"members":{"Name":{},"Policy":{},"PolicyArns":{"shape":"S4"},"DurationSeconds":{"type":"integer"},"Tags":{"shape":"S8"}}},"output":{"resultWrapper":"GetFederationTokenResult","type":"structure","members":{"Credentials":{"shape":"Si"},"FederatedUser":{"type":"structure","required":["FederatedUserId","Arn"],"members":{"FederatedUserId":{},"Arn":{}}},"PackedPolicySize":{"type":"integer"}}}},"GetSessionToken":{"input":{"type":"structure","members":{"DurationSeconds":{"type":"integer"},"SerialNumber":{},"TokenCode":{}}},"output":{"resultWrapper":"GetSessionTokenResult","type":"structure","members":{"Credentials":{"shape":"Si"}}}}},"shapes":{"S4":{"type":"list","member":{"type":"structure","members":{"arn":{}}}},"S8":{"type":"list","member":{"type":"structure","required":["Key","Value"],"members":{"Key":{},"Value":{}}}},"Si":{"type":"structure","required":["AccessKeyId","SecretAccessKey","SessionToken","Expiration"],"members":{"AccessKeyId":{},"SecretAccessKey":{},"SessionToken":{},"Expiration":{"type":"timestamp"}}},"Sn":{"type":"structure","required":["AssumedRoleId","Arn"],"members":{"AssumedRoleId":{},"Arn":{}}}}}')
},3639:e=>{"use strict"
e.exports={o:{}}},738:e=>{"use strict"
e.exports=JSON.parse('{"rules":{"*/*":{"endpoint":"{service}.{region}.amazonaws.com"},"cn-*/*":{"endpoint":"{service}.{region}.amazonaws.com.cn"},"us-iso-*/*":"usIso","us-isob-*/*":"usIsob","*/budgets":"globalSSL","*/cloudfront":"globalSSL","*/sts":"globalSSL","*/importexport":{"endpoint":"{service}.amazonaws.com","signatureVersion":"v2","globalEndpoint":true},"*/route53":"globalSSL","cn-*/route53":{"endpoint":"{service}.amazonaws.com.cn","globalEndpoint":true,"signingRegion":"cn-northwest-1"},"us-gov-*/route53":"globalGovCloud","us-iso-*/route53":{"endpoint":"{service}.c2s.ic.gov","globalEndpoint":true,"signingRegion":"us-iso-east-1"},"us-isob-*/route53":{"endpoint":"{service}.sc2s.sgov.gov","globalEndpoint":true,"signingRegion":"us-isob-east-1"},"*/waf":"globalSSL","*/iam":"globalSSL","cn-*/iam":{"endpoint":"{service}.cn-north-1.amazonaws.com.cn","globalEndpoint":true,"signingRegion":"cn-north-1"},"us-gov-*/iam":"globalGovCloud","us-gov-*/sts":{"endpoint":"{service}.{region}.amazonaws.com"},"us-gov-west-1/s3":"s3signature","us-west-1/s3":"s3signature","us-west-2/s3":"s3signature","eu-west-1/s3":"s3signature","ap-southeast-1/s3":"s3signature","ap-southeast-2/s3":"s3signature","ap-northeast-1/s3":"s3signature","sa-east-1/s3":"s3signature","us-east-1/s3":{"endpoint":"{service}.amazonaws.com","signatureVersion":"s3"},"us-east-1/sdb":{"endpoint":"{service}.amazonaws.com","signatureVersion":"v2"},"*/sdb":{"endpoint":"{service}.{region}.amazonaws.com","signatureVersion":"v2"}},"fipsRules":{"*/*":"fipsStandard","us-gov-*/*":"fipsStandard","us-iso-*/*":{"endpoint":"{service}-fips.{region}.c2s.ic.gov"},"us-iso-*/dms":"usIso","us-isob-*/*":{"endpoint":"{service}-fips.{region}.sc2s.sgov.gov"},"us-isob-*/dms":"usIsob","cn-*/*":{"endpoint":"{service}-fips.{region}.amazonaws.com.cn"},"*/api.ecr":"fips.api.ecr","*/api.sagemaker":"fips.api.sagemaker","*/batch":"fipsDotPrefix","*/eks":"fipsDotPrefix","*/models.lex":"fips.models.lex","*/runtime.lex":"fips.runtime.lex","*/runtime.sagemaker":{"endpoint":"runtime-fips.sagemaker.{region}.amazonaws.com"},"*/iam":"fipsWithoutRegion","*/route53":"fipsWithoutRegion","*/transcribe":"fipsDotPrefix","*/waf":"fipsWithoutRegion","us-gov-*/transcribe":"fipsDotPrefix","us-gov-*/api.ecr":"fips.api.ecr","us-gov-*/api.sagemaker":"fips.api.sagemaker","us-gov-*/models.lex":"fips.models.lex","us-gov-*/runtime.lex":"fips.runtime.lex","us-gov-*/acm-pca":"fipsWithServiceOnly","us-gov-*/batch":"fipsWithServiceOnly","us-gov-*/config":"fipsWithServiceOnly","us-gov-*/eks":"fipsWithServiceOnly","us-gov-*/elasticmapreduce":"fipsWithServiceOnly","us-gov-*/identitystore":"fipsWithServiceOnly","us-gov-*/dynamodb":"fipsWithServiceOnly","us-gov-*/elasticloadbalancing":"fipsWithServiceOnly","us-gov-*/guardduty":"fipsWithServiceOnly","us-gov-*/monitoring":"fipsWithServiceOnly","us-gov-*/resource-groups":"fipsWithServiceOnly","us-gov-*/runtime.sagemaker":"fipsWithServiceOnly","us-gov-*/servicecatalog-appregistry":"fipsWithServiceOnly","us-gov-*/servicequotas":"fipsWithServiceOnly","us-gov-*/ssm":"fipsWithServiceOnly","us-gov-*/sts":"fipsWithServiceOnly","us-gov-*/support":"fipsWithServiceOnly","us-gov-west-1/states":"fipsWithServiceOnly","us-iso-east-1/elasticfilesystem":{"endpoint":"elasticfilesystem-fips.{region}.c2s.ic.gov"},"us-gov-west-1/organizations":"fipsWithServiceOnly","us-gov-west-1/route53":{"endpoint":"route53.us-gov.amazonaws.com"}},"dualstackRules":{"*/*":{"endpoint":"{service}.{region}.api.aws"},"cn-*/*":{"endpoint":"{service}.{region}.api.amazonwebservices.com.cn"},"*/s3":"dualstackLegacy","cn-*/s3":"dualstackLegacyCn","*/s3-control":"dualstackLegacy","cn-*/s3-control":"dualstackLegacyCn","ap-south-1/ec2":"dualstackLegacyEc2","eu-west-1/ec2":"dualstackLegacyEc2","sa-east-1/ec2":"dualstackLegacyEc2","us-east-1/ec2":"dualstackLegacyEc2","us-east-2/ec2":"dualstackLegacyEc2","us-west-2/ec2":"dualstackLegacyEc2"},"dualstackFipsRules":{"*/*":{"endpoint":"{service}-fips.{region}.api.aws"},"cn-*/*":{"endpoint":"{service}-fips.{region}.api.amazonwebservices.com.cn"},"*/s3":"dualstackFipsLegacy","cn-*/s3":"dualstackFipsLegacyCn","*/s3-control":"dualstackFipsLegacy","cn-*/s3-control":"dualstackFipsLegacyCn"},"patterns":{"globalSSL":{"endpoint":"https://{service}.amazonaws.com","globalEndpoint":true,"signingRegion":"us-east-1"},"globalGovCloud":{"endpoint":"{service}.us-gov.amazonaws.com","globalEndpoint":true,"signingRegion":"us-gov-west-1"},"s3signature":{"endpoint":"{service}.{region}.amazonaws.com","signatureVersion":"s3"},"usIso":{"endpoint":"{service}.{region}.c2s.ic.gov"},"usIsob":{"endpoint":"{service}.{region}.sc2s.sgov.gov"},"fipsStandard":{"endpoint":"{service}-fips.{region}.amazonaws.com"},"fipsDotPrefix":{"endpoint":"fips.{service}.{region}.amazonaws.com"},"fipsWithoutRegion":{"endpoint":"{service}-fips.amazonaws.com"},"fips.api.ecr":{"endpoint":"ecr-fips.{region}.amazonaws.com"},"fips.api.sagemaker":{"endpoint":"api-fips.sagemaker.{region}.amazonaws.com"},"fips.models.lex":{"endpoint":"models-fips.lex.{region}.amazonaws.com"},"fips.runtime.lex":{"endpoint":"runtime-fips.lex.{region}.amazonaws.com"},"fipsWithServiceOnly":{"endpoint":"{service}.{region}.amazonaws.com"},"dualstackLegacy":{"endpoint":"{service}.dualstack.{region}.amazonaws.com"},"dualstackLegacyCn":{"endpoint":"{service}.dualstack.{region}.amazonaws.com.cn"},"dualstackFipsLegacy":{"endpoint":"{service}-fips.dualstack.{region}.amazonaws.com"},"dualstackFipsLegacyCn":{"endpoint":"{service}-fips.dualstack.{region}.amazonaws.com.cn"},"dualstackLegacyEc2":{"endpoint":"api.ec2.{region}.aws"}}}')
}},t={}
function r(n){var i=t[n]
if(void 0!==i)return i.exports
var o=t[n]={id:n,loaded:!1,exports:{}}
return e[n].call(o.exports,o,o.exports,r),o.loaded=!0,o.exports}r.n=e=>{
var t=e&&e.__esModule?()=>e.default:()=>e
return r.d(t,{a:t}),t},r.d=(e,t)=>{for(var n in t)r.o(t,n)&&!r.o(e,n)&&Object.defineProperty(e,n,{
enumerable:!0,get:t[n]})},r.g=function(){if("object"==typeof globalThis)return globalThis
try{return this||new Function("return this")()}catch(e){if("object"==typeof window)return window}
}(),r.o=(e,t)=>Object.prototype.hasOwnProperty.call(e,t),r.r=e=>{
"undefined"!=typeof Symbol&&Symbol.toStringTag&&Object.defineProperty(e,Symbol.toStringTag,{
value:"Module"}),Object.defineProperty(e,"__esModule",{value:!0})},r.nmd=e=>(e.paths=[],
e.children||(e.children=[]),e)
var n={}
return(()=>{"use strict"
r.r(n),r.d(n,{Cloud9:()=>e})
var e=r(2543)})(),n
})(),"object"==typeof exports&&"object"==typeof module?module.exports=t():"function"==typeof define&&define.amd?define([],t):"object"==typeof exports?exports.webpackNumbers=t():e.webpackNumbers=t()
}))


define("cssfilter/lib/default",[],(function(require,exports,module){function getDefaultWhiteList(){
var whiteList={"align-content":!1,"align-items":!1,"align-self":!1,"alignment-adjust":!1,
"alignment-baseline":!1,all:!1,"anchor-point":!1,animation:!1,"animation-delay":!1,
"animation-direction":!1,"animation-duration":!1,"animation-fill-mode":!1,
"animation-iteration-count":!1,"animation-name":!1,"animation-play-state":!1,
"animation-timing-function":!1,azimuth:!1,"backface-visibility":!1,background:!0,
"background-attachment":!0,"background-clip":!0,"background-color":!0,"background-image":!0,
"background-origin":!0,"background-position":!0,"background-repeat":!0,"background-size":!0,
"baseline-shift":!1,binding:!1,bleed:!1,"bookmark-label":!1,"bookmark-level":!1,"bookmark-state":!1,
border:!0,"border-bottom":!0,"border-bottom-color":!0,"border-bottom-left-radius":!0,
"border-bottom-right-radius":!0,"border-bottom-style":!0,"border-bottom-width":!0,
"border-collapse":!0,"border-color":!0,"border-image":!0,"border-image-outset":!0,
"border-image-repeat":!0,"border-image-slice":!0,"border-image-source":!0,"border-image-width":!0,
"border-left":!0,"border-left-color":!0,"border-left-style":!0,"border-left-width":!0,
"border-radius":!0,"border-right":!0,"border-right-color":!0,"border-right-style":!0,
"border-right-width":!0,"border-spacing":!0,"border-style":!0,"border-top":!0,"border-top-color":!0,
"border-top-left-radius":!0,"border-top-right-radius":!0,"border-top-style":!0,
"border-top-width":!0,"border-width":!0,bottom:!1,"box-decoration-break":!0,"box-shadow":!0,
"box-sizing":!0,"box-snap":!0,"box-suppress":!0,"break-after":!0,"break-before":!0,
"break-inside":!0,"caption-side":!1,chains:!1,clear:!0,clip:!1,"clip-path":!1,"clip-rule":!1,
color:!0,"color-interpolation-filters":!0,"column-count":!1,"column-fill":!1,"column-gap":!1,
"column-rule":!1,"column-rule-color":!1,"column-rule-style":!1,"column-rule-width":!1,
"column-span":!1,"column-width":!1,columns:!1,contain:!1,content:!1,"counter-increment":!1,
"counter-reset":!1,"counter-set":!1,crop:!1,cue:!1,"cue-after":!1,"cue-before":!1,cursor:!1,
direction:!1,display:!0,"display-inside":!0,"display-list":!0,"display-outside":!0,
"dominant-baseline":!1,elevation:!1,"empty-cells":!1,filter:!1,flex:!1,"flex-basis":!1,
"flex-direction":!1,"flex-flow":!1,"flex-grow":!1,"flex-shrink":!1,"flex-wrap":!1,float:!1,
"float-offset":!1,"flood-color":!1,"flood-opacity":!1,"flow-from":!1,"flow-into":!1,font:!0,
"font-family":!0,"font-feature-settings":!0,"font-kerning":!0,"font-language-override":!0,
"font-size":!0,"font-size-adjust":!0,"font-stretch":!0,"font-style":!0,"font-synthesis":!0,
"font-variant":!0,"font-variant-alternates":!0,"font-variant-caps":!0,"font-variant-east-asian":!0,
"font-variant-ligatures":!0,"font-variant-numeric":!0,"font-variant-position":!0,"font-weight":!0,
grid:!1,"grid-area":!1,"grid-auto-columns":!1,"grid-auto-flow":!1,"grid-auto-rows":!1,
"grid-column":!1,"grid-column-end":!1,"grid-column-start":!1,"grid-row":!1,"grid-row-end":!1,
"grid-row-start":!1,"grid-template":!1,"grid-template-areas":!1,"grid-template-columns":!1,
"grid-template-rows":!1,"hanging-punctuation":!1,height:!0,hyphens:!1,icon:!1,
"image-orientation":!1,"image-resolution":!1,"ime-mode":!1,"initial-letters":!1,
"inline-box-align":!1,"justify-content":!1,"justify-items":!1,"justify-self":!1,left:!1,
"letter-spacing":!0,"lighting-color":!0,"line-box-contain":!1,"line-break":!1,"line-grid":!1,
"line-height":!1,"line-snap":!1,"line-stacking":!1,"line-stacking-ruby":!1,"line-stacking-shift":!1,
"line-stacking-strategy":!1,"list-style":!0,"list-style-image":!0,"list-style-position":!0,
"list-style-type":!0,margin:!0,"margin-bottom":!0,"margin-left":!0,"margin-right":!0,
"margin-top":!0,"marker-offset":!1,"marker-side":!1,marks:!1,mask:!1,"mask-box":!1,
"mask-box-outset":!1,"mask-box-repeat":!1,"mask-box-slice":!1,"mask-box-source":!1,
"mask-box-width":!1,"mask-clip":!1,"mask-image":!1,"mask-origin":!1,"mask-position":!1,
"mask-repeat":!1,"mask-size":!1,"mask-source-type":!1,"mask-type":!1,"max-height":!0,"max-lines":!1,
"max-width":!0,"min-height":!0,"min-width":!0,"move-to":!1,"nav-down":!1,"nav-index":!1,
"nav-left":!1,"nav-right":!1,"nav-up":!1,"object-fit":!1,"object-position":!1,opacity:!1,order:!1,
orphans:!1,outline:!1,"outline-color":!1,"outline-offset":!1,"outline-style":!1,"outline-width":!1,
overflow:!1,"overflow-wrap":!1,"overflow-x":!1,"overflow-y":!1,padding:!0,"padding-bottom":!0,
"padding-left":!0,"padding-right":!0,"padding-top":!0,page:!1,"page-break-after":!1,
"page-break-before":!1,"page-break-inside":!1,"page-policy":!1,pause:!1,"pause-after":!1,
"pause-before":!1,perspective:!1,"perspective-origin":!1,pitch:!1,"pitch-range":!1,"play-during":!1,
position:!1,"presentation-level":!1,quotes:!1,"region-fragment":!1,resize:!1,rest:!1,
"rest-after":!1,"rest-before":!1,richness:!1,right:!1,rotation:!1,"rotation-point":!1,
"ruby-align":!1,"ruby-merge":!1,"ruby-position":!1,"shape-image-threshold":!1,"shape-outside":!1,
"shape-margin":!1,size:!1,speak:!1,"speak-as":!1,"speak-header":!1,"speak-numeral":!1,
"speak-punctuation":!1,"speech-rate":!1,stress:!1,"string-set":!1,"tab-size":!1,"table-layout":!1,
"text-align":!0,"text-align-last":!0,"text-combine-upright":!0,"text-decoration":!0,
"text-decoration-color":!0,"text-decoration-line":!0,"text-decoration-skip":!0,
"text-decoration-style":!0,"text-emphasis":!0,"text-emphasis-color":!0,"text-emphasis-position":!0,
"text-emphasis-style":!0,"text-height":!0,"text-indent":!0,"text-justify":!0,"text-orientation":!0,
"text-overflow":!0,"text-shadow":!0,"text-space-collapse":!0,"text-transform":!0,
"text-underline-position":!0,"text-wrap":!0,top:!1,transform:!1,"transform-origin":!1,
"transform-style":!1,transition:!1,"transition-delay":!1,"transition-duration":!1,
"transition-property":!1,"transition-timing-function":!1,"unicode-bidi":!1,"vertical-align":!1,
visibility:!1,"voice-balance":!1,"voice-duration":!1,"voice-family":!1,"voice-pitch":!1,
"voice-range":!1,"voice-rate":!1,"voice-stress":!1,"voice-volume":!1,volume:!1,"white-space":!1,
widows:!1,width:!0,"will-change":!1,"word-break":!0,"word-spacing":!0,"word-wrap":!0,"wrap-flow":!1,
"wrap-through":!1,"writing-mode":!1,"z-index":!1}
return whiteList}function onAttr(name,value,options){}function onIgnoreAttr(name,value,options){}
var REGEXP_URL_JAVASCRIPT=/javascript\s*\:/gim
function safeAttrValue(name,value){return REGEXP_URL_JAVASCRIPT.test(value)?"":value}
exports.whiteList=getDefaultWhiteList(),exports.getDefaultWhiteList=getDefaultWhiteList,
exports.onAttr=onAttr,exports.onIgnoreAttr=onIgnoreAttr,exports.safeAttrValue=safeAttrValue}))


define("cssfilter/lib/util",[],(function(require,exports,module){module.exports={
indexOf:function(arr,item){var i,j
if(Array.prototype.indexOf)return arr.indexOf(item)
for(i=0,j=arr.length;i<j;i++)if(arr[i]===item)return i
return-1},forEach:function(arr,fn,scope){var i,j
if(Array.prototype.forEach)return arr.forEach(fn,scope)
for(i=0,j=arr.length;i<j;i++)fn.call(scope,arr[i],i,arr)},trim:function(str){
return String.prototype.trim?str.trim():str.replace(/(^\s*)|(\s*$)/g,"")},trimRight:function(str){
return String.prototype.trimRight?str.trimRight():str.replace(/(\s*$)/g,"")}}}))


define("cssfilter/lib/parser",[],(function(require,exports,module){var _=require("./util")
function parseStyle(css,onAttr){";"!==(css=_.trimRight(css))[css.length-1]&&(css+=";")
var cssLength=css.length,isParenthesisOpen=!1,lastPos=0,i=0,retCSS=""
function addNewAttr(){if(!isParenthesisOpen){
var source=_.trim(css.slice(lastPos,i)),j=source.indexOf(":")
if(-1!==j){var name=_.trim(source.slice(0,j)),value=_.trim(source.slice(j+1))
if(name){var ret=onAttr(lastPos,retCSS.length,name,value,source)
ret&&(retCSS+=ret+"; ")}}}lastPos=i+1}for(;i<cssLength;i++){var c=css[i]
if("/"===c&&"*"===css[i+1]){var j=css.indexOf("*/",i+2)
if(-1===j)break
lastPos=(i=j+1)+1,isParenthesisOpen=!1
}else"("===c?isParenthesisOpen=!0:")"===c?isParenthesisOpen=!1:";"===c?isParenthesisOpen||addNewAttr():"\n"===c&&addNewAttr()
}return _.trim(retCSS)}module.exports=parseStyle}))


define("cssfilter/lib/css",[],(function(require,exports,module){
var DEFAULT=require("./default"),parseStyle=require("./parser")
require("./util")
function isNull(obj){return null==obj}function shallowCopyObject(obj){var ret={}
for(var i in obj)ret[i]=obj[i]
return ret}function FilterCSS(options){
(options=shallowCopyObject(options||{})).whiteList=options.whiteList||DEFAULT.whiteList,
options.onAttr=options.onAttr||DEFAULT.onAttr,
options.onIgnoreAttr=options.onIgnoreAttr||DEFAULT.onIgnoreAttr,
options.safeAttrValue=options.safeAttrValue||DEFAULT.safeAttrValue,this.options=options}
FilterCSS.prototype.process=function(css){if(!(css=(css=css||"").toString()))return""
var options=this.options,whiteList=options.whiteList,onAttr=options.onAttr,onIgnoreAttr=options.onIgnoreAttr,safeAttrValue=options.safeAttrValue
return parseStyle(css,(function(sourcePosition,position,name,value,source){
var check=whiteList[name],isWhite=!1
if(!0===check?isWhite=check:"function"==typeof check?isWhite=check(value):check instanceof RegExp&&(isWhite=check.test(value)),
!0!==isWhite&&(isWhite=!1),value=safeAttrValue(name,value)){var ret,opts={position:position,
sourcePosition:sourcePosition,source:source,isWhite:isWhite}
return isWhite?isNull(ret=onAttr(name,value,opts))?name+":"+value:ret:isNull(ret=onIgnoreAttr(name,value,opts))?void 0:ret
}}))},module.exports=FilterCSS}))


define("cssfilter/lib/index",[],(function(require,exports,module){
var DEFAULT=require("./default"),FilterCSS=require("./css")
function filterCSS(html,options){return new FilterCSS(options).process(html)}
for(var i in(exports=module.exports=filterCSS).FilterCSS=FilterCSS,DEFAULT)exports[i]=DEFAULT[i]
"undefined"!=typeof window&&(window.filterCSS=module.exports)}))


define("xss/lib/util",[],(function(require,exports,module){module.exports={
indexOf:function(arr,item){var i,j
if(Array.prototype.indexOf)return arr.indexOf(item)
for(i=0,j=arr.length;i<j;i++)if(arr[i]===item)return i
return-1},forEach:function(arr,fn,scope){var i,j
if(Array.prototype.forEach)return arr.forEach(fn,scope)
for(i=0,j=arr.length;i<j;i++)fn.call(scope,arr[i],i,arr)},trim:function(str){
return String.prototype.trim?str.trim():str.replace(/(^\s*)|(\s*$)/g,"")},spaceIndex:function(str){
var match=/\s|\n|\t/.exec(str)
return match?match.index:-1}}}))


define("xss/lib/default",[],(function(require,exports,module){
var FilterCSS=require("cssfilter").FilterCSS,getDefaultCSSWhiteList=require("cssfilter").getDefaultWhiteList,_=require("./util")
function getDefaultWhiteList(){return{a:["target","href","title"],abbr:["title"],address:[],
area:["shape","coords","href","alt"],article:[],aside:[],
audio:["autoplay","controls","crossorigin","loop","muted","preload","src"],b:[],bdi:["dir"],
bdo:["dir"],big:[],blockquote:["cite"],br:[],caption:[],center:[],cite:[],code:[],
col:["align","valign","span","width"],colgroup:["align","valign","span","width"],dd:[],
del:["datetime"],details:["open"],div:[],dl:[],dt:[],em:[],figcaption:[],figure:[],
font:["color","size","face"],footer:[],h1:[],h2:[],h3:[],h4:[],h5:[],h6:[],header:[],hr:[],i:[],
img:["src","alt","title","width","height","loading"],ins:["datetime"],kbd:[],li:[],mark:[],nav:[],
ol:[],p:[],pre:[],s:[],section:[],small:[],span:[],sub:[],summary:[],sup:[],strong:[],strike:[],
table:["width","border","align","valign"],tbody:["align","valign"],
td:["width","rowspan","colspan","align","valign"],tfoot:["align","valign"],
th:["width","rowspan","colspan","align","valign"],thead:["align","valign"],
tr:["rowspan","align","valign"],tt:[],u:[],ul:[],
video:["autoplay","controls","crossorigin","loop","muted","playsinline","poster","preload","src","height","width"]
}}var defaultCSSFilter=new FilterCSS
function onTag(tag,html,options){}function onIgnoreTag(tag,html,options){}
function onTagAttr(tag,name,value){}function onIgnoreTagAttr(tag,name,value){}
function escapeHtml(html){return html.replace(REGEXP_LT,"&lt;").replace(REGEXP_GT,"&gt;")}
function safeAttrValue(tag,name,value,cssFilter){if(value=friendlyAttrValue(value),
"href"===name||"src"===name){if("#"===(value=_.trim(value)))return"#"
if("http://"!==value.substr(0,7)&&"https://"!==value.substr(0,8)&&"mailto:"!==value.substr(0,7)&&"tel:"!==value.substr(0,4)&&"data:image/"!==value.substr(0,11)&&"ftp://"!==value.substr(0,6)&&"./"!==value.substr(0,2)&&"../"!==value.substr(0,3)&&"#"!==value[0]&&"/"!==value[0])return""
}else if("background"===name){
if(REGEXP_DEFAULT_ON_TAG_ATTR_4.lastIndex=0,REGEXP_DEFAULT_ON_TAG_ATTR_4.test(value))return""
}else if("style"===name){
if(REGEXP_DEFAULT_ON_TAG_ATTR_7.lastIndex=0,REGEXP_DEFAULT_ON_TAG_ATTR_7.test(value))return""
if(REGEXP_DEFAULT_ON_TAG_ATTR_8.lastIndex=0,REGEXP_DEFAULT_ON_TAG_ATTR_8.test(value)&&(REGEXP_DEFAULT_ON_TAG_ATTR_4.lastIndex=0,
REGEXP_DEFAULT_ON_TAG_ATTR_4.test(value)))return""
!1!==cssFilter&&(value=(cssFilter=cssFilter||defaultCSSFilter).process(value))}
return value=escapeAttrValue(value)}
var REGEXP_LT=/</g,REGEXP_GT=/>/g,REGEXP_QUOTE=/"/g,REGEXP_QUOTE_2=/&quot;/g,REGEXP_ATTR_VALUE_1=/&#([a-zA-Z0-9]*);?/gim,REGEXP_ATTR_VALUE_COLON=/&colon;?/gim,REGEXP_ATTR_VALUE_NEWLINE=/&newline;?/gim,REGEXP_DEFAULT_ON_TAG_ATTR_4=/((j\s*a\s*v\s*a|v\s*b|l\s*i\s*v\s*e)\s*s\s*c\s*r\s*i\s*p\s*t\s*|m\s*o\s*c\s*h\s*a):/gi,REGEXP_DEFAULT_ON_TAG_ATTR_7=/e\s*x\s*p\s*r\s*e\s*s\s*s\s*i\s*o\s*n\s*\(.*/gi,REGEXP_DEFAULT_ON_TAG_ATTR_8=/u\s*r\s*l\s*\(.*/gi
function escapeQuote(str){return str.replace(REGEXP_QUOTE,"&quot;")}function unescapeQuote(str){
return str.replace(REGEXP_QUOTE_2,'"')}function escapeHtmlEntities(str){
return str.replace(REGEXP_ATTR_VALUE_1,(function(str,code){
return"x"===code[0]||"X"===code[0]?String.fromCharCode(parseInt(code.substr(1),16)):String.fromCharCode(parseInt(code,10))
}))}function escapeDangerHtml5Entities(str){
return str.replace(REGEXP_ATTR_VALUE_COLON,":").replace(REGEXP_ATTR_VALUE_NEWLINE," ")}
function clearNonPrintableCharacter(str){
for(var str2="",i=0,len=str.length;i<len;i++)str2+=str.charCodeAt(i)<32?" ":str.charAt(i)
return _.trim(str2)}function friendlyAttrValue(str){
return str=clearNonPrintableCharacter(str=escapeDangerHtml5Entities(str=escapeHtmlEntities(str=unescapeQuote(str))))
}function escapeAttrValue(str){return str=escapeHtml(str=escapeQuote(str))}
function onIgnoreTagStripAll(){return""}function StripTagBody(tags,next){
"function"!=typeof next&&(next=function(){})
var isRemoveAllTag=!Array.isArray(tags)
function isRemoveTag(tag){return!!isRemoveAllTag||-1!==_.indexOf(tags,tag)}
var removeList=[],posStart=!1
return{onIgnoreTag:function(tag,html,options){if(isRemoveTag(tag)){if(options.isClosing){
var ret="[/removed]",end=options.position+ret.length
return removeList.push([!1!==posStart?posStart:options.position,end]),posStart=!1,ret}
return posStart||(posStart=options.position),"[removed]"}return next(tag,html,options)},
remove:function(html){var rethtml="",lastPos=0
return _.forEach(removeList,(function(pos){rethtml+=html.slice(lastPos,pos[0]),lastPos=pos[1]})),
rethtml+=html.slice(lastPos)}}}function stripCommentTag(html){
for(var retHtml="",lastPos=0;lastPos<html.length;){var i=html.indexOf("<!--",lastPos)
if(-1===i){retHtml+=html.slice(lastPos)
break}retHtml+=html.slice(lastPos,i)
var j=html.indexOf("-->",i)
if(-1===j)break
lastPos=j+3}return retHtml}function stripBlankChar(html){var chars=html.split("")
return(chars=chars.filter((function(char){var c=char.charCodeAt(0)
return 127!==c&&(!(c<=31)||(10===c||13===c))}))).join("")}exports.whiteList=getDefaultWhiteList(),
exports.getDefaultWhiteList=getDefaultWhiteList,exports.onTag=onTag,exports.onIgnoreTag=onIgnoreTag,
exports.onTagAttr=onTagAttr,
exports.onIgnoreTagAttr=onIgnoreTagAttr,exports.safeAttrValue=safeAttrValue,
exports.escapeHtml=escapeHtml,exports.escapeQuote=escapeQuote,exports.unescapeQuote=unescapeQuote,
exports.escapeHtmlEntities=escapeHtmlEntities,
exports.escapeDangerHtml5Entities=escapeDangerHtml5Entities,
exports.clearNonPrintableCharacter=clearNonPrintableCharacter,
exports.friendlyAttrValue=friendlyAttrValue,exports.escapeAttrValue=escapeAttrValue,
exports.onIgnoreTagStripAll=onIgnoreTagStripAll,exports.StripTagBody=StripTagBody,
exports.stripCommentTag=stripCommentTag,
exports.stripBlankChar=stripBlankChar,exports.attributeWrapSign='"',
exports.cssFilter=defaultCSSFilter,exports.getDefaultCSSWhiteList=getDefaultCSSWhiteList}))


define("xss/lib/parser",[],(function(require,exports,module){var _=require("./util")
function getTagName(html){var tagName,i=_.spaceIndex(html)
return tagName=-1===i?html.slice(1,-1):html.slice(1,i+1),"/"===(tagName=_.trim(tagName).toLowerCase()).slice(0,1)&&(tagName=tagName.slice(1)),
"/"===tagName.slice(-1)&&(tagName=tagName.slice(0,-1)),tagName}function isClosing(html){
return"</"===html.slice(0,2)}function parseTag(html,onTag,escapeHtml){"use strict"
var rethtml="",lastPos=0,tagStart=!1,quoteStart=!1,currentPos=0,len=html.length,currentTagName="",currentHtml=""
chariterator:for(currentPos=0;currentPos<len;currentPos++){var c=html.charAt(currentPos)
if(!1===tagStart){if("<"===c){tagStart=currentPos
continue}}else if(!1===quoteStart){if("<"===c){rethtml+=escapeHtml(html.slice(lastPos,currentPos)),
tagStart=currentPos,lastPos=currentPos
continue}if(">"===c||currentPos===len-1){rethtml+=escapeHtml(html.slice(lastPos,tagStart)),
currentTagName=getTagName(currentHtml=html.slice(tagStart,currentPos+1)),
rethtml+=onTag(tagStart,rethtml.length,currentTagName,currentHtml,isClosing(currentHtml)),
lastPos=currentPos+1,tagStart=!1
continue}if('"'===c||"'"===c)for(var i=1,ic=html.charAt(currentPos-i);""===ic.trim()||"="===ic;){
if("="===ic){quoteStart=c
continue chariterator}ic=html.charAt(currentPos-++i)}}else if(c===quoteStart){quoteStart=!1
continue}}return lastPos<len&&(rethtml+=escapeHtml(html.substr(lastPos))),rethtml}
var REGEXP_ILLEGAL_ATTR_NAME=/[^a-zA-Z0-9\\_:.-]/gim
function parseAttr(html,onAttr){"use strict"
var lastPos=0,lastMarkPos=0,retAttrs=[],tmpName=!1,len=html.length
function addAttr(name,value){
if(!((name=(name=_.trim(name)).replace(REGEXP_ILLEGAL_ATTR_NAME,"").toLowerCase()).length<1)){
var ret=onAttr(name,value||"")
ret&&retAttrs.push(ret)}}for(var i=0;i<len;i++){var j,c=html.charAt(i)
if(!1!==tmpName||"="!==c)if(!1===tmpName||i!==lastMarkPos)if(/\s|\n|\t/.test(c)){
if(html=html.replace(/\s|\n|\t/g," "),!1===tmpName){if(-1===(j=findNextEqual(html,i))){
addAttr(_.trim(html.slice(lastPos,i))),tmpName=!1,lastPos=i+1
continue}i=j-1
continue}if(-1===(j=findBeforeEqual(html,i-1))){
addAttr(tmpName,stripQuoteWrap(_.trim(html.slice(lastPos,i)))),tmpName=!1,lastPos=i+1
continue}}else;else{if(-1===(j=html.indexOf(c,i+1)))break
addAttr(tmpName,_.trim(html.slice(lastMarkPos+1,j))),tmpName=!1,lastPos=(i=j)+1
}else tmpName=html.slice(lastPos,i),
lastPos=i+1,lastMarkPos='"'===html.charAt(lastPos)||"'"===html.charAt(lastPos)?lastPos:findNextQuotationMark(html,i+1)
}
return lastPos<html.length&&(!1===tmpName?addAttr(html.slice(lastPos)):addAttr(tmpName,stripQuoteWrap(_.trim(html.slice(lastPos))))),
_.trim(retAttrs.join(" "))}function findNextEqual(str,i){for(;i<str.length;i++){var c=str[i]
if(" "!==c)return"="===c?i:-1}}function findNextQuotationMark(str,i){for(;i<str.length;i++){
var c=str[i]
if(" "!==c)return"'"===c||'"'===c?i:-1}}function findBeforeEqual(str,i){for(;i>0;i--){var c=str[i]
if(" "!==c)return"="===c?i:-1}}function isQuoteWrapString(text){
return'"'===text[0]&&'"'===text[text.length-1]||"'"===text[0]&&"'"===text[text.length-1]}
function stripQuoteWrap(text){return isQuoteWrapString(text)?text.substr(1,text.length-2):text}
exports.parseTag=parseTag,exports.parseAttr=parseAttr}))


define("xss/lib/xss",[],(function(require,exports,module){
var FilterCSS=require("cssfilter").FilterCSS,DEFAULT=require("./default"),parser=require("./parser"),parseTag=parser.parseTag,parseAttr=parser.parseAttr,_=require("./util")
function isNull(obj){return null==obj}function getAttrs(html){var i=_.spaceIndex(html)
if(-1===i)return{html:"",closing:"/"===html[html.length-2]}
var isClosing="/"===(html=_.trim(html.slice(i+1,-1)))[html.length-1]
return isClosing&&(html=_.trim(html.slice(0,-1))),{html:html,closing:isClosing}}
function shallowCopyObject(obj){var ret={}
for(var i in obj)ret[i]=obj[i]
return ret}function keysToLowerCase(obj){var ret={}
for(var i in obj)Array.isArray(obj[i])?ret[i.toLowerCase()]=obj[i].map((function(item){
return item.toLowerCase()})):ret[i.toLowerCase()]=obj[i]
return ret}function FilterXSS(options){
(options=shallowCopyObject(options||{})).stripIgnoreTag&&(options.onIgnoreTag&&console.error('Notes: cannot use these two options "stripIgnoreTag" and "onIgnoreTag" at the same time'),
options.onIgnoreTag=DEFAULT.onIgnoreTagStripAll),
options.whiteList||options.allowList?options.whiteList=keysToLowerCase(options.whiteList||options.allowList):options.whiteList=DEFAULT.whiteList,
this.attributeWrapSign=!0===options.singleQuotedAttributeValue?"'":DEFAULT.attributeWrapSign,
options.onTag=options.onTag||DEFAULT.onTag,options.onTagAttr=options.onTagAttr||DEFAULT.onTagAttr,
options.onIgnoreTag=options.onIgnoreTag||DEFAULT.onIgnoreTag,
options.onIgnoreTagAttr=options.onIgnoreTagAttr||DEFAULT.onIgnoreTagAttr,
options.safeAttrValue=options.safeAttrValue||DEFAULT.safeAttrValue,
options.escapeHtml=options.escapeHtml||DEFAULT.escapeHtml,
this.options=options,!1===options.css?this.cssFilter=!1:(options.css=options.css||{},
this.cssFilter=new FilterCSS(options.css))}FilterXSS.prototype.process=function(html){
if(!(html=(html=html||"").toString()))return""
var me=this,options=me.options,whiteList=options.whiteList,onTag=options.onTag,onIgnoreTag=options.onIgnoreTag,onTagAttr=options.onTagAttr,onIgnoreTagAttr=options.onIgnoreTagAttr,safeAttrValue=options.safeAttrValue,escapeHtml=options.escapeHtml,attributeWrapSign=me.attributeWrapSign,cssFilter=me.cssFilter
options.stripBlankChar&&(html=DEFAULT.stripBlankChar(html)),options.allowCommentTag||(html=DEFAULT.stripCommentTag(html))
var stripIgnoreTagBody=!1
options.stripIgnoreTagBody&&(stripIgnoreTagBody=DEFAULT.StripTagBody(options.stripIgnoreTagBody,onIgnoreTag),
onIgnoreTag=stripIgnoreTagBody.onIgnoreTag)
var retHtml=parseTag(html,(function(sourcePosition,position,tag,html,isClosing){var info={
sourcePosition:sourcePosition,position:position,isClosing:isClosing,
isWhite:Object.prototype.hasOwnProperty.call(whiteList,tag)},ret=onTag(tag,html,info)
if(!isNull(ret))return ret
if(info.isWhite){if(info.isClosing)return"</"+tag+">"
var attrs=getAttrs(html),whiteAttrList=whiteList[tag],attrsHtml=parseAttr(attrs.html,(function(name,value){
var isWhiteAttr=-1!==_.indexOf(whiteAttrList,name),ret=onTagAttr(tag,name,value,isWhiteAttr)
return isNull(ret)?isWhiteAttr?(value=safeAttrValue(tag,name,value,cssFilter))?name+"="+attributeWrapSign+value+attributeWrapSign:name:isNull(ret=onIgnoreTagAttr(tag,name,value,isWhiteAttr))?void 0:ret:ret
}))
return html="<"+tag,attrsHtml&&(html+=" "+attrsHtml),attrs.closing&&(html+=" /"),html+=">"}
return isNull(ret=onIgnoreTag(tag,html,info))?escapeHtml(html):ret}),escapeHtml)
return stripIgnoreTagBody&&(retHtml=stripIgnoreTagBody.remove(retHtml)),retHtml},
module.exports=FilterXSS}))


define("xss/lib/index",[],(function(require,exports,module){
var DEFAULT=require("./default"),parser=require("./parser"),FilterXSS=require("./xss")
function filterXSS(html,options){return new FilterXSS(options).process(html)}function isWorkerEnv(){
return"undefined"!=typeof self&&"undefined"!=typeof DedicatedWorkerGlobalScope&&self instanceof DedicatedWorkerGlobalScope
}(exports=module.exports=filterXSS).filterXSS=filterXSS,exports.FilterXSS=FilterXSS,function(){
for(var i in DEFAULT)exports[i]=DEFAULT[i]
for(var j in parser)exports[j]=parser[j]
}(),"undefined"!=typeof window&&(window.filterXSS=module.exports),
isWorkerEnv()&&(self.filterXSS=module.exports)}))


define("@c9/ide/plugins/c9.core/xss",[],(function(require,exports,module){"use strict"
Object.defineProperty(exports,"__esModule",{value:!0})
const sanitizer=new(require("xss").FilterXSS)({onIgnoreTagAttr:(tag,name,value,isWhiteAttr)=>{
if(new Set(["target","href","class","id","style"]).has(name))return`${name}='${value}'`},
onTagAttr:(tag,name,value,isWhiteAttr)=>{
if("a"===tag&&"href"===name&&value)return/^\s*javascript:/.test(value)?"href='#'":`href='${value}'`}
})
function sanitize(message,onIgnoreTagAttr){if(!onIgnoreTagAttr)return sanitizer.process(message)
const customSanitizer=Object.create(sanitizer)
return customSanitizer.options=Object.create(sanitizer.options),customSanitizer.options.onIgnoreTagAttr=onIgnoreTagAttr,
customSanitizer.process(message)}exports.sanitize=sanitize}))


define("events",[],(function(require,exports,module){
var EventEmitter=exports.EventEmitter=function(){},toString=Object.prototype.toString,isArray=Array.isArray||function(obj){
return"[object Array]"===toString.call(obj)},defaultMaxListeners=10
EventEmitter.prototype.setMaxListeners=function(n){this._events||(this._events={}),
this._events.maxListeners=n},EventEmitter.prototype.emit=function(type){if(this._events){
var handler=this._events[type]
if(handler){var returnValue
if("function"==typeof handler)switch(arguments.length){case 1:return handler.call(this)
case 2:return handler.call(this,arguments[1])
case 3:return handler.call(this,arguments[1],arguments[2])
default:var args=Array.prototype.slice.call(arguments,1)
returnValue=handler.apply(this,args)}else if(isArray(handler)){
args=Array.prototype.slice.call(arguments,1)
for(var temp,listeners=handler.slice(),i=0,l=listeners.length;i<l;i++)void 0!==(temp=listeners[i].apply(this,args))&&(returnValue=temp)
}return returnValue}}},EventEmitter.prototype.addListener=function(type,listener,plugin){
if("function"!=typeof listener)throw new Error("addListener only takes instances of Function")
this._events||(this._events={})
var eventList=this._events[type]
if(eventList)if(isArray(eventList)){var m
if(!eventList.warned)(m=void 0!==this._events.maxListeners?this._events.maxListeners:defaultMaxListeners)&&m>0&&eventList.length>m&&(eventList.warned=!0,
console.error('warning: possible EventEmitter memory leak detected. "'+eventList.length+'" listeners of type "'+type+'" added. Use emitter.setMaxListeners() to increase limit.'),
console.trace())
eventList.push(listener)}else this._events[type]=[eventList,listener]
else this._events[type]=listener
return"newListener"!=type&&this.emit("newListener",type,listener),plugin&&plugin.addEvent(this,type,listener),
this
},EventEmitter.prototype.on=EventEmitter.prototype.addListener,EventEmitter.prototype.once=function(type,listener,plugin){
var self=this,wrapped=function(){return self.removeListener(type,wrapped.listener),
wrapped.listener.apply(self,arguments)}
if(listener)return wrapped.listener=listener,self.on(type,wrapped,plugin),this
var result=new Promise((function(resolve){wrapped.listener=resolve}))
return self.on(type,wrapped,plugin),result
},EventEmitter.prototype.removeListener=function(type,listener){
if("function"!=typeof listener)throw new Error("removeListener only takes instances of Function")
if(!this._events||!this._events[type])return this
var list=this._events[type]
if(isArray(list)){if(!list.some((function(l,i){if((l.listener||l)==listener)return list.splice(i,1),
!0})))return this
0===list.length&&delete this._events[type]
}else(this._events[type].listener||this._events[type])===listener&&delete this._events[type]
return"removeListener"!=type&&this.emit("removeListener",type,listener),this
},EventEmitter.prototype.off=EventEmitter.prototype.removeListener,
EventEmitter.prototype.removeAllListeners=function(type){
return type&&this._events&&this._events[type]&&(this._events[type]=null),this
},EventEmitter.prototype.listeners=function(type){return this._events||(this._events={}),
this._events[type]||(this._events[type]=[]),
isArray(this._events[type])||(this._events[type]=[this._events[type]]),this._events[type]},
exports.once=function(emitter,...args){return emitter.once(...args)}}))


define("architect/imports",[],(function(require,exports,module){"use strict"
exports.$setImports=function(value){
module.exports=value||null,"undefined"!=typeof define&&define.modules&&(define.modules["architect/imports"]=value||{})
}}))


define("architect/architect",[],(function(require,exports,module){"use strict"
var USE_PROXY="undefined"!=typeof Proxy,LOADING={},EventEmitter=require("events").EventEmitter,{$setImports:setInternalImports}=require("./imports")
function setImports(imports,app){exports.$currentApp=app,setInternalImports(imports)}
function normalizeServiceName(name){
return name.replace(/[._\-]./g,([dot,letter])=>letter.toUpperCase())}
function registerAlias(app,name,newPlugin,replace){var normalizedName=normalizeServiceName(name)
;[name,normalizedName,name.replace(/[.]./g,x=>x[1].toUpperCase()),name.replace(/[._]./g,x=>x[1].toUpperCase()),name.replace(/[a-z\d][A-Z]/g,x=>x[0]+"."+x[1].toLowerCase()),name.replace(/[a-z\d][A-Z]/g,x=>x[0]+"_"+x[1].toLowerCase())].forEach((function(x){
app.$alias[x]=normalizedName,
app.$addServiceName&&(app.$addServiceName(x),app.$addServiceName(x+"Options"))})),
!replace&&app.serviceDefinitions[normalizedName]||(app.serviceDefinitions[normalizedName]=newPlugin)
}setInternalImports(null)
class Architect extends EventEmitter{constructor(config){super()
var app=this
app.config=config,app.serviceToPlugin={},app.serviceDefinitions={},app.$alias={},
app._moduleCache=Object.create(null)
var services=app.services={app:app,hub:app},handler={get:function(target,name){
const dependency=app.getService(name)
if(dependency instanceof Error){
const err=new Error(`Dependency ${name} failed to load:\n${dependency.message}`)
throw err.stack=dependency.stack,err}return dependency}}
USE_PROXY?app.imports=new Proxy(services,handler):(app.imports={},app.$addServiceName=function(name){
app.imports.__defineGetter__(name,(function(){return handler.get(null,name)}))},
Object.keys(services).forEach(app.$addServiceName)),
app.addPlugins(config),services.imports=app.imports}getService(name){
if(this.$alias[name]&&(name=this.$alias[name]),"symbol"==typeof name)return this.services[name]
try{const result=this.services[name]||name in this.serviceDefinitions&&this.$activatePlugin(name)
if(result==LOADING)throw new Error("Dependency cycle detected when loading "+name)
if(!result)throw new Error("Trying to access unknown service "+name)
return result}catch(err){return this.services[name]=err,err}}activate(pluginNames){
var serviceDefinitions=this.serviceDefinitions
pluginNames||(pluginNames=Object.keys(serviceDefinitions))
var errors={}
if(pluginNames.forEach(key=>{const service=this.getService(key)
service instanceof Error&&(errors[key]=service)}),setImports(null),this.emit("ready"),
Object.keys(errors).length>0){
const err=new Error("The following plugins failed to load:\n"+Object.keys(errors).map(key=>key+": "+errors[key].message).reduce((a,b)=>a+"\n"+b))
throw err.errors=errors,err}}$activatePlugin(name){name=normalizeServiceName(name)
var app=this,options=this.serviceDefinitions[name],setup=options.setup
if(!setup&&name.endsWith("Options"))return options
var optionsName=name+"Options"
this.serviceDefinitions[optionsName]&&(options=this.serviceDefinitions[optionsName])
var asyncResult,asyncErr,services=this.services,imports=this.imports
function addDefinition(key){var normalizedName=normalizeServiceName(key)
if(services[normalizedName]&&services[normalizedName]!=LOADING)return console.error(`Plugin ${name} attempted to redefine ${normalizedName}`)
services[normalizedName]=providedServices[key],app.serviceToPlugin[normalizedName]=options,
app.emit("service",normalizedName,providedServices[key])}services[name]=LOADING,
services[optionsName]=options,setImports(imports,this)
var syncResult=setup(options,imports,(function(err,result){
err&&(asyncErr=err),asyncResult=result||{}}))
if(asyncErr)throw asyncErr
var providedServices=asyncResult||syncResult
if(!providedServices)throw new Error(`register for "${name}" was not called.\n            Asynchronous registration of services is deprecated`)
if(providedServices[name]||/^[$_]|^\d+$/.test(name)&&(providedServices[name]={}),
Object.keys(providedServices).forEach(addDefinition),
services[name]==LOADING||!services[name])throw new Error(`${name} not provided by ${setup.packagePath||options.packagePath}`)
return services[name]}addPlugins(newPlugins,options={}){Object.keys(newPlugins||{}).forEach(key=>{
var newPlugin=newPlugins[key]
"function"==typeof newPlugin&&(newPlugin={setup:newPlugin
}),!newPlugin.provides&&newPlugin.setup&&(newPlugin.provides=newPlugin.setup.provides),
"string"==typeof newPlugin.provides&&(newPlugin.provides=[newPlugin.provides]),
newPlugin.provides&&newPlugin.provides.length?newPlugin.provides.forEach(name=>{
registerAlias(this,name,newPlugin,options.replace)
}):registerAlias(this,key,newPlugin,options.replace)})}}function createApp(config,callback){var app
try{app=new Architect(config)}catch(err){return callback(err,app)}return setTimeout((function(){try{
app.activate(),callback(null,app)}catch(err){callback(err,app)}})),app}exports.createApp=createApp,
exports.Architect=Architect,exports.$setImports=setImports}))


define("architect/requirejs-loader",[],(function(require,exports,module){"use strict"
function resolveArrayConfig(config,callback){var packagePaths=config.map((function(plugin){
return"string"==typeof plugin?plugin:plugin.provides&&plugin.packagePath&&!/!/.test(plugin.packagePath)?"architect!"+plugin.packagePath:plugin.packagePath
})).filter((function(path){return!!path})),request=require(packagePaths)
function done(modules){var i=0
callback(null,config.map((function(plugin){
return"string"==typeof plugin?modules[i++]:plugin.packagePath?(plugin.setup=modules[i++],
plugin):plugin})))}request.resolved?done(request.resolved):request.then(done)}
function resolveObjectConfig(config,callback){
var keys=Object.keys(config),packagePaths=keys.map((function(key){var path=config[key]
if("string"==typeof path)return/!/.test(path)?path:"architect!"+path})).filter((function(path){
return!!path})),request=require(packagePaths)
function done(modules){var i=0
keys.forEach((function(key){"string"==typeof config[key]&&(config[key]=modules[i++])})),
callback(null,config)}request.resolved?done(request.resolved):request.then(done)}
exports.resolveConfig=function(config,callback){
return Array.isArray(config)?resolveArrayConfig(config,callback):resolveObjectConfig(config,callback)
}}))


define("@c9/ide/shared_bootstrap",[],(function(require,exports,module){
require("@c9/ide/plugins/c9.core/xss").sanitize
function startArchitectApp(plugins,bootstrapStartTime){
var startingArchitectTime=Date.now(),architect=require("architect"),loader=require("architect/requirejs-loader")
return new Promise((resolve,reject)=>{loader.resolveConfig(plugins,(function(err,config){
if(err)throw err
architect.createApp(config,(err,architectApp)=>{if(onArchitectReady(err,architectApp),
err)return reject(err)
resolve(architectApp)}).on("service",(function(name,plugin,options){plugin.name||(plugin.name=name)
}))}),(function(mod){
const loadErrorMessage="Unable to load html5.js.\n\nThis may be caused by a false positive in your virus scanner. Please try reloading with ?packed=1 added to the URL."
if("@c9/ide/plugins/c9.ide.clipboard/html5"===mod.id)return alert(loadErrorMessage)}))})
function onArchitectReady(err,architectApp){
var architectReadyTime=Date.now(),services=architectApp.services
if(err){const dialogError=services.dialogError
dialogError&&dialogError.show?dialogError.show(err):alert(err)
const logger=services.logger
if(logger&&logger.logUncaughtException){logger.logUncaughtException(err)
for(const plugin of Object.keys(err.errors))logger.logUncaughtException(err.errors[plugin])
}else console.error(err.stack)}services.configure&&(services.configure.services=services),
window.app=services
var c9=services.c9,clientMetrics=services.clientMetrics
services.tabManager.on("tabManagerLoadedState",()=>{
clientMetrics.addValue("architectReadyToTabsLoadedTime",Date.now()-architectReadyTime),
clientMetrics.addValue("bootstrapStartToTabsLoadedTime",Date.now()-bootstrapStartTime)}),c9.ready(),
clientMetrics.addValue("bootstrapStartToStartArchitect",startingArchitectTime-bootstrapStartTime),
clientMetrics.addValue("architectCreateAppTime",architectReadyTime-startingArchitectTime),
c9.totalLoadTime=architectReadyTime-bootstrapStartTime}}
async function renderLoadingScreen(architectReadyPromise,bootstrapStartTime,options={}){
return"loading"===document.readyState&&await new Promise(resolve=>document.addEventListener("DOMContentLoaded",resolve)),
renderLoadingScreenAfterContentLoaded(architectReadyPromise,bootstrapStartTime,options)}
async function renderLoadingScreenAfterContentLoaded(architectReadyPromise,bootstrapStartTime,options={}){
const onLoadingTooLong=options.onLoadingTooLong||function(){}
if(architectReadyPromise.isPending){
const loadingPageHtml='<div id="loadingcontainer" class="">                     <div id="loadingide">                         <div class="timeout">                             This is taking longer than expected. The delay may be caused by high CPU usage in your environment, your T2 or T3 instance might be running out of burstable CPU capacity credits, or there are VPC configuration issues.                             Please check <a href="https://docs.aws.amazon.com/cloud9/latest/user-guide/troubleshooting.html" target="_blank">the troubleshooting documentation</a> for help with these issues.                         </div>                         <div id="dialog-overlay"></div>                         <div id="incompatible-browser-dialog">This version of the browser cannot display the AWS Cloud9 IDE.  Use a different browser instead.  <br /><a href="https://docs.aws.amazon.com/console/cloud9/browsers">Learn more</a></div>                         <div id="loadingideTopMargin"></div>                         <div id="c9logo"></div>                         <div id="loadingideLogoMargin"></div>                         <div id="loadingideSpinnerContainer">                         <div class="loadingide-spinner">                             <svg viewBox="0 0 100 100" xmlns="http://www.w3.org/2000/svg">                                 <circle fill="none" stroke="initial" stroke-width="5" stroke-linecap="round" stroke-dasharray="180" stroke-dashoffset="90" cx="50" cy="50" r="30"></circle>                             </svg>                         </div>                         </div>                         <div id="loadingideSpinnerMargin"></div>                         <div id="loadingideMessageContainer">                             <div class="cool-message"></div>                         </div>                         <div id="loadingideBottomMargin"></div>                         <div class="footer">                            <a href="https://status.aws.amazon.com">Status Page</a>                        </div>                     </div>                 </div>'
options.insertionElementId?document.getElementById(options.insertionElementId).innerHTML=loadingPageHtml:document.body.innerHTML=loadingPageHtml
}
var loadingIde=document.querySelector("#loadingide"),coolMessage=document.querySelector("#loadingide .cool-message")
let loadingTooLongTimeout
function hideLoader(){onLoadingTooLong(architectReadyPromise,!1),clearTimeout(loadingTooLongTimeout)
var loader=document.getElementById("loadingcontainer")
loader&&loader.parentNode.removeChild(loader),loadingIde&&(document.body.className=document.body.className.replace("loading "+loadingIde.className,""))
}coolMessage&&(coolMessage.innerText=options.loadingMessageOverride||getMessage()),
setTimeout((function(){
var s=document.querySelector("#loadingideSpinnerContainer .loadingide-spinner")
s&&(s.style.display="inline-block"),loadingTooLongTimeout=setTimeout((function(){
onLoadingTooLong(architectReadyPromise,!0)
var t=document.querySelector("#loadingide .timeout")
t&&(t.style.display="block")}),6e4)}),2e3)
const architectApp=await architectReadyPromise
var architectReadyTime=Date.now(),services=architectApp.services,settings=services.settings,vfs=services.vfs,clientMetrics=services.clientMetrics
vfs.connected||await vfs.once("connect"),clientMetrics.addValue("architectReadyToVfsConnectTime",Date.now()-architectReadyTime),
await settings.once("initialized")
const layout=services.layout
layout&&!layout.hasTheme&&await layout.once("eachTheme"),clientMetrics.addValue("bootstrapStartToHideLoaderTime",Date.now()-bootstrapStartTime),
clientMetrics.addValue("architectReadyToHideLoaderTime",Date.now()-architectReadyTime),hideLoader()}
function getMessage(){
var isMac=/Mac(Intel|intosh|PPC)/.test(navigator.platform),messages=["Use the Collaborate panel when collaborating for optimal teamwork.","Happy coding!","Everything as you left it.","Thank you Ada Lovelace!","POST /desktop/era","Try using VIM mode!","Press "+(isMac?"Ctrl-Option-Right":"Ctrl-Alt-Right")+" to select the next instance of a word.","Press "+(isMac?"Cmd-.":"Ctrl-.")+" to show all keyboard commands.","To rename a variable, highlight it then press "+(isMac?"Option-Cmd-R":" Ctrl-Alt-R")+".","Press "+(isMac?"Option-W":"Alt-W")+" to close your current IDE tab.","Press "+(isMac?"Cmd-D":"Ctrl-D")+" to delete the current line of code","Press "+(isMac?"Option-Tab":"Alt-`")+" to go to the next IDE tab.","Press "+(isMac?"Option-Shift-T":"Alt-Shift-T")+" to reopen a tab you closed.","Press "+(isMac?"Option-T":"Alt-T")+" to open a new terminal at any time.","Press "+(isMac?"Cmd-E":"Ctrl-E")+" to search for a file by name.","Press "+(isMac?"Cmd-Shift-E":"Ctrl-Shift-E")+" to search for a function by name.","Press "+(isMac?"Option-S":"Alt-S")+" to switch between a terminal and an editor."],idx=Math.floor(Math.random()*messages.length)
return idx==messages.length&&(idx=messages.length-1),messages[idx]}
exports.startCloud9=async function(getPlugins,bootstrapStartTime,options){
const architectAppPromise=new Promise((resolve,reject)=>{setTimeout(async()=>{
startArchitectApp(await getPlugins(architectAppPromise),bootstrapStartTime).then(result=>{
architectAppPromise.isPending=!1,resolve(result)},err=>{architectAppPromise.isPending=!1,reject(err)
})})})
architectAppPromise.isPending=!0
const ideShownPromise=renderLoadingScreen(architectAppPromise,bootstrapStartTime,options)
architectAppPromise.then(async architectApp=>{
const services=architectApp.services,tabManager=services.tabManager,clientMetrics=services.clientMetrics
await tabManager.once("tabManagerLoadedState"),await ideShownPromise
const bootstrapStartToCloud9Ready=Date.now()-bootstrapStartTime
clientMetrics.addValue("bootstrapStartToCloud9Ready",bootstrapStartToCloud9Ready)
const localStorage=services.webStorage.localStorage
await localStorage.getItem("IDE_TEST_RUN")?clientMetrics.addValue("bootstrapStartToCloud9Ready_Test",bootstrapStartToCloud9Ready):clientMetrics.addValue("bootstrapStartToCloud9Ready_Cust",bootstrapStartToCloud9Ready)
})}}))


define("@amzn/cloud9-ide-client/bootstrap/wms-client",[],(function(require,exports,module){
"use strict"
Object.defineProperty(exports,"__esModule",{value:!0})
const tangerine_box_adapter_1=require("../plugins/c9.ide.aws/tangerine-box-adapter")
function reportError(error,eventTracker,errorCode){
const transientErrorNames=["CredentialsError","RequestAbortedError"],errorType=["Network Failure","Missing credentials in config, if using AWS_CONFIG_FILE, set AWS_SDK_LOAD_CONFIG=1","Request aborted"].includes(error.message)||transientErrorNames.includes(error.name)?tangerine_box_adapter_1.ErrorType.ClientTransientError:tangerine_box_adapter_1.ErrorType.ClientUnavailable
eventTracker.addError({errorType:errorType,message:error.message,statusCode:errorCode})}
exports.reportError=reportError
class WmsClient{constructor(cloud9,stage,window,eventTracker){this.cloud9=cloud9,this.stage=stage,
this.window=window,this.eventTracker=eventTracker}
async getEnvironmentConfig(environmentId,bundleConfigId){var params={environmentId:environmentId}
bundleConfigId&&(params.bundleConfigId=bundleConfigId)
try{let result=await this.cloud9.getEnvironmentConfig(params).promise()
const getResponseError=msg=>{let err=new Error(msg)
return err.details=`Error for environment "${JSON.stringify(params)}": ${JSON.stringify(result)}`,
err}
if(!result||!result.config)throw getResponseError("API returned no environment config")
let environmentSettings
try{environmentSettings=JSON.parse(result.config)}catch(e){
throw getResponseError("API returned unexpected environment config")}return environmentSettings
}catch(err){(this.isDev()||this.isPreProd())&&console.error("Retrieve settings failed",err),
this.showErrorPage(err)}}isPreProd(){return"alpha"===this.stage||"beta"===this.stage}isDev(){
return["dev","Devo"].includes(this.stage)}reportMetrics(errorCode,error){
errorCode>499&&errorCode<=599&&reportError(error,this.eventTracker,errorCode)}showErrorPage(err){
var errorPageRootPath="/cloud9/home/",errorCode=err.statusCode||500,message=err.message||err.Message
if("NotFoundException"===err.name)errorCode=404
else if("AccessDeniedException"==err.name){
var userMatch=null==message?void 0:message.match(/arn:(aws|aws-cn|aws-us-gov|aws-iso|aws-iso-b):iam[^\s]*/)
message="User "+(userMatch?userMatch[0]:"")+" is not authorized to open this environment. Either the environment doesn't exist or the user is not a member of this environment."
}else"InternalFailure"===err.name?message=message||"Internal error in frontend proxy when opening environment":500===err.statusCode&&(message=message||"Internal error when opening environment")
this.reportMetrics(errorCode,err)
var url=errorPageRootPath+errorCode
message&&(url+="?message="+encodeURIComponent(message)),url&&(this.window.location.href=`${this.window.location.origin}${url}`)
}}exports.WmsClient=WmsClient}))


define("@amzn/cloud9-ide-client/bootstrap/nudge-allowlist",[],(function(require,exports,module){
"use strict"
Object.defineProperty(exports,"__esModule",{value:!0
}),exports.nudgeAllowlist=["473251255977","874642829988","371624305120","477414045963","951106794404","678116416646","318505654355","662869613975","896808033398","681603336916","366290493599","236002310118","314841138918","448223805965","265090179595","294898876855","532807461236","516690746032","476930979649","325428640083","436887141764","349517811744","189681391221","145085003454","799957521807","922327013870","474564287106","488247187723","261145902803","197726957049","555744174482","417498243647","462749695536","479390909666","764316345875","274694861127","587327736308","520163564823","702660373025","216347824205","638669179137","190664880089","284940736918","554435723203","493889021975","647747141963","862853072529","161304460550","622535914080","647518263045","516466982865","806123903233","957738166108","658980951053","588076294860","536848574488","060783421142","679375177819","318255694512","978604484805","615536668238","468839207449","541201481031","098801293207","208255907945","481011272543","091816578861","794366244892","342492324002","027088383656","551864160457","375748333999","594258283655","753836097776","409303902518","525387407571","653947136491","452196003503","395504764229","694012723545","251446768763","531940875336","289523893457","180488266157","436368895137","837314532250","362421521088","975758842837","619691854496","902331994444","053189750232","287130999306","003383845545","113128249270","060015299220","025653874906","290260404533","406184667328","978226959142","255602312584","895156080840","843365102939","504021508359","962977813371","266800770941","621780190064","456325443044","410736792317"]
}))


define("@amzn/cloud9-ide-client/bootstrap/bootstrap",[],(function(require,exports,module){
"use strict"
Object.defineProperty(exports,"__esModule",{value:!0})
const shared_bootstrap_1=require("@c9/ide/shared_bootstrap"),tangerine_box_adapter_1=require("../plugins/c9.ide.aws/tangerine-box-adapter"),wms_client_1=require("./wms-client"),nudge_allowlist_1=require("./nudge-allowlist")
async function loadAppConfigAndStartApp(environmentData,cloud9Client,eventTracker,urlParameters,bootstrapStartTime,packed){
async function getPlugins(architectAppPromise){
const startingApplicationTime=Date.now(),wmsConfigLoadingPromise=new wms_client_1.WmsClient(cloud9Client,environmentData.stage,window,eventTracker).getEnvironmentConfig(urlParameters.environmentId,urlParameters.bundleConfigId).then(wmsConfig=>({
wmsConfig:wmsConfig,settingsLoadingTime:Date.now()-startingApplicationTime
})),defaultBundlePath=getDefaultBundlePath(urlParameters.staticPrefix,urlParameters.buildPrefix,packed),defaultBundleLoadingTimePromise=require([defaultBundlePath]).then(_=>Date.now()-startingApplicationTime),[{wmsConfig:wmsConfig,settingsLoadingTime:settingsLoadingTime},defaultBundleLoadingTime]=await Promise.all([wmsConfigLoadingPromise,defaultBundleLoadingTimePromise]),settings=extendWmsConfigWithAdditionalSettings(wmsConfig,environmentData,urlParameters,bootstrapStartTime,packed),[architectPluginsConfig]=await require(["@amzn/cloud9-ide-client/configs/ide/"+settings.configName])
var plugins=window.plugins=architectPluginsConfig(settings)
return architectAppPromise.then(architectApp=>{eventTracker.addEvent({
eventType:tangerine_box_adapter_1.EventType.ClientAvailable
}),sendLoadingTimeMetrics(architectApp.services.clientMetrics,defaultBundleLoadingTime,settingsLoadingTime)
},err=>{wms_client_1.reportError(err,eventTracker)}).finally(()=>{
submitCustomerReadyMetric(eventTracker)}),plugins}preconfigureConsolePage(environmentData.region),
await shared_bootstrap_1.startCloud9(getPlugins,bootstrapStartTime,Object.assign(Object.assign({},getBootstrapOptions()),{
insertionElementId:"app"}))}function preconfigureConsolePage(region){
setCurrentRegionMezzanine(region),handleMezzanine()}
function sendLoadingTimeMetrics(clientMetricsService,defaultBundleLoadingTime,settingsLoadingTime){
clientMetricsService.addValue("defaultBundleLoadingTime",defaultBundleLoadingTime),
clientMetricsService.addValue("settingsLoadingTime",settingsLoadingTime)}
function getBootstrapOptions(){var loadingMessageOverride
return~location.hash.indexOf("create")&&(loadingMessageOverride="Creating Your New Development Environment",
location.hash=location.hash.replace(/&?create/,"")),{loadingMessageOverride:loadingMessageOverride,
onLoadingTooLong(architectAppPromise,wasTooLong){architectAppPromise.then(architectApp=>{
architectApp.services.clientMetrics.addValue("ideLoadingTooLong",wasTooLong?1:0)})}}}
function getDefaultBundlePath(staticPrefix,buildPrefix,packed){
var defaultBundle="@amzn/cloud9-ide-client/configs/ide/default"
return packed?staticPrefix+buildPrefix+"configs/ide/"+defaultBundle:defaultBundle}
function extendWmsConfigWithAdditionalSettings(wmsConfig,environmentData,urlParameters,bootstrapStartTime,packed){
"1"==urlParameters.collab?wmsConfig.collab=!0:"0"==urlParameters.collab&&(wmsConfig.collab=!1)
const regionOverride=isPreProd(environmentData.stage)&&urlParameters.region
regionOverride&&(wmsConfig.region=regionOverride)
const configName="environment-default"==wmsConfig.configName?"default":wmsConfig.configName,themeConfig=environmentData.region?"default":configName,themePrefix=`${urlParameters.staticPrefix+urlParameters.buildPrefix}skin/@amzn/cloud9-ide-client/configs/ide/${themeConfig}`,noTracking=urlParameters.noTracking,accountId=urlParameters.accountId,toolkitSettings=getToolkitSettings(wmsConfig),addedSettings={
startLoadTime:bootstrapStartTime,packed:packed,noTracking:noTracking,themePrefix:themePrefix,
vfsBaseUrl:environmentData.vfsBaseUrlOverride||wmsConfig.vfsBaseUrl,
vfsConsoleUrl:environmentData.vfsConsoleUrlOverride||wmsConfig.vfsConsoleUrl,configName:configName,
enableExtensions:!0,enableGitExtension:!0,enableJavaExtension:!0,enableJavaDebugExtension:!0,
webviewAssetsAuthority:environmentData.webviewAssetsAuthority,
dependenciesBucketName:environmentData.dependenciesBucketName,enableToolkit:!0,toolkitReleased:!0,
extendFileWatchingDepth:!0,defaultToolkitSetting:!0,
isSSHEnvironment:toolkitSettings.isSSHEnvironment,stage:environmentData.stage,
isPreProd:isPreProd(environmentData.stage),isDev:isDev(environmentData.stage),
isProd:!isPreProd(environmentData.stage)&&!isDev(environmentData.stage),
environmentId:urlParameters.environmentId,awsRegion:environmentData.region,
ideAssetsVersion:environmentData.ideAssetsVersion,
ideAssetsBucketName:environmentData.ideAssetsBucketName,
useOriginAccount:environmentData.useOriginAccount,
cloud9ApiEndpoint:environmentData.cloud9ApiEndpoint,accountId:accountId,
buildInfo:environmentData.buildInfo,nudge:enableNudgePlugin(environmentData,accountId),
nudgeCodeCatalyst:!0,deprecation:!0}
return Object.assign(wmsConfig,addedSettings)}function enableNudgePlugin(environmentData,accountId){
const stage=environmentData.stage,region=environmentData.region,isProdPDX=!isDev(stage)&&!isPreProd(stage)&&"us-west-2"===region
return isDev(stage)||isPreProd(stage)||isProdPDX||nudge_allowlist_1.nudgeAllowlist.includes(accountId)
}function getToolkitSettings(settings){let isSSHEnvironment=!1
try{isSSHEnvironment="ssh"===settings.project.type}catch(e){}return{
isSSHEnvironment:isSSHEnvironment}}function handleMezzanine(){if(window.AWSC){
var linkDocs=Array.prototype.slice.call(document.getElementsByTagName("link"))
;(linkDocs=linkDocs.filter((function(doc){return doc.href.indexOf("c9.ide")<0
}))).forEach((function(doc){doc.parentElement.removeChild(doc)}))
const header=document.getElementById("consoleNavHeader")
header&&(header.style.display="none")
const footer=document.getElementById("console-nav-footer")
footer&&(footer.style.display="none")}}function setCurrentRegionMezzanine(region){
window.ConsoleNavService&&window.ConsoleNavService.Model&&!window.ConsoleNavService.Model.currentRegionId&&(window.ConsoleNavService.Model.currentRegionId=region)
}function isPreProd(stage){return isAlpha(stage)||isBeta(stage)}function isAlpha(stage){
return"alpha"===stage}function isBeta(stage){return"beta"===stage}function isDev(stage){
return["dev","Devo"].includes(stage)}async function submitCustomerReadyMetric(eventTracker){var _a
try{
if(performance.measure("customerReady"),!(null===(_a=null===window||void 0===window?void 0:window.AWSC)||void 0===_a?void 0:_a.Timer))return void eventTracker.addError({
error:"Unable to emit customerReady metric",level:"error"})
window.AWSC.Timer.customerReady()}catch(_){}}
exports.loadAppConfigAndStartApp=loadAppConfigAndStartApp}))


define("@amzn/cloud9-ide-client/bootstrap/index.js",[],(function(require,exports,module){
"use strict"
Object.defineProperty(exports,"__esModule",{value:!0}),require("./configure-requirejs")
const tangerine_box_adapter_1=require("../plugins/c9.ide.aws/tangerine-box-adapter"),awscloud9_awsjava_script_sdkbundle_1=require("@amzn/awscloud9-awsjava-script-sdkbundle"),bootstrap_1=require("./bootstrap")
var bootstrapStartTime=Date.now()
async function retrieveUrlParameters(tb){
var me=document.querySelector("script[src*='bootstrap.js']"),url=new URL(window.location.href)
return{staticPrefix:me.src.split("/bootstrap.js")[0],
buildPrefix:"1"===url.searchParams.get("debug")?"/nc-build/":"/build/",
bundleConfigId:url.searchParams.get("bundleConfigId"),collab:url.searchParams.get("collab"),
region:url.searchParams.get("region"),noTracking:url.searchParams.get("noTracking"),
accountId:await tb.getAccountId(),environmentId:url.pathname.split("/").pop()}}
function reportCSPViolations(tb){window.addEventListener("securitypolicyviolation",e=>{
const c9origin=new URL(document.querySelector("script[src*='bootstrap.js']").src).origin
if(e.sourceFile.includes(c9origin)){if("blob"===e.blockedURI)return
tb.getEventTracker().addError({errorType:tangerine_box_adapter_1.ErrorType.CspViolationError,
blockedURI:e.blockedURI,violatedDirective:e.violatedDirective,
effectiveDirective:e.effectiveDirective,sourceFile:e.sourceFile,lineNumber:e.lineNumber,
columnNumber:e.columnNumber})}})}async function startBootstrap(){
const packed=!!document.currentScript,tb=new tangerine_box_adapter_1.TangerineBoxAdapter
reportCSPViolations(tb)
const environmentData=tb.getCustomContextParameters(),cloud9Client=getCloud9Client(environmentData.region,environmentData.cloud9ApiEndpoint,tb),eventTracker=tb.getEventTracker(),urlParameters=await retrieveUrlParameters(tb)
bootstrap_1.loadAppConfigAndStartApp(environmentData,cloud9Client,eventTracker,urlParameters,bootstrapStartTime,packed)
}function getCloud9Client(region,endpoint,tb){
const cloud9Client=new awscloud9_awsjava_script_sdkbundle_1.Cloud9({credentials:tb.getCredentials(),
region:region,endpoint:endpoint,correctClockSkew:!0})
return tb.emitSdkMetrics(cloud9Client),cloud9Client}startBootstrap()}))


define("ace-code",[],(function(){return require("ace-code/src/ace")
})),define("@c9/aceterm",[],(function(){return require("@c9/aceterm/src/aceterm")})),
define("tern",[],(function(){return require("tern/lib/tern")})),define("base64-js",[],(function(){
return require("base64-js/index")})),define("jsonm",[],(function(){
return require("jsonm/build/node/index")})),define("js-beautify",[],(function(){
return require("js-beautify/js/index")})),define("source-map",[],(function(){
return require("source-map/lib/source-map")})),define("lodash",[],(function(){
return require("lodash/lodash")})),define("lodash.isequal",[],(function(){
return require("lodash.isequal/index")})),define("@c9/msgpack-js",[],(function(){
return require("@c9/msgpack-js/msgpack")})),define("@c9/smith",[],(function(){
return require("@c9/smith/smith")})),define("@c9/kaefer",[],(function(){
return require("@c9/kaefer/index")})),define("@c9/vscode-source",[],(function(){
return require("@c9/vscode-source/out/main")})),define("engine.io-client",[],(function(){
return require("engine.io-client/index")})),define("secure-json-parse",[],(function(){
return require("secure-json-parse/index")})),define("vscode-uri",[],(function(){
return require("vscode-uri/lib/umd/index")})),define("vscode-languageserver-types",[],(function(){
return require("vscode-languageserver-types/lib/umd/main")})),define("architect",[],(function(){
return require("architect/architect")})),define("cloudformation-schema-js-yaml",[],(function(){
return require("cloudformation-schema-js-yaml/index")})),define("js-yaml",[],(function(){
return require("js-yaml/index")})),define("xss",[],(function(){return require("xss/lib/index")})),
define("cssfilter",[],(function(){return require("cssfilter/lib/index")
})),define("mocha",[],(function(){return require("mocha/index")})),define("chai",[],(function(){
return require("chai/index")})),define("js-polyfills",[],(function(){
return require("js-polyfills/polyfill")})),define("@mixer/postmessage-rpc",[],(function(){
return require("@mixer/postmessage-rpc/dist/rpc")})),define("debug-browser",[],(function(){
return require("debug-browser/dist/index")})),define("eventemitter3",[],(function(){
return require("eventemitter3/index")})),define("esprima",[],(function(){
return require("esprima/dist/esprima")})),define("buffer",[],(function(){
return require("buffer/index")})),define("@amzn/awscloud9-awsjava-script-sdkbundle",[],(function(){
return require("@amzn/awscloud9-awsjava-script-sdkbundle/dist/aws-sdk-bundle")})),
define("@amzn/aws-china-rebrand-utils",[],(function(){
return require("@amzn/aws-china-rebrand-utils/dist/index")})),define("iam-js-sdk",[],(function(){
return require("iam-js-sdk/dist/index")})),define("tangerinebox-weblib-bundle",[],(function(){
return require("tangerinebox-weblib-bundle/dist/index")}))


require("@amzn/cloud9-ide-client/bootstrap/index.js")

